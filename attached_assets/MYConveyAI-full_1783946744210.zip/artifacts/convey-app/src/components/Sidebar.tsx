import React from 'react';
import { Scale, LogOut, Menu } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { NAV_MENU } from '@/lib/data';

export function Sidebar({ mobileOpen, setMobileOpen }: { mobileOpen: boolean, setMobileOpen: (v: boolean) => void }) {
  const { activeSection, setActiveSection, setIsAuthenticated } = useApp();

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 bg-gold-950/80 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside className={`fixed md:static inset-y-0 left-0 z-50 w-72 bg-gold-950 border-r border-gold-800 transform transition-transform duration-300 ease-in-out flex flex-col ${
        mobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
      }`}>
        
        {/* Brand Header */}
        <div className="h-20 flex items-center px-6 border-b border-gold-800 shrink-0">
          <Scale className="w-8 h-8 text-amber-500 mr-3" />
          <span className="font-serif font-bold text-xl text-slate-50 tracking-wide">
            MYConvey<span className="text-amber-500">AI</span>
          </span>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 ml-2 mt-2">Curriculum</div>
          {NAV_MENU.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveSection(item.id);
                  setMobileOpen(false);
                }}
                className={`w-full text-left px-4 py-3.5 rounded-xl text-sm font-medium transition-all flex items-center group ${
                  isActive 
                    ? 'bg-amber-500/10 text-amber-500 shadow-sm border border-amber-500/20' 
                    : 'text-slate-400 hover:bg-gold-900 hover:text-slate-200 border border-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 mr-3 transition-colors ${isActive ? 'text-amber-500' : 'text-slate-500 group-hover:text-slate-300'}`} />
                {item.title}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-gold-800 shrink-0">
          <div className="bg-gold-900 rounded-xl p-4 border border-gold-800 mb-4">
            <p className="text-xs text-slate-400 mb-1">Instructor</p>
            <p className="text-sm font-bold text-slate-200 truncate">Dr Shahrul Mizan</p>
            <p className="text-xs text-amber-500 font-mono mt-1">UKM Law Faculty</p>
          </div>
          
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors border border-transparent hover:border-rose-500/20"
          >
            <LogOut className="w-4 h-4" />
            End Session
          </button>
        </div>
      </aside>
    </>
  );
}
