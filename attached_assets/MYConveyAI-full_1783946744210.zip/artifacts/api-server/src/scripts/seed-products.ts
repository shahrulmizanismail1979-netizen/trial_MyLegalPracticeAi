/**
 * Create the MYConveyAI subscription products and prices in Stripe.
 *
 * Idempotent — safe to run repeatedly. Each (tier, interval) gets one price with
 * `currency_options` covering every supported currency, identified by a stable
 * `lookup_key` (e.g. `student_month`) that the checkout route resolves at runtime.
 *
 * Run with:  pnpm --filter @workspace/api-server run seed-products
 */
import type Stripe from "stripe";
import { getUncachableStripeClient } from "../lib/stripeClient";
import { PLANS, CURRENCIES, type Currency, type Interval } from "../lib/access";

const BASE_CURRENCY: Currency = "myr";

async function findOrCreateProduct(
  stripe: Stripe,
  tier: keyof typeof PLANS,
): Promise<string> {
  const plan = PLANS[tier];
  const name = `MYConveyAI ${plan.name}`;
  const existing = await stripe.products.search({
    query: `name:'${name}' AND active:'true'`,
  });
  if (existing.data[0]) {
    console.log(`✓ Product exists: ${name} (${existing.data[0].id})`);
    return existing.data[0].id;
  }
  const product = await stripe.products.create({
    name,
    description: plan.tagline,
    metadata: { tier: plan.id },
  });
  console.log(`+ Created product: ${name} (${product.id})`);
  return product.id;
}

async function ensurePrice(
  stripe: Stripe,
  productId: string,
  tier: keyof typeof PLANS,
  interval: Interval,
): Promise<void> {
  const plan = PLANS[tier];
  const lookupKey = `${tier}_${interval}`;

  const existing = await stripe.prices.list({
    lookup_keys: [lookupKey],
    active: true,
    limit: 1,
  });
  if (existing.data[0]) {
    console.log(`  ✓ Price exists: ${lookupKey} (${existing.data[0].id})`);
    return;
  }

  const currencyOptions: Stripe.PriceCreateParams.CurrencyOptions = {};
  for (const c of CURRENCIES) {
    if (c === BASE_CURRENCY) continue;
    currencyOptions[c] = { unit_amount: plan.prices[interval][c] };
  }

  const price = await stripe.prices.create({
    product: productId,
    currency: BASE_CURRENCY,
    unit_amount: plan.prices[interval][BASE_CURRENCY],
    recurring: { interval },
    lookup_key: lookupKey,
    transfer_lookup_key: true,
    currency_options: currencyOptions,
    metadata: { tier: plan.id, interval },
  });
  console.log(`  + Created price: ${lookupKey} (${price.id})`);
}

async function main() {
  const stripe = await getUncachableStripeClient();
  console.log("Seeding MYConveyAI products & prices...\n");

  for (const tier of Object.keys(PLANS) as Array<keyof typeof PLANS>) {
    const productId = await findOrCreateProduct(stripe, tier);
    for (const interval of ["month", "year"] as Interval[]) {
      await ensurePrice(stripe, productId, tier, interval);
    }
  }

  console.log("\n✓ Done. Webhooks will sync this data into the local stripe schema.");
}

main().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
