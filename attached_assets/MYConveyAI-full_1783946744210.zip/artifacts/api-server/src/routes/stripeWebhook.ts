import type { Request, Response } from "express";
import type Stripe from "stripe";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { getStripeSync } from "../lib/stripeClient";
import type { Tier } from "../lib/access";

function tierFromMetadata(meta: Stripe.Metadata | null | undefined): Tier | null {
  const t = meta?.tier;
  if (t === "student" || t === "practitioner" || t === "firm") return t;
  return null;
}

/** Mirror a subscription's state onto our users table for fast authorization. */
async function reconcileSubscription(sub: Stripe.Subscription) {
  const customerId = typeof sub.customer === "string" ? sub.customer : sub.customer.id;
  const tier = tierFromMetadata(sub.metadata);
  const periodEnd = (sub as unknown as { current_period_end?: number }).current_period_end;

  const update: Partial<typeof usersTable.$inferInsert> = {
    subscriptionStatus: sub.status,
    stripeSubscriptionId: sub.id,
    stripeCustomerId: customerId,
  };
  if (tier) update.subscriptionTier = tier;
  if (typeof periodEnd === "number") update.currentPeriodEnd = new Date(periodEnd * 1000);

  const metaUserId = sub.metadata?.userId ? Number(sub.metadata.userId) : null;
  if (metaUserId && Number.isFinite(metaUserId)) {
    await db.update(usersTable).set(update).where(eq(usersTable.id, metaUserId));
  } else {
    await db.update(usersTable).set(update).where(eq(usersTable.stripeCustomerId, customerId));
  }
}

export async function stripeWebhookHandler(req: Request, res: Response) {
  const signature = req.headers["stripe-signature"];
  if (!signature || !Buffer.isBuffer(req.body)) {
    res.status(400).json({ error: "Invalid webhook request" });
    return;
  }
  const sig = Array.isArray(signature) ? signature[0]! : signature;

  let sync;
  try {
    sync = await getStripeSync();
  } catch (e) {
    req.log?.error({ err: e }, "Stripe not configured for webhook");
    res.status(503).json({ error: "Stripe not configured" });
    return;
  }

  // processWebhook verifies the signature and syncs the event into the
  // `stripe` schema. If it throws, the payload is not authentic.
  try {
    await sync.processWebhook(req.body as Buffer, sig);
  } catch (e) {
    req.log?.error({ err: e }, "Stripe webhook verification/sync failed");
    res.status(400).json({ error: "Invalid webhook" });
    return;
  }

  // Signature verified — safe to parse the body and reconcile our user records.
  try {
    const event = JSON.parse((req.body as Buffer).toString("utf8")) as Stripe.Event;
    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        await reconcileSubscription(event.data.object as Stripe.Subscription);
        break;
      }
      default:
        break;
    }
  } catch (e) {
    // Schema sync already succeeded; a reconcile error must not 500 the webhook
    // (Stripe would retry indefinitely). Log and acknowledge.
    req.log?.error({ err: e }, "Stripe webhook user reconcile failed");
  }

  res.json({ received: true });
}
