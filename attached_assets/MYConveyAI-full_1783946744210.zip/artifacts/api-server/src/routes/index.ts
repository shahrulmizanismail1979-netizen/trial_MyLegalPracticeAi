import { Router, type IRouter } from "express";
import healthRouter from "./health";
import conveyRouter from "./convey";
import adminRouter from "./admin";
import subscriptionRouter from "./subscription";

const router: IRouter = Router();

router.use(healthRouter);
router.use(conveyRouter);
router.use(subscriptionRouter);
router.use(adminRouter);

export default router;
