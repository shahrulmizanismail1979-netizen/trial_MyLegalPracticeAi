import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { attachUser } from "./middleware/auth";
import { stripeWebhookHandler } from "./routes/stripeWebhook";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());

// Stripe webhook needs the raw request body for signature verification, so it
// must be mounted BEFORE the JSON body parser.
app.post(
  "/api/convey/stripe-webhook",
  express.raw({ type: "application/json" }),
  stripeWebhookHandler,
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Parse the Bearer token (if any) and attach the live user record to req.
app.use(attachUser);

app.use("/api", router);

export default app;
