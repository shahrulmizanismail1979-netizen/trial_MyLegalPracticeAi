// Stripe client backed by the Replit Stripe connector.
// The connector securely stores the Stripe credentials at the account level; we
// fetch them fresh on every call (tokens/keys can rotate) and never cache the
// client. See the Replit Stripe integration / `stripe` skill.
import Stripe from "stripe";
import type { StripeSync } from "stripe-replit-sync";

interface ConnectorSettings {
  secret?: string;
  publishable?: string;
  webhook_secret?: string;
  webhook_url?: string;
  [k: string]: unknown;
}

async function getStripeCredentials(): Promise<{
  secretKey: string;
  publishableKey?: string;
  webhookSecret?: string;
}> {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? "repl " + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
      ? "depl " + process.env.WEB_REPL_RENEWAL
      : null;

  if (!hostname || !xReplitToken) {
    throw new Error(
      "Missing Replit connector environment. Connect Stripe via the Integrations tab.",
    );
  }

  const isProduction = process.env.REPLIT_DEPLOYMENT === "1";
  const targetEnvironment = isProduction ? "production" : "development";

  const url = new URL(`https://${hostname}/api/v2/connection`);
  url.searchParams.set("include_secrets", "true");
  url.searchParams.set("connector_names", "stripe");
  url.searchParams.set("environment", targetEnvironment);

  const res = await fetch(url.toString(), {
    headers: { Accept: "application/json", X_REPLIT_TOKEN: xReplitToken },
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch Stripe connection: ${res.status}`);
  }

  const data = (await res.json()) as {
    items?: Array<{ settings?: ConnectorSettings }>;
  };
  const settings = data.items?.[0]?.settings;
  if (!settings?.secret || !settings?.publishable) {
    throw new Error(`Stripe ${targetEnvironment} connection not found`);
  }

  return {
    secretKey: settings.secret,
    publishableKey: settings.publishable,
    webhookSecret: settings.webhook_secret,
  };
}

/**
 * Returns a fresh authenticated Stripe client.
 * WARNING: never cache this — credentials can rotate. Call again each time.
 */
export async function getUncachableStripeClient(): Promise<Stripe> {
  const { secretKey } = await getStripeCredentials();
  // Latest pinned API version — do not downgrade.
  return new Stripe(secretKey, { apiVersion: "2025-08-27.basil" });
}

/** Publishable key for any client-side Stripe.js usage. */
export async function getStripePublishableKey(): Promise<string> {
  const { publishableKey } = await getStripeCredentials();
  if (!publishableKey) throw new Error("No Stripe publishable key configured.");
  return publishableKey;
}

/**
 * Returns a StripeSync instance for managed webhooks + database sync.
 * Not cached — fetches fresh credentials so rotated keys are picked up.
 */
export async function getStripeSync(): Promise<StripeSync> {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error("DATABASE_URL is required for Stripe sync.");
  }
  const { secretKey, webhookSecret } = await getStripeCredentials();
  const { StripeSync } = await import("stripe-replit-sync");
  return new StripeSync({
    poolConfig: { connectionString: databaseUrl, max: 2 },
    stripeSecretKey: secretKey,
    stripeWebhookSecret: webhookSecret ?? "",
  });
}
