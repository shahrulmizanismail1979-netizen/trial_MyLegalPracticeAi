# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.
This project is a Malaysian Conveyancing Legal Practice learning platform called MYConveyAI.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **AI**: Gemini via Replit AI Integrations (`@workspace/integrations-gemini-ai`)
- **Auth**: bcryptjs (pure JS) for password hashing

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── convey-app/         # React + Vite frontend (Malaysian Conveyancing App)
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   ├── db/                 # Drizzle ORM schema + DB connection
│   └── integrations-gemini-ai/  # Gemini AI integration
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Application: MYConveyAI

A legal education platform for Malaysian Conveyancing Law by Prof Madya Dr Shahrul Mizan Ismail, Fakulti Undang-Undang, UKM.

### Theme
- **Dark Gold** theme with amber accents
- Custom CSS variables: `--color-gold-950` through `--color-gold-400` defined in `index.css`
- Background: deep charcoal-gold tones; accent: amber-500

### Authentication
- **Dual login** (restored after a production data-loss incident):
  1. **Legacy accounts (email + password)** — the original ~107 student accounts authenticate with their **email** (stored in the `username` column) + bcrypt `password_hash`. Username match is case-insensitive. This path was restored so pre-existing users are not locked out.
  2. **Access code** — new accounts / master / admin log in with a unique **access code**.
- `/convey/auth` accepts EITHER `{username,password}` OR `{accessCode}`; the Login page has an "Email & Password" tab (default) and an "Access Code" tab.
- **`access_code` is NULLABLE** in the schema/DB on purpose — adding it as NOT NULL to a populated table is what wiped prod before. Codes are backfilled at startup; legacy users can ignore their code and use email+password.
- On startup `backfillLegacyAccounts()` grandfathers every account with a `password_hash` (free Firm tier) and mirrors `email = username` where missing.
- Access code format: `MYCV-XXXX-XXXX-XXXX` (alphabet `ABCDEFGHJKLMNPQRSTUVWXYZ23456789`, CSPRNG via `randomBytes`, uniqueness pre-checked). Generated in `artifacts/api-server/src/lib/access.ts`.
- Login normalizes input with `trim().toUpperCase()` (so lowercase entry works).
- **Email** captured at signup for billing/receipts (Stripe customer); optional, never used to log in.
- **Master override code `240680`** — logging in with this unlocks EVERYTHING (Firm tier) for free, forever, with no payment. Backed by a permanent master account (`displayName: "Master Access"`, role admin, grandfathered, firm tier) re-asserted on every startup via `ensureMasterUser()`. Overridable with the `MASTER_ACCESS_CODE` env var.
- Default admin seeded on startup with access code `MYCV-ADMIN-2024` (firm tier, grandfathered). `username`/`passwordHash` columns are retained but **nullable** and no longer used to authenticate.
- `backfillAccessCodes()` runs at startup to assign codes to any legacy rows missing one.
- **Access code is the sole credential — treat like a password.** It is returned ONLY by `/convey/signup`, admin create-user, and admin regenerate-code (shown once). It is NOT returned by `/convey/auth` or `/convey/me`, and is **stripped before persisting** `convey_user` to localStorage (see `AppContext`).
- Auth/me return: `{ id, displayName, role, email, tier, grandfathered, subscriptionStatus, currentPeriodEnd }` (no accessCode, no username).
- Session is a JWT `token` (localStorage `convey_token`); `logout()` clears `convey_auth`, `convey_user`, `convey_token`.
- Forgot the code? No self-recovery — an admin regenerates it (which invalidates the old one).
- Roles: `admin` and `user`. Admin dashboard auth is **separate** (`ADMIN_PASSWORD` env), unaffected by the access-code system.

### Features
- **Landing page** at `/` with title, author, and institution
- **Login page** at `/login` with a single access-code field; **Signup page** at `/signup` (email + display name) shows the generated access code once with copy-to-clipboard
- **6 educational sections** in a sidebar layout:
  1. Part 1: Substantive Law (21 theory topics)
  2. Part 2: Conveyancing Workflows (62 workflows)
  3. Part 3: Forms & Drafting (24 form templates & precedents — incl. sub-sale SPA, deed of assignment, tenancy, facility agreement, letter of offer, statutory declaration, notice of assignment, vacant possession notice)
  4. Part 4: Leading Cases (100 landmark Malaysian cases)
  5. Costs & Fees (practitioner calculator: purchaser MOT/loan stamp duty with i-MILIKI first-home exemption, SRO 2023 legal fees + 8% SST, disbursements, valuation; separate Vendor RPGT engine with Schedule 4 exemption, holding-period rate table, s.21B retention)
  6. Terminology (193 legal terms across 22 categories)
- **39 AI tools** (all Gemini 2.5 Flash, accessible via grouped dropdown in dashboard header):
  - **Learn** (2): AI Tutor, Case Law Research
  - **Draft** (5): AI Drafter, Client Advice Letter, Legal Opinion Generator, Tenancy Agreement Drafter, Power of Attorney Drafter
  - **Review** (7): SPA/Contract Reviewer, Clause Comparator, Land Title Interpreter, Due Diligence Report, Requisition Letter, Land Search Analyzer, Loan Doc Reviewer
  - **Practice** (5): Risk Scanner, Checklist Generator, Deadline Calculator, Fee Quotation Generator, Completion Statement
  - **Tax & Finance** (3): Stamp Duty Calculator, RPGT Advisor, LHDN Tax Compliance
  - **Specialist** (5): Caveat Advisor, Developer Claim Advisor, Bankruptcy Search Advisor, Foreign Purchase Advisor, Strata Management Advisor
  - **Learning** (3): Quiz Generator, Mock Exam Generator, Case Law Analyzer
  - **Automation** (5): Transaction Simulator, Clause Library, Document Analyzer, Compliance Checker, Timeline Generator
  - **Corporate** (4): Corporate Resolution Drafter, Corporate Property Due Diligence, JV / JDA Drafter, Guarantee Drafter
- **Document viewer modal** — shows templates (copyable) and PDF placeholders
- **Dashboard header** shows logged-in user display name, admin badge, and logout button
- **Admin dashboard** at `/admin` — separate admin auth, two tabs:
  - **Analytics tab**: AI usage stats, content library stats (20 topics, 62 workflows, 17 forms, 100 cases, 193 terms, 39 tools), tool breakdown, daily usage chart, recent activity log
  - **Users tab**: Create users (email + display name → returns access code shown once), list (shows access code + email + tier per row, copyable), toggle active/deactivate/delete, **regenerate access code** (invalidates old, shows new), auto-refresh every 30s
  - Admin password: set via `ADMIN_PASSWORD` env var (default: "admin2024")
- **Responsive design** — mobile-first with overlay sidebar, overlay AI panel with close button, adaptive grids

### API Routes (37 total)
**Auth & Admin:**
- `/api/convey/auth` — login by access code (`{accessCode}`, case-normalized) → returns JWT + user (no accessCode)
- `/api/admin/auth` — admin dashboard authentication
- `/api/admin/stats` — usage statistics
- `/api/admin/users` — list users (GET; includes accessCode/email/tier), create user (POST; `{email, displayName, role}` → returns accessCode once)
- `/api/admin/users/:id` — delete user (DELETE)
- `/api/admin/users/:id/toggle` — toggle active (PATCH)
- `/api/admin/users/:id/reset-password` — **regenerate access code** (PATCH; returns new code, invalidates old)
- `/api/convey/signup` — public self-signup `{email, displayName}` → creates account, returns accessCode once + JWT

**Original 15 AI Tools:**
- `/api/convey/chat` — AI tutor chat
- `/api/convey/draft` — clause/document drafter
- `/api/convey/risk-scan` — risk scanner
- `/api/convey/checklist` — checklist generator
- `/api/convey/deadlines` — deadline calculator
- `/api/convey/review-spa` — SPA reviewer
- `/api/convey/compare-clauses` — clause comparator
- `/api/convey/interpret-title` — land title interpreter
- `/api/convey/fee-quotation` — fee quotation generator
- `/api/convey/advice-letter` — client advice letter
- `/api/convey/due-diligence` — due diligence report
- `/api/convey/legal-opinion` — legal opinion generator
- `/api/convey/requisition` — requisition letter
- `/api/convey/completion-statement` — completion statement
- `/api/convey/case-research` — case law research

**12 Practitioner AI Tools:**
- `/api/convey/stamp-duty` — stamp duty calculator with exemptions
- `/api/convey/rpgt` — Real Property Gains Tax analysis
- `/api/convey/tenancy` — tenancy agreement drafter
- `/api/convey/power-of-attorney` — POA drafter
- `/api/convey/caveat` — caveat entry/removal advice
- `/api/convey/land-search` — land search result analysis
- `/api/convey/developer-claim` — LAD/defect claims under HDA
- `/api/convey/bankruptcy-search` — bankruptcy/winding-up search interpretation
- `/api/convey/foreign-purchase` — EPU/state consent for foreign buyers
- `/api/convey/loan-doc` — loan facility agreement review
- `/api/convey/tax-compliance` — LHDN tax compliance advice
- `/api/convey/strata` — strata management (SMA 2013) advice

**8 New AI Tools (Learning & Automation):**
- `/api/convey/quiz` — quiz question generator
- `/api/convey/simulate` — transaction simulator
- `/api/convey/clause-library` — clause library search
- `/api/convey/analyze-doc` — document analyzer
- `/api/convey/compliance` — compliance checker
- `/api/convey/timeline` — timeline generator
- `/api/convey/mock-exam` — mock exam generator
- `/api/convey/analyze-case` — case law analyzer

### React Hooks (20 new beyond codegen)
- `useCalculateStampDuty`, `useAnalyzeRPGT`, `useDraftTenancy`, `useDraftPowerOfAttorney`
- `useAdviseCaveat`, `useAnalyzeLandSearch`, `useAdviseDeveloperClaim`, `useAdviseBankruptcySearch`
- `useAdviseForeignPurchase`, `useReviewLoanDoc`, `useAdviseTaxCompliance`, `useAdviseStrata`
- `useGenerateQuiz`, `useSimulateTransaction`, `useSearchClauseLibrary`, `useAnalyzeDocument`
- `useCheckCompliance`, `useGenerateTimeline`, `useGenerateMockExam`, `useAnalyzeCase`

### AiMode Type Values (39 total)
`tutor`, `drafter`, `reviewer`, `comparator`, `title`, `risk`, `checklist`, `deadlines`, `quotation`, `advice`, `duediligence`, `opinion`, `requisition`, `completion`, `caseresearch`, `stampduty`, `rpgt`, `tenancy`, `poa`, `caveat`, `landsearch`, `devclaim`, `bankruptcy`, `foreignpurchase`, `loandoc`, `taxcompliance`, `strata`, `quiz`, `simulator`, `clauselib`, `docanalyzer`, `compliance`, `timeline`, `mockexam`, `caseanalyzer`

### Database Schema
- **usersTable**: id (serial PK), **accessCode (text, unique, NOT NULL)** — sole login credential, **email** (text, nullable, for billing), username (nullable, legacy/unused), passwordHash (nullable, legacy/unused), displayName, role (user/admin), isActive (bool), grandfathered (bool), subscriptionTier, subscriptionStatus, stripeCustomerId, stripeSubscriptionId, currentPeriodEnd, createdAt, lastLoginAt
  - Schema changes applied via **psql directly** (drizzle push needs a TTY and is unusable here). `users_access_code_unique` constraint + `access_code SET NOT NULL` applied manually.
- **aiUsageLogs**: id (serial PK), tool, inputLength, outputLength, durationMs, createdAt

### Security
- API key never exposed to frontend (proxied through backend)
- Login by access code (server-side lookup; sole credential, treated like a password)
- **Access code never returned by `/auth` or `/me`, never persisted to localStorage** (stripped in AppContext) — only shown once at signup / admin create / admin regenerate
- Modern clipboard API (`navigator.clipboard.writeText()`)
- Admin routes protected by separate admin token

### Environment Variables
- `ADMIN_PASSWORD` — admin dashboard password (default: "admin2024")
- `AI_INTEGRATIONS_GEMINI_BASE_URL` — auto-set by Replit AI integration
- `AI_INTEGRATIONS_GEMINI_API_KEY` — auto-set by Replit AI integration
- `DATABASE_URL` — PostgreSQL connection (auto-set by Replit)
- `SESSION_SECRET` — session secret

### Critical Build Notes
- `@google/*` intentionally REMOVED from `artifacts/api-server/build.mjs` externals — do NOT re-add
- AiMode type in AppContext includes all 39 modes
- Auth is **access-code only** — bcryptjs/passwords no longer used to authenticate (username/passwordHash columns retained nullable for legacy)
- `CONVEY_ACCESS_PASSWORD` env var NO LONGER USED
- **NEVER re-run codegen** (`pnpm --filter @workspace/api-spec run codegen`) — it WIPES the ~1147 lines of manually-appended Zod schemas/hooks for the 39 AI tools. Patch generated files by hand instead. If accidentally wiped, restore with `git show HEAD:<path> > <path>` then re-apply only the intended diff.
- Generated files consumed two ways: `@workspace/api-client-react` exports `./src/index.ts` (source) BUT convey-app references it as a **composite project (compiled `dist/.d.ts`)** — after editing `api-client-react/src`, rebuild its decls (`tsc --build lib/api-client-react/tsconfig.json`) or convey-app sees stale types.
- `lib/api-zod` typecheck:libs has a **pre-existing** TS2308 duplicate-export failure (both `generated/api.ts` zod consts and `generated/types/*` interfaces export the same names). Not introduced by auth work; api-server uses esbuild (build is clean).
- New AI hooks manually appended to generated files (NOT re-run codegen) — imports must also be added to the import block in `api.ts`
- Compliance Checker uses `compChk*` prefixed state vars to avoid collision with Completion Statement's `comp*` vars in AIPanel.tsx

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json` which sets `composite: true`. The root `tsconfig.json` lists all lib packages as project references.

- **Always typecheck from the root** — run `pnpm run typecheck`
- **`emitDeclarationOnly`** — only emit `.d.ts` files during typecheck
- **Project references** — when package A depends on package B, A's `tsconfig.json` must list B in its `references` array

## Root Scripts

- `pnpm run build` — runs `typecheck` first, then recursively runs `build` in all packages
- `pnpm run typecheck` — runs `tsc --build --emitDeclarationOnly` using project references

## Packages

### `artifacts/convey-app` (`@workspace/convey-app`)

React + Vite frontend. All static educational content plus AI-powered features.

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server. 40+ routes for auth, admin user management, AI tools, analytics, and document export.
- Build: esbuild bundles into `dist/index.mjs` (note: `@google/*` was removed from externals so Gemini can be bundled)
- **Document Export** — `POST /api/convey/export-docx` generates Malaysian Land Office formatted `.docx` files using the `docx` package. Util: `src/utils/docxExport.ts` (A4, Times New Roman 12pt, MALAYSIA / Pejabat Tanah header, Ruj. Kami / Tarikh ref block, signature & witness blocks). Used by every AI tool's OutputBlock and every Form sample card via the frontend helper `artifacts/convey-app/src/lib/exportDocx.ts` (which provides `downloadDocx` and `downloadAndOpenInGoogleDocs`).
- **Gemini performance config (important)** — every `generateContent` call uses `maxOutputTokens: 3072` and `thinkingConfig: { thinkingBudget: 0 }`. Disabling Gemini 2.5-flash's default reasoning step is critical: without it, simple drafting calls take 30-60 seconds (causing users to think the AI is broken). With it, chat is sub-second and document drafts return in 5-20 seconds. Do NOT remove `thinkingBudget: 0` from any of the 39 endpoints unless you have a reasoning task that genuinely needs it.

### `lib/integrations-gemini-ai` (`@workspace/integrations-gemini-ai`)

Pre-built Gemini AI integration. Uses `AI_INTEGRATIONS_GEMINI_BASE_URL` and `AI_INTEGRATIONS_GEMINI_API_KEY`.

### `lib/db` (`@workspace/db`)

Database layer using Drizzle ORM with PostgreSQL. Contains `usersTable` and `aiUsageLogs`.

### `lib/api-spec` (`@workspace/api-spec`)

OpenAPI 3.1 spec with conveyancing endpoints.
Run codegen: `pnpm --filter @workspace/api-spec run codegen`
