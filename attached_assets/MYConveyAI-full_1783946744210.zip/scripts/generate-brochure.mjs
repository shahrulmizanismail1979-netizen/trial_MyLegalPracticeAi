import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';

const doc = new PDFDocument({
  size: 'A4',
  margins: { top: 50, bottom: 50, left: 55, right: 55 },
  info: {
    Title: 'MYConveyAI — AI-Powered Legal Practice Platform',
    Author: 'Prof Madya Dr Shahrul Mizan Ismail',
    Subject: 'Product Brochure',
  },
});

const outputPath = path.resolve('exports/MYConveyAI-Brochure.pdf');
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
const stream = fs.createWriteStream(outputPath);
doc.pipe(stream);

const GOLD = '#D4A843';
const DARK_BG = '#1A1610';
const DARK_CARD = '#252017';
const CREAM = '#FAF6EE';
const LIGHT_TEXT = '#9B9484';
const WHITE = '#FFFFFF';
const AMBER = '#F59E0B';

const pw = doc.page.width;
const ph = doc.page.height;
const ml = 55;
const mr = 55;
const cw = pw - ml - mr;

function drawPageBg() {
  doc.save();
  doc.rect(0, 0, pw, ph).fill(DARK_BG);
  doc.restore();
}

function drawAccentLine(y, width = 60) {
  doc.save();
  doc.moveTo((pw - width) / 2, y).lineTo((pw + width) / 2, y).lineWidth(2).strokeColor(GOLD).stroke();
  doc.restore();
}

function footer(pageNum) {
  doc.save();
  doc.fontSize(7).fillColor(LIGHT_TEXT).font('Helvetica');
  doc.text(`MYConveyAI — AI-Powered Legal Practice Platform`, ml, ph - 35, { width: cw / 2, align: 'left' });
  doc.text(`Page ${pageNum}`, pw / 2, ph - 35, { width: cw / 2, align: 'right' });
  doc.restore();
}

// ══════════════════════════════════════════════════════════════
// PAGE 1 — COVER
// ══════════════════════════════════════════════════════════════
drawPageBg();

doc.save();
doc.rect(0, 0, pw, 8).fill(GOLD);
doc.rect(0, ph - 8, pw, 8).fill(GOLD);
doc.restore();

let y = 160;
doc.fontSize(11).fillColor(GOLD).font('Helvetica').text('INTRODUCING', 0, y, { align: 'center', characterSpacing: 6 });

y += 40;
doc.fontSize(42).fillColor(WHITE).font('Helvetica-Bold').text('MYConveyAI', 0, y, { align: 'center' });

y += 56;
doc.fontSize(16).fillColor(CREAM).font('Helvetica').text('AI-Powered Legal Practice Platform', 0, y, { align: 'center' });

y += 35;
drawAccentLine(y);

y += 25;
doc.fontSize(12).fillColor(LIGHT_TEXT).font('Helvetica').text('The Definitive Digital Companion for', 0, y, { align: 'center' });
y += 18;
doc.text('Malaysian Conveyancing Practitioners', 0, y, { align: 'center' });

y += 60;
doc.fontSize(10).fillColor(GOLD).font('Helvetica-Bold').text('35 AI Tools  •  20 Legal Topics  •  194 Terms  •  100 Landmark Cases', 0, y, { align: 'center' });

y += 80;
doc.fontSize(11).fillColor(CREAM).font('Helvetica').text('Created by', 0, y, { align: 'center' });
y += 20;
doc.fontSize(14).fillColor(WHITE).font('Helvetica-Bold').text('Prof Madya Dr Shahrul Mizan Ismail', 0, y, { align: 'center' });
y += 22;
doc.fontSize(11).fillColor(LIGHT_TEXT).font('Helvetica').text('Fakulti Undang-Undang', 0, y, { align: 'center' });
y += 17;
doc.text('Universiti Kebangsaan Malaysia', 0, y, { align: 'center' });

footer(1);

// ══════════════════════════════════════════════════════════════
// PAGE 2 — OVERVIEW & CONTENT LIBRARY
// ══════════════════════════════════════════════════════════════
doc.addPage();
drawPageBg();

y = 50;
doc.fontSize(9).fillColor(GOLD).font('Helvetica').text('PLATFORM OVERVIEW', ml, y, { characterSpacing: 4 });
y += 25;
doc.fontSize(26).fillColor(WHITE).font('Helvetica-Bold').text('Everything You Need in One Platform', ml, y, { width: cw });
y += 40;
doc.fontSize(10.5).fillColor(LIGHT_TEXT).font('Helvetica').text(
  'MYConveyAI is a comprehensive AI-powered platform built exclusively for Malaysian conveyancing practice. ' +
  'It brings together an extensive legal reference library with 35 purpose-built AI tools — giving practitioners ' +
  'instant access to authoritative guidance, intelligent document drafting, automated compliance checks, and much more.',
  ml, y, { width: cw, lineGap: 4 }
);

y += 65;
doc.fontSize(10.5).fillColor(CREAM).font('Helvetica').text(
  'Whether you are preparing a Sale and Purchase Agreement, calculating stamp duty, researching case law, or ' +
  'conducting due diligence — MYConveyAI accelerates your workflow while ensuring accuracy and compliance ' +
  'with Malaysian legislation including the National Land Code 2020, Housing Development Act 1966, ' +
  'Stamp Act 1949, and the Solicitors\' Remuneration Order 2023.',
  ml, y, { width: cw, lineGap: 4 }
);

y += 90;
drawAccentLine(y);
y += 20;
doc.fontSize(9).fillColor(GOLD).font('Helvetica').text('CONTENT LIBRARY', ml, y, { characterSpacing: 4 });
y += 25;
doc.fontSize(20).fillColor(WHITE).font('Helvetica-Bold').text('Comprehensive Legal Reference', ml, y, { width: cw });

y += 38;

const stats = [
  { num: '20', label: 'Substantive\nLaw Topics', desc: 'From land tenure systems to e-conveyancing, environmental law, and East Malaysia land law.' },
  { num: '62', label: 'Conveyancing\nWorkflows', desc: 'Step-by-step procedures for every transaction type — sub-sale, new build, auction, refinancing.' },
  { num: '17', label: 'Form\nTemplates', desc: 'Statutory forms including 14A, 16B, 16I, MOT, consent forms, and more.' },
  { num: '100', label: 'Landmark\nCases', desc: 'Authoritative Malaysian case law with facts, ratio decidendi, and practical significance.' },
  { num: '194', label: 'Legal\nTerms', desc: 'Comprehensive glossary across 22 categories — from NLC provisions to Islamic finance.' },
  { num: '35', label: 'AI-Powered\nTools', desc: 'Purpose-built AI tools for drafting, review, research, compliance, and practice management.' },
];

const colCount = 3;
const cardW = (cw - 20) / colCount;
const cardH = 130;

stats.forEach((s, i) => {
  const col = i % colCount;
  const row = Math.floor(i / colCount);
  const cx = ml + col * (cardW + 10);
  const cy = y + row * (cardH + 10);

  doc.save();
  doc.roundedRect(cx, cy, cardW - 10, cardH, 6).fillAndStroke(DARK_CARD, '#3D3526');
  doc.restore();

  doc.fontSize(28).fillColor(GOLD).font('Helvetica-Bold').text(s.num, cx + 12, cy + 12, { width: cardW - 30 });
  doc.fontSize(8.5).fillColor(WHITE).font('Helvetica-Bold').text(s.label, cx + 12, cy + 44, { width: cardW - 30, lineGap: 2 });
  doc.fontSize(7.5).fillColor(LIGHT_TEXT).font('Helvetica').text(s.desc, cx + 12, cy + 72, { width: cardW - 30, lineGap: 2 });
});

footer(2);

// ══════════════════════════════════════════════════════════════
// PAGE 3 — AI TOOLS: LEARN, DRAFT, REVIEW
// ══════════════════════════════════════════════════════════════
const toolSections = [
  {
    group: 'LEARN', count: 2, color: '#60A5FA',
    desc: 'Interactive AI reference tools for instant legal guidance and case research.',
    tools: [
      { name: 'AI Legal Tutor', desc: 'Ask any question about Malaysian conveyancing law — NLC 2020, HDA 1966, property transactions. Get detailed, referenced answers instantly.' },
      { name: 'Case Law Research', desc: 'Research Malaysian case law relevant to conveyancing. Find leading cases, judicial reasoning, and citations for your work.' },
    ],
  },
  {
    group: 'DRAFT', count: 5, color: '#34D399',
    desc: 'AI-powered document drafting for professional legal documents and correspondence.',
    tools: [
      { name: 'AI Drafter', desc: 'Generate SPA clauses, loan agreements, undertaking letters, and other contract provisions.' },
      { name: 'Client Advice Letter', desc: 'Draft formal advice letters covering transaction status, legal implications, and recommended actions.' },
      { name: 'Legal Opinion Generator', desc: 'Produce formal legal opinions on title validity, encumbrances, restrictions, and compliance.' },
      { name: 'Tenancy Agreement Drafter', desc: 'Draft tenancy agreements for residential or commercial properties under Malaysian law.' },
      { name: 'Power of Attorney Drafter', desc: 'Draft general or specific POA documents including NLC-compliant provisions.' },
    ],
  },
  {
    group: 'REVIEW', count: 7, color: '#22D3EE',
    desc: 'Analytical tools to examine, compare, and interpret legal documents and search results.',
    tools: [
      { name: 'SPA / Contract Reviewer', desc: 'Clause-by-clause review identifying risks, non-standard terms, and compliance issues.' },
      { name: 'Clause Comparator', desc: 'Side-by-side comparison of clause versions with legal impact assessment.' },
      { name: 'Land Title Interpreter', desc: 'Decode geran/pajakan/hakmilik — restrictions, endorsements, caveats, and charges.' },
      { name: 'Due Diligence Report', desc: 'Comprehensive property due diligence covering title, planning, charges, and tenancies.' },
      { name: 'Requisition Letter', desc: 'Draft requisitions on title based on search results and outstanding issues.' },
      { name: 'Land Search Analyzer', desc: 'Plain-language analysis of official land search results from the land office.' },
      { name: 'Loan Document Reviewer', desc: 'Review facility agreements — unusual conditions, borrower obligations, and risks.' },
    ],
  },
];

const toolSections2 = [
  {
    group: 'PRACTICE', count: 5, color: '#FBBF24',
    desc: 'Workflow tools for risk management, deadline tracking, calculations, and administration.',
    tools: [
      { name: 'Risk Scanner', desc: 'Identify red flags, ambiguities, and liability issues in clauses and documents.' },
      { name: 'Checklist Generator', desc: 'Step-by-step checklists for sub-sale, new development, auction, refinancing, and more.' },
      { name: 'Deadline Calculator', desc: 'Calculate statutory deadlines — stamping (30 days), adjudication, registration, completion.' },
      { name: 'Fee Quotation Generator', desc: 'Professional fee quotations based on the Solicitors\' Remuneration Order 2023 scale.' },
      { name: 'Completion Statement', desc: 'Generate completion accounts with price breakdown, adjustments, and balance calculations.' },
    ],
  },
  {
    group: 'TAX & FINANCE', count: 3, color: '#F472B6',
    desc: 'Tax calculation and financial compliance for property transactions.',
    tools: [
      { name: 'Stamp Duty Calculator', desc: 'Ad valorem rates, first-time buyer exemptions, HOC campaigns, Budget 2024 provisions.' },
      { name: 'RPGT Advisor', desc: 'Real Property Gains Tax analysis — disposal dates, nationality rules, Schedule 5 exemptions.' },
      { name: 'LHDN Tax Compliance', desc: 'Withholding tax, RPGT filing obligations, penalty avoidance, and compliance advice.' },
    ],
  },
  {
    group: 'SPECIALIST', count: 5, color: '#FB923C',
    desc: 'Advisory tools for niche areas of Malaysian conveyancing practice.',
    tools: [
      { name: 'Caveat Advisor', desc: 'Private, registrar\'s, and lien-holder\'s caveats — entry, removal, and lapsing (NLC s.322-329).' },
      { name: 'Developer Claim Advisor', desc: 'LAD claims, defect liability, and purchaser rights under the Housing Development Act 1966.' },
      { name: 'Bankruptcy Search Advisor', desc: 'Interpret Insolvency Department searches and winding-up results for transactions.' },
      { name: 'Foreign Purchase Advisor', desc: 'EPU approval, state consent, minimum price thresholds for foreign purchasers.' },
      { name: 'Strata Management Advisor', desc: 'MC/JMB obligations, maintenance charges, sinking funds under SMA 2013.' },
    ],
  },
];

const toolSections3 = [
  {
    group: 'ASSESSMENT', count: 3, color: '#818CF8',
    desc: 'Sharpen expertise with AI-generated assessments and deep case analysis.',
    tools: [
      { name: 'Quiz Generator', desc: 'MCQ quizzes on any conveyancing topic — NLC, HDA, stamp duty, registration. Choose difficulty and quantity.' },
      { name: 'Mock Exam Generator', desc: 'Full exam-style papers with essay questions, problem scenarios, and model answers.' },
      { name: 'Case Law Analyzer', desc: 'Deep-dive case analysis — facts, issues, reasoning, ratio decidendi, and practical implications.' },
    ],
  },
  {
    group: 'AUTOMATION', count: 5, color: '#2DD4BF',
    desc: 'Workflow automation for document management and transaction planning.',
    tools: [
      { name: 'Transaction Simulator', desc: 'Walk through a full conveyancing transaction — engagement to completion with milestones.' },
      { name: 'Clause Library', desc: 'Browse and search standard clauses for SPAs, loan agreements, tenancies, special conditions.' },
      { name: 'Document Analyzer', desc: 'AI analysis of any legal document — type identification, provisions, obligations, risks.' },
      { name: 'Compliance Checker', desc: 'Full AML/CFT audit, regulatory compliance, professional conduct rules, documentation review.' },
      { name: 'Timeline Generator', desc: 'Detailed transaction timelines with statutory deadlines and practical milestone scheduling.' },
    ],
  },
];

function renderToolPage(sections, pageNum) {
  doc.addPage();
  drawPageBg();

  let y = 50;

  if (pageNum === 3) {
    doc.fontSize(9).fillColor(GOLD).font('Helvetica').text('AI TOOLS', ml, y, { characterSpacing: 4 });
    y += 25;
    doc.fontSize(26).fillColor(WHITE).font('Helvetica-Bold').text('35 Purpose-Built AI Tools', ml, y, { width: cw });
    y += 36;
    doc.fontSize(10.5).fillColor(LIGHT_TEXT).font('Helvetica').text(
      'Every tool is designed specifically for Malaysian conveyancing practice — powered by advanced AI ' +
      'and informed by the National Land Code, HDA, Stamp Act, RPGTA, SMA, and current judicial authorities.',
      ml, y, { width: cw, lineGap: 4 }
    );
    y += 52;
  }

  sections.forEach((section) => {
    if (y > ph - 200) {
      footer(pageNum);
      doc.addPage();
      drawPageBg();
      pageNum++;
      y = 50;
    }

    doc.save();
    doc.roundedRect(ml - 2, y - 2, cw + 4, 28, 4).fill(section.color + '15');
    doc.restore();

    doc.fontSize(9).fillColor(section.color).font('Helvetica-Bold').text(
      `${section.group}  —  ${section.count} TOOLS`, ml + 10, y + 5, { characterSpacing: 2, width: cw - 20 }
    );
    y += 34;

    doc.fontSize(9).fillColor(LIGHT_TEXT).font('Helvetica-Oblique').text(section.desc, ml + 10, y, { width: cw - 20, lineGap: 2 });
    y += 22;

    section.tools.forEach((tool) => {
      if (y > ph - 70) {
        footer(pageNum);
        doc.addPage();
        drawPageBg();
        pageNum++;
        y = 50;
      }

      doc.save();
      doc.circle(ml + 14, y + 5, 2.5).fill(section.color);
      doc.restore();

      doc.fontSize(9.5).fillColor(WHITE).font('Helvetica-Bold').text(tool.name, ml + 24, y, { width: cw - 30, continued: true });
      doc.fillColor(LIGHT_TEXT).font('Helvetica').text(`  —  ${tool.desc}`, { width: cw - 30, lineGap: 2 });

      y = doc.y + 8;
    });

    y += 14;
  });

  footer(pageNum);
  return pageNum;
}

let pageNum = 3;
pageNum = renderToolPage(toolSections, pageNum);
pageNum = renderToolPage(toolSections2, pageNum + 1);
pageNum = renderToolPage(toolSections3, pageNum + 1);

// ══════════════════════════════════════════════════════════════
// FINAL PAGE — WHY MYCONVEYAI & CTA
// ══════════════════════════════════════════════════════════════
doc.addPage();
drawPageBg();
pageNum++;

y = 50;
doc.fontSize(9).fillColor(GOLD).font('Helvetica').text('WHY MYCONVEYAI', ml, y, { characterSpacing: 4 });
y += 25;
doc.fontSize(26).fillColor(WHITE).font('Helvetica-Bold').text('Built for Malaysian Practitioners', ml, y, { width: cw });

y += 45;

const benefits = [
  { title: 'Malaysian Law-Specific', desc: 'Every tool is trained on and references Malaysian legislation — NLC 2020, HDA 1966, Stamp Act 1949, RPGTA 1976, SMA 2013, and the Solicitors\' Remuneration Order 2023. No generic advice.' },
  { title: 'Practitioner-Grade Output', desc: 'AI-generated drafts, opinions, and analyses are structured for direct professional use — complete with legal citations, statutory references, and practitioner notes.' },
  { title: 'Comprehensive Reference Library', desc: '20 substantive law topics, 62 conveyancing workflows, 17 statutory forms, 100 landmark cases, and 194 legal terms — all in one searchable platform.' },
  { title: 'Secure & Access-Controlled', desc: 'Password-protected multi-user access with role-based administration. User accounts managed through a dedicated Admin Dashboard with full analytics.' },
  { title: 'Instant Calculations', desc: 'Stamp duty, RPGT, legal fees (SRO 2023), completion statements, and deadline calculations — accurate, current, and ready to use.' },
  { title: 'Always Up to Date', desc: 'Covers the latest legislative developments including Budget 2024 provisions, HOC campaign exemptions, and recent judicial pronouncements.' },
];

benefits.forEach((b) => {
  if (y > ph - 100) {
    footer(pageNum);
    doc.addPage();
    drawPageBg();
    pageNum++;
    y = 50;
  }

  doc.save();
  doc.roundedRect(ml, y, cw, 1, 0).fill(GOLD + '30');
  doc.restore();
  y += 10;

  doc.fontSize(11).fillColor(GOLD).font('Helvetica-Bold').text(b.title, ml, y, { width: cw });
  y += 18;
  doc.fontSize(9.5).fillColor(LIGHT_TEXT).font('Helvetica').text(b.desc, ml, y, { width: cw, lineGap: 3 });
  y = doc.y + 18;
});

y += 20;
drawAccentLine(y);
y += 30;

doc.save();
doc.roundedRect(ml, y, cw, 130, 8).fillAndStroke(DARK_CARD, GOLD + '40');
doc.restore();

doc.fontSize(20).fillColor(WHITE).font('Helvetica-Bold').text('Ready to Transform Your Practice?', ml + 20, y + 20, { width: cw - 40, align: 'center' });
doc.fontSize(10).fillColor(LIGHT_TEXT).font('Helvetica').text(
  'MYConveyAI brings together decades of Malaysian conveyancing expertise with cutting-edge AI technology. ' +
  'Access 35 purpose-built tools and a comprehensive legal reference library — all from one platform.',
  ml + 20, y + 55, { width: cw - 40, align: 'center', lineGap: 3 }
);
doc.fontSize(10).fillColor(GOLD).font('Helvetica-Bold').text(
  'Contact your account manager to get started.',
  ml + 20, y + 100, { width: cw - 40, align: 'center' }
);

y += 160;
doc.fontSize(10).fillColor(CREAM).font('Helvetica-Bold').text('Prof Madya Dr Shahrul Mizan Ismail', 0, y, { width: pw, align: 'center' });
y += 16;
doc.fontSize(9).fillColor(LIGHT_TEXT).font('Helvetica').text('Fakulti Undang-Undang', 0, y, { width: pw, align: 'center' });
y += 14;
doc.text('Universiti Kebangsaan Malaysia', 0, y, { width: pw, align: 'center' });

footer(pageNum);

doc.end();

stream.on('finish', () => {
  console.log(`PDF generated successfully: ${outputPath}`);
});
