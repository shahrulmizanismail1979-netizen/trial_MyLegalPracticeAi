/**
 * Extracts pure-data structures from the convey-app source files
 * (which mix React/JSX with the data) and from the lib/* data files
 * (which are already pure data). Writes normalised JSON to disk so the
 * book builder can consume them without touching the app.
 */
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const REPO = path.resolve(import.meta.dirname, '..', '..', '..');
const APP_SRC = path.join(REPO, 'artifacts', 'convey-app', 'src');
const OUT_DIR = path.join(REPO, 'scripts', 'src', 'build-book', '_tmp');

fs.mkdirSync(OUT_DIR, { recursive: true });

// ─── 1. Extract TOPICS from Theory.tsx ───────────────────────────────
function sliceArrayLiteral(file: string, declStart: number): string {
  // Find first '=' after declStart, then first '[' after that
  const eq = file.indexOf('=', declStart);
  const arrStart = file.indexOf('[', eq);
  let i = arrStart, depth = 0;
  let inStr: string | null = null;
  let inTpl = false;
  let inLine = false, inBlock = false;
  while (i < file.length) {
    const ch = file[i];
    const next = file[i + 1];
    if (inLine) { if (ch === '\n') inLine = false; }
    else if (inBlock) { if (ch === '*' && next === '/') { inBlock = false; i++; } }
    else if (inStr) {
      if (ch === '\\') { i++; }
      else if (ch === inStr) inStr = null;
    }
    else if (inTpl) {
      if (ch === '\\') { i++; }
      else if (ch === '`') inTpl = false;
    }
    else {
      if (ch === '/' && next === '/') { inLine = true; i++; }
      else if (ch === '/' && next === '*') { inBlock = true; i++; }
      else if (ch === '"' || ch === "'") inStr = ch;
      else if (ch === '`') inTpl = true;
      else if (ch === '[') depth++;
      else if (ch === ']') { depth--; if (depth === 0) return file.slice(arrStart, i + 1); }
    }
    i++;
  }
  throw new Error('Unterminated array literal');
}

function extractTheoryTopics(): void {
  const file = fs.readFileSync(path.join(APP_SRC, 'components/sections/Theory.tsx'), 'utf8');
  const declStart = file.indexOf('const TOPICS');
  if (declStart < 0) throw new Error('TOPICS not found');
  const arr = sliceArrayLiteral(file, declStart);
  let block = `export const TOPICS = ${arr};\n`;
  // Strip JSX icon entries like:  icon: <Scale className="w-5 h-5" />,
  block = block.replace(/^\s*icon:\s*<[^>]*\/>\s*,\s*\n/gm, '');
  fs.writeFileSync(path.join(OUT_DIR, 'theoryData.mjs'), block);
}

// ─── 2. Extract TERMS from Terminology.tsx ───────────────────────────
function extractTerms(): void {
  const file = fs.readFileSync(path.join(APP_SRC, 'components/sections/Terminology.tsx'), 'utf8');
  const declStart = file.indexOf('const TERMS');
  if (declStart < 0) throw new Error('TERMS not found');
  const arr = sliceArrayLiteral(file, declStart);
  fs.writeFileSync(path.join(OUT_DIR, 'termsData.mjs'), `export const TERMS = ${arr};\n`);
}

extractTheoryTopics();
extractTerms();
console.log('Extracted Theory + Terminology to', OUT_DIR);
