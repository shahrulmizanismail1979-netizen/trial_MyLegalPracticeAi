/**
 * MYConveyAI — Book Manuscript Builder (MS Word / .docx)
 *
 * Mirrors build-book.ts (PDF) but emits a Microsoft Word document. Same data
 * sources, same OSCOLA conventions, same cross-reference deduplication.
 *
 * Output: exports/MYConveyAI-Manuscript.docx
 *
 * Word-specific decisions:
 *  - Word auto-flows pages, so we never insert manual page breaks except at
 *    Part / Cover / TOC boundaries — eliminating any chance of empty pages.
 *  - The TOC is a real Word TOC field (TableOfContents) that auto-populates
 *    when the user opens the file — Word will compute the page numbers.
 *  - Heading levels feed the TOC: H1 = Part, H2 = Chapter, H3 = Section.
 *  - Case names are italicised inline (OSCOLA) by scanning runs against the
 *    canonical CASES list, exactly as in the PDF builder.
 *  - Cross-references to Part III forms / Part IV cases use the SAME
 *    lookupForm() / lookupCanonicalCase() helpers replicated here.
 */

import fs from 'node:fs';
import path from 'node:path';
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  PageBreak,
  PageNumber,
  Header,
  Footer,
  TableOfContents,
  StyleLevel,
  LevelFormat,
  convertInchesToTwip,
  LineRuleType,
  UnderlineType,
} from 'docx';

const REPO = path.resolve(import.meta.dirname, '..', '..', '..');
const TMP = path.join(REPO, 'scripts', 'src', 'build-book', '_tmp');
const OUT = path.join(REPO, 'exports', 'MYConveyAI-Manuscript.docx');

// ─── Load data (same sources as PDF builder) ─────────────────────────
const { TOPICS } = await import(path.join(TMP, 'theoryData.mjs')) as { TOPICS: LawTopic[] };
const { TERMS } = await import(path.join(TMP, 'termsData.mjs')) as { TERMS: Term[] };
const { CASES } = await import(
  path.join(REPO, 'artifacts/convey-app/src/lib/casesData.ts')
) as { CASES: CaseDef[] };
const { WORKFLOWS, WORKFLOW_CATEGORIES } = await import(
  path.join(REPO, 'artifacts/convey-app/src/lib/workflowData.ts')
) as { WORKFLOWS: Workflow[]; WORKFLOW_CATEGORIES: string[] };
const { FORMS_LIBRARY, FORM_CATEGORIES } = await import(
  path.join(REPO, 'artifacts/convey-app/src/lib/formsData.ts')
) as { FORMS_LIBRARY: FormDoc[]; FORM_CATEGORIES: string[] };

// ─── Types ───────────────────────────────────────────────────────────
interface TopicSection { heading: string; content: string }
interface KeyCase { name: string; citation: string; principle: string }
interface LawTopic {
  id: string; title: string; legislation: string; color: string;
  intro: string; sections: TopicSection[];
  keyPrinciples: string[]; keyCases: KeyCase[];
}
interface Term { term: string; meaning: string; source: string; example: string; category: string }
interface CaseDef {
  id: string; title: string; citation: string; topic: string; tags: string[];
  facts: string; issue: string; held: string; significance: string;
  diagram: { parties: string[]; issue: string; result: string };
}
interface WFDocument { id: string; title: string; type: string; note: string; sample: string }
interface WFStep {
  id: number; phase: string; label: string;
  timeframe?: string; legalBasis?: string; tip?: string;
  documents?: WFDocument[];
}
interface Workflow {
  id: string; title: string; category: string;
  difficulty: string; duration: string; summary: string;
  legislation: string[]; steps: WFStep[];
}
interface FormDoc {
  id: string; formNumber: string; name: string; nameMs: string;
  category: string; legalBasis: string; purpose: string; whoUses: string;
  keyFields: string[]; stampDuty: string; timeline: string;
  importantNotes: string[]; sample: string;
}

// ─── Cross-reference indexes (identical logic to PDF builder) ────────
function normaliseCaseName(s: string): string {
  return s.toLowerCase()
    .replace(/&\s*ors?/g, '')
    .replace(/\(no\s*\d+\)/g, '')
    .replace(/[^a-z0-9 ]+/g, ' ')
    .replace(/\s+/g, ' ').trim();
}
const caseByNorm = new Map<string, { number: number; def: CaseDef }>();
CASES.forEach((c, i) => caseByNorm.set(normaliseCaseName(c.title), { number: i + 1, def: c }));
function lookupCanonicalCase(name: string): { number: number; def: CaseDef } | null {
  const norm = normaliseCaseName(name);
  if (caseByNorm.has(norm)) return caseByNorm.get(norm)!;
  for (const [k, v] of caseByNorm) {
    if (k.startsWith(norm) || norm.startsWith(k.split(' v ')[0])) return v;
  }
  return null;
}

const formByNumber = new Map<string, { partIII: number; def: FormDoc }>();
FORMS_LIBRARY.forEach((f, i) => {
  const entry = { partIII: i + 1, def: f };
  const num = f.formNumber.toLowerCase().trim();
  formByNumber.set(num, entry);
  const compact = num.replace(/[^a-z0-9]/g, '');
  if (compact) formByNumber.set(compact, entry);
  formByNumber.set(f.name.toLowerCase().trim(), entry);
});
function lookupForm(docTitle: string): { partIII: number; def: FormDoc } | null {
  const t = docTitle.toLowerCase();
  const direct = formByNumber.get(t.trim());
  if (direct) return direct;
  const probes: RegExp[] = [
    /\bform\s+1[469][a-z]?\b/i,
    /\bckht\s*\d+[a-z]?\b/i,
    /\bpds\s*\d+(\s*\/\s*e-?stamp)?\b/i,
    /\bhda\s*schedule\s*[gh]\b/i,
    /\bundertaking\s+to\s+discharge\b/i,
    /\bsolicitor'?s?\s+undertaking\b/i,
  ];
  for (const rx of probes) {
    const m = t.match(rx);
    if (!m) continue;
    const cand = m[0].toLowerCase().replace(/\s+/g, ' ').trim();
    if (formByNumber.has(cand)) return formByNumber.get(cand)!;
    const compact = cand.replace(/[^a-z0-9]/g, '');
    if (formByNumber.has(compact)) return formByNumber.get(compact)!;
    const numOnly = cand.replace(/[^a-z0-9]/g, '').replace(/^(form|ckht|pds|hda|schedule)/, '');
    if (numOnly && formByNumber.has(numOnly)) return formByNumber.get(numOnly)!;
  }
  return null;
}

// ─── Statute extraction (identical to PDF builder) ───────────────────
const STATUTES = new Set<string>();
const STATUTE_BLOCKLIST = [
  /^banking\s+practice/i, /^common\s+law/i, /^conveyancing\s+practice/i,
  /^equity$/i, /^bar\s+council/i,
  /^bnm\s+(guidelines|prudential|shariah|practice|standards)/i,
  /^bank\s+negara/i, /^estate\s+agency/i, /^solicitors?\s+professional/i,
  /^islamic\s+banking\s+practice/i, /^common\s+law\s+principle/i,
  /^co-?ownership\s+law/i, /^any\s+/i, /^used\s+in\s+malaysia/i,
  /^not\s+a\s+statutory/i,
];
const STATUTE_CANONICAL: Array<[RegExp, string]> = [
  [/^NLC(\s+1965)?$/i, 'National Land Code 1965'],
  [/^STA(\s+1985)?$/i, 'Strata Titles Act 1985'],
  [/^SMA(\s+2013)?$/i, 'Strata Management Act 2013'],
  [/^SRA(\s+1950)?$/i, 'Specific Relief Act 1950'],
  [/^Relief Act 1950$/i, 'Specific Relief Act 1950'],
  [/^RPGTA?(\s+1976)?$/i, 'Real Property Gains Tax Act 1976'],
  [/^HDA(\s+1966)?$/i, 'Housing Development (Control and Licensing) Act 1966'],
  [/^IFSA(\s+2013)?$/i, 'Islamic Financial Services Act 2013'],
  [/^AMLA(\s+2001)?$/i, 'Anti-Money Laundering, Anti-Terrorism Financing and Proceeds of Unlawful Activities Act 2001'],
  [/^CA(\s+1950)?$/i, 'Contracts Act 1950'],
  [/^Strata Titles Act\s*2013$/i, 'Strata Management Act 2013'],
  [/^National Land Code amendments$/i, 'National Land Code 1965'],
  [/^NLC conveyancing practice$/i, 'National Land Code 1965'],
  [/^Housing Development Act$/i, 'Housing Development (Control and Licensing) Act 1966'],
  [/^Housing Development Act 1966$/i, 'Housing Development (Control and Licensing) Act 1966'],
  [/^Probate\s*&\s*Administration Act 1959$/i, 'Probate and Administration Act 1959'],
  [/^RPGT Act 1976$/i, 'Real Property Gains Tax Act 1976'],
  [/^RPGT Orders?$/i, 'Real Property Gains Tax Act 1976'],
  [/^LA Act 1960$/i, 'Land Acquisition Act 1960'],
  [/^SDBA 1974$/i, 'Street, Drainage and Building Act 1974'],
  [/^UBBL 1984$/i, 'Uniform Building By-Laws 1984'],
  [/^Federal Constitution Art(?:icle|\.)\s*\d+$/i, 'Federal Constitution'],
  [/^Item\s+\d+,\s*First Schedule,\s*Stamp Act 1949$/i, 'Stamp Act 1949'],
  [/^Schedule\s+\d+,\s*Real Property Gains Tax Act 1976$/i, 'Real Property Gains Tax Act 1976'],
  [/^Stamp Act 1949 Exemption$/i, 'Stamp Act 1949'],
  [/^Rules of Court 2012 Order \d+$/i, 'Rules of Court 2012'],
  [/^Court Order(\s+for.*)?$/i, ''],
  [/^court practice$/i, ''],
  [/^contract law$/i, ''],
  [/^EQ Order 2015$/i, 'Environmental Quality Act 1974'],
  [/^Stamp Duty Order$/i, 'Stamp Act 1949'],
  [/^Malay Reservations Enactment$/i, 'Malay Reservations Enactment 1913'],
  [/^Survey Act$/i, 'Licensed Land Surveyors Act 1958'],
  [/^Syariah Court rules$/i, ''],
  [/^State Land Enactments\s*&?\s*Restrictions?$/i, 'State Land Enactments'],
  [/^Solicitors Accounts Rules$/i, "Solicitors' Account Rules 1990"],
  [/^Legal Profession Rules 1978$/i, 'Legal Profession Act 1976'],
  [/^Introduced in Malaysia.*Federated Malay States Act 1915$/i, 'Federated Malay States Act 1915'],
  [/^MM2H Programme rules$/i, ''],
  [/^Finance Acts$/i, ''],
];
function recordStatute(raw: string) {
  if (!raw) return;
  const parts = raw.split(/[;]/g);
  for (const part of parts) {
    let cleaned = part.replace(/\([^)]*\)/g, '').replace(/\([^)]*$/, '').replace(/—.*$/, '').trim();
    cleaned = cleaned.replace(/^(Sections?|s\.?|ss\.?|Para(graph)?\.?|Schedule)\s+\d+[A-Za-z]*([,–\s&]+\d+[A-Za-z]*)*[,\s]+/i, '');
    cleaned = cleaned.replace(/^Form\s+\d+[A-Za-z]*[,\s]+/i, '');
    cleaned = cleaned.replace(/[.,]\s*$/, '');
    cleaned = cleaned.replace(/[)\]]+\s*$/, '');
    cleaned = cleaned.replace(/\s+s\.?\s*\d+[A-Za-z]*(\s*\(\d+\))?\s*$/i, '');
    cleaned = cleaned.replace(/\s+read\s+with.*$/i, '');
    cleaned = cleaned.replace(/\s+\[\d{4}\].*$/, '');
    cleaned = cleaned.replace(/\s+v\s+.*$/i, '');
    cleaned = cleaned.replace(/\s+(Exemption|Regulations)\s.*$/i, '');
    cleaned = cleaned.replace(/^Order\s+\d+.*$/i, '');
    cleaned = cleaned.replace(/^Strata Titles Act\s+2013\s*$/i, 'Strata Management Act 2013');
    cleaned = cleaned.replace(/&\s+Form\s+\d+[A-Za-z]*,?\s*/i, '');
    cleaned = cleaned.replace(/[—–]/g, '-').replace(/\s+/g, ' ').trim();
    let dropped = false;
    for (const [rx, canon] of STATUTE_CANONICAL) {
      if (rx.test(cleaned)) {
        if (!canon) { dropped = true; break; }
        cleaned = canon; break;
      }
    }
    if (dropped) continue;
    if (cleaned.length < 6 || cleaned.length > 120) continue;
    if (STATUTE_BLOCKLIST.some(rx => rx.test(cleaned))) continue;
    if (!/(Act|Code|Order|Rules|Constitution|\b\d{4}\b)/i.test(cleaned)) continue;
    STATUTES.add(cleaned);
  }
}

// ─── docx primitives ─────────────────────────────────────────────────
const FONT = 'Times New Roman';
// Sizes are in half-points (so 24 = 12pt)
const SIZE_BODY = 22;       // 11pt body
const SIZE_H4 = 22;
const SIZE_H3 = 24;
const SIZE_H2 = 28;
const SIZE_H1 = 36;
const SIZE_PART = 64;
const SIZE_COVER = 56;

const allCaseNamesSorted = [...CASES.map(c => c.title)].sort((a, b) => b.length - a.length);

/** Split a string into TextRuns, italicising any case-name occurrence. */
function inlineRuns(text: string, base: { bold?: boolean; italics?: boolean; size?: number; color?: string } = {}): TextRun[] {
  if (!text) return [new TextRun({ text: '', font: FONT, size: base.size ?? SIZE_BODY })];
  type Mark = { start: number; end: number };
  const lower = text.toLowerCase();
  const marks: Mark[] = [];
  for (const name of allCaseNamesSorted) {
    if (name.length < 8) continue;
    const target = name.toLowerCase();
    let from = 0;
    while (true) {
      const idx = lower.indexOf(target, from);
      if (idx === -1) break;
      const overlap = marks.some(m => !(idx + name.length <= m.start || idx >= m.end));
      if (!overlap) marks.push({ start: idx, end: idx + name.length });
      from = idx + name.length;
    }
  }
  marks.sort((a, b) => a.start - b.start);
  const runs: TextRun[] = [];
  let cursor = 0;
  const baseProps = {
    font: FONT,
    size: base.size ?? SIZE_BODY,
    bold: base.bold ?? false,
    color: base.color,
  };
  for (const m of marks) {
    if (m.start > cursor) {
      runs.push(new TextRun({ ...baseProps, text: text.slice(cursor, m.start), italics: base.italics ?? false }));
    }
    runs.push(new TextRun({ ...baseProps, text: text.slice(m.start, m.end), italics: true }));
    cursor = m.end;
  }
  if (cursor < text.length) {
    runs.push(new TextRun({ ...baseProps, text: text.slice(cursor), italics: base.italics ?? false }));
  }
  if (runs.length === 0) {
    runs.push(new TextRun({ ...baseProps, text, italics: base.italics ?? false }));
  }
  return runs;
}

function bodyPara(text: string, opts: { indent?: number; spacingAfter?: number } = {}): Paragraph {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: opts.spacingAfter ?? 120, line: 300, lineRule: LineRuleType.AUTO },
    indent: opts.indent ? { left: opts.indent } : undefined,
    children: inlineRuns(text),
  });
}

function bulletPara(text: string, marker = '•'): Paragraph {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: 60, line: 300, lineRule: LineRuleType.AUTO },
    indent: { left: convertInchesToTwip(0.35), hanging: convertInchesToTwip(0.2) },
    children: [
      new TextRun({ text: marker + '  ', font: FONT, size: SIZE_BODY, bold: true }),
      ...inlineRuns(text),
    ],
  });
}

function H1Heading(text: string): Paragraph {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    alignment: AlignmentType.LEFT,
    spacing: { before: 400, after: 200, line: 360, lineRule: LineRuleType.AUTO },
    children: [new TextRun({ text, font: FONT, size: SIZE_H1, bold: true, color: '000000' })],
  });
}
function H2Heading(text: string): Paragraph {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    alignment: AlignmentType.LEFT,
    spacing: { before: 320, after: 160, line: 340, lineRule: LineRuleType.AUTO },
    children: [new TextRun({ text, font: FONT, size: SIZE_H2, bold: true, color: '000000' })],
  });
}
function H3Heading(text: string): Paragraph {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    alignment: AlignmentType.LEFT,
    spacing: { before: 240, after: 120, line: 320, lineRule: LineRuleType.AUTO },
    children: [new TextRun({ text, font: FONT, size: SIZE_H3, bold: true, color: '000000' })],
  });
}
function H4Heading(text: string): Paragraph {
  return new Paragraph({
    spacing: { before: 160, after: 80, line: 300, lineRule: LineRuleType.AUTO },
    children: [new TextRun({ text, font: FONT, size: SIZE_H4, bold: true, italics: true })],
  });
}

function pageBreakBefore(): Paragraph {
  return new Paragraph({ children: [new PageBreak()] });
}

function partOpener(roman: string, subtitle: string): Paragraph[] {
  return [
    pageBreakBefore(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 2400, after: 200 },
      children: [new TextRun({ text: 'PART', font: FONT, size: 22, characterSpacing: 80, color: '666666' })],
    }),
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      alignment: AlignmentType.CENTER,
      spacing: { before: 200, after: 240 },
      children: [new TextRun({ text: roman, font: FONT, size: SIZE_PART, bold: true })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 0 },
      children: [new TextRun({ text: subtitle, font: FONT, size: 26, italics: true, color: '333333' })],
    }),
  ];
}

function chapterHeading(title: string): Paragraph[] {
  return [
    pageBreakBefore(),
    new Paragraph({
      alignment: AlignmentType.LEFT,
      spacing: { before: 200, after: 80 },
      children: [new TextRun({ text: 'CHAPTER', font: FONT, size: 18, characterSpacing: 60, color: '666666' })],
    }),
    new Paragraph({
      heading: HeadingLevel.HEADING_2,
      alignment: AlignmentType.LEFT,
      spacing: { before: 80, after: 240 },
      children: [new TextRun({ text: title, font: FONT, size: SIZE_H1, bold: true })],
    }),
  ];
}

// Render arbitrary multi-line content with bullet/numbered awareness
function renderContent(content: string): Paragraph[] {
  const out: Paragraph[] = [];
  const lines = content.split('\n');
  let buffer: string[] = [];
  const flush = () => {
    if (!buffer.length) return;
    out.push(bodyPara(buffer.join(' ')));
    buffer = [];
  };
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) { flush(); continue; }
    const m = line.match(/^([•\-]|\d+\.)\s+(.*)$/);
    if (m) {
      flush();
      out.push(bulletPara(m[2], m[1].replace('-', '•')));
    } else {
      buffer.push(line);
    }
  }
  flush();
  return out;
}

// ─── BUILD: assemble the document children ───────────────────────────
const children: Paragraph[] = [];

// COVER
children.push(
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 4800, after: 480 },
    children: [new TextRun({
      text: "A PRACTITIONER'S COMPENDIUM",
      font: FONT, size: 22, characterSpacing: 120, color: '444444',
    })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 200, after: 200 },
    children: [new TextRun({
      text: 'MALAYSIAN CONVEYANCING LAW',
      font: FONT, size: SIZE_COVER, bold: true,
    })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 1200 },
    children: [new TextRun({
      text: 'Substantive Law, Practice, Forms & Leading Cases',
      font: FONT, size: 28, italics: true, color: '333333',
    })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 1200, after: 200 },
    children: [new TextRun({
      text: 'Prof Madya Dr Shahrul Mizan Ismail',
      font: FONT, size: 26,
    })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 80 },
    children: [new TextRun({ text: 'Fakulti Undang-Undang', font: FONT, size: 22, italics: true, color: '333333' })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 0 },
    children: [new TextRun({ text: 'Universiti Kebangsaan Malaysia', font: FONT, size: 22, italics: true, color: '333333' })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 4800, after: 0 },
    children: [new TextRun({ text: 'First Edition', font: FONT, size: 20, characterSpacing: 60, color: '444444' })],
  }),
);

// HALF-TITLE
children.push(
  pageBreakBefore(),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 4800, after: 200 },
    children: [new TextRun({ text: 'Malaysian Conveyancing Law', font: FONT, size: 40, bold: true })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 0 },
    children: [new TextRun({ text: "A Practitioner's Compendium", font: FONT, size: 24, italics: true, color: '333333' })],
  }),
);

// COPYRIGHT / IMPRINT
children.push(pageBreakBefore());
const imprintParas = [
  '© Prof Madya Dr Shahrul Mizan Ismail. All rights reserved.',
  'Published as the print companion to the MYConveyAI digital platform.',
  'First edition prepared from the consolidated educational corpus of the MYConveyAI application — comprising 21 substantive-law topics, 62 conveyancing workflows, 16 statutory forms, 100 leading cases and 193 legal terms.',
  'All citations conform to the Oxford Standard for the Citation of Legal Authorities (OSCOLA), adapted for Malaysian sources. Case names are italicised throughout the text. Statutes are cited by short title and section number.',
  'No part of this work constitutes legal advice. Practitioners must verify every authority and statutory provision against the current state of the law before relying on any matter discussed herein.',
];
imprintParas.forEach(p => children.push(bodyPara(p)));

// ABOUT THE AUTHOR + PREFACE
children.push(pageBreakBefore(), H2Heading('About the Author'));
children.push(bodyPara(
  'Prof Madya Dr Shahrul Mizan Ismail teaches at the Faculty of Law, Universiti Kebangsaan Malaysia (UKM). His research and teaching focus on Malaysian land law, conveyancing practice and the comparative jurisprudence of indefeasibility under Torrens-system jurisdictions.',
));
children.push(H2Heading('Preface'));
const prefaceParas = [
  'This volume gathers the substantive law, the procedural workflow, the precedent forms and the leading authorities of Malaysian conveyancing into a single reference work for the practitioner, the pupil-in-chambers and the law student. Its content is drawn directly from the MYConveyAI digital teaching platform, which has served as both a learning environment and an everyday desk-tool for users of conveyancing law in Malaysia.',
  'The work is divided into five parts. Part I sets out the substantive law — the National Land Code 1965, the doctrine of indefeasibility, contract principles applicable to land transactions, the Strata Titles Act 1985, the law on caveats, the Real Property Gains Tax Act 1976 and other statutory regimes that frame the practice. Part II moves to the procedural plane and traces sixty-two distinct conveyancing workflows from sub-sale to foreclosure, each broken down into discrete chronological steps. Part III collects sixteen statutory forms most frequently encountered in practice, with annotated samples. Part IV is a synthesis of one hundred leading Malaysian cases. Part V provides a practical guide to costs, fees, stamp duty and RPGT under the Solicitors Remuneration Order 2023.',
  'Three editorial decisions deserve a brief note. First, this work avoids duplication: where Part I refers to a leading case, the reader is directed to the full treatment in Part IV rather than repeating it. Second, the same convention applies to statutory forms: workflows in Part II reference the relevant form in Part III rather than reproducing the full sample. Third, every case name in the running text is italicised in conformity with OSCOLA, and a consolidated Table of Cases and Table of Statutes appear at the end of the volume to facilitate cross-referencing.',
  "It is the author's hope that this compendium will be of practical service to those who practise, teach or study conveyancing law in Malaysia.",
];
prefaceParas.forEach(p => children.push(bodyPara(p)));

// TABLE OF CONTENTS — Word will auto-populate this on file open
children.push(
  pageBreakBefore(),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 240, after: 240 },
    children: [new TextRun({ text: 'Contents', font: FONT, size: 40, bold: true })],
  }),
  new Paragraph({
    children: [
      new TableOfContents('Contents', {
        hyperlink: true,
        headingStyleRange: '1-3',
        stylesWithLevels: [
          new StyleLevel('Heading 1', 1),
          new StyleLevel('Heading 2', 2),
          new StyleLevel('Heading 3', 3),
        ],
      }),
    ],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 200, after: 0 },
    children: [new TextRun({
      text: '(In Microsoft Word, right-click the table above and choose "Update Field" to populate page numbers.)',
      font: FONT, size: 18, italics: true, color: '666666',
    })],
  }),
);

// ─── PART I — SUBSTANTIVE LAW ────────────────────────────────────────
children.push(...partOpener('I', 'The Substantive Law of Conveyancing in Malaysia'));

TOPICS.forEach((topic, idx) => {
  recordStatute(topic.legislation);
  children.push(...chapterHeading(`${idx + 1}. ${topic.title}`));
  children.push(new Paragraph({
    spacing: { after: 160 },
    children: [new TextRun({ text: topic.legislation, font: FONT, size: 20, italics: true, color: '444444' })],
  }));
  children.push(bodyPara(topic.intro));
  for (const s of topic.sections) {
    children.push(H3Heading(s.heading));
    children.push(...renderContent(s.content));
  }
  if (topic.keyPrinciples.length) {
    children.push(H3Heading('Key Principles'));
    topic.keyPrinciples.forEach((p, i) => children.push(bulletPara(p, `${i + 1}.`)));
  }
  if (topic.keyCases.length) {
    children.push(H3Heading('Leading Authorities'));
    for (const kc of topic.keyCases) {
      const ref = lookupCanonicalCase(kc.name);
      children.push(new Paragraph({
        spacing: { before: 120, after: 60, line: 300, lineRule: LineRuleType.AUTO },
        indent: { left: convertInchesToTwip(0.2) },
        children: [
          new TextRun({ text: kc.name, font: FONT, size: SIZE_BODY, italics: true, bold: true }),
          new TextRun({ text: '  ' + kc.citation, font: FONT, size: SIZE_BODY }),
        ],
      }));
      children.push(new Paragraph({
        spacing: { after: 60, line: 300, lineRule: LineRuleType.AUTO },
        indent: { left: convertInchesToTwip(0.4) },
        alignment: AlignmentType.JUSTIFIED,
        children: inlineRuns(kc.principle, { size: 21, color: '222222' }),
      }));
      if (ref) {
        children.push(new Paragraph({
          spacing: { after: 120 },
          indent: { left: convertInchesToTwip(0.4) },
          children: [new TextRun({
            text: `See Part IV, Case ${ref.number}, for the full report.`,
            font: FONT, size: 19, italics: true, color: '666666',
          })],
        }));
      }
    }
  }
});

// ─── PART II — WORKFLOWS ─────────────────────────────────────────────
children.push(...partOpener('II', 'The Sixty-Two Conveyancing Workflows'));
const workflowsByCategory = new Map<string, Workflow[]>();
for (const cat of WORKFLOW_CATEGORIES) workflowsByCategory.set(cat, []);
for (const w of WORKFLOWS) {
  if (!workflowsByCategory.has(w.category)) workflowsByCategory.set(w.category, []);
  workflowsByCategory.get(w.category)!.push(w);
}
let wfCounter = 0;
for (const cat of workflowsByCategory.keys()) {
  const list = workflowsByCategory.get(cat)!;
  if (!list.length) continue;
  children.push(...chapterHeading(cat));
  for (const wf of list) {
    wfCounter++;
    children.push(H3Heading(`${wfCounter}. ${wf.title}`));
    children.push(new Paragraph({
      spacing: { after: 120 },
      children: [new TextRun({
        text: `${wf.id} · ${wf.difficulty} · Approximate duration: ${wf.duration}`,
        font: FONT, size: 20, italics: true, color: '444444',
      })],
    }));
    children.push(bodyPara(wf.summary));
    if (wf.legislation.length) {
      children.push(H4Heading('Statutory Framework'));
      wf.legislation.forEach(l => recordStatute(l));
      children.push(bodyPara(wf.legislation.join('; ') + '.', { indent: convertInchesToTwip(0.2) }));
    }
    children.push(H4Heading('Procedural Steps'));
    let lastPhase = '';
    for (const step of wf.steps) {
      if (step.phase !== lastPhase) {
        children.push(new Paragraph({
          spacing: { before: 200, after: 80 },
          indent: { left: convertInchesToTwip(0.1) },
          children: [new TextRun({ text: step.phase, font: FONT, size: 21, bold: true, italics: true })],
        }));
        lastPhase = step.phase;
      }
      // Step number + label
      children.push(new Paragraph({
        spacing: { before: 120, after: 40, line: 280, lineRule: LineRuleType.AUTO },
        indent: { left: convertInchesToTwip(0.3), hanging: convertInchesToTwip(0.3) },
        children: [
          new TextRun({ text: `Step ${step.id}.  `, font: FONT, size: 21 }),
          new TextRun({ text: step.label, font: FONT, size: 21, bold: true }),
        ],
      }));
      const meta: string[] = [];
      if (step.timeframe) meta.push(`Timeframe: ${step.timeframe}`);
      if (step.legalBasis) { meta.push(`Legal basis: ${step.legalBasis}`); recordStatute(step.legalBasis); }
      if (meta.length) {
        children.push(new Paragraph({
          spacing: { after: 40, line: 260, lineRule: LineRuleType.AUTO },
          indent: { left: convertInchesToTwip(0.5) },
          children: [new TextRun({ text: meta.join(' · '), font: FONT, size: 19, italics: true, color: '444444' })],
        }));
      }
      if (step.tip) {
        children.push(new Paragraph({
          spacing: { after: 40, line: 260, lineRule: LineRuleType.AUTO },
          indent: { left: convertInchesToTwip(0.5) },
          children: [
            new TextRun({ text: 'Practice tip: ', font: FONT, size: 19, color: '222222' }),
            new TextRun({ text: step.tip, font: FONT, size: 19, italics: true, color: '222222' }),
          ],
        }));
      }
      if (step.documents && step.documents.length) {
        for (const d of step.documents) {
          const matched = lookupForm(d.title);
          const trail = matched ? ` — see Part III, Form ${matched.partIII}, for the precedent.` : ` — ${d.note}`;
          children.push(new Paragraph({
            spacing: { after: 40, line: 260, lineRule: LineRuleType.AUTO },
            indent: { left: convertInchesToTwip(0.5) },
            children: [
              new TextRun({ text: 'Document: ', font: FONT, size: 19, color: '222222' }),
              new TextRun({ text: d.title, font: FONT, size: 19, italics: true, color: '222222' }),
              new TextRun({ text: trail, font: FONT, size: 19, color: '222222' }),
            ],
          }));
        }
      }
    }
  }
}

// ─── PART III — FORMS ────────────────────────────────────────────────
children.push(...partOpener('III', 'Statutory Forms & Drafting Precedents'));
const formsByCategory = new Map<string, FormDoc[]>();
for (const cat of FORM_CATEGORIES) formsByCategory.set(cat, []);
for (const f of FORMS_LIBRARY) {
  if (!formsByCategory.has(f.category)) formsByCategory.set(f.category, []);
  formsByCategory.get(f.category)!.push(f);
}
let formCounter = 0;
for (const cat of formsByCategory.keys()) {
  const list = formsByCategory.get(cat)!;
  if (!list.length) continue;
  children.push(...chapterHeading(cat));
  for (const f of list) {
    formCounter++;
    recordStatute(f.legalBasis);
    children.push(H3Heading(`Form ${formCounter}. ${f.formNumber} — ${f.name}`));
    children.push(new Paragraph({
      spacing: { after: 120 },
      children: [new TextRun({ text: `(${f.nameMs})`, font: FONT, size: 20, italics: true, color: '444444' })],
    }));
    children.push(H4Heading('Legal Basis'));
    children.push(bodyPara(f.legalBasis));
    children.push(H4Heading('Purpose & Function'));
    children.push(bodyPara(f.purpose));
    children.push(H4Heading('Who Uses It'));
    children.push(bodyPara(f.whoUses));
    if (f.keyFields.length) {
      children.push(H4Heading('Key Fields'));
      f.keyFields.forEach(k => children.push(bulletPara(k)));
    }
    children.push(H4Heading('Stamp Duty'));
    children.push(bodyPara(f.stampDuty));
    children.push(H4Heading('Timeline'));
    children.push(bodyPara(f.timeline));
    if (f.importantNotes.length) {
      children.push(H4Heading('Practice Notes'));
      f.importantNotes.forEach((n, i) => children.push(bulletPara(n, `${i + 1}.`)));
    }
    children.push(H4Heading('Precedent'));
    // Render as monospace block
    const sampleLines = f.sample.split('\n');
    sampleLines.forEach(line => {
      children.push(new Paragraph({
        spacing: { after: 0, line: 260, lineRule: LineRuleType.AUTO },
        indent: { left: convertInchesToTwip(0.25) },
        children: [new TextRun({ text: line || ' ', font: 'Courier New', size: 18 })],
      }));
    });
  }
}

// ─── PART IV — LEADING CASES ─────────────────────────────────────────
children.push(...partOpener('IV', 'One Hundred Leading Malaysian Cases'));
children.push(...chapterHeading('The One Hundred Leading Cases'));
const casesByTopic = new Map<string, CaseDef[]>();
for (const c of CASES) {
  if (!casesByTopic.has(c.topic)) casesByTopic.set(c.topic, []);
  casesByTopic.get(c.topic)!.push(c);
}
let caseCounter = 0;
for (const [topicLabel, list] of casesByTopic) {
  children.push(H3Heading(topicLabel));
  for (const c of list) {
    caseCounter++;
    children.push(new Paragraph({
      spacing: { before: 200, after: 60, line: 300, lineRule: LineRuleType.AUTO },
      children: [
        new TextRun({ text: `Case ${caseCounter}.  `, font: FONT, size: 24, bold: true }),
        new TextRun({ text: c.title, font: FONT, size: 24, bold: true, italics: true }),
        new TextRun({ text: `  ${c.citation}`, font: FONT, size: 24, bold: true }),
      ],
    }));
    children.push(new Paragraph({
      spacing: { after: 100 },
      children: [new TextRun({ text: c.tags.join(' · '), font: FONT, size: 20, italics: true, color: '444444' })],
    }));
    children.push(H4Heading('Facts'));
    children.push(bodyPara(c.facts));
    children.push(H4Heading('Issue'));
    children.push(bodyPara(c.issue));
    children.push(H4Heading('Held'));
    children.push(bodyPara(c.held));
    children.push(H4Heading('Significance'));
    children.push(bodyPara(c.significance));
  }
}

// ─── PART V — COSTS, FEES, STAMP DUTY & RPGT ─────────────────────────
children.push(...partOpener('V', 'Costs, Fees, Stamp Duty and RPGT'));
children.push(...chapterHeading('The Statutory Costs Framework'));
children.push(bodyPara(
  'A Malaysian conveyancing transaction attracts a layered set of statutory and professional charges. This Part consolidates the rates, exemptions and computation rules currently in force, drawing on the Stamp Act 1949, the Real Property Gains Tax Act 1976, the Solicitors Remuneration Order 2023 and current Pejabat Tanah charging schedules. The companion online assessor in the MYConveyAI platform performs these computations interactively; the rules set out here are the legal authority on which those computations are made.',
));
children.push(H3Heading('Stamp Duty on the Memorandum of Transfer (Ad Valorem)'));
recordStatute('Stamp Act 1949');
children.push(bodyPara('Stamp duty on a Form 14A Memorandum of Transfer is computed by reference to the higher of the consideration and the market value of the property. The current bands are:'));
children.push(bulletPara('First RM100,000 — 1.0%.'));
children.push(bulletPara('Next RM400,000 (RM100,001 to RM500,000) — 2.0%.'));
children.push(bulletPara('Next RM500,000 (RM500,001 to RM1,000,000) — 3.0%.'));
children.push(bulletPara('Above RM1,000,000 — 4.0%.'));
children.push(bodyPara('The first-home exemption (Malaysian citizen, never previously owned residential property): full exemption on the first RM500,000 of consideration; fifty per cent exemption on the next RM500,000 (so the effective marginal rate between RM500,000 and RM1,000,000 is reduced by half). Above RM1,000,000 the exemption ceases and the full ad valorem scale applies to the entire price.'));
children.push(H3Heading('Stamp Duty on the Loan Agreement'));
children.push(bodyPara('A principal loan agreement attracts stamp duty at 0.5% of the principal sum, payable under the Stamp Act 1949. Subordinate or supplemental security documents are typically chargeable at the nominal rate of RM10. Failure to stamp within thirty days of execution attracts a five-fold penalty and renders the instrument inadmissible in evidence.'));
children.push(H3Heading("Solicitors' Remuneration Order 2023"));
recordStatute('Solicitors Remuneration Order 2023');
children.push(bodyPara('The SRO 2023 prescribes the minimum scale fee for conveyancing matters. The scale (applicable to both the SPA / Transfer and the Loan / Charge documentation) is:'));
children.push(bulletPara('First RM500,000 — 1.0%.'));
children.push(bulletPara('RM500,001 to RM1,000,000 — 0.8%.'));
children.push(bulletPara('RM1,000,001 to RM3,000,000 — 0.7%.'));
children.push(bulletPara('RM3,000,001 to RM5,000,000 — 0.6%.'));
children.push(bulletPara('Above RM5,000,000 — negotiable, but not less than 0.5%.'));
children.push(bodyPara('The minimum fee is RM500. Charging below the scale is an offence under the Legal Profession Act 1976 and may attract disciplinary sanction by the Advocates and Solicitors Disciplinary Board.'));
children.push(H3Heading('Real Property Gains Tax (RPGT)'));
recordStatute('Real Property Gains Tax Act 1976');
children.push(bodyPara('RPGT is charged on the chargeable gain on disposal of a real property or shares in a real property company. The current rates are:'));
children.push(bulletPara('Malaysian citizens and permanent residents — 30% (years 1–3); 20% (year 4); 15% (year 5); nil (year 6 onwards).'));
children.push(bulletPara('Non-citizens and non-permanent residents — 30% (years 1–5); 10% (year 6 onwards).'));
children.push(bulletPara('Companies incorporated in Malaysia — 30% (years 1–3); 20% (year 4); 15% (year 5); 10% (year 6 onwards).'));
children.push(bodyPara('Statutory exemptions include (a) the once-in-a-lifetime exemption available to a Malaysian citizen individual on disposal of one private residential property; (b) gifts between spouses, parents and children where no money changes hands; and (c) compulsory acquisitions under the Land Acquisition Act 1960.'));
children.push(bodyPara('Section 21B of the RPGT Act imposes a withholding obligation on the purchaser: three per cent of the consideration must be retained and remitted to the Inland Revenue Board within sixty days of the SPA date. The vendor files Form CKHT 1A and the purchaser files Form CKHT 2A within the same period.'));
children.push(H3Heading('Other Disbursements'));
children.push(bodyPara('In addition to the principal duties and fees, a typical sub-sale transaction will incur:'));
children.push(bulletPara('Land search fees at the relevant Pejabat Tanah dan Galian — approximately RM20–RM30 per title.'));
children.push(bulletPara('Bankruptcy or insolvency search at the Department of Insolvency — approximately RM10–RM25 per search.'));
children.push(bulletPara('Land Office presentment and registration fees — between RM10 and RM300 depending on transaction value and state.'));
children.push(bulletPara('Miscellaneous disbursements (commissioner for oaths, courier, postage and photocopying) — typically RM200–RM400.'));

// ─── GLOSSARY ────────────────────────────────────────────────────────
children.push(...partOpener('Glossary', 'A Concise Lexicon of Malaysian Conveyancing Terms'));
children.push(...chapterHeading('Glossary of Terms'));
const termsByCategory = new Map<string, Term[]>();
for (const t of TERMS) {
  if (!termsByCategory.has(t.category)) termsByCategory.set(t.category, []);
  termsByCategory.get(t.category)!.push(t);
}
const sortedCats = [...termsByCategory.keys()].sort();
for (const cat of sortedCats) {
  children.push(H3Heading(cat));
  const list = termsByCategory.get(cat)!.sort((a, b) => a.term.localeCompare(b.term));
  for (const t of list) {
    recordStatute(t.source);
    children.push(new Paragraph({
      spacing: { before: 160, after: 40 },
      children: [new TextRun({ text: t.term, font: FONT, size: 22, bold: true })],
    }));
    children.push(new Paragraph({
      spacing: { after: 30, line: 280, lineRule: LineRuleType.AUTO },
      indent: { left: convertInchesToTwip(0.2) },
      alignment: AlignmentType.JUSTIFIED,
      children: [
        new TextRun({ text: 'Meaning. ', font: FONT, size: 21, bold: true }),
        ...inlineRuns(t.meaning, { size: 21 }),
      ],
    }));
    children.push(new Paragraph({
      spacing: { after: 30, line: 280, lineRule: LineRuleType.AUTO },
      indent: { left: convertInchesToTwip(0.2) },
      children: [
        new TextRun({ text: 'Source. ', font: FONT, size: 21, bold: true }),
        new TextRun({ text: t.source, font: FONT, size: 21, italics: true }),
      ],
    }));
    children.push(new Paragraph({
      spacing: { after: 80, line: 280, lineRule: LineRuleType.AUTO },
      indent: { left: convertInchesToTwip(0.2) },
      alignment: AlignmentType.JUSTIFIED,
      children: [
        new TextRun({ text: 'Illustration. ', font: FONT, size: 21, bold: true }),
        ...inlineRuns(t.example, { size: 21, italics: true }),
      ],
    }));
  }
}

// ─── TABLE OF CASES ──────────────────────────────────────────────────
children.push(...partOpener('Table of Cases', 'Alphabetical Index of All Authorities Cited'));
children.push(...chapterHeading('Table of Cases'));
const tableCases = [...CASES].sort((a, b) => a.title.localeCompare(b.title));
for (const c of tableCases) {
  children.push(new Paragraph({
    spacing: { after: 40, line: 280, lineRule: LineRuleType.AUTO },
    indent: { left: convertInchesToTwip(0.25), hanging: convertInchesToTwip(0.25) },
    children: [
      new TextRun({ text: c.title, font: FONT, size: 21, italics: true }),
      new TextRun({ text: ` ${c.citation}.`, font: FONT, size: 21 }),
    ],
  }));
}

// ─── TABLE OF STATUTES ───────────────────────────────────────────────
children.push(...partOpener('Table of Statutes', 'Statutory Provisions Cited'));
children.push(...chapterHeading('Table of Statutes'));
const sortedStatutes = [...STATUTES].sort((a, b) => a.localeCompare(b));
for (const s of sortedStatutes) {
  children.push(new Paragraph({
    spacing: { after: 40, line: 280, lineRule: LineRuleType.AUTO },
    indent: { left: convertInchesToTwip(0.25), hanging: convertInchesToTwip(0.2) },
    children: [
      new TextRun({ text: '•  ', font: FONT, size: 21, bold: true }),
      new TextRun({ text: s, font: FONT, size: 21 }),
    ],
  }));
}

// ─── BIBLIOGRAPHY ────────────────────────────────────────────────────
children.push(...partOpener('Bibliography', 'Selected Secondary Sources'));
children.push(...chapterHeading('Selected Secondary Sources'));
const biblio = [
  'Buang, Salleh, Malaysian Torrens System (2nd edn, Dewan Bahasa dan Pustaka 2007).',
  'Das, S K, The Torrens System in Malaysia (Malayan Law Journal 1963).',
  'Judith Sihombing, National Land Code: A Commentary (3rd edn, LexisNexis 2018).',
  'Teo Keang Sood and Khaw Lake Tee, Land Law in Malaysia: Cases and Commentary (3rd edn, LexisNexis 2012).',
  'Wong, David S Y, Tenure and Land Dealings in the Malay States (Singapore University Press 1975).',
  'Yusoff, Sharifah Suhana, Malaysian Legal System (4th edn, Sweet & Maxwell Asia 2016).',
  'Bar Council of Malaysia, Conveyancing Practice Manual (current edition).',
  'Federal Court of Malaysia, Practice Directions (consolidated).',
  'Inland Revenue Board of Malaysia (LHDN), Public Rulings on Real Property Gains Tax and Stamp Duty (current series).',
];
for (const b of biblio) {
  children.push(new Paragraph({
    spacing: { after: 100, line: 280, lineRule: LineRuleType.AUTO },
    indent: { left: convertInchesToTwip(0.25), hanging: convertInchesToTwip(0.25) },
    children: [new TextRun({ text: b, font: FONT, size: 21 })],
  }));
}

// ─── ASSEMBLE THE DOCUMENT ───────────────────────────────────────────
fs.mkdirSync(path.dirname(OUT), { recursive: true });

const doc = new Document({
  creator: 'MYConveyAI Build Pipeline',
  title: "Malaysian Conveyancing Law: A Practitioner's Compendium",
  description: 'Comprehensive treatise on Malaysian conveyancing law and practice',
  styles: {
    default: {
      document: {
        run: { font: FONT, size: SIZE_BODY },
      },
    },
  },
  features: {
    updateFields: true, // ask Word to refresh the TOC field on open
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 }, // A4 (twentieths of a point)
        margin: {
          top: convertInchesToTwip(1),
          right: convertInchesToTwip(1),
          bottom: convertInchesToTwip(1),
          left: convertInchesToTwip(1),
        },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({
            text: "Malaysian Conveyancing Law — A Practitioner's Compendium",
            font: FONT, size: 18, italics: true, color: '666666',
          })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 20 })],
        })],
      }),
    },
    children,
  }],
});

const buf = await Packer.toBuffer(doc);
fs.writeFileSync(OUT, buf);

const stat = fs.statSync(OUT);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('Word manuscript produced:');
console.log('  Path: ', OUT);
console.log('  Size: ', (stat.size / 1024).toFixed(1) + ' KB');
console.log('  Total paragraph elements:', children.length);
console.log('  Cases listed in Table of Cases:', CASES.length);
console.log('  Statutes collected:', STATUTES.size);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
