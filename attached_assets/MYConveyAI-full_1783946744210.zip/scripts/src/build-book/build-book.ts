/**
 * MYConveyAI — Book Manuscript Builder
 *
 * Compiles the entire educational content of the MYConveyAI app into a single
 * print-ready PDF manuscript that follows OSCOLA citation conventions.
 *
 * Source data:
 *   - 21 substantive law topics       (Theory.tsx → TOPICS)
 *   - 62 conveyancing workflows       (lib/workflowData.ts → WORKFLOWS)
 *   - 16 statutory forms              (lib/formsData.ts → FORMS_LIBRARY)
 *   - 100 leading cases               (lib/casesData.ts → CASES)
 *   - 193 legal terms                 (Terminology.tsx → TERMS)
 *
 * Deduplication:
 *   - Topics' keyCases are cross-referenced to Part IV instead of repeating
 *     full case treatments.
 *   - Workflow document samples reference Part III rather than reprinting the
 *     full statutory form template.
 *
 * Output: exports/MYConveyAI-Manuscript.pdf
 */

import fs from 'node:fs';
import path from 'node:path';
import PDFDocument from 'pdfkit';

const REPO = path.resolve(import.meta.dirname, '..', '..', '..');
const TMP = path.join(REPO, 'scripts', 'src', 'build-book', '_tmp');
const OUT = path.join(REPO, 'exports', 'MYConveyAI-Manuscript.pdf');

// ─── Load data ───────────────────────────────────────────────────────
const { TOPICS } = await import(path.join(TMP, 'theoryData.mjs')) as { TOPICS: LawTopic[] };
const { TERMS } = await import(path.join(TMP, 'termsData.mjs')) as { TERMS: Term[] };
const { CASES } = await import(
  path.join(REPO, 'artifacts/convey-app/src/lib/casesData.ts')
) as { CASES: CaseDef[] };
const { WORKFLOWS, WORKFLOW_CATEGORIES } = await import(
  path.join(REPO, 'artifacts/convey-app/src/lib/workflowData.ts')
) as { WORKFLOWS: Workflow[]; WORKFLOW_CATEGORIES: string[] };
const { FORMS_LIBRARY, FORM_CATEGORIES } = await import(
  path.join(REPO, 'artifacts/convey-app/src/lib/formsData.ts')
) as { FORMS_LIBRARY: FormDoc[]; FORM_CATEGORIES: string[] };

// ─── Types (mirroring app shape — declared local to avoid imports) ───
interface TopicSection { heading: string; content: string }
interface KeyCase { name: string; citation: string; principle: string }
interface LawTopic {
  id: string; title: string; legislation: string; color: string;
  intro: string; sections: TopicSection[];
  keyPrinciples: string[]; keyCases: KeyCase[];
}
interface Term { term: string; meaning: string; source: string; example: string; category: string }
interface CaseDef {
  id: string; title: string; citation: string; topic: string; tags: string[];
  facts: string; issue: string; held: string; significance: string;
  diagram: { parties: string[]; issue: string; result: string };
}
interface WFDocument { id: string; title: string; type: string; note: string; sample: string }
interface WFStep {
  id: number; phase: string; label: string;
  timeframe?: string; legalBasis?: string; tip?: string;
  documents?: WFDocument[];
}
interface Workflow {
  id: string; title: string; category: string;
  difficulty: string; duration: string; summary: string;
  legislation: string[]; steps: WFStep[];
}
interface FormDoc {
  id: string; formNumber: string; name: string; nameMs: string;
  category: string; legalBasis: string; purpose: string; whoUses: string;
  keyFields: string[]; stampDuty: string; timeline: string;
  importantNotes: string[]; sample: string;
}

// ─── Build cross-reference indexes for de-duplication ────────────────
function normaliseCaseName(s: string): string {
  return s.toLowerCase()
    .replace(/&\s*ors?/g, '')
    .replace(/\(no\s*\d+\)/g, '')
    .replace(/[^a-z0-9 ]+/g, ' ')
    .replace(/\s+/g, ' ').trim();
}
const caseByNorm = new Map<string, { number: number; def: CaseDef }>();
CASES.forEach((c, i) => caseByNorm.set(normaliseCaseName(c.title), { number: i + 1, def: c }));

function lookupCanonicalCase(name: string): { number: number; def: CaseDef } | null {
  const norm = normaliseCaseName(name);
  if (caseByNorm.has(norm)) return caseByNorm.get(norm)!;
  // partial match: vendor short-form like "Tan Ying Hong" should match "Tan Ying Hong v Tan Sian San"
  for (const [k, v] of caseByNorm) {
    if (k.startsWith(norm) || norm.startsWith(k.split(' v ')[0])) return v;
  }
  return null;
}

const formByNumber = new Map<string, { partIII: number; def: FormDoc }>();
FORMS_LIBRARY.forEach((f, i) => {
  const entry = { partIII: i + 1, def: f };
  const num = f.formNumber.toLowerCase().trim();
  formByNumber.set(num, entry);
  // Also index by normalised number (no spaces, no punctuation) and by the
  // form name itself, so that workflow doc titles like "CKHT 1A Form (Vendor)",
  // "Form 14A (Memorandum of Transfer)", "PDS 1 Form (e-Stamp for SPA)",
  // "Form 16N — Discharge of Charge", "HDA Schedule G SPA" all resolve.
  const compact = num.replace(/[^a-z0-9]/g, '');
  if (compact) formByNumber.set(compact, entry);
  formByNumber.set(f.name.toLowerCase().trim(), entry);
});

function lookupForm(docTitle: string): { partIII: number; def: FormDoc } | null {
  const t = docTitle.toLowerCase();
  const direct = formByNumber.get(t.trim());
  if (direct) return direct;
  // Pattern probes — match full token (use m[0] not capture group) so candidates
  // align with the index keys, which are stored as full form numbers.
  const probes: RegExp[] = [
    /\bform\s+1[469][a-z]?\b/i,                 // Form 14A, Form 16N, etc.
    /\bckht\s*\d+[a-z]?\b/i,                    // CKHT 1A, CKHT 502
    /\bpds\s*\d+(\s*\/\s*e-?stamp)?\b/i,        // PDS 1, PDS 15, PDS 1 / e-Stamp
    /\bhda\s*schedule\s*[gh]\b/i,               // HDA Schedule G/H
    /\bundertaking\s+to\s+discharge\b/i,        // Undertaking to Discharge
    /\bsolicitor'?s?\s+undertaking\b/i,         // Solicitor's Undertaking
  ];
  for (const rx of probes) {
    const m = t.match(rx);
    if (!m) continue;
    const cand = m[0].toLowerCase().replace(/\s+/g, ' ').trim();
    if (formByNumber.has(cand)) return formByNumber.get(cand)!;
    const compact = cand.replace(/[^a-z0-9]/g, '');
    if (formByNumber.has(compact)) return formByNumber.get(compact)!;
    // For PDS variants like "pds 1 form" — fallback to first numeric token
    const numOnly = cand.replace(/[^a-z0-9]/g, '').replace(/^(form|ckht|pds|hda|schedule)/, '');
    if (numOnly && formByNumber.has(numOnly)) return formByNumber.get(numOnly)!;
  }
  return null;
}

// ─── PDF setup ───────────────────────────────────────────────────────
fs.mkdirSync(path.dirname(OUT), { recursive: true });

const doc = new PDFDocument({
  size: 'A4',
  margins: { top: 72, bottom: 72, left: 72, right: 72 },
  bufferPages: true,
  autoFirstPage: false,
  info: {
    Title: 'Malaysian Conveyancing Law: A Practitioner\'s Compendium',
    Author: 'Prof Madya Dr Shahrul Mizan Ismail, Fakulti Undang-Undang, UKM',
    Subject: 'Comprehensive treatise on Malaysian conveyancing law and practice',
    Keywords: 'NLC, conveyancing, Malaysia, indefeasibility, RPGT, stamp duty, Torrens',
  },
});

const writeStream = fs.createWriteStream(OUT);
doc.pipe(writeStream);

const PAGE_W = 595.28;  // A4 in pts
const PAGE_H = 841.89;
const ML = 72, MR = 72, MT = 72, MB = 72;
const CW = PAGE_W - ML - MR;
const TEXT_BOTTOM = PAGE_H - MB - 30; // leave room for page number / running head

const SERIF = 'Times-Roman';
const SERIF_B = 'Times-Bold';
const SERIF_I = 'Times-Italic';
const SERIF_BI = 'Times-BoldItalic';
const SANS = 'Helvetica';
const SANS_B = 'Helvetica-Bold';

// ─── TOC machinery ───────────────────────────────────────────────────
type TocLevel = 'part' | 'chapter' | 'section';
interface TocEntry { level: TocLevel; label: string; page: number }
const TOC: TocEntry[] = [];
const RESERVED_TOC_PAGES = 2; // we'll render TOC into these reserved slots later
let currentRunningHead = '';
let currentPart = '';

// Track for tables-of-cases / statutes
const STATUTES = new Set<string>();
const STATUTE_BLOCKLIST = [
  /^banking\s+practice/i,
  /^common\s+law/i,
  /^conveyancing\s+practice/i,
  /^equity$/i,
  /^bar\s+council/i,
  /^bnm\s+(guidelines|prudential|shariah|practice|standards)/i,
  /^bank\s+negara/i,
  /^estate\s+agency/i,
  /^solicitors?\s+professional/i,
  /^islamic\s+banking\s+practice/i,
  /^common\s+law\s+principle/i,
  /^co-?ownership\s+law/i,
  /^any\s+/i,
  /^used\s+in\s+malaysia/i,
  /^not\s+a\s+statutory/i,
];
// Canonicalisation map for common abbreviations → full statute names
const STATUTE_CANONICAL: Array<[RegExp, string]> = [
  [/^NLC(\s+1965)?$/i, 'National Land Code 1965'],
  [/^STA(\s+1985)?$/i, 'Strata Titles Act 1985'],
  [/^SMA(\s+2013)?$/i, 'Strata Management Act 2013'],
  [/^SRA(\s+1950)?$/i, 'Specific Relief Act 1950'],
  [/^Relief Act 1950$/i, 'Specific Relief Act 1950'],
  [/^RPGTA?(\s+1976)?$/i, 'Real Property Gains Tax Act 1976'],
  [/^HDA(\s+1966)?$/i, 'Housing Development (Control and Licensing) Act 1966'],
  [/^IFSA(\s+2013)?$/i, 'Islamic Financial Services Act 2013'],
  [/^AMLA(\s+2001)?$/i, 'Anti-Money Laundering, Anti-Terrorism Financing and Proceeds of Unlawful Activities Act 2001'],
  [/^CA(\s+1950)?$/i, 'Contracts Act 1950'],
  [/^Strata Titles Act\s*2013$/i, 'Strata Management Act 2013'], // common typo
  [/^National Land Code amendments$/i, 'National Land Code 1965'],
  [/^NLC conveyancing practice$/i, 'National Land Code 1965'],
  [/^Housing Development Act$/i, 'Housing Development (Control and Licensing) Act 1966'],
  [/^Housing Development Act 1966$/i, 'Housing Development (Control and Licensing) Act 1966'],
  [/^Probate\s*&\s*Administration Act 1959$/i, 'Probate and Administration Act 1959'],
  [/^RPGT Act 1976$/i, 'Real Property Gains Tax Act 1976'],
  [/^RPGT Orders?$/i, 'Real Property Gains Tax Act 1976'],
  [/^LA Act 1960$/i, 'Land Acquisition Act 1960'],
  [/^SDBA 1974$/i, 'Street, Drainage and Building Act 1974'],
  [/^UBBL 1984$/i, 'Uniform Building By-Laws 1984'],
  [/^Federal Constitution Art(?:icle|\.)\s*\d+$/i, 'Federal Constitution'],
  [/^Item\s+\d+,\s*First Schedule,\s*Stamp Act 1949$/i, 'Stamp Act 1949'],
  [/^Schedule\s+\d+,\s*Real Property Gains Tax Act 1976$/i, 'Real Property Gains Tax Act 1976'],
  [/^Stamp Act 1949 Exemption$/i, 'Stamp Act 1949'],
  [/^Rules of Court 2012 Order \d+$/i, 'Rules of Court 2012'],
  [/^Court Order(\s+for.*)?$/i, ''],     // not a statute
  [/^court practice$/i, ''],
  [/^contract law$/i, ''],
  [/^EQ Order 2015$/i, 'Environmental Quality Act 1974'],
  [/^Stamp Duty Order$/i, 'Stamp Act 1949'],
  [/^Malay Reservations Enactment$/i, 'Malay Reservations Enactment 1913'],
  [/^Survey Act$/i, 'Licensed Land Surveyors Act 1958'],
  [/^Syariah Court rules$/i, ''],
  [/^State Land Enactments\s*&?\s*Restrictions?$/i, 'State Land Enactments'],
  [/^Solicitors Accounts Rules$/i, 'Solicitors\' Account Rules 1990'],
  [/^Legal Profession Rules 1978$/i, 'Legal Profession Act 1976'],
  [/^Introduced in Malaysia.*Federated Malay States Act 1915$/i, 'Federated Malay States Act 1915'],
  [/^MM2H Programme rules$/i, ''],
  [/^Finance Acts$/i, ''],
];
function recordStatute(raw: string) {
  if (!raw) return;
  // Split semicolon-, comma- and slash-separated lists
  const parts = raw.split(/[;]/g);
  for (const part of parts) {
    let cleaned = part.replace(/\([^)]*\)/g, '').replace(/\([^)]*$/, '').replace(/—.*$/, '').trim();
    // Strip leading "Section NN[,] " or "s.NN " or "Para.. of "
    cleaned = cleaned.replace(/^(Sections?|s\.?|ss\.?|Para(graph)?\.?|Schedule)\s+\d+[A-Za-z]*([,–\s&]+\d+[A-Za-z]*)*[,\s]+/i, '');
    cleaned = cleaned.replace(/^Form\s+\d+[A-Za-z]*[,\s]+/i, '');
    // Drop trailing ".", "v.", " s.NN", and section refs — we want base statute name only
    cleaned = cleaned.replace(/[.,]\s*$/, '');
    cleaned = cleaned.replace(/[)\]]+\s*$/, '');                   // strip stray closing brackets
    cleaned = cleaned.replace(/\s+s\.?\s*\d+[A-Za-z]*(\s*\(\d+\))?\s*$/i, '');
    cleaned = cleaned.replace(/\s+read\s+with.*$/i, '');            // "X read with Y" → X
    cleaned = cleaned.replace(/\s+\[\d{4}\].*$/, '');               // strip case-citation tails
    cleaned = cleaned.replace(/\s+v\s+.*$/i, '');                   // strip case-name tails
    cleaned = cleaned.replace(/\s+(Exemption|Regulations)\s.*$/i, '');
    cleaned = cleaned.replace(/^Order\s+\d+.*$/i, '');              // drop "Order 83 ..." (court rule paras, not statutes)
    cleaned = cleaned.replace(/^Strata Titles Act\s+2013\s*$/i, 'Strata Management Act 2013');
    cleaned = cleaned.replace(/&\s+Form\s+\d+[A-Za-z]*,?\s*/i, '');
    // Collapse all internal whitespace and normalise dashes/ampersands so the
    // canonical map below matches reliably.
    cleaned = cleaned.replace(/[—–]/g, '-').replace(/\s+/g, ' ').trim();
    // Apply canonical mapping
    let dropped = false;
    for (const [rx, canon] of STATUTE_CANONICAL) {
      if (rx.test(cleaned)) {
        if (!canon) { dropped = true; break; }
        cleaned = canon; break;
      }
    }
    if (dropped) continue;
    if (cleaned.length < 6 || cleaned.length > 120) continue;
    if (STATUTE_BLOCKLIST.some(rx => rx.test(cleaned))) continue;
    // Must contain either a 4-digit year, "Act", "Code", "Order", "Rules", "Constitution"
    if (!/(Act|Code|Order|Rules|Constitution|\b\d{4}\b)/i.test(cleaned)) continue;
    STATUTES.add(cleaned);
  }
}

// ─── Page helpers ────────────────────────────────────────────────────
let bodyStarted = false;
let inChrome = false;
function newPage() {
  doc.addPage();
}
doc.on('pageAdded', () => {
  if (!bodyStarted || inChrome) return;
  inChrome = true;
  const savedY = doc.y;
  const savedX = doc.x;
  // Temporarily neutralise top/bottom margins so chrome writes outside the
  // body region do NOT trigger pdfkit's automatic page-overflow.
  const origTop = doc.page.margins.top;
  const origBottom = doc.page.margins.bottom;
  doc.page.margins.top = 0;
  doc.page.margins.bottom = 0;
  doc.save();
  doc.font(SERIF_I).fontSize(9).fillColor('#444');
  const ph = currentRunningHead || '';
  doc.text(ph, ML, 40, { width: CW, align: 'center', lineBreak: false });
  const folio = doc.bufferedPageRange().count;
  doc.font(SERIF).fontSize(10).fillColor('#000')
     .text(String(folio), ML, PAGE_H - 50, { width: CW, align: 'center', lineBreak: false });
  doc.restore();
  doc.page.margins.top = origTop;
  doc.page.margins.bottom = origBottom;
  doc.x = savedX;
  doc.y = savedY;
  inChrome = false;
});

function currentPageNumber(): number {
  return doc.bufferedPageRange().count;
}

function ensureSpace(needed: number) {
  if (doc.y + needed > TEXT_BOTTOM) newPage();
}

// ─── Typography primitives ───────────────────────────────────────────
function H1(text: string) {
  ensureSpace(120);
  doc.moveDown(2);
  doc.font(SERIF_B).fontSize(24).fillColor('#000')
     .text(text, ML, doc.y, { width: CW, align: 'center' });
  doc.moveDown(0.4);
  // accent rule
  const y = doc.y;
  doc.moveTo(PAGE_W / 2 - 60, y).lineTo(PAGE_W / 2 + 60, y).lineWidth(1).strokeColor('#000').stroke();
  doc.moveDown(1.2);
}

function H2(text: string) {
  ensureSpace(80);
  doc.moveDown(1.2);
  doc.font(SERIF_B).fontSize(16).fillColor('#000')
     .text(text, ML, doc.y, { width: CW });
  doc.moveDown(0.5);
}

function H3(text: string) {
  ensureSpace(40);
  doc.moveDown(0.7);
  doc.font(SERIF_B).fontSize(12).fillColor('#000')
     .text(text, ML, doc.y, { width: CW });
  doc.moveDown(0.3);
}

function H4(text: string) {
  ensureSpace(28);
  doc.moveDown(0.4);
  doc.font(SERIF_BI).fontSize(11).fillColor('#000')
     .text(text, ML, doc.y, { width: CW });
  doc.moveDown(0.2);
}

// Body paragraph that supports inline italics for case names by scanning
// against the CASES list. Splits text into runs and emits italic case names.
const allCaseNamesSorted = [...CASES.map(c => c.title)].sort((a, b) => b.length - a.length);

function emitInlineItalicised(text: string) {
  // Find the longest case-name occurrences and split
  // Simple approach: linear scan, build list of (start, len, italicText)
  type Span = { start: number; end: number; italic: boolean; text: string };
  const lower = text.toLowerCase();
  const marks: { start: number; end: number; italicText: string }[] = [];
  for (const name of allCaseNamesSorted) {
    if (name.length < 8) continue;
    let from = 0;
    const target = name.toLowerCase();
    while (true) {
      const idx = lower.indexOf(target, from);
      if (idx === -1) break;
      // Check non-overlap with existing marks
      const overlap = marks.some(m => !(idx + name.length <= m.start || idx >= m.end));
      if (!overlap) marks.push({ start: idx, end: idx + name.length, italicText: text.slice(idx, idx + name.length) });
      from = idx + name.length;
    }
  }
  marks.sort((a, b) => a.start - b.start);
  const runs: Span[] = [];
  let cursor = 0;
  for (const m of marks) {
    if (m.start > cursor) runs.push({ start: cursor, end: m.start, italic: false, text: text.slice(cursor, m.start) });
    runs.push({ start: m.start, end: m.end, italic: true, text: m.italicText });
    cursor = m.end;
  }
  if (cursor < text.length) runs.push({ start: cursor, end: text.length, italic: false, text: text.slice(cursor) });
  if (runs.length === 0) runs.push({ start: 0, end: text.length, italic: false, text });
  // Emit
  runs.forEach((r, i) => {
    doc.font(r.italic ? SERIF_I : SERIF);
    doc.text(r.text, { continued: i < runs.length - 1 });
  });
}

function P(text: string, opts?: { indent?: number }) {
  if (!text) return;
  doc.font(SERIF).fontSize(11).fillColor('#000');
  const para = text.replace(/\r/g, '').trim();
  doc.text('', ML + (opts?.indent ?? 0), doc.y, { width: CW - (opts?.indent ?? 0), align: 'justify', lineGap: 2 });
  emitInlineItalicised(para);
  doc.moveDown(0.5);
}

// Render content blocks with bullet/numbered awareness
function renderContent(content: string) {
  const lines = content.split('\n');
  let buffer: string[] = [];
  const flushPara = () => {
    if (!buffer.length) return;
    P(buffer.join(' '));
    buffer = [];
  };
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) { flushPara(); continue; }
    if (/^[•\-]\s+/.test(line) || /^\d+\.\s+/.test(line)) {
      flushPara();
      doc.font(SERIF).fontSize(11).fillColor('#000');
      doc.text('', ML + 18, doc.y, { width: CW - 18, align: 'left', lineGap: 2 });
      const m = line.match(/^([•\-]|\d+\.)\s+(.*)$/);
      const marker = m ? m[1] : '•';
      const rest = m ? m[2] : line;
      doc.font(SERIF_B).text(marker.replace('-', '•') + '  ', { continued: true });
      doc.font(SERIF);
      emitInlineItalicised(rest);
      doc.moveDown(0.2);
    } else {
      buffer.push(line);
    }
  }
  flushPara();
}

// ─── Add a heading and record TOC entry ──────────────────────────────
function partOpener(title: string, subtitle?: string) {
  newPage();
  // Center vertically
  doc.y = PAGE_H / 2 - 80;
  doc.font(SERIF).fontSize(11).fillColor('#666')
     .text('PART', ML, doc.y, { width: CW, align: 'center', characterSpacing: 4 });
  doc.moveDown(0.5);
  doc.font(SERIF_B).fontSize(36).fillColor('#000')
     .text(title, ML, doc.y, { width: CW, align: 'center' });
  if (subtitle) {
    doc.moveDown(0.6);
    doc.font(SERIF_I).fontSize(13).fillColor('#333')
       .text(subtitle, ML, doc.y, { width: CW, align: 'center' });
  }
  TOC.push({ level: 'part', label: title, page: currentPageNumber() });
  currentPart = title;
  currentRunningHead = title.toUpperCase();
}

function chapter(title: string, opts?: { runningHead?: string }) {
  newPage();
  doc.font(SERIF).fontSize(10).fillColor('#666')
     .text('CHAPTER', ML, doc.y, { width: CW, align: 'left', characterSpacing: 3 });
  doc.moveDown(0.3);
  doc.font(SERIF_B).fontSize(20).fillColor('#000')
     .text(title, ML, doc.y, { width: CW });
  doc.moveDown(0.4);
  const y = doc.y;
  doc.moveTo(ML, y).lineTo(ML + 80, y).lineWidth(1).strokeColor('#000').stroke();
  doc.moveDown(1);
  TOC.push({ level: 'chapter', label: title, page: currentPageNumber() });
  currentRunningHead = (opts?.runningHead ?? title).toUpperCase();
}

function section(title: string) {
  H2(title);
  TOC.push({ level: 'section', label: title, page: currentPageNumber() });
}

// ─── FRONT MATTER ────────────────────────────────────────────────────
// Cover (no running head/folio)
newPage();
doc.y = 200;
doc.font(SERIF).fontSize(10).fillColor('#444')
   .text('A PRACTITIONER\'S COMPENDIUM', ML, doc.y, { width: CW, align: 'center', characterSpacing: 6 });
doc.moveDown(2);
doc.font(SERIF_B).fontSize(34).fillColor('#000')
   .text('MALAYSIAN CONVEYANCING LAW', ML, doc.y, { width: CW, align: 'center' });
doc.moveDown(0.4);
doc.font(SERIF_I).fontSize(16).fillColor('#333')
   .text('Substantive Law, Practice, Forms & Leading Cases', ML, doc.y, { width: CW, align: 'center' });
doc.moveDown(4);
const yRule = doc.y;
doc.moveTo(PAGE_W / 2 - 100, yRule).lineTo(PAGE_W / 2 + 100, yRule).lineWidth(1).strokeColor('#000').stroke();
doc.moveDown(1.5);
doc.font(SERIF).fontSize(13).fillColor('#000')
   .text('Prof Madya Dr Shahrul Mizan Ismail', ML, doc.y, { width: CW, align: 'center' });
doc.moveDown(0.3);
doc.font(SERIF_I).fontSize(11).fillColor('#333')
   .text('Fakulti Undang-Undang', ML, doc.y, { width: CW, align: 'center' });
doc.moveDown(0.1);
doc.text('Universiti Kebangsaan Malaysia', ML, doc.y, { width: CW, align: 'center' });
doc.y = PAGE_H - 110;
doc.font(SERIF).fontSize(10).fillColor('#444')
   .text('First Edition', ML, doc.y, { width: CW, align: 'center', characterSpacing: 3 });

// Half-title
newPage();
doc.y = PAGE_H / 2 - 40;
doc.font(SERIF_B).fontSize(20).fillColor('#000')
   .text('Malaysian Conveyancing Law', ML, doc.y, { width: CW, align: 'center' });
doc.moveDown(0.5);
doc.font(SERIF_I).fontSize(12).fillColor('#333')
   .text('A Practitioner\'s Compendium', ML, doc.y, { width: CW, align: 'center' });

// Copyright / Imprint
newPage();
doc.y = MT;
doc.font(SERIF).fontSize(10).fillColor('#000')
   .text('© Prof Madya Dr Shahrul Mizan Ismail. All rights reserved.', ML, doc.y, { width: CW });
doc.moveDown(1);
doc.text('Published as the print companion to the MYConveyAI digital platform.', { width: CW });
doc.moveDown(1);
doc.text('First edition prepared from the consolidated educational corpus of the MYConveyAI application — comprising 21 substantive-law topics, 62 conveyancing workflows, 16 statutory forms, 100 leading cases and 193 legal terms.', { width: CW });
doc.moveDown(1);
doc.text('All citations conform to the Oxford Standard for the Citation of Legal Authorities (OSCOLA), adapted for Malaysian sources. Case names are italicised throughout the text. Statutes are cited by short title and section number.', { width: CW });
doc.moveDown(1);
doc.text('No part of this work constitutes legal advice. Practitioners must verify every authority and statutory provision against the current state of the law before relying on any matter discussed herein.', { width: CW });

// Author / Foreword
newPage();
doc.y = MT;
doc.font(SERIF_B).fontSize(18).fillColor('#000').text('About the Author', ML, doc.y, { width: CW });
doc.moveDown(1);
doc.font(SERIF).fontSize(11).fillColor('#000');
doc.text('Prof Madya Dr Shahrul Mizan Ismail teaches at the Faculty of Law, Universiti Kebangsaan Malaysia (UKM). His research and teaching focus on Malaysian land law, conveyancing practice and the comparative jurisprudence of indefeasibility under Torrens-system jurisdictions.', { width: CW, align: 'justify', lineGap: 2 });
doc.moveDown(2);
doc.font(SERIF_B).fontSize(18).text('Preface', ML, doc.y, { width: CW });
doc.moveDown(1);
doc.font(SERIF).fontSize(11);
const prefaceParas = [
  'This volume gathers the substantive law, the procedural workflow, the precedent forms and the leading authorities of Malaysian conveyancing into a single reference work for the practitioner, the pupil-in-chambers and the law student. Its content is drawn directly from the MYConveyAI digital teaching platform, which has served as both a learning environment and an everyday desk-tool for users of conveyancing law in Malaysia.',
  'The work is divided into five parts. Part I sets out the substantive law — the National Land Code 1965, the doctrine of indefeasibility, contract principles applicable to land transactions, the Strata Titles Act 1985, the law on caveats, the Real Property Gains Tax Act 1976 and other statutory regimes that frame the practice. Part II moves to the procedural plane and traces sixty-two distinct conveyancing workflows from sub-sale to foreclosure, each broken down into discrete chronological steps. Part III collects sixteen statutory forms most frequently encountered in practice, with annotated samples. Part IV is a synthesis of one hundred leading Malaysian cases. Part V provides a practical guide to costs, fees, stamp duty and RPGT under the Solicitors Remuneration Order 2023.',
  'Three editorial decisions deserve a brief note. First, this work avoids duplication: where Part I refers to a leading case, the reader is directed to the full treatment in Part IV rather than repeating it. Second, the same convention applies to statutory forms: workflows in Part II reference the relevant form in Part III rather than reproducing the full sample. Third, every case name in the running text is italicised in conformity with OSCOLA, and a consolidated Table of Cases and Table of Statutes appear at the end of the volume to facilitate cross-referencing.',
  'It is the author\'s hope that this compendium will be of practical service to those who practise, teach or study conveyancing law in Malaysia.',
];
for (const p of prefaceParas) {
  doc.text(p, { width: CW, align: 'justify', lineGap: 2 });
  doc.moveDown(0.6);
}

// ─── Reserve TOC pages (will fill later) ─────────────────────────────
const TOC_START_PAGE = currentPageNumber() + 1;
for (let i = 0; i < RESERVED_TOC_PAGES; i++) newPage();

// ─── BODY: turn on running head + folio ──────────────────────────────
bodyStarted = true;

// ════════════════════════════════════════════════════════════════════
// PART I — SUBSTANTIVE LAW
// ════════════════════════════════════════════════════════════════════
partOpener('I', 'The Substantive Law of Conveyancing in Malaysia');

TOPICS.forEach((topic, idx) => {
  recordStatute(topic.legislation);
  chapter(`${idx + 1}. ${topic.title}`, { runningHead: `Chapter ${idx + 1} — ${topic.title}` });
  doc.font(SERIF_I).fontSize(10).fillColor('#444')
     .text(topic.legislation, ML, doc.y, { width: CW });
  doc.moveDown(0.6);
  P(topic.intro);

  for (const s of topic.sections) {
    H3(s.heading);
    renderContent(s.content);
  }

  if (topic.keyPrinciples.length) {
    H3('Key Principles');
    doc.font(SERIF).fontSize(11).fillColor('#000');
    topic.keyPrinciples.forEach((p, i) => {
      doc.text(`${i + 1}. `, ML + 12, doc.y, { width: CW - 12, continued: true, lineGap: 2 });
      emitInlineItalicised(p);
      doc.moveDown(0.25);
    });
  }

  if (topic.keyCases.length) {
    H3('Leading Authorities');
    for (const kc of topic.keyCases) {
      const ref = lookupCanonicalCase(kc.name);
      ensureSpace(40);
      doc.font(SERIF_I).fontSize(11).fillColor('#000')
         .text(kc.name, ML + 12, doc.y, { width: CW - 12, continued: true });
      doc.font(SERIF).text(' ' + kc.citation, { continued: false });
      doc.font(SERIF).fontSize(10.5).fillColor('#222');
      doc.text('   ', ML + 24, doc.y, { width: CW - 24, continued: true });
      emitInlineItalicised(kc.principle);
      if (ref) {
        doc.font(SERIF_I).fontSize(9.5).fillColor('#666')
           .text(`   See Part IV, Case ${ref.number}, for the full report.`, ML + 24, doc.y, { width: CW - 24 });
      }
      doc.moveDown(0.4);
    }
  }
});

// ════════════════════════════════════════════════════════════════════
// PART II — CONVEYANCING WORKFLOWS
// ════════════════════════════════════════════════════════════════════
partOpener('II', 'The Sixty-Two Conveyancing Workflows');

const workflowsByCategory = new Map<string, Workflow[]>();
for (const cat of WORKFLOW_CATEGORIES) workflowsByCategory.set(cat, []);
for (const w of WORKFLOWS) {
  if (!workflowsByCategory.has(w.category)) workflowsByCategory.set(w.category, []);
  workflowsByCategory.get(w.category)!.push(w);
}

let wfCounter = 0;
for (const cat of workflowsByCategory.keys()) {
  const list = workflowsByCategory.get(cat)!;
  if (!list.length) continue;
  chapter(cat, { runningHead: `Workflows — ${cat}` });

  for (const wf of list) {
    wfCounter++;
    H3(`${wfCounter}. ${wf.title}`);
    doc.font(SERIF_I).fontSize(10).fillColor('#444')
       .text(`${wf.id} · ${wf.difficulty} · Approximate duration: ${wf.duration}`, ML, doc.y, { width: CW });
    doc.moveDown(0.4);
    P(wf.summary);

    if (wf.legislation.length) {
      H4('Statutory Framework');
      wf.legislation.forEach(l => recordStatute(l));
      doc.font(SERIF).fontSize(10.5).fillColor('#000');
      doc.text(wf.legislation.join('; ') + '.', ML + 12, doc.y, { width: CW - 12, lineGap: 2 });
      doc.moveDown(0.3);
    }

    H4('Procedural Steps');
    let lastPhase = '';
    for (const step of wf.steps) {
      if (step.phase !== lastPhase) {
        ensureSpace(36);
        doc.moveDown(0.2);
        doc.font(SERIF_BI).fontSize(10.5).fillColor('#000')
           .text(step.phase, ML + 6, doc.y, { width: CW - 6 });
        doc.moveDown(0.1);
        lastPhase = step.phase;
      }
      ensureSpace(28);
      doc.font(SERIF).fontSize(10.5).fillColor('#000');
      doc.text(`Step ${step.id}.  `, ML + 18, doc.y, { width: CW - 18, continued: true, lineGap: 1.5 });
      doc.font(SERIF_B).text(step.label, { continued: false });
      const meta: string[] = [];
      if (step.timeframe) meta.push(`Timeframe: ${step.timeframe}`);
      if (step.legalBasis) { meta.push(`Legal basis: ${step.legalBasis}`); recordStatute(step.legalBasis); }
      if (meta.length) {
        doc.font(SERIF_I).fontSize(9.5).fillColor('#444')
           .text(meta.join(' · '), ML + 30, doc.y, { width: CW - 30, lineGap: 1.5 });
      }
      if (step.tip) {
        doc.font(SERIF).fontSize(9.5).fillColor('#222')
           .text('Practice tip: ', ML + 30, doc.y, { width: CW - 30, continued: true });
        doc.font(SERIF_I).text(step.tip, { continued: false });
      }
      if (step.documents && step.documents.length) {
        doc.font(SERIF).fontSize(9.5).fillColor('#222');
        for (const d of step.documents) {
          // Cross-reference standard forms instead of duplicating the sample
          const matched = lookupForm(d.title);
          if (matched) {
            doc.text('Document: ', ML + 30, doc.y, { width: CW - 30, continued: true });
            doc.font(SERIF_I).text(d.title, { continued: true });
            doc.font(SERIF).text(` — see Part III, Form ${matched.partIII}, for the precedent.`, { continued: false });
          } else {
            doc.text('Document: ', ML + 30, doc.y, { width: CW - 30, continued: true });
            doc.font(SERIF_I).text(d.title, { continued: true });
            doc.font(SERIF).text(` — ${d.note}`, { continued: false });
          }
          doc.moveDown(0.1);
        }
      }
      doc.moveDown(0.25);
    }
    doc.moveDown(0.6);
  }
}

// ════════════════════════════════════════════════════════════════════
// PART III — STATUTORY FORMS & PRECEDENTS
// ════════════════════════════════════════════════════════════════════
partOpener('III', 'Statutory Forms & Drafting Precedents');

const formsByCategory = new Map<string, FormDoc[]>();
for (const cat of FORM_CATEGORIES) formsByCategory.set(cat, []);
for (const f of FORMS_LIBRARY) {
  if (!formsByCategory.has(f.category)) formsByCategory.set(f.category, []);
  formsByCategory.get(f.category)!.push(f);
}

let formCounter = 0;
for (const cat of formsByCategory.keys()) {
  const list = formsByCategory.get(cat)!;
  if (!list.length) continue;
  chapter(cat, { runningHead: `Forms — ${cat}` });
  for (const f of list) {
    formCounter++;
    recordStatute(f.legalBasis);
    H3(`Form ${formCounter}. ${f.formNumber} — ${f.name}`);
    doc.font(SERIF_I).fontSize(10).fillColor('#444')
       .text(`(${f.nameMs})`, ML, doc.y, { width: CW });
    doc.moveDown(0.3);
    H4('Legal Basis');
    P(f.legalBasis);
    H4('Purpose & Function');
    P(f.purpose);
    H4('Who Uses It');
    P(f.whoUses);
    if (f.keyFields.length) {
      H4('Key Fields');
      doc.font(SERIF).fontSize(10.5).fillColor('#000');
      f.keyFields.forEach(k => {
        doc.text('•  ', ML + 18, doc.y, { width: CW - 18, continued: true });
        emitInlineItalicised(k);
        doc.moveDown(0.05);
      });
    }
    H4('Stamp Duty');
    P(f.stampDuty);
    H4('Timeline');
    P(f.timeline);
    if (f.importantNotes.length) {
      H4('Practice Notes');
      doc.font(SERIF).fontSize(10.5).fillColor('#000');
      f.importantNotes.forEach((n, i) => {
        doc.text(`${i + 1}. `, ML + 12, doc.y, { width: CW - 12, continued: true, lineGap: 2 });
        emitInlineItalicised(n);
        doc.moveDown(0.1);
      });
    }
    H4('Precedent');
    doc.font('Courier').fontSize(8.5).fillColor('#000');
    doc.text(f.sample, ML + 18, doc.y, { width: CW - 18, lineGap: 1.5 });
    doc.font(SERIF);
    doc.moveDown(0.7);
  }
}

// ════════════════════════════════════════════════════════════════════
// PART IV — LEADING CASES (one hundred)
// ════════════════════════════════════════════════════════════════════
partOpener('IV', 'One Hundred Leading Malaysian Cases');

// Group by topic. Topic labels become H2 dividers (no TOC entry — keeps TOC tight)
chapter('The One Hundred Leading Cases', { runningHead: 'Leading Cases' });
const casesByTopic = new Map<string, CaseDef[]>();
for (const c of CASES) {
  if (!casesByTopic.has(c.topic)) casesByTopic.set(c.topic, []);
  casesByTopic.get(c.topic)!.push(c);
}
let caseCounter = 0;
for (const [topicLabel, list] of casesByTopic) {
  H2(topicLabel);
  for (const c of list) {
    caseCounter++;
    ensureSpace(120);
    doc.font(SERIF_B).fontSize(12).fillColor('#000')
       .text(`Case ${caseCounter}.  `, ML, doc.y, { width: CW, continued: true });
    doc.font(SERIF_BI).text(c.title, { continued: true });
    doc.font(SERIF_B).text(`  ${c.citation}`, { continued: false });
    doc.moveDown(0.2);
    doc.font(SERIF_I).fontSize(10).fillColor('#444')
       .text(c.tags.join(' · '), ML, doc.y, { width: CW });
    doc.moveDown(0.3);
    H4('Facts');
    P(c.facts);
    H4('Issue');
    P(c.issue);
    H4('Held');
    P(c.held);
    H4('Significance');
    P(c.significance);
    doc.moveDown(0.5);
  }
}

// ════════════════════════════════════════════════════════════════════
// PART V — COSTS, FEES, STAMP DUTY & RPGT
// ════════════════════════════════════════════════════════════════════
partOpener('V', 'Costs, Fees, Stamp Duty and RPGT');

chapter('The Statutory Costs Framework', { runningHead: 'Costs, Fees, Stamp Duty & RPGT' });

P('A Malaysian conveyancing transaction attracts a layered set of statutory and professional charges. This Part consolidates the rates, exemptions and computation rules currently in force, drawing on the Stamp Act 1949, the Real Property Gains Tax Act 1976, the Solicitors Remuneration Order 2023 and current Pejabat Tanah charging schedules. The companion online assessor in the MYConveyAI platform performs these computations interactively; the rules set out here are the legal authority on which those computations are made.');

H3('Stamp Duty on the Memorandum of Transfer (Ad Valorem)');
recordStatute('Stamp Act 1949');
P('Stamp duty on a Form 14A Memorandum of Transfer is computed by reference to the higher of the consideration and the market value of the property. The current bands are:');
P('• First RM100,000 — 1.0%.');
P('• Next RM400,000 (RM100,001 to RM500,000) — 2.0%.');
P('• Next RM500,000 (RM500,001 to RM1,000,000) — 3.0%.');
P('• Above RM1,000,000 — 4.0%.');
P('The first-home exemption (Malaysian citizen, never previously owned residential property): full exemption on the first RM500,000 of consideration; fifty per cent exemption on the next RM500,000 (so the effective marginal rate between RM500,000 and RM1,000,000 is reduced by half). Above RM1,000,000 the exemption ceases and the full ad valorem scale applies to the entire price.');

H3('Stamp Duty on the Loan Agreement');
P('A principal loan agreement attracts stamp duty at 0.5% of the principal sum, payable under the Stamp Act 1949. Subordinate or supplemental security documents are typically chargeable at the nominal rate of RM10. Failure to stamp within thirty days of execution attracts a five-fold penalty and renders the instrument inadmissible in evidence.');

H3('Solicitors\' Remuneration Order 2023');
recordStatute('Solicitors Remuneration Order 2023');
P('The SRO 2023 prescribes the minimum scale fee for conveyancing matters. The scale (applicable to both the SPA / Transfer and the Loan / Charge documentation) is:');
P('• First RM500,000 — 1.0%.');
P('• RM500,001 to RM1,000,000 — 0.8%.');
P('• RM1,000,001 to RM3,000,000 — 0.7%.');
P('• RM3,000,001 to RM5,000,000 — 0.6%.');
P('• Above RM5,000,000 — negotiable, but not less than 0.5%.');
P('The minimum fee is RM500. Charging below the scale is an offence under the Legal Profession Act 1976 and may attract disciplinary sanction by the Advocates and Solicitors Disciplinary Board.');

H3('Real Property Gains Tax (RPGT)');
recordStatute('Real Property Gains Tax Act 1976');
P('RPGT is charged on the chargeable gain on disposal of a real property or shares in a real property company. The current rates are:');
P('• Malaysian citizens and permanent residents — 30% (years 1–3); 20% (year 4); 15% (year 5); nil (year 6 onwards).');
P('• Non-citizens and non-permanent residents — 30% (years 1–5); 10% (year 6 onwards).');
P('• Companies incorporated in Malaysia — 30% (years 1–3); 20% (year 4); 15% (year 5); 10% (year 6 onwards).');
P('Statutory exemptions include (a) the once-in-a-lifetime exemption available to a Malaysian citizen individual on disposal of one private residential property; (b) gifts between spouses, parents and children where no money changes hands; and (c) compulsory acquisitions under the Land Acquisition Act 1960.');
P('Section 21B of the RPGT Act imposes a withholding obligation on the purchaser: three per cent of the consideration must be retained and remitted to the Inland Revenue Board within sixty days of the SPA date. The vendor files Form CKHT 1A and the purchaser files Form CKHT 2A within the same period.');

H3('Other Disbursements');
P('In addition to the principal duties and fees, a typical sub-sale transaction will incur:');
P('• Land search fees at the relevant Pejabat Tanah dan Galian — approximately RM20–RM30 per title.');
P('• Bankruptcy or insolvency search at the Department of Insolvency — approximately RM10–RM25 per search.');
P('• Land Office presentment and registration fees — between RM10 and RM300 depending on transaction value and state.');
P('• Miscellaneous disbursements (commissioner for oaths, courier, postage and photocopying) — typically RM200–RM400.');

// ════════════════════════════════════════════════════════════════════
// END MATTER — Glossary, Tables, Bibliography
// ════════════════════════════════════════════════════════════════════

// Glossary
partOpener('Glossary', 'A Concise Lexicon of Malaysian Conveyancing Terms');

const termsByCategory = new Map<string, Term[]>();
for (const t of TERMS) {
  if (!termsByCategory.has(t.category)) termsByCategory.set(t.category, []);
  termsByCategory.get(t.category)!.push(t);
}
const sortedCats = [...termsByCategory.keys()].sort();
chapter('Glossary of Terms', { runningHead: 'Glossary' });
for (const cat of sortedCats) {
  H2(cat);
  const list = termsByCategory.get(cat)!.sort((a, b) => a.term.localeCompare(b.term));
  for (const t of list) {
    ensureSpace(40);
    doc.font(SERIF_B).fontSize(11).fillColor('#000')
       .text(t.term, ML, doc.y, { width: CW });
    doc.moveDown(0.1);
    doc.font(SERIF).fontSize(10.5).fillColor('#000');
    doc.text('Meaning. ', ML + 12, doc.y, { width: CW - 12, continued: true, lineGap: 2 });
    emitInlineItalicised(t.meaning);
    doc.font(SERIF).fontSize(10.5);
    doc.text('Source. ', ML + 12, doc.y, { width: CW - 12, continued: true });
    doc.font(SERIF_I).text(t.source, { continued: false });
    recordStatute(t.source);
    doc.font(SERIF).fontSize(10.5);
    doc.text('Illustration. ', ML + 12, doc.y, { width: CW - 12, continued: true });
    doc.font(SERIF_I);
    emitInlineItalicised(t.example);
    doc.font(SERIF);
    doc.moveDown(0.5);
  }
}

// Table of Cases (alphabetical, with citation, OSCOLA-italic)
partOpener('Table of Cases', 'Alphabetical Index of All Authorities Cited');
chapter('Table of Cases');
const tableCases = [...CASES].sort((a, b) => a.title.localeCompare(b.title));
doc.font(SERIF).fontSize(10.5).fillColor('#000');
for (const c of tableCases) {
  ensureSpace(18);
  doc.font(SERIF_I).text(c.title, ML, doc.y, { width: CW, continued: true });
  doc.font(SERIF).text(` ${c.citation}.`, { continued: false, lineGap: 2 });
  doc.moveDown(0.05);
}

// Table of Statutes (deduped + alphabetical)
partOpener('Table of Statutes', 'Statutory Provisions Cited');
chapter('Table of Statutes');
const sortedStatutes = [...STATUTES].sort((a, b) => a.localeCompare(b));
doc.font(SERIF).fontSize(10.5).fillColor('#000');
for (const s of sortedStatutes) {
  ensureSpace(14);
  doc.text('• ', ML, doc.y, { width: CW, continued: true });
  doc.text(s, { continued: false, lineGap: 2 });
}

// Bibliography (secondary sources)
partOpener('Bibliography', 'Selected Secondary Sources');
chapter('Selected Secondary Sources');
const biblio = [
  'Buang, Salleh, Malaysian Torrens System (2nd edn, Dewan Bahasa dan Pustaka 2007).',
  'Das, S K, The Torrens System in Malaysia (Malayan Law Journal 1963).',
  'Judith Sihombing, National Land Code: A Commentary (3rd edn, LexisNexis 2018).',
  'Teo Keang Sood and Khaw Lake Tee, Land Law in Malaysia: Cases and Commentary (3rd edn, LexisNexis 2012).',
  'Wong, David S Y, Tenure and Land Dealings in the Malay States (Singapore University Press 1975).',
  'Yusoff, Sharifah Suhana, Malaysian Legal System (4th edn, Sweet & Maxwell Asia 2016).',
  'Bar Council of Malaysia, Conveyancing Practice Manual (current edition).',
  'Federal Court of Malaysia, Practice Directions (consolidated).',
  'Inland Revenue Board of Malaysia (LHDN), Public Rulings on Real Property Gains Tax and Stamp Duty (current series).',
];
doc.font(SERIF).fontSize(10.5).fillColor('#000');
for (const b of biblio) {
  ensureSpace(16);
  doc.text(b, ML, doc.y, { width: CW, lineGap: 2 });
  doc.moveDown(0.2);
}

// ════════════════════════════════════════════════════════════════════
// BACKFILL TABLE OF CONTENTS into reserved pages
// ════════════════════════════════════════════════════════════════════
const range = doc.bufferedPageRange();
const totalPages = range.count;

// Switch to TOC start page
doc.switchToPage(TOC_START_PAGE - 1); // 0-indexed
doc.y = MT;
doc.font(SERIF_B).fontSize(20).fillColor('#000')
   .text('Contents', ML, doc.y, { width: CW, align: 'center' });
doc.moveDown(0.3);
const yLine = doc.y;
doc.moveTo(PAGE_W / 2 - 40, yLine).lineTo(PAGE_W / 2 + 40, yLine).strokeColor('#000').lineWidth(0.8).stroke();
doc.moveDown(1.2);

let tocPageOffset = 0;
function ensureTocSpace(needed: number) {
  if (doc.y + needed > TEXT_BOTTOM) {
    tocPageOffset++;
    if (tocPageOffset >= RESERVED_TOC_PAGES) {
      // Out of reserved space; collapse remaining entries silently (rare for our N)
      throw new Error(`TOC overflow — increase RESERVED_TOC_PAGES (current ${RESERVED_TOC_PAGES})`);
    }
    doc.switchToPage(TOC_START_PAGE - 1 + tocPageOffset);
    doc.y = MT;
  }
}

// Render a TOC entry as a single visual line: label on left, dots filling
// the middle, page number on right. Done with three independent draws on
// the same baseline (no `continued` chain — that propagates the width).
function tocLine(label: string, pageStr: string, opts: { bold: boolean; size: number; indent: number; topGap: number }) {
  ensureTocSpace(opts.size + 8 + opts.topGap);
  if (opts.topGap) doc.y += opts.topGap;
  const baselineY = doc.y;
  doc.font(opts.bold ? SERIF_B : SERIF).fontSize(opts.size).fillColor('#000');
  // 1. Label (left)
  const xLabel = ML + opts.indent;
  const maxLabelW = CW - opts.indent - 60; // reserve space for page number + leaders
  const labelW = Math.min(doc.widthOfString(label), maxLabelW);
  doc.text(label, xLabel, baselineY, { width: maxLabelW, lineBreak: false, ellipsis: true });
  // 2. Page number (right)
  doc.font(opts.bold ? SERIF_B : SERIF).fontSize(opts.size);
  const pageW = doc.widthOfString(pageStr);
  const xPage = ML + CW - pageW;
  doc.text(pageStr, xPage, baselineY, { width: pageW + 1, lineBreak: false });
  // 3. Dot leader (middle) — filled with single dots so it always fits cleanly
  doc.font(SERIF).fontSize(opts.size).fillColor('#666');
  const dotChar = '.';
  const dotW = doc.widthOfString(dotChar + ' ');
  const xDotsStart = xLabel + labelW + 6;
  const xDotsEnd = xPage - 6;
  const room = xDotsEnd - xDotsStart;
  if (room > dotW) {
    const n = Math.max(2, Math.floor(room / dotW));
    const leader = (dotChar + ' ').repeat(n);
    doc.text(leader, xDotsStart, baselineY, { width: room, lineBreak: false });
  }
  doc.fillColor('#000');
  // Advance cursor below this line
  doc.y = baselineY + opts.size + 4;
}

for (const e of TOC) {
  ensureTocSpace(18);
  if (e.level === 'part') {
    tocLine(`PART ${e.label}`, String(e.page), { bold: true, size: 12.5, indent: 0, topGap: 8 });
  } else if (e.level === 'chapter') {
    tocLine(e.label, String(e.page), { bold: false, size: 10.5, indent: 18, topGap: 0 });
  }
  // Skip section-level entries in TOC to keep it tight (no overlap, no fluff)
}

// Pad: if there are unused reserved TOC pages at the end, that creates blanks.
// But our spec forbids meaningless empty pages — we can't physically remove
// pages from PDFKit easily, but we can fill the remainder with a "Reader's
// Notes" lined area which is meaningful in a printed legal compendium.
for (let p = tocPageOffset + 1; p < RESERVED_TOC_PAGES; p++) {
  doc.switchToPage(TOC_START_PAGE - 1 + p);
  doc.y = MT;
  doc.font(SERIF_B).fontSize(14).fillColor('#000').text('Reader\'s Notes', ML, doc.y, { width: CW, align: 'left' });
  doc.moveDown(1);
  // Faint ruled lines
  let y = doc.y;
  while (y < TEXT_BOTTOM - 20) {
    doc.moveTo(ML, y).lineTo(ML + CW, y).strokeColor('#cccccc').lineWidth(0.4).stroke();
    y += 22;
  }
}

// ─── Finalise ───────────────────────────────────────────────────────
doc.flushPages();
doc.end();

await new Promise<void>((resolve, reject) => {
  writeStream.on('finish', () => resolve());
  writeStream.on('error', reject);
});

const stat = fs.statSync(OUT);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('Manuscript produced:');
console.log('  Path: ', OUT);
console.log('  Size: ', (stat.size / 1024).toFixed(1) + ' KB');
console.log('  Pages:', totalPages);
console.log('  TOC entries collected:', TOC.length);
console.log('  Cases listed in Table of Cases:', CASES.length);
console.log('  Statutes collected:', STATUTES.size);
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
