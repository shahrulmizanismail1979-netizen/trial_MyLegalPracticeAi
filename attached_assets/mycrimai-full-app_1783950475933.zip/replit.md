# MyCrimAi - Malaysian Criminal Law Practice Companion

## Overview

AI-powered Malaysian Criminal Law Practice Companion by Prof Madya Dr Shahrul Mizan Ismail, Fakulti Undang-Undang, Universiti Kebangsaan Malaysia. Features theory topics, case laws, cause papers, practice workflows, sample documents, a legal glossary, costs & fees reference, 11 AI-powered practitioner tools, and interactive practice simulators — all behind an access code login.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (artifact: criminal-law, path: /)
- **API framework**: Express 5 (artifact: api-server)
- **AI**: OpenAI via Replit AI Integrations (gpt-5.2, SSE streaming)
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **UI**: shadcn/ui components, dark theme, Tailwind CSS

## Authentication

- Access code login: `MYCRIMAI2024` (stored in env var `ACCESS_CODE`)
- Session-based auth with `express-session`
- Auth middleware (`requireAuth`) protects all content and AI API routes
- Public routes: `/api/health`, `/api/auth/*`

## AI Features

11 AI-powered tools using OpenAI GPT-5.2 with SSE streaming:

### Research & Analysis
1. **AI Legal Research** (`/workspace/ai/research`) - Multi-turn chat for Malaysian criminal law questions with statute/case citations
2. **Case Fact Analyzer** (`/workspace/ai/case-analyzer`) - Paste case facts → applicable charges, defenses, sentencing range, precedents, bail considerations
3. **Charge Sheet Analyzer** (`/workspace/ai/charge-analyzer`) - Parse charge sheets → elements to prove, defenses, sentencing guidelines, bail analysis, strategy recommendations
4. **Sentencing Predictor** (`/workspace/ai/sentencing`) - Input offence details → predicted sentencing range, comparable precedents, aggravating/mitigating analysis

### Drafting & Strategy
5. **Document Drafter** (`/workspace/ai/document-drafter`) - Generate bail applications, written submissions, mitigation pleas, notices of appeal, AG representations, criminal motions
6. **Legal Opinion Writer** (`/workspace/ai/legal-opinion`) - Generate formal structured legal opinions (client advisory, case evaluation, defence strategy, appeal prospects, plea advice)
7. **Case Strategy Planner** (`/workspace/ai/case-strategy`) - Comprehensive defence/prosecution strategy with evidence assessment, witness management, legal arguments, trial timeline, risk analysis
8. **Appeal Grounds Analyzer** (`/workspace/ai/appeal-grounds`) - Paste trial court judgment → identified appeal grounds (errors of law, misdirections, procedural irregularities, sentencing errors) with authorities

### Practice Simulators
9. **Cross-Examination Helper** (`/workspace/ai/cross-examination`) - Generate strategic cross-examination questions from witness statements with Evidence Act references
10. **Witness Examination Practice** (`/workspace/ai/witness-practice`) - Interactive simulator with 11 witness types × 4 examination modes
11. **Judge Response Practice** (`/workspace/ai/judge-practice`) - Practice advocacy before 9 judge personalities × 7 practice modes

### AI Architecture
- Backend: `artifacts/api-server/src/routes/ai/index.ts` - 11 POST endpoints with SSE streaming
- Frontend hook: `artifacts/criminal-law/src/lib/use-ai-stream.ts` - Custom React hook for SSE consumption
- Markdown renderer: `artifacts/criminal-law/src/components/ai/markdown-renderer.tsx`
- AI client: `lib/integrations-openai-ai-server` - OpenAI SDK with Replit AI Integrations proxy

## Database Tables

- `topics` - Criminal law theory topics with HTML content
- `case_laws` - Legal case precedents with citations, courts, key principles
- `cause_papers` - Court document templates
- `workflows` - Step-by-step practice procedures (steps stored as JSON)
- `sample_documents` - Template legal documents
- `glossary_terms` - Legal terminology with Malay translations
- `costs_fees` - Fee schedules with legal basis

## Frontend Pages

### Public
- `/` - Landing page
- `/login` - Access code login

### Workspace (auth required)
- `/workspace` - Dashboard with stats, AI tools section, recent activity
- `/workspace/topics` - Theory topics list with search
- `/workspace/topics/:id` - Topic detail
- `/workspace/case-laws` - Case laws list
- `/workspace/case-laws/:id` - Case law detail
- `/workspace/cause-papers` - Cause papers list
- `/workspace/cause-papers/:id` - Cause paper detail
- `/workspace/workflows` - Practice workflows list
- `/workspace/workflows/:id` - Workflow detail with numbered steps
- `/workspace/sample-documents` - Sample documents list
- `/workspace/sample-documents/:id` - Document detail
- `/workspace/glossary` - Glossary with alphabet filter
- `/workspace/glossary/:id` - Glossary term detail
- `/workspace/costs-fees` - Costs & fees list
- `/workspace/costs-fees/:id` - Cost/fee detail
- `/workspace/search` - Global search

### Guide
- `/workspace/how-to-use` - How To Use guide (comprehensive platform guide)

### AI Tools (auth required)
- `/workspace/ai/research` - AI Legal Research chat
- `/workspace/ai/case-analyzer` - Case Fact Analyzer
- `/workspace/ai/document-drafter` - Document Drafter
- `/workspace/ai/charge-analyzer` - Charge Sheet Analyzer
- `/workspace/ai/cross-examination` - Cross-Examination Helper
- `/workspace/ai/sentencing` - Sentencing Predictor
- `/workspace/ai/legal-opinion` - Legal Opinion Writer
- `/workspace/ai/case-strategy` - Case Strategy Planner
- `/workspace/ai/appeal-grounds` - Appeal Grounds Analyzer
- `/workspace/ai/witness-practice` - Witness Examination Practice simulator
- `/workspace/ai/judge-practice` - Judge Response Practice simulator

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/criminal-law run dev` — run frontend locally

## Key Libraries

- `lib/api-spec` - OpenAPI spec and codegen config
- `lib/api-client-react` - Generated React Query hooks
- `lib/api-zod` - Generated Zod validation schemas
- `lib/db` - Drizzle ORM schema and database connection
- `lib/integrations-openai-ai-server` - OpenAI SDK integration. The shared client (`src/client.ts`) prefers `OPENAI_API_KEY` (direct `api.openai.com`) when set, and falls back to `AI_INTEGRATIONS_OPENAI_*` proxy variables otherwise. We switched to a direct key after the Replit AI Integrations proxy started returning "ApiKey not approved" 401s in both dev and production.
- `scripts/src/seed.ts` - Database seed script with Malaysian criminal law content

## Voice Features (TTS + STT)

All 11 AI tools support voice mode powered by the browser's Web Speech API:
- `artifacts/criminal-law/src/lib/use-voice.ts` — `useVoice()` hook (TTS auto-speak, mic STT, voice selection, persistent enabled state in localStorage)
  - Chunks long responses (max 180 chars per utterance, sentence-grouped + hard-split fallback) to avoid Chrome TTS truncation
  - Token-guarded `speakForce` cancels stale callbacks when called again rapidly
- `artifacts/criminal-law/src/components/ai/voice-controls.tsx` — Reusable voice toolbar (Play / Stop / Mute / voice picker) used on all single-response AI pages
- `artifacts/criminal-law/src/components/ai/mic-input-button.tsx` — Mic button for chat/text inputs
- Witness Practice and Judge Practice use inline voice controls (their own custom UI)
- All other AI pages use the shared `VoiceControls` + auto-speak `useEffect(..., [isStreaming])` pattern

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
