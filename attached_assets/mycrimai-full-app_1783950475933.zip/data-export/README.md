# MyCrimAi — Full App Export

## Contents
- Complete source code (pnpm monorepo: frontend, API server, shared libs, seed scripts)
- `data-export/legacy_users_access_codes.csv` — all 92 legacy user access codes from production (spreadsheet-friendly)
- `data-export/legacy_users_access_codes.sql` — same data as ready-to-run SQL restore script

## Restoring users on a new database
1. Create the schema first: `pnpm --filter @workspace/db run push`
2. Then run the SQL file: `psql "$DATABASE_URL" -f data-export/legacy_users_access_codes.sql`

## Seeding reference content (topics, cause papers, documents, etc.)
Content is code-defined: `RUN_EXPAND_SEED=1 pnpm --filter @workspace/scripts exec tsx src/expand-seed.ts`

## Required environment variables
DATABASE_URL, SESSION_SECRET, MASTER_ACCESS_CODE, OPENAI_API_KEY, ACCESS_CODE, Stripe keys (see replit.md)

NOTE: This export contains live user credentials (access codes) and customer emails — store it securely.
