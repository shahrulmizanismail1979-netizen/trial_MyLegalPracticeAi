import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Scale, CheckCircle2, Copy, Loader2, AlertCircle } from "lucide-react";
import { TIER_DEFINITIONS, normalizeTier } from "@workspace/entitlements";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface SuccessResponse {
  code: string;
  codes: string[];
  tier: string;
}

export function BillingSuccessPage() {
  const { toast } = useToast();
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [data, setData] = useState<SuccessResponse | null>(null);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get("session_id");
    if (!sessionId) {
      setStatus("error");
      setErrorMsg("Missing checkout session. Please contact us if you were charged.");
      return;
    }

    const baseUrl = import.meta.env.BASE_URL || "/";
    const apiUrl = `${baseUrl}api/billing/success?session_id=${encodeURIComponent(
      sessionId,
    )}`.replace(/([^:]\/)\/+/g, "$1");

    fetch(apiUrl, { credentials: "include" })
      .then(async (res) => {
        const body = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(body.message || "Could not finalize subscription.");
        return body as SuccessResponse;
      })
      .then((body) => {
        setData(body);
        setStatus("ready");
      })
      .catch((err) => {
        setErrorMsg(err.message || "Something went wrong finalizing your subscription.");
        setStatus("error");
      });
  }, []);

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code).then(
      () => toast({ title: "Copied", description: "Access code copied to clipboard." }),
      () => toast({ title: "Copy failed", variant: "destructive" }),
    );
  };

  const tierName = data ? TIER_DEFINITIONS[normalizeTier(data.tier)].name : "";

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center items-center p-4">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background z-0 pointer-events-none" />

      <div className="z-10 w-full max-w-md">
        <div className="flex justify-center mb-8">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="bg-primary/10 p-3 rounded-full border border-primary/20">
              <Scale className="h-8 w-8 text-primary" />
            </div>
          </Link>
        </div>

        <Card className="border-primary/20 bg-card/50 backdrop-blur-sm shadow-2xl shadow-primary/5">
          {status === "loading" && (
            <CardContent className="py-12 flex flex-col items-center gap-4 text-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-muted-foreground">Finalizing your subscription…</p>
            </CardContent>
          )}

          {status === "error" && (
            <>
              <CardHeader className="text-center space-y-2">
                <div className="flex justify-center">
                  <AlertCircle className="h-10 w-10 text-destructive" />
                </div>
                <CardTitle className="font-serif text-2xl">Something went wrong</CardTitle>
                <CardDescription>{errorMsg}</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                <Button asChild variant="outline">
                  <Link href="/pricing">Back to pricing</Link>
                </Button>
              </CardContent>
            </>
          )}

          {status === "ready" && data && (
            <>
              <CardHeader className="text-center space-y-2">
                <div className="flex justify-center">
                  <CheckCircle2 className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="font-serif text-2xl">
                  Welcome to {tierName}
                </CardTitle>
                <CardDescription>
                  Your subscription is active. Use the access code
                  {data.codes.length > 1 ? "s" : ""} below to sign in. Keep{" "}
                  {data.codes.length > 1 ? "them" : "it"} safe.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col gap-4">
                <div className="space-y-2">
                  {data.codes.map((code) => (
                    <div
                      key={code}
                      className="flex items-center justify-between gap-2 rounded-lg border border-primary/20 bg-background/60 px-4 py-3 font-mono text-lg tracking-wider"
                      data-testid="text-access-code"
                    >
                      <span>{code}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => copyCode(code)}
                        aria-label="Copy access code"
                        data-testid={`button-copy-${code}`}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                <Button asChild className="w-full" data-testid="button-go-to-login">
                  <Link href="/login">Sign in now</Link>
                </Button>
              </CardContent>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
