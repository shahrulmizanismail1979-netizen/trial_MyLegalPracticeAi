import { runMigrations } from "stripe-replit-sync";
import app from "./app";
import { logger } from "./lib/logger";
import { getStripeSync } from "./stripeClient";

// Configure Stripe sync (schema migrations + managed webhook + initial
// backfill). Non-fatal: the app must keep serving even if Stripe is
// unreachable or not yet connected.
async function initStripe(): Promise<void> {
  try {
    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) throw new Error("DATABASE_URL required for Stripe sync");

    // 1. Create the `stripe` schema and tables (idempotent).
    await runMigrations({ databaseUrl });

    // 2. StripeSync instance (used for webhook setup + backfill).
    const sync = await getStripeSync();
    const domains = process.env.REPLIT_DOMAINS?.split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    const host = domains?.[0] || process.env.REPLIT_DEV_DOMAIN;
    if (host) {
      const webhook = await sync.findOrCreateManagedWebhook(
        `https://${host}/api/stripe/webhook`,
      );
      logger.info({ url: webhook.url }, "Stripe managed webhook ready");
    }
    await sync.syncBackfill({ object: "all" });
    logger.info("Stripe data backfill complete");
  } catch (err) {
    logger.error({ err }, "Stripe initialization failed (continuing without it)");
  }
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const server = app.listen(port, "0.0.0.0", () => {
  logger.info({ port }, "Server listening");
  void initStripe();
});

server.on("error", (err) => {
  logger.error({ err, port }, "Failed to bind server port");
  process.exit(1);
});
