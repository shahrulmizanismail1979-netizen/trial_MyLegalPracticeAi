import { Router, type IRouter } from "express";
import { db, accessCodesTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import {
  isPurchasableTier,
  isCurrency,
  normalizeTier,
  tierSeats,
  TIER_DEFINITIONS,
  STRIPE_TIER_METADATA_KEY,
  type BillingInterval,
} from "@workspace/entitlements";
import { getUncachableStripeClient } from "../stripeClient";
import { requireAuth } from "../middleware/requireAuth";
import { generateAccessCode } from "../lib/accessCodes";

const router: IRouter = Router();

const STRIPE_INTERVAL_METADATA_KEY = "mycrimai_interval";

function publicBaseUrl(): string {
  const domains = process.env.REPLIT_DOMAINS?.split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const host = domains?.[0] || process.env.REPLIT_DEV_DOMAIN;
  if (!host) {
    throw new Error("No public domain available for checkout redirect URLs");
  }
  return `https://${host}`;
}

function isInterval(value: unknown): value is BillingInterval {
  return value === "month" || value === "year";
}

// Create a Stripe Checkout session for a tier/interval/currency.
// Public: purchasing happens before the buyer has an access code.
router.post("/billing/checkout", async (req, res): Promise<void> => {
  const tier = (req.body?.tier ?? "").toString();
  const interval = (req.body?.interval ?? "month").toString();
  const currency = (req.body?.currency ?? "usd").toString().toLowerCase();

  if (!isPurchasableTier(tier)) {
    res.status(400).json({ message: "Unknown plan." });
    return;
  }
  if (!isInterval(interval)) {
    res.status(400).json({ message: "Invalid billing interval." });
    return;
  }
  if (!isCurrency(currency)) {
    res.status(400).json({ message: "Unsupported currency." });
    return;
  }

  try {
    const stripe = await getUncachableStripeClient();
    const search = await stripe.prices.search({
      query: `active:'true' AND metadata['${STRIPE_TIER_METADATA_KEY}']:'${tier}' AND metadata['${STRIPE_INTERVAL_METADATA_KEY}']:'${interval}'`,
      limit: 1,
    });
    const price = search.data[0];
    if (!price) {
      req.log.warn({ tier, interval }, "No Stripe price found for plan");
      res.status(503).json({
        message:
          "Online checkout is not available yet. Please try again shortly or contact us.",
      });
      return;
    }

    const base = publicBaseUrl();
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: price.id, quantity: 1 }],
      currency,
      allow_promotion_codes: true,
      success_url: `${base}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${base}/pricing`,
      metadata: {
        [STRIPE_TIER_METADATA_KEY]: tier,
        [STRIPE_INTERVAL_METADATA_KEY]: interval,
        mycrimai_currency: currency,
      },
      subscription_data: {
        metadata: {
          [STRIPE_TIER_METADATA_KEY]: tier,
          [STRIPE_INTERVAL_METADATA_KEY]: interval,
        },
      },
    });

    if (!session.url) {
      res.status(502).json({ message: "Could not start checkout." });
      return;
    }
    res.json({ url: session.url });
  } catch (err) {
    req.log.error({ err }, "Checkout session creation failed");
    res.status(500).json({ message: "Could not start checkout. Please try again." });
  }
});

// Finalize a completed checkout: issue (or return existing) tiered access
// code(s) tied to the Stripe subscription. Idempotent per subscription.
router.get("/billing/success", async (req, res): Promise<void> => {
  const sessionId = (req.query?.session_id ?? "").toString().trim();
  if (!sessionId) {
    res.status(400).json({ message: "Missing checkout session id." });
    return;
  }

  try {
    const stripe = await getUncachableStripeClient();
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ["subscription", "customer"],
    });

    // Only issue access once the session is complete AND payment is settled.
    // (subscription mode marks "no_payment_required" for trials/100%-off codes.)
    const paymentSettled =
      session.payment_status === "paid" ||
      session.payment_status === "no_payment_required";
    if (session.status !== "complete" || !paymentSettled) {
      res.status(400).json({ message: "Payment is not yet complete." });
      return;
    }

    const tier = normalizeTier(session.metadata?.[STRIPE_TIER_METADATA_KEY]);
    if (!isPurchasableTier(tier)) {
      res.status(400).json({ message: "Could not determine your plan." });
      return;
    }

    const subscriptionId =
      typeof session.subscription === "string"
        ? session.subscription
        : session.subscription?.id;
    const customerId =
      typeof session.customer === "string"
        ? session.customer
        : session.customer?.id;
    const email = session.customer_details?.email ?? null;

    if (!subscriptionId || !customerId) {
      res.status(400).json({ message: "Subscription details unavailable." });
      return;
    }

    const seats = tierSeats(tier);
    const tierName = TIER_DEFINITIONS[tier].name;

    // Issue codes atomically per subscription. A transaction-scoped advisory
    // lock serializes concurrent finalizations of the same subscription so the
    // read-then-insert below cannot double-issue seat bundles.
    const codes = await db.transaction(async (tx) => {
      await tx.execute(
        sql`SELECT pg_advisory_xact_lock(hashtext(${subscriptionId}))`,
      );

      const existing = await tx
        .select()
        .from(accessCodesTable)
        .where(eq(accessCodesTable.stripeSubscriptionId, subscriptionId));
      if (existing.length > 0) {
        return existing.map((c) => c.code);
      }

      const values = Array.from({ length: seats }, (_, i) => ({
        code: generateAccessCode(),
        label:
          seats > 1
            ? `${tierName} subscription (seat ${i + 1}/${seats})`
            : `${tierName} subscription`,
        isActive: true,
        tier,
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId,
        customerEmail: email,
        subscriptionStatus: "active",
        isOwner: i === 0,
      }));

      const created = await tx
        .insert(accessCodesTable)
        .values(values)
        .returning();
      return created.map((c) => c.code);
    });

    res.json({ code: codes[0], codes, tier });
  } catch (err) {
    req.log.error({ err }, "Checkout success finalization failed");
    res
      .status(500)
      .json({ message: "Could not finalize your subscription. Please contact us." });
  }
});

// Stripe billing portal for the logged-in subscriber to manage their plan.
router.post(
  "/billing/portal",
  requireAuth,
  async (req, res): Promise<void> => {
    const row = res.locals.accessCode as
      | { stripeCustomerId?: string | null; isOwner?: boolean }
      | undefined;
    const customerId = row?.stripeCustomerId;
    if (!customerId) {
      res.status(400).json({
        message: "No billing account is linked to this access code.",
      });
      return;
    }
    // Only the owner seat (the buyer) may manage billing; additional seats on a
    // multi-seat subscription cannot cancel or modify the whole plan.
    if (!row?.isOwner) {
      res.status(403).json({
        message:
          "Only the account owner can manage billing. Please contact whoever set up your subscription.",
      });
      return;
    }

    try {
      const stripe = await getUncachableStripeClient();
      const portal = await stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: `${publicBaseUrl()}/workspace`,
      });
      res.json({ url: portal.url });
    } catch (err) {
      req.log.error({ err }, "Billing portal session creation failed");
      res.status(500).json({ message: "Could not open the billing portal." });
    }
  },
);

export default router;
