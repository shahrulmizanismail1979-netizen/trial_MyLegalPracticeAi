// Stripe integration (Replit connector: ccfg_stripe).
// Keep this handler minimal — stripe-replit-sync owns all webhook processing
// and syncs Stripe data into the local `stripe` schema.
import { getStripeSync } from "./stripeClient";

export class WebhookHandlers {
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    if (!Buffer.isBuffer(payload)) {
      throw new Error(
        "STRIPE WEBHOOK ERROR: Payload must be a Buffer. Received type: " +
          typeof payload +
          ". Ensure the webhook route is registered BEFORE express.json().",
      );
    }

    const sync = await getStripeSync();
    await sync.processWebhook(payload, signature);
  }
}
