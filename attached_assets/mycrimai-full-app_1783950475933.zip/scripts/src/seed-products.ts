// Seed Stripe products and prices for the four MyCrimAi subscription tiers.
// Each tier has a monthly and an annual price, each priced in USD with
// currency_options for EUR/GBP/MYR/SGD/AUD/CAD so checkout can charge in the
// buyer's chosen currency. Idempotent: re-running reuses existing products and
// skips prices that already exist (matched by metadata).
import {
  PURCHASABLE_TIERS,
  TIER_DEFINITIONS,
  CURRENCIES,
  priceMinor,
  STRIPE_TIER_METADATA_KEY,
  type PurchasableTier,
  type BillingInterval,
  type CurrencyCode,
} from "@workspace/entitlements";
import { getUncachableStripeClient } from "./stripeClient";

const INTERVAL_METADATA_KEY = "mycrimai_interval";
const INTERVALS: BillingInterval[] = ["month", "year"];

async function findProductForTier(
  stripe: Awaited<ReturnType<typeof getUncachableStripeClient>>,
  tier: PurchasableTier,
): Promise<string | null> {
  const search = await stripe.products.search({
    query: `active:'true' AND metadata['${STRIPE_TIER_METADATA_KEY}']:'${tier}'`,
    limit: 1,
  });
  return search.data[0]?.id ?? null;
}

async function priceExists(
  stripe: Awaited<ReturnType<typeof getUncachableStripeClient>>,
  tier: PurchasableTier,
  interval: BillingInterval,
): Promise<boolean> {
  const search = await stripe.prices.search({
    query: `active:'true' AND metadata['${STRIPE_TIER_METADATA_KEY}']:'${tier}' AND metadata['${INTERVAL_METADATA_KEY}']:'${interval}'`,
    limit: 1,
  });
  return search.data.length > 0;
}

function buildCurrencyOptions(tier: PurchasableTier, interval: BillingInterval) {
  const options: Record<string, { unit_amount: number }> = {};
  for (const { code } of CURRENCIES) {
    if (code === "usd") continue;
    options[code] = {
      unit_amount: priceMinor(tier, interval, code as CurrencyCode),
    };
  }
  return options;
}

async function main(): Promise<void> {
  const stripe = await getUncachableStripeClient();

  for (const tier of PURCHASABLE_TIERS) {
    const def = TIER_DEFINITIONS[tier];

    let productId = await findProductForTier(stripe, tier);
    if (!productId) {
      const product = await stripe.products.create({
        name: `MyCrimAi ${def.name}`,
        description: def.tagline,
        metadata: { [STRIPE_TIER_METADATA_KEY]: tier },
      });
      productId = product.id;
      console.log(`Created product: ${product.name} (${product.id})`);
    } else {
      console.log(`Reusing product for tier "${tier}" (${productId})`);
    }

    for (const interval of INTERVALS) {
      if (await priceExists(stripe, tier, interval)) {
        console.log(`  Price ${tier}/${interval} already exists — skipping`);
        continue;
      }
      const price = await stripe.prices.create({
        product: productId,
        currency: "usd",
        unit_amount: priceMinor(tier, interval, "usd"),
        currency_options: buildCurrencyOptions(tier, interval),
        recurring: { interval },
        metadata: {
          [STRIPE_TIER_METADATA_KEY]: tier,
          [INTERVAL_METADATA_KEY]: interval,
        },
      });
      console.log(
        `  Created price ${tier}/${interval}: ${price.id} ($${
          priceMinor(tier, interval, "usd") / 100
        }/${interval})`,
      );
    }
  }

  console.log("\nStripe product/price seeding complete.");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Seeding failed:", err);
    process.exit(1);
  });
