import { db, topicsTable, caseLawsTable, causePapersTable, workflowsTable, sampleDocumentsTable, glossaryTermsTable, costsFeesTable } from "@workspace/db";

async function seed() {
  await db.insert(topicsTable).values([
    {
      title: "Elements of Criminal Liability",
      description: "Understanding actus reus and mens rea under Malaysian criminal law",
      content: "Criminal liability in Malaysia is governed primarily by the Penal Code (Act 574). The two fundamental elements required to establish criminal liability are:\n\n1. **Actus Reus (Guilty Act)**: The physical element of a crime — the actual conduct, omission, or state of affairs that constitutes the offence.\n\n2. **Mens Rea (Guilty Mind)**: The mental element — the intention, knowledge, or recklessness of the accused at the time of committing the act.\n\nSection 39 of the Penal Code defines 'voluntarily' as causing an effect by means whereby the person intended to cause it, or by means which, at the time of employing those means, the person knew or had reason to believe to be likely to cause it.\n\nThe burden of proof lies with the prosecution to establish both elements beyond reasonable doubt, as stated in Section 101 of the Evidence Act 1950.",
      category: "General Principles",
      orderIndex: 1,
    },
    {
      title: "Classification of Offences",
      description: "Seizable vs non-seizable, bailable vs non-bailable offences",
      content: "Malaysian criminal law classifies offences into several categories:\n\n**By Seizability:**\n- Seizable Offences: Police may arrest without warrant (Schedule 1, CPC)\n- Non-seizable Offences: Arrest requires warrant from Magistrate\n\n**By Bail:**\n- Bailable Offences: Accused has right to bail\n- Non-bailable Offences: Bail is at court's discretion\n\n**By Severity:**\n- Summary offences: Tried by Magistrate\n- Indictable offences: May be tried by Sessions Court or High Court\n\nThe First Schedule of the Criminal Procedure Code (CPC) provides a comprehensive table classifying each offence.",
      category: "General Principles",
      orderIndex: 2,
    },
    {
      title: "Right to Counsel under Article 5(3)",
      description: "Constitutional right to legal representation in criminal proceedings",
      content: "Article 5(3) of the Federal Constitution provides: 'Where a person is arrested he shall be informed as soon as may be of the grounds of his arrest and shall be allowed to consult and be defended by a legal practitioner of his choice.'\n\nKey principles:\n- Right attaches immediately upon arrest\n- Applies to all persons regardless of citizenship\n- Cannot be unreasonably denied or delayed\n- Extends to remand proceedings\n\nLandmark cases:\n- Ooi Ah Phua v Officer-in-Charge Criminal Investigation [1975] 2 MLJ 198\n- Hashim bin Saud v Yahaya bin Hashim [1977] 2 MLJ 116",
      category: "Constitutional Rights",
      orderIndex: 3,
    },
    {
      title: "Powers of Arrest",
      description: "Police powers of arrest under the CPC and special legislation",
      content: "The powers of arrest in Malaysia are governed by the Criminal Procedure Code (CPC):\n\n**Arrest without warrant (Section 23 CPC):**\n- Any police officer may arrest without warrant any person who has been concerned in a seizable offence\n- Any person who is in possession of anything reasonably suspected to be stolen property\n- Any person who obstructs a police officer in the execution of duty\n\n**Arrest with warrant (Section 34 CPC):**\n- Court issues warrant directed to police officer\n- Must state offence and person to be arrested\n- Valid throughout Malaysia\n\n**Private person arrest (Section 27 CPC):**\n- Any private person may arrest any person committing a seizable offence in their view\n- Must hand over to police without unnecessary delay",
      category: "Criminal Procedure",
      orderIndex: 4,
    },
    {
      title: "Bail and Bond",
      description: "Law and procedure relating to bail in criminal cases",
      content: "Bail in Malaysia is governed by Chapter XXXIV of the CPC (Sections 387-400).\n\n**Bailable Offences:**\n- Accused has the right to be released on bail (Section 387)\n- Court must grant bail unless there are exceptional circumstances\n\n**Non-Bailable Offences:**\n- Bail is at the discretion of the court\n- Court considers: severity of offence, likelihood of absconding, risk of interference with witnesses\n- Capital offences: bail generally not granted\n\n**Types of Bail:**\n1. Police bail (Section 28 CPC)\n2. Court bail (Section 387-388 CPC)\n3. High Court bail (inherent jurisdiction)\n\n**Bail pending appeal:**\n- Governed by Section 311 CPC\n- Must show special circumstances",
      category: "Criminal Procedure",
      orderIndex: 5,
    },
    {
      title: "Law of Homicide",
      description: "Murder, culpable homicide, and related offences under the Penal Code",
      content: "Homicide under Malaysian law is primarily covered under Sections 299-311 of the Penal Code.\n\n**Culpable Homicide (Section 299):**\nWhoever causes death by doing an act with the intention of causing death, or with the intention of causing such bodily injury as is likely to cause death, or with the knowledge that the act is likely to cause death.\n\n**Murder (Section 300):**\nCulpable homicide amounts to murder in four circumstances:\n1. Act done with intention of causing death\n2. Act done with intention of causing bodily injury known to be likely to cause death\n3. Act done with intention of causing bodily injury sufficient in the ordinary course of nature to cause death\n4. Act done with knowledge that it is so imminently dangerous that it must in all probability cause death\n\n**Exceptions to Murder (Section 300):**\n1. Provocation (Exception 1)\n2. Private defence (Exception 2)\n3. Public servant exceeding powers (Exception 3)\n4. Sudden fight (Exception 4)\n5. Consent (Exception 5)\n\n**Punishment:**\n- Murder: Death (Section 302) or imprisonment of 30-40 years and whipping (Section 302(a))\n- Culpable homicide not amounting to murder: Up to 30 years imprisonment (Section 304)",
      category: "Substantive Criminal Law",
      orderIndex: 6,
    },
    {
      title: "Law of Theft and Related Offences",
      description: "Theft, robbery, extortion, and criminal breach of trust",
      content: "Property offences under the Penal Code:\n\n**Theft (Section 378):**\nDishonest taking of movable property out of the possession of any person without that person's consent.\n\n**Criminal Breach of Trust (Section 405):**\nEntrusted with property or dominion over property and dishonestly misappropriates or converts it.\n\n**Robbery (Section 390):**\nTheft combined with voluntary causing or attempting to cause hurt, fear of instant hurt, or wrongful restraint.\n\n**Extortion (Section 383):**\nIntentionally putting a person in fear of injury and dishonestly inducing the person to deliver property.\n\n**Key distinctions:**\n- Theft vs CBT: possession vs entrustment\n- Robbery vs theft: element of violence or fear\n- Extortion vs robbery: threatened vs immediate harm",
      category: "Substantive Criminal Law",
      orderIndex: 7,
    },
    {
      title: "Dangerous Drugs Act 1952",
      description: "Drug offences, presumptions, and penalties under the DDA",
      content: "The Dangerous Drugs Act 1952 (Act 234) is the primary legislation governing drug offences in Malaysia.\n\n**Key Offences:**\n- Section 6: Importation/exportation of dangerous drugs\n- Section 12: Possession of dangerous drugs\n- Section 13: Self-administration of dangerous drugs\n- Section 39B: Trafficking in dangerous drugs\n\n**Presumptions:**\n- Section 37(d): Possession of certain quantities creates presumption of trafficking\n- Section 37(da): Presumption of trafficking for specific amounts\n\n**Trafficking thresholds (selected):**\n- Cannabis: 200g and above\n- Heroin/morphine: 15g and above\n- Methamphetamine: 50g and above\n\n**Penalties:**\n- Trafficking: Death or life imprisonment with minimum 15 strokes of whipping\n- Possession: Up to 5 years imprisonment or RM20,000 fine or both\n- Self-administration: Up to 2 years imprisonment or RM5,000 fine or both",
      category: "Special Legislation",
      orderIndex: 8,
    },
  ]);

  await db.insert(caseLawsTable).values([
    {
      caseName: "PP v Mohd Radzi bin Abu Bakar",
      citation: "[2005] 6 MLJ 393",
      court: "Federal Court",
      year: 2005,
      summary: "The Federal Court laid down the test for establishing a prima facie case at the end of the prosecution's case in criminal trials.",
      keyPrinciples: "1. At the close of prosecution case, the court must determine whether prosecution has made out a prima facie case.\n2. The test is a maximum evaluation of the prosecution evidence.\n3. The court must consider whether the evidence, if unrebutted, would warrant conviction.\n4. This replaced the earlier 'no case to answer' test.",
      category: "Criminal Procedure",
      fullText: "This landmark decision by the Federal Court redefined the test at the close of the prosecution's case. The court held that a prima facie case is made out when the prosecution evidence, at its face value, establishes each ingredient of the offence, and if unrebutted or unexplained, would warrant a conviction. The earlier approach of merely establishing a 'no case to answer' was departed from.",
    },
    {
      caseName: "PP v Dato' Seri Anwar Ibrahim",
      citation: "[2004] 3 MLJ 405",
      court: "Federal Court",
      year: 2004,
      summary: "Important case on the standard of proof in criminal cases and the evaluation of evidence.",
      keyPrinciples: "1. The standard of proof in criminal cases is beyond reasonable doubt.\n2. Reasonable doubt must be based on reason and common sense.\n3. The court must evaluate the totality of evidence.\n4. Inconsistencies in prosecution witnesses must be carefully examined.",
      category: "Evidence",
      fullText: "The Federal Court examined the standard of proof required in criminal cases and emphasized that the prosecution must prove its case beyond reasonable doubt. The court discussed the meaning of 'beyond reasonable doubt' and its application in evaluating witness testimony and circumstantial evidence.",
    },
    {
      caseName: "Balachandran v PP",
      citation: "[2005] 2 MLJ 301",
      court: "Federal Court",
      year: 2005,
      summary: "Federal Court clarified the meaning of prima facie case and maximum evaluation of prosecution evidence.",
      keyPrinciples: "1. Prima facie case requires credible evidence proving each ingredient of the offence.\n2. Maximum evaluation means the court must assess the credibility of prosecution witnesses.\n3. If evidence is unreliable, a prima facie case is not established.\n4. This approach ensures accused persons are not called upon to defend unreliable evidence.",
      category: "Criminal Procedure",
      fullText: "In this seminal decision, the Federal Court further clarified the test for prima facie case established in Radzi's case. The court held that maximum evaluation requires the trial court to consider the credibility and reliability of prosecution evidence at the end of the prosecution's case.",
    },
  ]);

  await db.insert(causePapersTable).values([
    {
      title: "Charge Sheet (Pertuduhan)",
      court: "Magistrate's Court",
      description: "Standard format for a charge sheet in criminal cases before the Magistrate's Court",
      templateContent: "DALAM MAHKAMAH MAJISTRET DI ____________________\n\nKES JENAYAH NO: ____________________\n\nPENDAKWA RAYA\nlawan\n______________________ (Nama OKT)\nNo. K/P: ______________________\n\nPERTUDUHAN\n\nBahawa kamu pada ______________________ (tarikh), lebih kurang pukul ______________________ (masa), bertempat di ______________________ (tempat), dalam Daerah ______________________, dalam Negeri ______________________, telah ______________________ (butiran kesalahan) dan dengan itu kamu telah melakukan suatu kesalahan yang boleh dihukum di bawah Seksyen ______________________ Kanun Keseksaan.\n\nBertarikh: ______________________\n\n______________________\nTimbalan Pendakwa Raya",
      category: "Criminal Procedure",
    },
    {
      title: "Notice of Alibi (Notis Alibi)",
      court: "Sessions Court / High Court",
      description: "Notice of alibi defence to be served on the prosecution",
      templateContent: "DALAM MAHKAMAH ______________________ DI ______________________\n\nKES JENAYAH NO: ______________________\n\nPENDAKWA RAYA\nlawan\n______________________ (Nama OKT)\n\nNOTIS ALIBI\n(Di bawah Seksyen 402A Kanun Tatacara Jenayah)\n\nKepada: Timbalan Pendakwa Raya\n\nAmbil perhatian bahawa tertuduh bercadang untuk mengemukakan pembelaan alibi di dalam perbicaraan kes ini.\n\nButir-butir alibi adalah seperti berikut:\n\n1. Pada masa kejadian, tertuduh berada di ______________________\n2. Saksi-saksi alibi:\n   (a) Nama: ______________________ Alamat: ______________________\n   (b) Nama: ______________________ Alamat: ______________________\n\nBertarikh: ______________________\n\n______________________\nPeguambela Tertuduh",
      category: "Defence",
    },
    {
      title: "Bail Application (Permohonan Jaminan)",
      court: "All Courts",
      description: "Application for bail in non-bailable offences",
      templateContent: "DALAM MAHKAMAH ______________________ DI ______________________\n\nKES JENAYAH NO: ______________________\n\nPENDAKWA RAYA\nlawan\n______________________ (Nama OKT)\n\nAFIDAVIT SOKONGAN PERMOHONAN JAMINAN\n\nSaya, ______________________ (nama pemohon/penjamin), No. K/P: ______________________, beralamat di ______________________, dengan sesungguhnya berikrar dan menyatakan seperti berikut:\n\n1. Saya adalah ______________________ (hubungan) kepada tertuduh.\n2. Tertuduh telah ditangkap pada ______________________ dan dituduh di bawah Seksyen ______________________.\n3. Tertuduh tidak akan melarikan diri jika diberikan jaminan kerana ______________________ (sebab-sebab).\n4. Saya bersedia menjadi penjamin dengan jumlah jaminan yang ditetapkan oleh Mahkamah.\n\nBertarikh: ______________________\n\n______________________\nPemohon",
      category: "Criminal Procedure",
    },
  ]);

  await db.insert(workflowsTable).values([
    {
      title: "First Appearance / Mention (Sebutan Pertama)",
      description: "Step-by-step workflow for handling a client's first court appearance",
      steps: JSON.stringify([
        { step: 1, title: "Client Interview", description: "Meet with client at lockup/prison. Obtain instructions. Verify identity and charges." },
        { step: 2, title: "Review Charge Sheet", description: "Examine the charge sheet for defects. Ensure proper section and particulars." },
        { step: 3, title: "Bail Application", description: "Prepare bail application if non-bailable. Present grounds for bail to court." },
        { step: 4, title: "Plea Taking", description: "Advise client on plea options. If claiming trial, enter not guilty plea." },
        { step: 5, title: "Request Documents", description: "Apply for copies of witness statements, investigation papers, and other documents." },
        { step: 6, title: "Case Management", description: "Discuss trial dates with prosecution. Obtain next mention/trial date." },
      ]),
      category: "Court Procedure",
      estimatedDuration: "1-2 hours",
    },
    {
      title: "Criminal Trial Preparation",
      description: "Comprehensive workflow for preparing a criminal trial defence",
      steps: JSON.stringify([
        { step: 1, title: "Case Analysis", description: "Review all prosecution documents. Identify weaknesses in prosecution case." },
        { step: 2, title: "Client Briefing", description: "Detailed meeting with client. Obtain version of events. Identify defence witnesses." },
        { step: 3, title: "Legal Research", description: "Research applicable law, recent case authorities, and procedural requirements." },
        { step: 4, title: "Defence Strategy", description: "Formulate defence theory. Prepare cross-examination questions." },
        { step: 5, title: "Witness Preparation", description: "Interview defence witnesses. Prepare witness statements if needed." },
        { step: 6, title: "Document Preparation", description: "Prepare submission bundles, authorities, and any preliminary applications." },
      ]),
      category: "Trial",
      estimatedDuration: "2-4 weeks",
    },
    {
      title: "Filing a Criminal Appeal",
      description: "Procedure for filing a criminal appeal to the High Court or Court of Appeal",
      steps: JSON.stringify([
        { step: 1, title: "Notice of Appeal", description: "File Notice of Appeal within 14 days from date of conviction/sentence (Section 307 CPC)." },
        { step: 2, title: "Obtain Grounds of Judgment", description: "Request written grounds of judgment from trial court." },
        { step: 3, title: "Petition of Appeal", description: "Draft and file Petition of Appeal with specific grounds within time allowed." },
        { step: 4, title: "Record of Appeal", description: "Prepare and file Record of Appeal containing notes of proceedings and exhibits." },
        { step: 5, title: "Written Submissions", description: "File written submissions setting out legal arguments and authorities." },
        { step: 6, title: "Appeal Hearing", description: "Present oral arguments at appeal hearing. Respond to any questions from bench." },
      ]),
      category: "Appeals",
      estimatedDuration: "3-6 months",
    },
  ]);

  await db.insert(sampleDocumentsTable).values([
    {
      title: "Written Submission (Hujahan Bertulis) - Defence",
      description: "Template for defence written submission at the end of trial",
      documentType: "Submission",
      content: "DALAM MAHKAMAH ______________________ DI ______________________\n\nKES JENAYAH NO: ______________________\n\nANTARA\nPENDAKWA RAYA ... PENDAKWA\nDAN\n______________________ ... TERTUDUH\n\nHUJAHAN BERTULIS PIHAK PEMBELAAN\n\n1. PENDAHULUAN\n1.1 Tertuduh telah dituduh di bawah Seksyen ______________________ Kanun Keseksaan.\n1.2 Perbicaraan telah dijalankan selama ______________________ hari.\n1.3 Pihak pendakwaan telah memanggil ______________________ orang saksi.\n\n2. FAKTA KES\n2.1 ______________________\n\n3. ISU-ISU\n3.1 Sama ada pihak pendakwaan telah membuktikan kes prima facie/kes melampaui keraguan munasabah.\n\n4. UNDANG-UNDANG\n4.1 ______________________\n\n5. HUJAHAN\n5.1 ______________________\n\n6. KESIMPULAN\n6.1 Pihak pembelaan dengan hormatnya memohon agar tertuduh dibebaskan dan dilepaskan.\n\nBertarikh: ______________________\n\n______________________\nPeguambela Tertuduh",
      category: "Trial",
    },
    {
      title: "Mitigation Plea (Rayuan Mitigasi)",
      description: "Template for plea in mitigation after conviction",
      documentType: "Mitigation",
      content: "DALAM MAHKAMAH ______________________ DI ______________________\n\nKES JENAYAH NO: ______________________\n\nRAYUAN MITIGASI\n\nYang Arif,\n\nSaya mewakili tertuduh yang telah disabitkan kesalahan di bawah Seksyen ______________________.\n\nFaktor-faktor mitigasi yang ingin dikemukakan:\n\n1. LATAR BELAKANG TERTUDUH\n- Umur: ______________________\n- Status perkahwinan: ______________________\n- Tanggungan: ______________________\n- Pekerjaan: ______________________\n\n2. FAKTOR MITIGASI\n- Kesalahan pertama / tiada rekod jenayah terdahulu\n- Mengaku bersalah pada peringkat awal\n- Menunjukkan penyesalan\n- Kerjasama dengan pihak polis\n- ______________________\n\n3. PERMOHONAN\nDengan hormatnya memohon agar Mahkamah menjatuhkan hukuman yang seringan mungkin dengan mengambil kira faktor-faktor mitigasi di atas.\n\nBertarikh: ______________________\n\n______________________\nPeguambela Tertuduh",
      category: "Sentencing",
    },
  ]);

  await db.insert(glossaryTermsTable).values([
    { term: "Actus Reus", definition: "The physical element or guilty act required to establish criminal liability. It includes acts, omissions, and states of affairs.", malayTranslation: "Perbuatan Salah / Perbuatan Bersalah", relatedTerms: "Mens Rea, Criminal Liability, Voluntary Act" },
    { term: "Mens Rea", definition: "The mental element or guilty mind required for criminal liability. It encompasses intention, knowledge, recklessness, and negligence.", malayTranslation: "Niat Jahat / Niat Bersalah", relatedTerms: "Actus Reus, Intention, Knowledge" },
    { term: "Prima Facie", definition: "Latin term meaning 'at first sight'. In criminal law, it refers to evidence that, if unrebutted, would be sufficient to prove a case.", malayTranslation: "Pada Pandangan Pertama", relatedTerms: "Burden of Proof, Standard of Proof, Maximum Evaluation" },
    { term: "Beyond Reasonable Doubt", definition: "The standard of proof required in criminal cases. The prosecution must prove the accused's guilt to such a degree that there is no reasonable doubt in the mind of a reasonable person.", malayTranslation: "Melampaui Keraguan Munasabah", relatedTerms: "Standard of Proof, Burden of Proof, Presumption of Innocence" },
    { term: "Remand", definition: "The detention of an accused person in custody pending trial or investigation. Under Section 117 CPC, police remand is initially for up to 4 days, extendable to 7 days.", malayTranslation: "Reman / Tahanan Reman", relatedTerms: "Bail, Arrest, Detention" },
    { term: "Acquittal", definition: "A judgment that a person is not guilty of the offence charged. Can be an acquittal and discharge (DNAA) or acquittal not amounting to an acquittal.", malayTranslation: "Pembebasan / Pelepasan", relatedTerms: "Discharge, Conviction, Verdict" },
    { term: "Plea Bargaining", definition: "Under Section 172C-172H CPC, the process where the accused pleads guilty in exchange for a reduced charge or sentence recommendation.", malayTranslation: "Pengakuan Bersalah Melalui Tawar-Menawar", relatedTerms: "Guilty Plea, Sentence, Mitigation" },
    { term: "Charge", definition: "A formal accusation of a criminal offence made against a person. The charge must state the offence, the section of law, and the particulars of the offence.", malayTranslation: "Pertuduhan / Tuduhan", relatedTerms: "Indictment, Information, Complaint" },
    { term: "Abetment", definition: "Under Section 107 of the Penal Code, instigating, conspiring, or intentionally aiding the commission of an offence.", malayTranslation: "Bersubahat", relatedTerms: "Conspiracy, Aiding, Principal Offender" },
    { term: "Bail Bond", definition: "A written undertaking by the accused (and sureties) to appear in court on specified dates, with a monetary guarantee forfeited upon failure to appear.", malayTranslation: "Bon Jaminan", relatedTerms: "Bail, Surety, Recognizance" },
  ]);

  await db.insert(costsFeesTable).values([
    {
      title: "Filing Fee - Criminal Appeal",
      description: "Fee for filing a Notice of Appeal in criminal cases",
      amount: "RM 50.00",
      category: "Court Fees",
      courtType: "High Court",
      legalBasis: "Subordinate Courts Rules 1955",
    },
    {
      title: "Bail Bond Fee",
      description: "Processing fee for bail bonds in criminal cases",
      amount: "RM 4.00 per RM 1,000",
      category: "Court Fees",
      courtType: "All Courts",
      legalBasis: "Criminal Procedure Code",
    },
    {
      title: "Certified True Copy of Judgment",
      description: "Fee for obtaining certified true copy of grounds of judgment",
      amount: "RM 5.00 per page",
      category: "Court Fees",
      courtType: "All Courts",
      legalBasis: "Courts of Judicature Act 1964",
    },
    {
      title: "Legal Aid Bureau - Means Test",
      description: "Income threshold for eligibility for legal aid in criminal cases",
      amount: "RM 25,000 annual income (or less)",
      category: "Legal Aid",
      courtType: "All Courts",
      legalBasis: "Legal Aid Act 1971",
    },
    {
      title: "Solicitor-Client Costs (Criminal Trial)",
      description: "Guideline range for criminal trial representation fees",
      amount: "RM 5,000 - RM 50,000+",
      category: "Professional Fees",
      courtType: "Sessions Court / High Court",
      legalBasis: "Solicitors' Remuneration Order 2005 (guideline only)",
    },
  ]);

  console.log("Seed data inserted successfully!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
