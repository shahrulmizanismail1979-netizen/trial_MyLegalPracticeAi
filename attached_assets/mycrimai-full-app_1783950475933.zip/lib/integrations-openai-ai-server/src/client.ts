import OpenAI from "openai";

const directApiKey = process.env.OPENAI_API_KEY;

if (directApiKey) {
  // Prefer the user-provided OpenAI API key when present (talks directly to api.openai.com).
  // This is used when the Replit AI Integrations proxy is unavailable or its key is unapproved.
} else {
  if (!process.env.AI_INTEGRATIONS_OPENAI_BASE_URL) {
    throw new Error(
      "Either OPENAI_API_KEY or AI_INTEGRATIONS_OPENAI_BASE_URL must be set.",
    );
  }
  if (!process.env.AI_INTEGRATIONS_OPENAI_API_KEY) {
    throw new Error(
      "Either OPENAI_API_KEY or AI_INTEGRATIONS_OPENAI_API_KEY must be set.",
    );
  }
}

export const openai = directApiKey
  ? new OpenAI({ apiKey: directApiKey })
  : new OpenAI({
      apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
      baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
    });
