import { GoogleGenAI } from "@google/genai";
import OpenAI from "openai";

const userKey = process.env.GEMINI_API_KEY;

interface GenerateContentStreamArgs {
  model: string;
  contents: Array<{ role: string; parts: Array<{ text: string }> }>;
  config?: {
    systemInstruction?: string;
    maxOutputTokens?: number;
  };
}

interface GenerateContentArgs extends GenerateContentStreamArgs {
  config?: {
    systemInstruction?: string;
    maxOutputTokens?: number;
    responseModalities?: string[];
  };
}

interface ContentChunk {
  text?: string;
}

interface AiClient {
  models: {
    generateContentStream: (
      args: GenerateContentStreamArgs,
    ) => Promise<AsyncIterable<ContentChunk>>;
    generateContent: (args: GenerateContentArgs) => Promise<{
      text?: string;
      candidates?: Array<{
        content?: { parts?: Array<{ inlineData?: { data?: string } }> };
      }>;
    }>;
  };
}

function makeOpenAIAdapter(apiKey: string): AiClient {
  const oai = new OpenAI({ apiKey });

  function mapModel(model: string): string {
    if (model.includes("image")) return "gpt-4o";
    if (model.includes("flash")) return "gpt-4o-mini";
    if (model.includes("pro")) return "gpt-4o";
    return "gpt-4o-mini";
  }

  function contentToString(content: unknown): string {
    if (typeof content === "string") return content;
    if (Array.isArray(content)) {
      return content
        .map((part) => {
          if (typeof part === "string") return part;
          if (part && typeof part === "object" && "text" in part) {
            const t = (part as { text?: unknown }).text;
            return typeof t === "string" ? t : "";
          }
          return "";
        })
        .join("");
    }
    return "";
  }

  function buildMessages(args: GenerateContentStreamArgs) {
    const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [];
    if (args.config?.systemInstruction) {
      messages.push({ role: "system", content: args.config.systemInstruction });
    }
    for (const c of args.contents) {
      const text = c.parts.map((p) => p.text).join("\n");
      const role: "user" | "assistant" = c.role === "model" ? "assistant" : "user";
      messages.push({ role, content: text });
    }
    return messages;
  }

  return {
    models: {
      async generateContentStream(args: GenerateContentStreamArgs) {
        const messages = buildMessages(args);
        const stream = await oai.chat.completions.create({
          model: mapModel(args.model),
          messages,
          max_tokens: args.config?.maxOutputTokens,
          stream: true,
        });

        async function* iterator(): AsyncIterable<ContentChunk> {
          for await (const part of stream) {
            const text = part.choices?.[0]?.delta?.content;
            if (text) yield { text };
          }
        }

        return iterator();
      },

      async generateContent(args: GenerateContentArgs) {
        const messages = buildMessages(args);
        const result = await oai.chat.completions.create({
          model: mapModel(args.model),
          messages,
          max_tokens: args.config?.maxOutputTokens,
        });
        const text = contentToString(result.choices?.[0]?.message?.content);
        return { text };
      },
    },
  };
}

let aiClient: AiClient;

if (userKey && userKey.startsWith("sk-")) {
  aiClient = makeOpenAIAdapter(userKey);
} else if (userKey && userKey.length > 0) {
  aiClient = new GoogleGenAI({ apiKey: userKey }) as unknown as AiClient;
} else {
  if (!process.env.AI_INTEGRATIONS_GEMINI_BASE_URL) {
    throw new Error(
      "AI_INTEGRATIONS_GEMINI_BASE_URL must be set. Did you forget to provision the Gemini AI integration?",
    );
  }

  if (!process.env.AI_INTEGRATIONS_GEMINI_API_KEY) {
    throw new Error(
      "AI_INTEGRATIONS_GEMINI_API_KEY must be set. Did you forget to provision the Gemini AI integration?",
    );
  }

  aiClient = new GoogleGenAI({
    apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY,
    httpOptions: {
      apiVersion: "",
      baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
    },
  }) as unknown as AiClient;
}

export const ai = aiClient;
