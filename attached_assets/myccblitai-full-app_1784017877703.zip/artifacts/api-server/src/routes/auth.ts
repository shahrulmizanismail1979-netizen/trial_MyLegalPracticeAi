import { Router, type IRouter } from "express";
import { VerifyAccessCodeBody } from "@workspace/api-zod";
import jwt from "jsonwebtoken";
import { eq } from "drizzle-orm";
import { db, accessCodes } from "@workspace/db";

const router: IRouter = Router();

const SECRET = process.env.SESSION_SECRET || "myccblitai-secret-key-2024";

const MASTER_CODE = "240680";
const DEFAULT_CODES = ["CCBLIT2024", "MYCCBLIT", "UKM2024", "PRACTITIONER"];
const VALID_CODES = [
  MASTER_CODE,
  ...(process.env.ACCESS_CODES
    ? process.env.ACCESS_CODES.split(",")
    : DEFAULT_CODES),
]
  .map((c) => c.trim().toUpperCase())
  .filter((c) => c.length > 0);

router.post("/auth/verify", async (req, res): Promise<void> => {
  const parsed = VerifyAccessCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const code = parsed.data.code.trim().toUpperCase();

  let valid = VALID_CODES.includes(code);
  let dbCodeId: number | null = null;

  if (!valid) {
    const rows = await db.select().from(accessCodes).where(eq(accessCodes.code, code));
    const row = rows[0];
    if (row && row.active) {
      valid = true;
      dbCodeId = row.id;
    }
  }

  if (!valid) {
    res.status(401).json({ error: "Invalid access code" });
    return;
  }

  if (dbCodeId !== null) {
    await db
      .update(accessCodes)
      .set({ lastUsedAt: new Date() })
      .where(eq(accessCodes.id, dbCodeId));
  }

  const token = jwt.sign({ role: "practitioner", code }, SECRET, { expiresIn: "7d" });
  res.json({ success: true, token });
});

export default router;
