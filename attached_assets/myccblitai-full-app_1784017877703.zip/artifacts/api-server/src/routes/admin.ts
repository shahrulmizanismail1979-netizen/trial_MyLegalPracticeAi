import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import jwt from "jsonwebtoken";
import { eq, desc } from "drizzle-orm";
import { db, accessCodes } from "@workspace/db";

const router: IRouter = Router();

const SECRET = process.env.SESSION_SECRET || "myccblitai-secret-key-2024";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin1234";

function generateCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 10; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  try {
    const decoded = jwt.verify(auth.slice(7), SECRET) as { role?: string };
    if (decoded.role !== "admin") {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

router.post("/admin/login", async (req, res): Promise<void> => {
  const { password } = req.body ?? {};
  if (typeof password !== "string" || password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Invalid admin password" });
    return;
  }
  const token = jwt.sign({ role: "admin" }, SECRET, { expiresIn: "7d" });
  res.json({ success: true, token });
});

router.get("/admin/codes", requireAdmin, async (_req, res): Promise<void> => {
  const codes = await db.select().from(accessCodes).orderBy(desc(accessCodes.createdAt));
  res.json({ codes });
});

router.post("/admin/codes", requireAdmin, async (req, res): Promise<void> => {
  const label = typeof req.body?.label === "string" ? req.body.label.trim() : "";
  let code = "";
  for (let attempt = 0; attempt < 5; attempt++) {
    code = generateCode();
    const existing = await db.select().from(accessCodes).where(eq(accessCodes.code, code));
    if (existing.length === 0) break;
  }
  const [inserted] = await db
    .insert(accessCodes)
    .values({ code, label: label || null, active: true })
    .returning();
  res.json({ code: inserted });
});

router.patch("/admin/codes/:id", requireAdmin, async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const active = Boolean(req.body?.active);
  const [updated] = await db
    .update(accessCodes)
    .set({ active })
    .where(eq(accessCodes.id, id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  res.json({ code: updated });
});

router.delete("/admin/codes/:id", requireAdmin, async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  await db.delete(accessCodes).where(eq(accessCodes.id, id));
  res.json({ success: true });
});

export default router;
