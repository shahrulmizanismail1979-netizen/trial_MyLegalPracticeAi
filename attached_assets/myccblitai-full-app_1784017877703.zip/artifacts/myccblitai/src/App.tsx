import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import AccessPage from "@/pages/access";
import WorkspaceIndex from "@/pages/workspace/index";
import ToolPage from "@/pages/workspace/tool";
import ChatPage from "@/pages/workspace/chat";
import CalculatorsPage from "@/pages/workspace/calculators";
import ReferencePage from "@/pages/workspace/reference";
import StrategyPage from "@/pages/workspace/strategy";
import AdminLoginPage from "@/pages/admin/login";
import AdminDashboardPage from "@/pages/admin/dashboard";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/access" component={AccessPage} />
      <Route path="/workspace" component={WorkspaceIndex} />
      <Route path="/workspace/chat" component={ChatPage} />
      <Route path="/workspace/calculators" component={CalculatorsPage} />
      <Route path="/workspace/reference" component={ReferencePage} />
      <Route path="/workspace/strategy" component={StrategyPage} />
      <Route path="/workspace/tool/:toolId" component={ToolPage} />
      <Route path="/admin" component={AdminLoginPage} />
      <Route path="/admin/dashboard" component={AdminDashboardPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
