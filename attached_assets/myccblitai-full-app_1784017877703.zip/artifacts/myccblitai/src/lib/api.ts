export function getApiBaseUrl(): string {
  const explicit = import.meta.env.VITE_API_URL as string | undefined;
  if (explicit && explicit.length > 0) {
    return explicit.endsWith("/") ? explicit : `${explicit}/`;
  }
  const base = import.meta.env.BASE_URL || "/";
  return base.endsWith("/") ? base : `${base}/`;
}

export function apiUrl(path: string): string {
  const base = getApiBaseUrl();
  const trimmed = path.startsWith("/") ? path.slice(1) : path;
  return `${base}${trimmed}`;
}
