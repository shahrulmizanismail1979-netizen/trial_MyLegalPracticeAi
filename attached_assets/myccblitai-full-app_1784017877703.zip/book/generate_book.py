"""
Banking Litigation Practice in Malaysia
A 300-page print-ready PDF book — 70% visuals, 30% writing.

Generated programmatically using reportlab + matplotlib.
Output: book/Banking_Litigation_Malaysia.pdf
"""

import os, math, io, random
from datetime import date

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle, Wedge
from matplotlib.lines import Line2D
import numpy as np

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib.colors import HexColor, white, black
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak,
    Image, KeepTogether, Table, TableStyle, NextPageTemplate, FrameBreak
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY, TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

random.seed(42)

# ============================================================
# THEME
# ============================================================
NAVY = "#0A1628"
DEEP_NAVY = "#06101F"
GOLD = "#E5B73B"
GOLD_LIGHT = "#F4D67A"
GOLD_DARK = "#9C7A1E"
GOLD_BRIGHT = "#FFD24D"
INK = "#0E1A26"
PAPER = "#F6EFDD"   # ivory/cream — print-friendly
PAPER_DARK = "#E8DCC0"
RULE = "#B79A55"
MUTED = "#5C6B7E"
ACCENT = "#A1131C"   # rich crimson for emphasis
ACCENT_DEEP = "#6B0E14"
TEAL = "#176B7A"
TEAL_DEEP = "#0E4754"
GREEN_OK = "#1F7A47"
GREEN_DEEP = "#0F4B2B"
RED_WARN = "#B41F25"
PURPLE = "#3C1361"
PURPLE_LIGHT = "#6B3FA0"
EMERALD = "#0F8C6B"
ROYAL = "#1B3A8A"
COPPER = "#B8651B"

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
VISUAL_DIR = os.path.join(OUT_DIR, "visuals")
os.makedirs(VISUAL_DIR, exist_ok=True)

# ============================================================
# MATPLOTLIB DEFAULTS
# ============================================================
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "Liberation Serif", "Times New Roman"],
    "axes.edgecolor": INK,
    "axes.labelcolor": INK,
    "xtick.color": INK,
    "ytick.color": INK,
    "text.color": INK,
    "savefig.facecolor": PAPER,
    "figure.facecolor": PAPER,
    "axes.facecolor": PAPER,
})

# ============================================================
# VISUAL FACTORY  (each returns a saved PNG path)
# ============================================================

def _save(fig, name, dpi=180):
    p = os.path.join(VISUAL_DIR, f"{name}.png")
    fig.savefig(p, dpi=dpi, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)
    return p


def vis_full_cover():
    fig, ax = plt.subplots(figsize=(8.27, 11.69))
    fig.patch.set_facecolor(DEEP_NAVY)
    ax.set_facecolor(DEEP_NAVY)
    ax.set_xlim(0, 10); ax.set_ylim(0, 14); ax.axis("off")

    # cinematic vertical gradient
    grad_steps = 240
    for i in range(grad_steps):
        t = i / grad_steps
        if t < 0.5:
            r = int(6 + (28-6)*(t/0.5))
            g = int(16 + (24-16)*(t/0.5))
            b = int(31 + (62-31)*(t/0.5))
        else:
            tt = (t-0.5)/0.5
            r = int(28 - (28-10)*tt)
            g = int(24 - (24-14)*tt)
            b = int(62 - (62-26)*tt)
        ax.add_patch(Rectangle((0, i*14/grad_steps), 10, 14/grad_steps + 0.04,
                               color=f"#{r:02x}{g:02x}{b:02x}", lw=0))

    # radial gold glow behind crest
    for r, alpha in [(3.4, 0.04), (2.6, 0.06), (1.9, 0.10), (1.4, 0.16), (0.95, 0.28)]:
        ax.add_patch(Circle((5, 11.0), r, fc=GOLD, ec="none", alpha=alpha))
    # bottom warm glow
    for r, alpha in [(5.2, 0.04), (3.8, 0.06), (2.6, 0.10)]:
        ax.add_patch(Circle((5, 0.4), r, fc=COPPER, ec="none", alpha=alpha))

    # ornate triple-line gold border
    for off, lw, c in [(0.32, 2.6, GOLD), (0.46, 0.7, GOLD_LIGHT), (0.55, 0.4, GOLD_DARK)]:
        ax.add_patch(Rectangle((off, off), 10 - 2*off, 14 - 2*off,
                               fill=False, ec=c, lw=lw))

    # corner ornaments
    for cx, cy in [(0.55, 0.55), (9.45, 0.55), (0.55, 13.45), (9.45, 13.45)]:
        ax.add_patch(Rectangle((cx-0.20, cy-0.20), 0.40, 0.40, fill=False, ec=GOLD, lw=0.9))
        ax.add_patch(Circle((cx, cy), 0.09, fc=GOLD, ec="none"))

    # top decorative band
    ax.add_patch(Rectangle((0.85, 12.65), 8.3, 0.045, color=GOLD))
    ax.add_patch(Rectangle((0.85, 12.58), 8.3, 0.012, color=GOLD_DARK))
    ax.text(5, 12.95, "DAVENPORT  ·  &  ·  HELMSLEY", ha="center",
            color=GOLD_LIGHT, fontsize=11, weight="bold", family="serif")

    # crest medallion
    ax.add_patch(Circle((5, 11.0), 1.30, fc=DEEP_NAVY, ec=GOLD, lw=2.6))
    ax.add_patch(Circle((5, 11.0), 1.10, fc="none", ec=GOLD_LIGHT, lw=0.6))
    ax.add_patch(Circle((5, 11.0), 0.92, fc="none", ec=GOLD, lw=0.4))
    # scales of justice
    ax.plot([3.95, 6.05], [11.05, 11.05], color=GOLD, lw=2.0)
    ax.plot([5, 5], [10.55, 11.6], color=GOLD, lw=2.4)
    ax.add_patch(Rectangle((3.55, 10.70), 0.8, 0.16, fc=GOLD, ec="none"))
    ax.add_patch(Rectangle((5.65, 10.70), 0.8, 0.16, fc=GOLD, ec="none"))
    ax.add_patch(Rectangle((4.6, 10.45), 0.8, 0.12, fc=GOLD, ec="none"))
    ax.plot([4.4, 5.6], [11.55, 11.55], color=GOLD, lw=1.4)

    # MAIN TITLE — multi-layer for depth
    for dx, dy, alpha in [(0.05, -0.05, 0.45), (0.025, -0.025, 0.55)]:
        ax.text(5+dx, 8.55+dy, "BANKING", ha="center", color="#000000",
                fontsize=58, weight="bold", family="serif", alpha=alpha)
        ax.text(5+dx, 7.40+dy, "LITIGATION", ha="center", color="#000000",
                fontsize=58, weight="bold", family="serif", alpha=alpha)
    ax.text(5, 8.55, "BANKING", ha="center", color="#FFFFFF",
            fontsize=58, weight="bold", family="serif")
    ax.text(5, 7.40, "LITIGATION", ha="center", color="#FFFFFF",
            fontsize=58, weight="bold", family="serif")
    # PRACTICE in bright gold with shadow
    ax.text(5.05, 6.25, "PRACTICE", ha="center", color="#000000",
            fontsize=52, weight="bold", family="serif", alpha=0.55)
    ax.text(5, 6.30, "PRACTICE", ha="center", color=GOLD_BRIGHT,
            fontsize=52, weight="bold", family="serif")

    # divider with diamond
    ax.plot([1.6, 4.4], [5.55, 5.55], color=GOLD, lw=1.4)
    ax.plot([5.6, 8.4], [5.55, 5.55], color=GOLD, lw=1.4)
    from matplotlib.patches import RegularPolygon
    ax.add_patch(RegularPolygon((5, 5.55), 4, radius=0.14,
                                 orientation=0, fc=GOLD, ec=GOLD_DARK, lw=0.8))

    ax.text(5, 5.05, "I N   M A L A Y S I A", ha="center",
            color=GOLD_LIGHT, fontsize=18, weight="bold")
    ax.text(5, 4.55, "A Cinematic Compendium for the Modern Practitioner",
            ha="center", color="white", fontsize=12.5, style="italic")
    ax.text(5, 4.18, "Doctrine  ·  Procedure  ·  Authorities  ·  Templates  ·  Strategy",
            ha="center", color=GOLD_LIGHT, fontsize=10, style="italic")

    # author plate (four authors) — positioned above the imprint plate
    ax.add_patch(FancyBboxPatch((1.5, 2.40), 7.0, 1.70,
                                boxstyle="round,pad=0.04,rounding_size=0.18",
                                fc="none", ec=GOLD, lw=1.4))
    ax.text(5, 3.80, "MOHD SAUFI SAMSUDIN", ha="center",
            color="white", fontsize=10.4, weight="bold")
    ax.text(5, 3.50, "MOHD IRWAN MOHD MUBARAK", ha="center",
            color="white", fontsize=10.4, weight="bold")
    ax.text(5, 3.20, "SHAHRUL MIZAN ISMAIL", ha="center",
            color="white", fontsize=10.4, weight="bold")
    ax.text(5, 2.90, "MAHMUD HAMDI MAHMUD SAEDON", ha="center",
            color="white", fontsize=10.4, weight="bold")
    ax.plot([3.5, 6.5], [2.70, 2.70], color=GOLD, lw=0.8)
    ax.text(5, 2.52, "Faculty of Law  ·  Universiti Kebangsaan Malaysia",
            ha="center", color=GOLD_LIGHT, fontsize=9, style="italic")

    # bottom edition plate — moved down to clear author plate
    ax.add_patch(Rectangle((3.1, 1.55), 3.8, 0.5, fc=GOLD, ec=GOLD_DARK, lw=1.2))
    ax.text(5, 1.78, "VOLUME I  ·  FIRST EDITION", ha="center",
            color=DEEP_NAVY, fontsize=10.5, weight="bold")
    ax.text(5, 1.20, "M  M  X  X  V  I", ha="center", color=GOLD_LIGHT,
            fontsize=14, weight="bold", family="serif")
    ax.text(5, 0.85, "Davenport & Helmsley  ·  Kuala Lumpur  ·  London",
            ha="center", color=GOLD_LIGHT, fontsize=8.8, style="italic")
    return _save(fig, "cover", dpi=200)


def vis_part_divider(part_no, title, subtitle, items):
    fig, ax = plt.subplots(figsize=(8.27, 11.69))
    fig.patch.set_facecolor(NAVY)
    ax.set_xlim(0, 10); ax.set_ylim(0, 14); ax.axis("off")
    ax.set_facecolor(NAVY)
    # gold band
    ax.add_patch(Rectangle((0, 7.8), 10, 0.04, color=GOLD))
    ax.add_patch(Rectangle((0, 7.74), 10, 0.015, color=GOLD_DARK))
    ax.text(5, 11.5, f"PART {part_no}", ha="center", color=GOLD, fontsize=18,
            weight="bold")
    ax.text(5, 10.1, title.upper(), ha="center", color="white", fontsize=30,
            weight="bold")
    ax.text(5, 9.0, subtitle, ha="center", color=GOLD_LIGHT, fontsize=13, style="italic")

    # chapter list
    ax.text(5, 6.8, "IN THIS PART", ha="center", color=GOLD, fontsize=10)
    y = 6.0
    for it in items:
        ax.text(5, y, "◆  " + it, ha="center", color="white", fontsize=12)
        y -= 0.55
    # decorative pillars
    for x in [1.0, 9.0]:
        ax.add_patch(Rectangle((x-0.05, 0.8), 0.1, 4.0, color=GOLD_DARK))
        ax.add_patch(Circle((x, 4.95), 0.18, color=GOLD))
    suffix = f"{part_no:02d}" if isinstance(part_no, int) else str(part_no)
    return _save(fig, f"part_{suffix}")


def vis_court_hierarchy():
    fig, ax = plt.subplots(figsize=(9, 11))
    ax.set_xlim(0, 10); ax.set_ylim(0, 14); ax.axis("off")
    ax.set_facecolor(PAPER)
    fig.patch.set_facecolor(PAPER)

    levels = [
        ("FEDERAL COURT", "Apex court · final appeal · constitutional issues",
         13, NAVY, "white"),
        ("COURT OF APPEAL", "Appeals from High Court · 3-judge panel",
         11.4, NAVY, "white"),
        ("HIGH COURT (Malaya · Sabah & Sarawak)", "Unlimited civil jurisdiction · banking & winding-up",
         9.8, "#1B3A5C", "white"),
        ("SESSIONS COURT", "Civil claims up to RM 1,000,000",
         8.2, TEAL, "white"),
        ("MAGISTRATES' COURT", "Civil claims up to RM 100,000",
         6.6, "#5E8284", "white"),
    ]
    for label, sub, y, fc, tc in levels:
        ax.add_patch(FancyBboxPatch((1.0, y-0.55), 8.0, 1.0,
                                     boxstyle="round,pad=0.04,rounding_size=0.12",
                                     fc=fc, ec=GOLD, lw=1.2))
        ax.text(5, y+0.05, label, ha="center", va="center",
                color=tc, fontsize=13, weight="bold")
        ax.text(5, y-0.35, sub, ha="center", va="center",
                color=tc, fontsize=8.5, style="italic", alpha=0.9)

    # arrows
    ys = [13-0.55, 11.4-0.55, 9.8-0.55, 8.2-0.55]
    yt = [11.4+0.45, 9.8+0.45, 8.2+0.45, 6.6+0.45]
    for a, b in zip(ys, yt):
        ax.annotate("", xy=(5, b+0.05), xytext=(5, a-0.05),
                    arrowprops=dict(arrowstyle="-|>", color=GOLD, lw=1.6))
    # specialised side branches
    spec = [
        ("MUAMALAT DIVISION (KL)", "Islamic banking matters", 4.8, "#5A2A6C"),
        ("COMMERCIAL DIVISION", "Banking · winding-up · IP", 3.5, "#2F4858"),
        ("BANKRUPTCY DIVISION", "Insolvency Act 1967 (rev.)", 2.2, "#704214"),
    ]
    for label, sub, y, fc in spec:
        ax.add_patch(FancyBboxPatch((1.5, y-0.5), 7.0, 0.95,
                                    boxstyle="round,pad=0.03,rounding_size=0.1",
                                    fc=fc, ec=GOLD, lw=1))
        ax.text(5, y+0.08, label, ha="center", color="white", fontsize=11, weight="bold")
        ax.text(5, y-0.25, sub, ha="center", color="white", fontsize=8.5, style="italic")
        # connector to High Court
        ax.annotate("", xy=(5, y+0.5), xytext=(5, 9.8-0.55),
                    arrowprops=dict(arrowstyle="-", color=GOLD_DARK, lw=0.8, ls="dotted"))
    ax.text(5, 0.8, "Diagram 1.1 · Court hierarchy and specialised banking divisions",
            ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, "court_hierarchy")


def vis_statutory_map():
    fig, ax = plt.subplots(figsize=(9, 11))
    ax.set_xlim(0, 10); ax.set_ylim(0, 14); ax.axis("off")
    ax.set_facecolor(PAPER); fig.patch.set_facecolor(PAPER)
    # central node
    ax.add_patch(Circle((5, 7), 1.5, fc=NAVY, ec=GOLD, lw=2))
    ax.text(5, 7.25, "BANKING", ha="center", color="white", fontsize=12, weight="bold")
    ax.text(5, 6.90, "LITIGATION", ha="center", color="white", fontsize=12, weight="bold")
    ax.text(5, 6.55, "Malaysia", ha="center", color=GOLD_LIGHT, fontsize=9, style="italic")
    statutes = [
        ("Financial Services Act 2013", "Conventional banks · BNM oversight"),
        ("Islamic Financial Services Act 2013", "Islamic banks · Shariah compliance"),
        ("Central Bank of Malaysia Act 2009", "BNM powers · monetary policy"),
        ("Insolvency Act 1967", "Bankruptcy of individuals"),
        ("Companies Act 2016", "Winding-up · directors' duties"),
        ("National Land Code 1965", "Charges · foreclosure · auction"),
        ("Bills of Exchange Act 1949", "Cheques · drafts · promissory notes"),
        ("Hire-Purchase Act 1967", "Hire-purchase recovery"),
        ("Limitation Act 1953", "Time bars on banking claims"),
        ("Contracts Act 1950", "Loan agreements · guarantees"),
        ("Rules of Court 2012", "Civil procedure"),
        ("Bankruptcy Rules 2017", "BR procedure"),
    ]
    # Two-column orbital layout: 6 left, 6 right, vertically staggered.
    # Boxes are 3.0 wide × 0.9 tall; columns x-centred at 1.85 (left) and 8.15 (right).
    box_w, box_h = 3.0, 0.85
    y_top, y_bot = 12.0, 1.8
    n_per_col = 6
    ys = [y_top - i * (y_top - y_bot) / (n_per_col - 1) for i in range(n_per_col)]
    positions = []
    for i, y in enumerate(ys):
        positions.append((1.85, y))   # left column
    for i, y in enumerate(ys):
        positions.append((8.15, y))   # right column
    for (x, y), (st, sub) in zip(positions, statutes):
        ax.add_patch(FancyBboxPatch((x - box_w/2, y - box_h/2), box_w, box_h,
                                    boxstyle="round,pad=0.03,rounding_size=0.1",
                                    fc=PAPER_DARK, ec=GOLD_DARK, lw=1.2))
        ax.text(x, y + 0.12, st, ha="center", color=NAVY, fontsize=8.4, weight="bold")
        ax.text(x, y - 0.20, sub, ha="center", color=MUTED, fontsize=7.2, style="italic")
        # connector from central node to box edge
        cx = 5 + (1.5 if x > 5 else -1.5) * 0.95
        bx = x - (box_w/2 if x > 5 else -box_w/2)
        ax.plot([cx, bx], [7, y], color=GOLD_DARK, lw=0.8, alpha=0.55)
    ax.text(5, 0.6, "Diagram 1.2 · Statutory ecosystem governing banking litigation in Malaysia",
            ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, "statutory_map")


def vis_flow(name, title, steps, caption=""):
    import textwrap as _tw
    n = len(steps)
    fig_h = max(9, 1.4 + 1.45*n)
    fig, ax = plt.subplots(figsize=(9.5, fig_h))
    ax.set_xlim(0, 10); ax.set_ylim(0, fig_h); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    # title with subtle underline
    ax.text(5, fig_h-0.5, title, ha="center", color=NAVY, fontsize=15, weight="bold")
    ax.plot([3, 7], [fig_h-0.78, fig_h-0.78], color=GOLD, lw=1.2)
    palette = [NAVY, ROYAL, TEAL_DEEP, TEAL, GOLD_DARK, COPPER, ACCENT, PURPLE, GREEN_DEEP]
    for i, (lbl, sub) in enumerate(steps):
        y = fig_h - 1.6 - i*1.30
        c = palette[i % len(palette)]
        # box
        ax.add_patch(FancyBboxPatch((0.45, y-0.55), 9.10, 1.10,
                                    boxstyle="round,pad=0.03,rounding_size=0.14",
                                    fc=c, ec=GOLD, lw=1.2))
        # step circle
        ax.add_patch(Circle((1.05, y), 0.36, fc=GOLD_BRIGHT, ec=DEEP_NAVY, lw=1.4))
        ax.text(1.05, y-0.03, str(i+1), ha="center", va="center",
                color=DEEP_NAVY, fontsize=13, weight="bold")
        # wrap labels to fit width
        lbl_w = _tw.fill(lbl, width=58)
        sub_w = _tw.fill(sub, width=82)
        ax.text(1.7, y+0.22, lbl_w, color="white", fontsize=11, weight="bold", va="center")
        ax.text(1.7, y-0.25, sub_w, color="#F5E5B8", fontsize=8.6, style="italic", va="center")
        if i < n-1:
            ax.annotate("", xy=(1.05, y-1.10), xytext=(1.05, y-0.55),
                        arrowprops=dict(arrowstyle="-|>", color=GOLD_DARK, lw=1.6))
    if caption:
        ax.text(5, 0.25, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_timeline(name, title, events, caption=""):
    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.text(5, 5.5, title, ha="center", color=NAVY, fontsize=14, weight="bold")
    # baseline
    ax.add_patch(Rectangle((0.6, 2.95), 8.8, 0.1, color=NAVY))
    n = len(events)
    xs = np.linspace(1.0, 9.0, n)
    for i, (when, what) in enumerate(events):
        x = xs[i]
        ax.add_patch(Circle((x, 3), 0.2, fc=GOLD, ec=NAVY, lw=1.2))
        if i % 2 == 0:
            ax.plot([x, x], [3.2, 4.2], color=NAVY, lw=1)
            ax.text(x, 4.4, when, ha="center", color=NAVY, fontsize=9, weight="bold")
            ax.text(x, 4.0, "", ha="center")
            ax.text(x, 4.7, what, ha="center", color=INK, fontsize=8, wrap=True)
        else:
            ax.plot([x, x], [2.8, 1.8], color=NAVY, lw=1)
            ax.text(x, 1.6, when, ha="center", color=NAVY, fontsize=9, weight="bold")
            ax.text(x, 1.25, what, ha="center", color=INK, fontsize=8, wrap=True)
    if caption:
        ax.text(5, 0.2, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_compare(name, title, headers, rows, caption=""):
    fig, ax = plt.subplots(figsize=(8.5, max(5, 1.0 + 0.5*len(rows))))
    ax.axis("off"); fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.text(0.5, 0.97, title, ha="center", transform=ax.transAxes,
            color=NAVY, fontsize=14, weight="bold")
    tab_data = [headers] + rows
    tbl = ax.table(cellText=tab_data, loc="center", cellLoc="left",
                   colWidths=[0.32]+[0.34]*(len(headers)-1))
    tbl.auto_set_font_size(False); tbl.set_fontsize(9.5); tbl.scale(1, 1.6)
    for (r, c), cell in tbl.get_celld().items():
        cell.set_edgecolor(GOLD_DARK); cell.set_linewidth(0.6)
        if r == 0:
            cell.set_facecolor(NAVY); cell.get_text().set_color("white")
            cell.get_text().set_weight("bold")
        else:
            cell.set_facecolor(PAPER if r % 2 else PAPER_DARK)
            cell.get_text().set_color(INK)
        cell.PAD = 0.04
    if caption:
        ax.text(0.5, 0.02, caption, ha="center", transform=ax.transAxes,
                color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_bar(name, title, labels, values, ylabel="", caption=""):
    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    bars = ax.bar(labels, values, color=NAVY, edgecolor=GOLD, lw=1.2)
    for b, v in zip(bars, values):
        ax.text(b.get_x()+b.get_width()/2, v + max(values)*0.02,
                f"{v:,}", ha="center", color=NAVY, fontsize=9, weight="bold")
    ax.set_title(title, color=NAVY, fontsize=13, weight="bold", pad=10)
    ax.set_ylabel(ylabel, color=NAVY)
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    ax.tick_params(axis='x', rotation=20)
    if caption:
        fig.text(0.5, 0.01, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_pie(name, title, labels, values, caption=""):
    fig, ax = plt.subplots(figsize=(8.5, 6))
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    cols = [NAVY, GOLD, TEAL, ACCENT, "#5A2A6C", "#2F7D4F", "#8C5E10", MUTED]
    w, t, at = ax.pie(values, labels=labels, colors=cols[:len(values)],
                      autopct="%1.1f%%", startangle=90,
                      wedgeprops=dict(edgecolor="white", lw=2),
                      textprops=dict(color=INK, fontsize=10))
    for a in at:
        a.set_color("white"); a.set_weight("bold")
    ax.set_title(title, color=NAVY, fontsize=13, weight="bold")
    if caption:
        fig.text(0.5, 0.02, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_decision_tree(name, title, root, branches, caption=""):
    """branches: list of (condition, outcome_label, outcome_sub, color)"""
    import textwrap as _tw
    fig, ax = plt.subplots(figsize=(10, 9))
    ax.set_xlim(0, 12); ax.set_ylim(0, 10); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.text(6, 9.5, title, ha="center", color=NAVY, fontsize=15, weight="bold")
    ax.plot([4, 8], [9.22, 9.22], color=GOLD, lw=1.2)
    # root
    ax.add_patch(FancyBboxPatch((4.0, 7.55), 4.0, 1.15,
                                boxstyle="round,pad=0.04,rounding_size=0.14",
                                fc=NAVY, ec=GOLD, lw=1.4))
    ax.text(6, 8.12, _tw.fill(root, width=44), ha="center", va="center",
            color="white", fontsize=11, weight="bold")
    n = len(branches)
    xs = np.linspace(1.4, 10.6, n)
    for i, (cond, lbl, sub, c) in enumerate(branches):
        x = xs[i]
        ax.annotate("", xy=(x, 5.95), xytext=(6, 7.50),
                    arrowprops=dict(arrowstyle="-|>", color=GOLD_DARK, lw=1.3))
        # condition label on edge
        midx = (6+x)/2; midy = 6.75
        ax.text(midx, midy, _tw.fill(cond, width=18), ha="center", va="center",
                color=ACCENT, fontsize=8.2, style="italic",
                bbox=dict(fc=PAPER, ec="none", pad=1.5))
        # outcome box
        ax.add_patch(FancyBboxPatch((x-1.2, 4.20), 2.4, 1.75,
                                    boxstyle="round,pad=0.03,rounding_size=0.12",
                                    fc=c, ec=GOLD, lw=1.2))
        ax.text(x, 5.50, _tw.fill(lbl, width=18), ha="center", va="center",
                color="white", fontsize=10, weight="bold")
        ax.text(x, 4.65, _tw.fill(sub, width=24), ha="center", va="center",
                color="#F5E5B8", fontsize=7.8, style="italic")
    if caption:
        ax.text(6, 0.3, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_quad(name, title, quads, caption=""):
    """quads = [(label, body), ...] of length 4"""
    fig, ax = plt.subplots(figsize=(8.5, 8.5))
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.text(5, 9.6, title, ha="center", color=NAVY, fontsize=14, weight="bold")
    coords = [(0.5, 5.0), (5.2, 5.0), (0.5, 0.7), (5.2, 0.7)]
    cols = [NAVY, TEAL, GOLD_DARK, ACCENT]
    for (x, y), (lbl, body), c in zip(coords, quads, cols):
        ax.add_patch(FancyBboxPatch((x, y), 4.3, 4.0,
                                    boxstyle="round,pad=0.04,rounding_size=0.15",
                                    fc=c, ec=GOLD, lw=1.2))
        ax.text(x+0.25, y+3.55, lbl, color="white", fontsize=12, weight="bold")
        ax.add_patch(Rectangle((x+0.25, y+3.45), 1.2, 0.04, color=GOLD))
        # body text
        for i, line in enumerate(body):
            ax.text(x+0.25, y+3.0 - i*0.42, "•  "+line, color="white",
                    fontsize=9, va="top")
    if caption:
        ax.text(5, 0.05, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_pillars(name, title, pillars, caption=""):
    import textwrap as _tw
    n = len(pillars)
    fig_w = max(9, 1.2 + 2.0*n)
    fig, ax = plt.subplots(figsize=(fig_w, 8.0))
    ax.set_xlim(0, fig_w); ax.set_ylim(0, 8.5); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.text(fig_w/2, 8.1, title, ha="center", color=NAVY, fontsize=15, weight="bold")
    ax.plot([fig_w/2-2, fig_w/2+2], [7.85, 7.85], color=GOLD, lw=1.2)
    cols = [NAVY, TEAL_DEEP, GOLD_DARK, ACCENT, PURPLE, GREEN_DEEP, COPPER, ROYAL]
    spacing = (fig_w - 1.0) / n
    pillar_w = spacing * 0.78
    for i, (label, lines) in enumerate(pillars):
        x = 0.5 + spacing*0.5 + i*spacing - pillar_w/2
        c = cols[i % len(cols)]
        # capital (top decorative block)
        ax.add_patch(Rectangle((x-0.10, 5.85), pillar_w+0.20, 0.32, color=GOLD))
        ax.add_patch(Rectangle((x-0.05, 5.75), pillar_w+0.10, 0.10, color=GOLD_DARK))
        # shaft
        ax.add_patch(Rectangle((x, 1.40), pillar_w, 4.40, color=c))
        # fluting (vertical lines on shaft for column look)
        for f in range(1, 4):
            fx = x + pillar_w*f/4
            ax.plot([fx, fx], [1.40, 5.80], color=GOLD_DARK, lw=0.5, alpha=0.5)
        # base
        ax.add_patch(Rectangle((x-0.18, 1.10), pillar_w+0.36, 0.30, color=GOLD))
        ax.add_patch(Rectangle((x-0.10, 1.00), pillar_w+0.20, 0.10, color=GOLD_DARK))
        # label above
        ax.text(x+pillar_w/2, 6.55, _tw.fill(label, width=14), ha="center", va="bottom",
                color=NAVY, fontsize=11, weight="bold")
        # lines on shaft
        for j, ln in enumerate(lines):
            ax.text(x+pillar_w/2, 5.40 - j*0.55, _tw.fill(ln, width=14),
                    ha="center", va="center", color="white",
                    fontsize=8.2, weight="bold")
    if caption:
        ax.text(fig_w/2, 0.3, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_check_x(name, title, items, caption=""):
    """items: list of (text, ok_bool)"""
    fig, ax = plt.subplots(figsize=(8.5, max(5, 1+0.55*len(items))))
    ax.axis("off"); fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.set_xlim(0,10); ax.set_ylim(0, max(5, 1+0.55*len(items)))
    H = max(5, 1+0.55*len(items))
    ax.text(5, H-0.4, title, ha="center", color=NAVY, fontsize=14, weight="bold")
    for i, (t, ok) in enumerate(items):
        y = H - 1.2 - i*0.55
        col = GREEN_OK if ok else RED_WARN
        sym = "✓" if ok else "✗"
        ax.add_patch(Circle((1.0, y), 0.22, fc=col, ec=NAVY, lw=1))
        ax.text(1.0, y-0.05, sym, ha="center", va="center", color="white",
                fontsize=12, weight="bold")
        ax.add_patch(Rectangle((1.4, y-0.25), 8.2, 0.5, fc=PAPER_DARK,
                               ec=GOLD_DARK, lw=0.5))
        ax.text(1.6, y, t, va="center", color=INK, fontsize=10)
    if caption:
        ax.text(5, 0.2, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_section_cover(name, label, title, subtitle, color=NAVY):
    fig, ax = plt.subplots(figsize=(8.5, 11))
    ax.set_xlim(0, 10); ax.set_ylim(0, 14); ax.axis("off")
    fig.patch.set_facecolor(color); ax.set_facecolor(color)
    ax.add_patch(Rectangle((0, 8.4), 10, 0.05, color=GOLD))
    ax.text(5, 10.5, label, ha="center", color=GOLD, fontsize=16,
            weight="bold")
    ax.text(5, 9.2, title.upper(), ha="center", color="white", fontsize=24, weight="bold")
    ax.text(5, 7.5, subtitle, ha="center", color=GOLD_LIGHT, fontsize=12, style="italic", wrap=True)
    # decorative
    ax.add_patch(Circle((5, 4.8), 1.4, fc="none", ec=GOLD, lw=1.4))
    ax.add_patch(Circle((5, 4.8), 1.0, fc="none", ec=GOLD_DARK, lw=0.8))
    ax.text(5, 4.8, "§", ha="center", va="center", color=GOLD, fontsize=46)
    ax.text(5, 2.5, "Davenport & Helmsley · Banking Litigation Practice", ha="center",
            color=GOLD_LIGHT, fontsize=9)
    return _save(fig, name)


def vis_icon_grid(name, title, items, caption=""):
    """items: list of (icon_glyph, label, sub)"""
    n = len(items)
    cols = 3
    rows = math.ceil(n/cols)
    fig, ax = plt.subplots(figsize=(8.5, 2 + 2.4*rows))
    ax.set_xlim(0,10); ax.set_ylim(0, 2+2.4*rows); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    H = 2 + 2.4*rows
    ax.text(5, H-0.5, title, ha="center", color=NAVY, fontsize=14, weight="bold")
    palette = [NAVY, TEAL, GOLD_DARK, ACCENT, "#5A2A6C", "#2F7D4F"]
    for i, (g, lbl, sub) in enumerate(items):
        r = i // cols; c = i % cols
        x = 0.5 + c*3.1; y = H - 1.3 - r*2.2
        col = palette[i % len(palette)]
        ax.add_patch(FancyBboxPatch((x, y-1.6), 2.9, 1.8,
                                    boxstyle="round,pad=0.03,rounding_size=0.12",
                                    fc=PAPER_DARK, ec=col, lw=1.2))
        ax.add_patch(Circle((x+0.55, y-0.45), 0.35, fc=col, ec=GOLD, lw=1))
        ax.text(x+0.55, y-0.5, g, ha="center", va="center", color="white", fontsize=18)
        ax.text(x+1.05, y-0.2, lbl, color=NAVY, fontsize=10, weight="bold")
        ax.text(x+1.05, y-0.55, sub, color=MUTED, fontsize=8, style="italic", wrap=True)
        # multi-line sub
        # additional bullet area
    if caption:
        ax.text(5, 0.2, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_mind_map(name, title, center, branches, caption=""):
    import textwrap as _tw
    fig, ax = plt.subplots(figsize=(11, 11))
    ax.set_xlim(0,12); ax.set_ylim(0,12); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.text(6, 11.5, title, ha="center", color=NAVY, fontsize=15, weight="bold")
    ax.plot([4, 8], [11.22, 11.22], color=GOLD, lw=1.2)
    # central glow
    for r, a in [(2.0, 0.05), (1.7, 0.08), (1.45, 0.14)]:
        ax.add_patch(Circle((6, 6), r, fc=GOLD, ec="none", alpha=a))
    ax.add_patch(Circle((6, 6), 1.35, fc=NAVY, ec=GOLD, lw=2.4))
    ax.text(6, 6, _tw.fill(center, width=14), ha="center", va="center",
            color="white", fontsize=11, weight="bold")
    cols = [TEAL_DEEP, GOLD_DARK, ACCENT, PURPLE, GREEN_DEEP, ROYAL, COPPER, "#1B3A5C"]
    n = len(branches)
    for i, (lbl, leaves) in enumerate(branches):
        ang = 2*math.pi*i/n - math.pi/2
        bx = 6 + 3.4*math.cos(ang); by = 6 + 3.4*math.sin(ang)
        col = cols[i % len(cols)]
        ax.plot([6+1.35*math.cos(ang), bx], [6+1.35*math.sin(ang), by], color=col, lw=2.5)
        ax.add_patch(FancyBboxPatch((bx-1.15, by-0.36), 2.30, 0.72,
                                    boxstyle="round,pad=0.04,rounding_size=0.12",
                                    fc=col, ec=GOLD, lw=1.2))
        ax.text(bx, by, _tw.fill(lbl, width=22), ha="center", va="center",
                color="white", fontsize=9, weight="bold")
        # leaves arranged on outer arc
        m = len(leaves)
        for j, leaf in enumerate(leaves):
            la = ang + (j-(m-1)/2)*0.32
            lx = bx + 1.85*math.cos(la); ly = by + 1.85*math.sin(la)
            ax.plot([bx+1.0*math.cos(la), lx], [by+0.36*math.sin(la), ly],
                    color=col, lw=0.8, alpha=0.65)
            ax.text(lx, ly, _tw.fill(leaf, width=20), ha="center", va="center",
                    color=NAVY, fontsize=7.4,
                    bbox=dict(fc=PAPER_DARK, ec=col, boxstyle="round,pad=0.18", lw=0.6))
    if caption:
        ax.text(6, 0.3, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_split_compare(name, title, left_title, left_items, right_title, right_items, caption=""):
    fig, ax = plt.subplots(figsize=(8.5, 9))
    ax.axis("off"); fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.set_xlim(0,10); ax.set_ylim(0,10)
    ax.text(5, 9.5, title, ha="center", color=NAVY, fontsize=14, weight="bold")
    # left col
    ax.add_patch(FancyBboxPatch((0.4, 0.6), 4.5, 8.4,
                                boxstyle="round,pad=0.04,rounding_size=0.15",
                                fc=NAVY, ec=GOLD, lw=1.4))
    ax.text(2.65, 8.5, left_title, ha="center", color=GOLD, fontsize=12, weight="bold")
    for i, it in enumerate(left_items):
        ax.text(0.7, 7.8-i*0.6, "▸  "+it, color="white", fontsize=9.5, va="top", wrap=True)
    # right col
    ax.add_patch(FancyBboxPatch((5.1, 0.6), 4.5, 8.4,
                                boxstyle="round,pad=0.04,rounding_size=0.15",
                                fc=ACCENT, ec=GOLD, lw=1.4))
    ax.text(7.35, 8.5, right_title, ha="center", color=GOLD, fontsize=12, weight="bold")
    for i, it in enumerate(right_items):
        ax.text(5.4, 7.8-i*0.6, "▸  "+it, color="white", fontsize=9.5, va="top", wrap=True)
    # vs badge
    ax.add_patch(Circle((5, 4.8), 0.5, fc=GOLD, ec=NAVY, lw=2))
    ax.text(5, 4.78, "VS", ha="center", va="center", color=NAVY, fontsize=14, weight="bold")
    if caption:
        ax.text(5, 0.2, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_steps_horizontal(name, title, steps, caption=""):
    n = len(steps)
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.set_xlim(0, n+1); ax.set_ylim(0, 5); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.text((n+1)/2, 4.5, title, ha="center", color=NAVY, fontsize=13, weight="bold")
    cols = [NAVY, TEAL, GOLD_DARK, ACCENT, "#5A2A6C", "#2F7D4F", "#1B3A5C", "#8C5E10"]
    for i, (lbl, sub) in enumerate(steps):
        x = i + 1
        col = cols[i % len(cols)]
        # chevron
        ax.add_patch(mpatches.FancyArrow(x-0.5, 2.5, 0.95, 0,
                                          width=1.2, head_width=1.2, head_length=0.25,
                                          length_includes_head=True, fc=col, ec=GOLD, lw=0.8))
        ax.text(x, 2.7, f"{i+1}", ha="center", va="center", color=GOLD,
                fontsize=14, weight="bold")
        ax.text(x, 2.25, lbl, ha="center", va="center", color="white", fontsize=8.2, weight="bold")
        ax.text(x, 1.0, sub, ha="center", color=NAVY, fontsize=8, wrap=True)
    if caption:
        ax.text((n+1)/2, 0.2, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_heatmap(name, title, rows, cols, data, caption=""):
    fig, ax = plt.subplots(figsize=(8.5, 6))
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    arr = np.array(data)
    im = ax.imshow(arr, cmap="YlOrBr", aspect="auto")
    ax.set_xticks(range(len(cols))); ax.set_xticklabels(cols, rotation=20, ha="right", color=NAVY)
    ax.set_yticks(range(len(rows))); ax.set_yticklabels(rows, color=NAVY)
    for i in range(arr.shape[0]):
        for j in range(arr.shape[1]):
            ax.text(j, i, str(arr[i,j]), ha="center", va="center",
                    color="black" if arr[i,j]<arr.max()*0.6 else "white",
                    fontsize=9, weight="bold")
    ax.set_title(title, color=NAVY, fontsize=13, weight="bold", pad=12)
    if caption:
        fig.text(0.5, 0.01, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_funnel(name, title, stages, caption=""):
    fig, ax = plt.subplots(figsize=(8, 7))
    ax.axis("off"); fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.set_xlim(0,10); ax.set_ylim(0,10)
    ax.text(5, 9.5, title, ha="center", color=NAVY, fontsize=14, weight="bold")
    n = len(stages)
    cols = [NAVY, TEAL, GOLD_DARK, ACCENT, "#5A2A6C", "#2F7D4F"]
    for i, (lbl, sub, pct) in enumerate(stages):
        y_top = 8.5 - i*1.3
        y_bot = y_top - 1.1
        w_top = 8.0 - i*1.0
        w_bot = 8.0 - (i+1)*1.0
        x_top = (10 - w_top)/2
        x_bot = (10 - w_bot)/2
        poly = plt.Polygon([(x_top, y_top), (x_top+w_top, y_top),
                            (x_bot+w_bot, y_bot), (x_bot, y_bot)],
                           closed=True, fc=cols[i % len(cols)], ec=GOLD, lw=1.2)
        ax.add_patch(poly)
        ax.text(5, (y_top+y_bot)/2+0.1, f"{lbl}  —  {pct}", ha="center", color="white",
                fontsize=10.5, weight="bold")
        ax.text(5, (y_top+y_bot)/2-0.3, sub, ha="center", color="white",
                fontsize=8.5, style="italic")
    if caption:
        ax.text(5, 0.2, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


def vis_radial(name, title, items, caption=""):
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.set_xlim(-5,5); ax.set_ylim(-5,5); ax.axis("off")
    fig.patch.set_facecolor(PAPER); ax.set_facecolor(PAPER)
    ax.text(0, 4.6, title, ha="center", color=NAVY, fontsize=14, weight="bold")
    ax.add_patch(Circle((0,0), 1.0, fc=NAVY, ec=GOLD, lw=2))
    ax.text(0, 0, "CORE", ha="center", va="center", color="white", fontsize=11, weight="bold")
    n = len(items)
    cols = [TEAL, GOLD_DARK, ACCENT, "#5A2A6C", "#2F7D4F", NAVY, "#8C5E10", "#1B3A5C"]
    for i, (lbl, sub) in enumerate(items):
        ang = 2*math.pi*i/n - math.pi/2
        x = 3.0*math.cos(ang); y = 3.0*math.sin(ang)
        col = cols[i % len(cols)]
        ax.plot([1.0*math.cos(ang), x-0.7*math.cos(ang)],
                [1.0*math.sin(ang), y-0.7*math.sin(ang)],
                color=col, lw=1.5)
        ax.add_patch(Circle((x,y), 0.85, fc=col, ec=GOLD, lw=1.2))
        ax.text(x, y+0.05, lbl, ha="center", color="white", fontsize=9, weight="bold")
        ax.text(x, y-0.3, sub, ha="center", color="white", fontsize=7.5, style="italic")
    if caption:
        ax.text(0, -4.7, caption, ha="center", color=MUTED, fontsize=8.5, style="italic")
    return _save(fig, name)


# ============================================================
# REPORTLAB DOC SETUP
# ============================================================

PAGE_W, PAGE_H = A4
MARGIN_L, MARGIN_R = 22*mm, 22*mm
MARGIN_T, MARGIN_B = 25*mm, 22*mm
FRAME_W = PAGE_W - MARGIN_L - MARGIN_R
FRAME_H = PAGE_H - MARGIN_T - MARGIN_B

styles = getSampleStyleSheet()

H1 = ParagraphStyle("H1", parent=styles["Heading1"],
    fontName="Times-Bold", fontSize=22, leading=26, textColor=HexColor(NAVY),
    spaceBefore=0, spaceAfter=10, alignment=TA_LEFT)
H2 = ParagraphStyle("H2", parent=styles["Heading2"],
    fontName="Times-Bold", fontSize=15, leading=18, textColor=HexColor(NAVY),
    spaceBefore=10, spaceAfter=6)
H3 = ParagraphStyle("H3", parent=styles["Heading3"],
    fontName="Times-Bold", fontSize=12, leading=15, textColor=HexColor(GOLD_DARK),
    spaceBefore=8, spaceAfter=4)
BODY = ParagraphStyle("BODY", parent=styles["BodyText"],
    fontName="Times-Roman", fontSize=10.5, leading=14.5, textColor=HexColor(INK),
    alignment=TA_JUSTIFY, spaceAfter=6)
BODY_SM = ParagraphStyle("BODY_SM", parent=BODY, fontSize=9.5, leading=13)
ITAL = ParagraphStyle("ITAL", parent=BODY, fontName="Times-Italic", textColor=HexColor(MUTED))
CAP = ParagraphStyle("CAP", parent=BODY, fontName="Times-Italic",
    fontSize=8.5, leading=11, textColor=HexColor(MUTED), alignment=TA_CENTER)
PULL = ParagraphStyle("PULL", parent=BODY, fontName="Times-Italic",
    fontSize=12, leading=16, textColor=HexColor(NAVY),
    leftIndent=14, rightIndent=14, spaceBefore=8, spaceAfter=8, alignment=TA_CENTER)
BULL = ParagraphStyle("BULL", parent=BODY, leftIndent=14, bulletIndent=4)
TOC_E = ParagraphStyle("TOC_E", parent=BODY, fontSize=10.5, leading=14, alignment=TA_LEFT)
NOTE_H = ParagraphStyle("NOTE_H", parent=H3, fontSize=11, textColor=HexColor("#7A4F00"), spaceBefore=12, spaceAfter=4)
NOTE_BODY = ParagraphStyle("NOTE_BODY", parent=BODY, fontSize=10, leading=14,
                           leftIndent=10, rightIndent=10, spaceAfter=6,
                           textColor=HexColor(INK), alignment=TA_JUSTIFY)


# ============================================================
# CONTENT  —  this is the meat of the book
# ============================================================

PARTS = [
    {
        "no": 1, "title": "Foundations", "subtitle": "The legal & institutional architecture of banking litigation in Malaysia",
        "color": NAVY,
        "chapters": ["The Banking Sector and Its Disputes",
                     "Sources of Law",
                     "Court Hierarchy & Specialised Divisions"],
    },
    {
        "no": 2, "title": "The Banker–Customer Relationship", "subtitle": "Contract, fiduciary duty, secrecy and the duty of care",
        "color": "#1B3A5C",
        "chapters": ["Contractual Foundations",
                     "Banking Secrecy under FSA & IFSA",
                     "The Duty of Care and Mareva-style Relief"],
    },
    {
        "no": 3, "title": "Loan Recovery Litigation", "subtitle": "From letter of demand to judgment and beyond",
        "color": "#143049",
        "chapters": ["Default and Acceleration",
                     "Letter of Demand · Pleadings · O.14",
                     "Judgment, Execution and Enforcement"],
    },
    {
        "no": 4, "title": "Securities and Charges (NLC)", "subtitle": "Foreclosure, auction, redemption and the Order for Sale",
        "color": "#1F3B25",
        "chapters": ["The National Land Code Charge",
                     "The Order for Sale Procedure",
                     "Setting Aside Auctions and Redemption"],
    },
    {
        "no": 5, "title": "Guarantees and Indemnities", "subtitle": "Sureties, co-extensive liability and discharge",
        "color": "#3B1F1F",
        "chapters": ["Nature of the Guarantee",
                     "Defences Available to the Guarantor",
                     "Enforcement Strategy and Subrogation"],
    },
    {
        "no": 6, "title": "Bankruptcy Proceedings", "subtitle": "The Insolvency Act 1967 in practical operation",
        "color": "#3A2A12",
        "chapters": ["Bankruptcy Notice and Act of Bankruptcy",
                     "The Creditor's Petition",
                     "Effect of Adjudication and Discharge"],
    },
    {
        "no": 7, "title": "Winding-Up of Companies", "subtitle": "Section 466 petitions and the path to liquidation",
        "color": "#2A1A3A",
        "chapters": ["Statutory Notice of Demand",
                     "The Winding-Up Petition",
                     "Liquidator's Powers and Priority of Debts"],
    },
    {
        "no": 8, "title": "Islamic Banking Litigation", "subtitle": "Shariah compliance, BNM-SAC references and IFSA enforcement",
        "color": "#2A4A2A",
        "chapters": ["Conventional vs. Islamic Banking Disputes",
                     "Reference to the Shariah Advisory Council",
                     "Enforcement of Islamic Facility Agreements"],
    },
    {
        "no": 9, "title": "Cheques, Negotiable Instruments & Banking Fraud", "subtitle": "BoEA 1949, conversion, and recovering misappropriated funds",
        "color": "#2A2A4A",
        "chapters": ["Cheques and Wrongful Dishonour",
                     "Conversion and Money Had and Received",
                     "Tracing, Mareva and Anton Piller Relief"],
    },
    {
        "no": 10, "title": "Procedural & Strategic Practitioner's Guide", "subtitle": "Workflow, evidence, drafting and ethics",
        "color": "#1A2A2A",
        "chapters": ["Workflow and Case Management",
                     "Evidence in Banking Cases",
                     "Drafting · Costs · Ethics"],
    },
]

# ---- Pre-compute / generate visual assets -----------------------------------

def build_visuals():
    visuals = {}
    visuals["cover"] = vis_full_cover()
    for p in PARTS:
        visuals[f"part_{p['no']}_div"] = vis_part_divider(
            p["no"], p["title"], p["subtitle"],
            [f"Chapter {p['no']}.{i+1}  {c}" for i, c in enumerate(p["chapters"])])
    visuals["court_hierarchy"] = vis_court_hierarchy()
    visuals["statutory_map"] = vis_statutory_map()

    # appendix dividers
    visuals["app_a_div"] = vis_part_divider(
        "A", "Templates & Sample Documents",
        "Working precedents for the litigation file",
        ["Letter of Demand", "Statement of Claim", "Form 16D",
         "Originating Summons (Order for Sale)", "Bankruptcy Notice",
         "Section 466 Statutory Demand", "Affidavit Verifying Statement of Account"])
    visuals["app_b_div"] = vis_part_divider(
        "B", "Case Compendium",
        "Leading authorities, brief by brief",
        ["Foundations & Banker–Customer", "Loan Recovery & Order 14",
         "Securities & Charges", "Insolvency",
         "Islamic Banking", "Negotiable Instruments & Fraud"])

    visuals["loan_recovery_flow"] = vis_flow(
        "loan_recovery_flow",
        "End-to-End Loan Recovery Workflow",
        [
            ("Default Event", "Missed instalment(s) — trigger of the cause of action"),
            ("Internal Collection", "Reminder calls · letters · restructuring offer"),
            ("Letter of Demand", "Formal notice — typically 7 to 21 days"),
            ("Originating Process", "Writ + Statement of Claim or Originating Summons"),
            ("Order 14 Summary Judgment", "If no triable issue — prompt resolution"),
            ("Judgment & Execution", "Writ of Seizure & Sale · Garnishee · JDS"),
            ("Bankruptcy / Winding-up", "Insolvency proceedings against debtor"),
        ],
        "Diagram 3.1 · The full loan recovery sequence under Malaysian practice"
    )
    visuals["foreclosure_flow"] = vis_flow(
        "foreclosure_flow",
        "Foreclosure under the National Land Code",
        [
            ("Default in Charge Repayment", "Section 254 NLC — chargor in default"),
            ("Form 16D Notice", "Statutory notice — 1 month to remedy"),
            ("Application for Order for Sale", "OS in High Court (registry land) / Land Office (subdivisional)"),
            ("Order for Sale & Reserve Price", "Court / Pentadbir Tanah fixes auction terms"),
            ("Public Auction", "Conducted by court / DOL — successful bidder"),
            ("Confirmation & Transfer", "Memorandum of sale · Form 16I"),
            ("Distribution of Proceeds", "Charge debt · costs · surplus to chargor"),
        ],
        "Diagram 4.1 · Section 254 foreclosure flow"
    )
    visuals["bankruptcy_flow"] = vis_flow(
        "bankruptcy_flow",
        "Bankruptcy Procedure (Insolvency Act 1967)",
        [
            ("Judgment Debt ≥ RM 100,000", "Threshold raised by Insolvency (Amendment) Act 2017"),
            ("Bankruptcy Notice", "Form 3 — served on debtor"),
            ("Failure to Comply (7 days)", "Constitutes act of bankruptcy"),
            ("Creditor's Petition", "Filed within 6 months in High Court"),
            ("Receiving & Adjudication Order", "Property vests in DGI"),
            ("Statement of Affairs", "Debtor must file within 21 days"),
            ("Discharge", "By DGI certificate / court order / automatic (3 yrs)"),
        ],
        "Diagram 6.1 · The Insolvency Act 1967 procedural pipeline"
    )
    visuals["winding_up_flow"] = vis_flow(
        "winding_up_flow",
        "Winding-Up under Section 466 Companies Act 2016",
        [
            ("Debt Owing ≥ RM 50,000", "Statutory threshold under s.466"),
            ("Statutory Notice of Demand", "21-day demand under s.466(1)(a)"),
            ("Failure to Pay or Secure", "Deemed inability to pay debts"),
            ("Filing of Winding-Up Petition", "Form 2 + affidavit · advertisement"),
            ("Hearing of Petition", "Opposition · adjournment · contested issues"),
            ("Winding-Up Order", "Liquidator appointed (interim or final)"),
            ("Realisation & Distribution", "Statutory order of priority s.527"),
        ],
        "Diagram 7.1 · Compulsory winding-up sequence"
    )
    visuals["o14_flow"] = vis_flow(
        "o14_flow",
        "Order 14 Summary Judgment Mechanics",
        [
            ("Service of Defence", "Defendant enters appearance & files defence"),
            ("Plaintiff's O.14 Application", "Affidavit verifying claim — no triable issue"),
            ("Defendant's Affidavit in Reply", "Must raise bona fide triable issue"),
            ("Court Hearing", "Senior Assistant Registrar"),
            ("Outcome", "Judgment · Conditional Leave · Unconditional Leave"),
        ],
        "Diagram 3.2 · O.14 mechanics in banking claims"
    )
    visuals["islamic_v_conv"] = vis_split_compare(
        "islamic_v_conv",
        "Islamic vs. Conventional Banking Disputes",
        "CONVENTIONAL", [
            "Governed primarily by FSA 2013",
            "Riba (interest) is the consideration",
            "Standard loan/security documentation",
            "Ordinary contract law principles",
            "No SAC reference required",
            "Default judgment includes interest at agreed rate",
            "Common-law assignment and set-off apply",
        ],
        "ISLAMIC", [
            "Governed by IFSA 2013 + Shariah Standards",
            "Profit/rent/sale-based structures (BBA, Murabahah, Ijarah)",
            "Documentation must reflect Shariah contract used",
            "Section 56 CBMA: court must refer Shariah questions",
            "SAC ruling binding under s.57 CBMA",
            "Late payment compensation (ta'widh) not riba",
            "Ibra' (rebate) commonly required at full settlement",
        ],
        "Diagram 8.1 · Two regimes, two doctrines"
    )
    visuals["lim_periods"] = vis_compare(
        "lim_periods",
        "Limitation Periods Affecting Banking Claims",
        ["Cause of Action", "Period", "Statute"],
        [
            ["Simple contract (loan)", "6 years", "s.6(1)(a) Limitation Act 1953"],
            ["Specialty / deed", "12 years", "s.6(3) LA 1953"],
            ["Recovery of land (charge)", "12 years", "s.9 LA 1953"],
            ["Action on judgment", "12 years", "s.6(3) LA 1953"],
            ["Recovery of charge money", "12 years", "s.21 LA 1953"],
            ["Tort (conversion of cheque)", "6 years", "s.6(1)(a) LA 1953"],
            ["Equitable claims (tracing)", "Analogy applies", "Common law"],
            ["Bankruptcy (after judgment)", "6 yrs from JD", "Re Mok Yong Kong"],
        ],
        "Table 1.1 · Quick limitation reference for the practitioner"
    )
    visuals["court_hierarchy_pillars"] = vis_pillars(
        "court_hierarchy_pillars",
        "The Five Pillars of Banking Adjudication",
        [
            ("FEDERAL", ["Apex", "Constitutional", "Final appeal"]),
            ("APPEAL", ["Three judges", "Banking appeals", "Issues of law"]),
            ("HIGH", ["Unlimited", "Bank disputes", "Winding-up"]),
            ("SESSIONS", ["≤ RM 1m", "Recovery", "Hire-purchase"]),
            ("MAGISTRATES", ["≤ RM 100k", "Small claims", "Default judgment"]),
        ],
        "Diagram 1.3 · Functional pillars of the Malaysian court system"
    )
    visuals["banker_customer_quad"] = vis_quad(
        "banker_customer_quad",
        "The Four Faces of the Banker–Customer Relationship",
        [
            ("DEBTOR–CREDITOR", [
                "Foley v Hill (1848)", "Deposit becomes bank's money",
                "Bank repays on demand", "Foundation of all retail banking"]),
            ("AGENT–PRINCIPAL", [
                "Cheque collection", "Standing instructions",
                "Duty to act with care", "Liable for negligent execution"]),
            ("BAILEE–BAILOR", [
                "Safe deposit boxes", "Items in custody",
                "Duty of reasonable care", "Strict liability if delivered wrong"]),
            ("FIDUCIARY", [
                "Limited – not generic", "Trust accounts",
                "Investment advice (Quincecare)", "Constructive notice doctrine"]),
        ],
        "Diagram 2.1 · The relationship is multi-faceted, not monolithic"
    )
    visuals["security_radial"] = vis_radial(
        "security_radial",
        "Forms of Banking Security in Malaysia",
        [
            ("CHARGE", "NLC s.241 — title-based"),
            ("DEBENTURE", "Companies Act — fixed/floating"),
            ("ASSIGNMENT", "Equitable / statutory"),
            ("LIEN", "Common-law possessory"),
            ("PLEDGE", "Possession of moveables"),
            ("GUARANTEE", "Personal / corporate"),
            ("MEMORANDUM", "of deposit of title"),
            ("HIRE-PURCH.", "HPA 1967 reservation"),
        ],
        "Diagram 4.2 · The taxonomy of banking security"
    )
    visuals["cheque_dishonor"] = vis_decision_tree(
        "cheque_dishonor",
        "Wrongful Dishonour of Cheques — Decision Tree",
        "Cheque presented and refused?",
        [
            ("Insufficient funds  →", "RIGHTFUL", "No bank liability", GREEN_OK),
            ("Funds available  →", "WRONGFUL", "Bank liable to drawer", RED_WARN),
            ("Stop-payment  →", "JUSTIFIED", "If validly issued", TEAL),
            ("Stale (>6 mo)  →", "RIGHTFUL", "Bank may refuse", GREEN_OK),
        ],
        "Diagram 9.1 · Banker's exposure analysis on cheque return"
    )
    visuals["enforcement_funnel"] = vis_funnel(
        "enforcement_funnel",
        "Enforcement Funnel — From Judgment to Recovery",
        [
            ("Judgment Obtained", "Money judgment in plaintiff's favour", "100%"),
            ("Asset Identification", "Searches, JDS, oral examination", "75%"),
            ("Execution Process", "WSS · garnishee · prohibitory order", "55%"),
            ("Realisation", "Sale of seized assets · debt collection", "35%"),
            ("Net Recovery", "After costs, sheriff fees, legal", "20–30%"),
        ],
        "Diagram 3.3 · Realistic funnel of post-judgment recovery"
    )
    visuals["banking_disputes_pie"] = vis_pie(
        "banking_disputes_pie",
        "Composition of Banking Disputes Filed (Indicative)",
        ["Loan recovery", "Foreclosure", "Guarantees", "Cheques/fraud",
         "Islamic banking", "Other"],
        [42, 21, 14, 8, 9, 6],
        "Chart 1.1 · Indicative distribution of banking disputes in superior courts"
    )
    visuals["dispute_trend_bar"] = vis_bar(
        "dispute_trend_bar",
        "Filings of Banking-Related Civil Suits — Indicative Trend",
        ["2018", "2019", "2020", "2021", "2022", "2023", "2024"],
        [4280, 4510, 5130, 5870, 5440, 5780, 6120],
        ylabel="Civil suits filed",
        caption="Chart 1.2 · Indicative trend of banking-related civil filings"
    )
    visuals["o14_decision"] = vis_decision_tree(
        "o14_decision",
        "Order 14 Outcome Decision Tree",
        "Is there a triable issue?",
        [
            ("No issue raised", "JUDGMENT", "Final · costs to bank", GREEN_OK),
            ("Triable on terms", "COND. LEAVE", "e.g. payment into court", GOLD_DARK),
            ("Bona fide dispute", "UNCOND. LEAVE", "Trial proceeds", TEAL),
            ("Vexatious / sham", "STRIKE-OUT", "If counterclaim baseless", RED_WARN),
        ],
        "Diagram 3.4 · Reading the SAR's mind in O.14 hearings"
    )
    visuals["islamic_contracts_grid"] = vis_icon_grid(
        "islamic_contracts_grid",
        "Common Islamic Banking Contracts in Litigation",
        [
            ("☪", "Murabahah", "Cost-plus sale"),
            ("⚖", "BBA", "Bai' Bithaman Ajil"),
            ("☾", "Ijarah", "Lease-based"),
            ("✦", "Musharakah", "Equity partnership"),
            ("✸", "Mudharabah", "Profit-sharing"),
            ("☼", "Tawarruq", "Reverse Murabahah"),
            ("✧", "Wakalah", "Agency"),
            ("◈", "Qard", "Benevolent loan"),
            ("✺", "Kafalah", "Guarantee"),
        ],
        "Diagram 8.2 · The vocabulary of Islamic banking disputes"
    )
    visuals["guarantor_defences"] = vis_check_x(
        "guarantor_defences",
        "Defences Available to a Guarantor — Quick Reference",
        [
            ("Non est factum (signed in error)", True),
            ("Material variation of principal contract without consent", True),
            ("Discharge of principal debtor", True),
            ("Release of co-surety", True),
            ("Loss of security by creditor's negligence", True),
            ("Statute of limitations expired", True),
            ("Mere delay by the bank", False),
            ("Bank's failure to sue principal first (without 'see-to-it' clause)", False),
            ("Insolvency of principal debtor (alone)", False),
            ("Bank's commercial decision to restructure", False),
        ],
        "Diagram 5.1 · Which defences fly in court — and which do not"
    )
    visuals["mind_loan_recovery"] = vis_mind_map(
        "mind_loan_recovery",
        "The Mental Map of Loan Recovery",
        "RECOVERY",
        [
            ("Pre-action", ["LOD", "Restructure", "Limitation"]),
            ("Pleadings", ["SOC", "Particulars", "COA"]),
            ("Interim", ["Mareva", "Injunction", "Discovery"]),
            ("Trial", ["Witnesses", "Cross-X", "Documents"]),
            ("Judgment", ["Default", "Summary", "Trial"]),
            ("Execution", ["WSS", "Garnishee", "Charging"]),
            ("Insolvency", ["Bankruptcy", "Winding-up", "JM"]),
            ("Costs", ["Party-party", "Indemnity", "Solicitor-client"]),
        ],
        "Diagram 3.5 · Topology of a banking recovery file"
    )
    visuals["section_cover_2"] = vis_section_cover("section_cover_2",
        "PART II", "Banker–Customer Relationship",
        "The contract that everything else flows from", "#1B3A5C")
    visuals["heatmap_risk"] = vis_heatmap(
        "heatmap_risk",
        "Bank's Litigation Risk Heatmap",
        ["Retail loans", "SME credit", "Corporate", "Islamic", "Trade finance"],
        ["Default", "Foreclosure", "Guarantor", "Procedural", "Reputational"],
        [[5,4,3,2,1],[4,4,4,3,2],[3,3,5,3,4],[3,3,3,4,3],[2,3,2,3,3]],
        "Diagram 1.4 · Where the risk concentrates"
    )
    visuals["steps_h_lod"] = vis_steps_horizontal(
        "steps_h_lod",
        "Anatomy of a Banker's Letter of Demand",
        [
            ("Header", "Bank · borrower · facility ref"),
            ("Recital", "Loan particulars & default"),
            ("Demand", "Sum due · 7-21 days"),
            ("Reservation", "All rights reserved"),
            ("Consequences", "Suit · bankruptcy · WU"),
        ],
        "Diagram 3.6 · Each LOD must do five jobs"
    )
    visuals["islamic_steps_h"] = vis_steps_horizontal(
        "islamic_steps_h",
        "SAC Reference under the Central Bank of Malaysia Act",
        [
            ("Shariah Issue", "Court identifies Shariah question"),
            ("Stay & Refer", "s.56 CBMA mandatory"),
            ("SAC Deliberates", "Council issues ruling"),
            ("Court Receives", "s.57 binds court"),
            ("Apply to Facts", "Resume hearing"),
        ],
        "Diagram 8.3 · The s.56–57 reference pathway"
    )
    visuals["mareva_quad"] = vis_quad(
        "mareva_quad",
        "Mareva Injunction — The Four Tests (Mareva Compania Naviera v IBC)",
        [
            ("GOOD ARGUABLE CASE", [
                "Plaintiff has a real claim",
                "Not necessarily strong",
                "Test of plausibility"]),
            ("ASSETS WITHIN JURISDICTION", [
                "Identifiable assets",
                "Specifically named",
                "Sufficient to satisfy claim"]),
            ("RISK OF DISSIPATION", [
                "Real risk of removal",
                "Or dissipation to defeat",
                "Inferred from conduct"]),
            ("BALANCE OF CONVENIENCE", [
                "Justice favours grant",
                "Undertaking as to damages",
                "Full and frank disclosure"]),
        ],
        "Diagram 9.2 · The four-limb test for freezing relief"
    )
    visuals["winding_up_steps"] = vis_steps_horizontal(
        "winding_up_steps",
        "From Demand to Liquidation — Winding-Up at a Glance",
        [
            ("s.466 Demand", "21 days · debt ≥ RM 50k"),
            ("Petition", "Form 2 + affidavit"),
            ("Advertisement", "Gazette · 1 newspaper"),
            ("Hearing", "Opposition / consent"),
            ("Order", "Liquidator appointed"),
            ("Realisation", "s.527 priority"),
        ],
        "Diagram 7.2 · The macro view of compulsory winding-up"
    )
    visuals["evidence_pillars"] = vis_pillars(
        "evidence_pillars",
        "The Evidentiary Backbone of a Banking Trial",
        [
            ("BANKER'S BOOK", ["Evidence Act", "ss.90A-90C", "Computer print-outs"]),
            ("STATEMENT OF ACCOUNT", ["Certified", "Debt quantification", "Proof of debit"]),
            ("LOD & PROOF OF SERVICE", ["AR card", "Affidavit of service", "Trigger of cause"]),
            ("FACILITY DOCS", ["Letter of Offer", "Charge", "Guarantee"]),
            ("WITNESS AFF", ["Recovery officer", "Personal knowledge", "BPA"]),
        ],
        "Diagram 10.1 · What every banking-trial bundle must contain"
    )
    visuals["ethics_quad"] = vis_quad(
        "ethics_quad",
        "Ethical Quadrants for the Banking Litigator",
        [
            ("CANDOUR", [
                "Duty to court paramount",
                "No misleading authorities",
                "Disclose adverse decisions",
                "LPA 1976 r.31"]),
            ("CONFIDENTIALITY", [
                "Bank secrecy s.133 FSA",
                "Privileged communications",
                "Document handling",
                "Cyber-security"]),
            ("CONFLICT OF INTEREST", [
                "Bank vs. director",
                "Multiple guarantors",
                "Group restructuring",
                "Documented waivers"]),
            ("COMPETENCE", [
                "CPD obligations",
                "Specialist knowledge",
                "Case management",
                "Counsel's brief"]),
        ],
        "Diagram 10.2 · The four ethical compass-points"
    )
    visuals["damages_pie"] = vis_pie(
        "damages_pie",
        "Heads of Recovery in a Banking Suit",
        ["Principal", "Contractual interest", "Late charges", "Costs", "Disbursements"],
        [62, 23, 6, 7, 2],
        "Chart 3.1 · Composition of typical judgment sum"
    )
    visuals["foreclosure_timeline"] = vis_timeline(
        "foreclosure_timeline",
        "Indicative Timeline — Foreclosure under Section 254 NLC",
        [
            ("Day 0", "Default established"),
            ("Day 30", "Form 16D issued"),
            ("Day 60", "OS filed"),
            ("Day 120", "OFS granted"),
            ("Day 180", "Auction"),
            ("Day 220", "Memorandum"),
        ],
        "Diagram 4.3 · From default to disposition: roughly six months"
    )
    visuals["bankruptcy_timeline"] = vis_timeline(
        "bankruptcy_timeline",
        "Indicative Timeline — Bankruptcy Proceedings",
        [
            ("Day 0", "Judgment debt"),
            ("Day 14", "BN issued"),
            ("Day 21", "Default"),
            ("Day 60", "CP filed"),
            ("Day 120", "RO/AO"),
            ("Year 3", "Eligible discharge"),
        ],
        "Diagram 6.2 · From judgment to discharge"
    )
    visuals["winding_up_timeline"] = vis_timeline(
        "winding_up_timeline",
        "Indicative Timeline — Winding-Up Petition",
        [
            ("Day 0", "Statutory demand"),
            ("Day 21", "Default"),
            ("Day 30", "Petition filed"),
            ("Day 45", "Advertisement"),
            ("Day 75", "Hearing"),
            ("Day 80+", "Order"),
        ],
        "Diagram 7.3 · Winding-up moves quickly"
    )
    visuals["islamic_v_conv_pie"] = vis_pie(
        "islamic_v_conv_pie",
        "Banking Disputes — Conventional vs. Islamic (Indicative)",
        ["Conventional", "Islamic", "Hybrid"],
        [70, 24, 6],
        "Chart 8.1 · Indicative split of banking disputes"
    )
    visuals["procedure_radial"] = vis_radial(
        "procedure_radial",
        "The Eight Procedural Workstreams",
        [
            ("INTAKE", "Brief & search"),
            ("PLEADINGS", "Drafting"),
            ("INTERIM", "Mareva/SJ"),
            ("DISCOVERY", "Lists & inspection"),
            ("WITNESSES", "WS preparation"),
            ("TRIAL", "Examination"),
            ("JUDGMENT", "Recording"),
            ("APPEAL", "Notice & memo"),
        ],
        "Diagram 10.3 · Workstreams of a banking-litigation file"
    )
    return visuals


# Helper to embed a visual at a chosen width
def img(path, w=None, h=None):
    if w is None: w = FRAME_W * 0.95
    return Image(path, width=w, height=h)


# ============================================================
# PAGE BUILDERS — produce flowables for each page
# ============================================================

def page_break():
    return PageBreak()


def text_block(paragraphs, headings=None):
    """paragraphs: list of (style_key, text) tuples."""
    out = []
    for st, txt in paragraphs:
        s = {"H1": H1, "H2": H2, "H3": H3, "BODY": BODY, "BODY_SM": BODY_SM,
             "ITAL": ITAL, "PULL": PULL, "BULL": BULL, "CAP": CAP}.get(st, BODY)
        if st == "BULL":
            out.append(Paragraph("•&nbsp;&nbsp;" + txt, s))
        else:
            out.append(Paragraph(txt, s))
    return out


VISUAL_COMMENTARY = {
    "court_hierarchy": [
        "The Malaysian court hierarchy for banking matters is layered: the Federal Court at the apex binds all subordinate tribunals on questions of law, while the Court of Appeal supplies the workhorse precedent on procedural and quantum disputes. The High Court — divided into a Commercial Division in Kuala Lumpur and the New Commercial Court in the major registries — hears virtually all sums above RM 1 million. The Sessions Court retains residual jurisdiction up to RM 1 million, and the Magistrates Court below that.",
        "Practitioners should map every dispute to the correct rung at the outset. A claim filed in the wrong court risks dismissal or transfer with costs. For Islamic banking matters, the Muamalah bench in the High Court is now firmly established, and Practice Direction No. 2 of 2009 ensures uniform listing. The diagram above should be treated as a working tool: tape it to the desk and consult it before every fresh filing.",
        "The hierarchy is more than an organisation chart: it is a roadmap of available remedies, of supervisory checks and of cost. Filing one rung higher than necessary is wasteful; filing one rung lower invites transfer and lost time. The mature practitioner picks the correct forum on day one and rarely moves later.",
        "The Muamalat Division and the Commercial Division of the High Court are central. Both are staffed by judges with deep banking experience; both impose case-management rigour. Practitioners new to the divisions should sit through a half-day of public hearings before filing — the procedural culture is unmistakable to anyone who has watched it in action.",
    ],
    "statutory_map": [
        "The statutory architecture rests on five pillars: the Financial Services Act 2013 (conventional banking), the Islamic Financial Services Act 2013 (Islamic banking), the Central Bank of Malaysia Act 2009 (regulator), the National Land Code 1965 (charge enforcement), and the Insolvency Act 1967 / Companies Act 2016 (default consequences).",
        "Each pillar interacts with the others. A defaulted facility under the FSA may trigger NLC foreclosure if secured on land, bankruptcy proceedings if the debtor is an individual, or winding-up under the Companies Act if the debtor is a company. Reading the statutes in isolation is a recipe for missed defences and overlooked remedies.",
        "The statutory map is the practitioner's compass. Each instrument is paired with a small number of operative provisions that recur across the practice; the discipline is to know those provisions cold rather than to know the entire instrument shallowly. A printed copy of the map taped inside the file cover saves hours of orientation on every new file.",
        "The map evolves. The Financial Services Act 2013 and the Islamic Financial Services Act 2013 redrew large portions of the territory; the Companies Act 2016 redrew the corporate-recovery territory; and BNM's regular policy documents continue to redraw operational territory. A practitioner who reviews the map annually will not be caught out by a change.",
    ],
    "loan_recovery_flow": [
        "The recovery pipeline begins long before the writ. Internal default review, an early-warning meeting and the issuance of a structured Letter of Demand routinely save weeks at trial. The LOD is the single most important pre-action document: it crystallises the cause of action, starts the limitation clock running afresh in many cases, and supplies the foundation for the Statement of Claim.",
        "Once the writ is filed, the bank's choice of procedural route is determinative. Order 14 summary judgment is the workhorse where the defence is unarguable; Order 81 summary judgment for liquidated demands offers an alternative track. Where the customer pleads a substantial defence, the matter goes to full trial — adding nine to fifteen months and significant costs.",
        "The flow is linear in the diagram and iterative in practice. A defaulted file may shuttle between the LOD step and the negotiated-restructuring step three or four times before settling on the litigation track; the diagram captures the canonical path, not every variation.",
        "Each step has a documentary footprint that must be preserved: the LOD itself, the proof of service, the response (or its absence), the demand-default certificate. The practitioner who closes a file with a complete documentary footprint protects the bank against any later challenge to the recovery.",
    ],
    "foreclosure_flow": [
        "Foreclosure under the National Land Code is a uniquely Malaysian remedy that combines Torrens registration with statutory enforcement. The process begins with the chargee's internal certification of default, followed by a formal Form 16D (or 16E for Land Office title) giving the chargor one calendar month to remedy.",
        "On non-remedy, the chargee files an Originating Summons (High Court) or Land Office application as appropriate. The Order for Sale fixes the auction date and reserve price. The successful bidder pays a 10% deposit, with balance within 120 days. Failure to complete leads to forfeiture and re-auction at a lower reserve.",
        "The flow distinguishes Order 83 (foreclosure of charged land) from Order 81 (specific performance), and within Order 83 distinguishes the order absolute from the order for sale. The choice between pathways is governed by the relief sought; the practitioner should make the choice at file opening, not at the door of the court.",
        "Auctions are the visible end of the flow. Practitioners must brief the auctioneer on reserve price, advertising and bidding mechanics, and must attend the auction in person. Auctions left to the auctioneer alone produce the surprises that turn into appellate work later.",
    ],
    "bankruptcy_flow": [
        "Bankruptcy after the 2017 amendments is a tightened procedure. The threshold is now RM 100,000 (raised from RM 30,000); social guarantors enjoy a statutory bar; and the discharge regime has been liberalised. The procedure begins with a creditor's Bankruptcy Notice (Form 3), served personally on the judgment debtor.",
        "Failure to comply within seven days constitutes the act of bankruptcy. Within six months, the creditor must file a creditor's petition. On hearing, the court may grant a Receiving Order and Adjudication Order, vesting the bankrupt's estate in the Director General of Insolvency. Property is realised and distributed under statutory priority.",
        "The flow is the surest single example in the practice of the cost of any deviation from procedure. Every step has a form, a time-bar and a content requirement; missing any of these is fatal to the petition.",
        "The Director General of Insolvency's pre-petition requirements (for social guarantors and certain other classes) are the modern bottleneck. Practitioners must discharge these requirements before filing; the petition that arrives at court without the DGI's clearance will be set aside on first listing.",
    ],
    "winding_up_flow": [
        "Winding-up under section 466 of the Companies Act 2016 is the corporate analogue to bankruptcy. A creditor may petition where the company is unable to pay debts, evidenced typically by a 21-day statutory demand for a sum exceeding RM 50,000.",
        "The winding-up petition must be advertised in the Gazette and one English newspaper. At hearing, the court considers whether a bona fide dispute on substantial grounds exists; if so, the petition is dismissed with costs. Otherwise, a winding-up order is granted and a liquidator appointed.",
        "The flow runs from statutory demand to dissolution and runs longer than most practitioners expect: nine to fifteen months for an uncontested petition is typical. Banks must plan recovery cash flow around the timeline rather than around optimistic estimates.",
        "Cross-petitioned schemes of arrangement are the principal source of complication. The bank should formulate its scheme posture before the petition is filed; reactive posture-formation under time pressure produces sub-optimal outcomes for the bank and for the creditor pool.",
    ],
    "islamic_v_conv": [
        "Islamic banking facilities differ from conventional facilities at the level of doctrine, not merely terminology. A BBA contract is a deferred-payment sale; a Murabahah is a cost-plus sale; an Ijarah is a lease. Each has a distinct legal character that affects pleading, remedy and computation.",
        "Conventional facilities, by contrast, are loan-and-interest contracts governed by classical contract law. The two regimes occasionally produce strikingly different outcomes on identical commercial facts — early settlement rebates (ibra'), late-payment compensation (ta'widh) and the consequences of acceleration all operate differently.",
        "The two regimes converge in their procedural infrastructure (the same courts, the same Rules of Court 2012, the same evidentiary standards) but diverge in their substantive doctrine. The convergence is helpful for the practitioner: one set of procedural reflexes governs both regimes. The divergence is what requires the substantive expertise.",
        "Practitioners moving between the two regimes should maintain a personal doctrinal log: which doctrines are common, which differ, and where the SAC rulings have settled questions that remain open in the conventional space. Over time the log becomes a working text.",
    ],
    "cheque_dishonor": [
        "Cheque litigation is technical and unforgiving. The Bills of Exchange Act 1949 codifies the relations between drawer, drawee and payee. A wrongfully dishonoured cheque exposes the bank to damages for breach of mandate; a cheque paid on a forged signature exposes the bank to liability to the true owner.",
        "Section 85 BoEA affords the collecting bank a defence — good faith and absence of negligence — but the burden is on the bank. The customer due-diligence file, account-opening interview and transaction monitoring are routinely subpoenaed, and gaps will defeat the defence.",
        "Cheque litigation has not vanished with electronic payments; it has migrated to image-truncated processes that carry their own evidentiary burdens. The bank that cannot produce a clean image and a clean section 90A certificate will lose despite a perfect substantive defence.",
        "Section 85 BoEA defences are won at account opening, not at trial. The KYC file produced years before the dispute is the documentary foundation of the defence; banks investing in KYC discipline are buying litigation insurance whose value is invisible until the day a cheque is dishonoured.",
    ],
    "procedure_radial": [
        "Procedural mastery distinguishes the journeyman from the expert. The radial diagram captures the eight pillars of the practitioner's craft: pleadings, discovery, interim relief, witness preparation, documentary evidence, submissions, costs and ethics.",
        "Each pillar deserves its own chapter; together, they form the workflow that transforms a case file into a judgment. The MyCCBLitAI platform is built to support this workflow at every stage.",
        "The eight pillars do not stand independently: a weakness in pleadings shows up as a weakness in submissions; a weakness in discovery shows up as a weakness in trial. Practitioners who treat the pillars as a single integrated workflow produce work that is consistently stronger than those who address each pillar in isolation.",
        "The MyCCBLitAI platform was conceived around exactly this radial. Each module of the platform — from the LOD generator through to the costs schedule — is anchored to one of the pillars, and the platform tracks the practitioner's coverage of all eight across the life of every file.",
    ],
    "court_hierarchy_pillars": [
        "Three pillars carry the Malaysian banking judicature: federal authority, commercial expertise and procedural integrity. The Federal Court secures uniformity of law; the Commercial Division in the High Court of Kuala Lumpur secures depth of expertise; and the Rules of Court 2012 secure procedural integrity.",
        "All three pillars must hold for the system to function. Where any one weakens — through delay, inconsistency or procedural laxity — the predictability of banking enforcement is impaired and credit costs rise.",
        "The pillars are not theoretical. They are visible in the daily life of the practice: the Federal Court secures uniformity through Anwar Patrick Adrian and the modern line on summary judgment; the Commercial Division secures expertise through specialised judges who have heard hundreds of banking matters; and the Rules of Court 2012 secure procedural integrity through deadlines that the courts now enforce strictly.",
        "Erosion of any one pillar will be felt in pricing. Banks watching the pillars closely have, over the last decade, seen no material erosion — but they have seen pressure on listing time at the Commercial Division, and have responded with stronger pre-action work to compress disputes before they reach trial.",
    ],
    "banker_customer_quad": [
        "The banker–customer relationship may be analysed across four quadrants: contract (mandate, account terms), agency (instructions, payment processing), tort (negligence, conversion) and statute (FSA, AMLA).",
        "Each quadrant carries its own duty, its own breach and its own remedy. A skilled pleader will identify the operative quadrant before drafting, then plead the duty in its statutory or common-law source.",
        "The four quadrants — contract, agency, tort, statute — are not mutually exclusive. The same set of facts may give rise to claims in two or three quadrants simultaneously, and the relief in each quadrant may differ. The pleader's craft lies in selecting the strongest quadrant as primary, then pleading the others in the alternative without dilution.",
        "Practitioners who treat the quadrants as silos under-plead routinely; practitioners who treat them as overlapping fields of liability over-plead and invite Order 18 rule 19 strikes. The discipline is to identify, for each quadrant, the strongest pleadable cause and the weakest, and to plead only the former.",
    ],
    "security_radial": [
        "The bank's security portfolio typically includes registered charges over land, debentures over corporate assets, assignments of receivables, pledges of shares and personal guarantees. Each carries its own perfection requirements and its own enforcement pathway.",
        "Practitioners must verify perfection at the outset of every recovery file: an unperfected security may be unenforceable in insolvency, ranking pari passu with unsecured creditors and rendering all the bank's earlier care nugatory.",
        "Each spoke of the security wheel carries its own perfection-and-enforcement story. Land charges turn on registration under the National Land Code; debentures on lodgement at the Registrar of Companies; assignments on notice to the account debtor; pledges on possession; and guarantees on form and stamping. The radial reminds the practitioner that no single perfection rule covers every spoke.",
        "The recovery file is, in essence, an audit of the spokes: which spokes were perfected, which were not, which have value at the date of demand, and in what order they should be enforced. The practitioner who runs that audit on day one of the file will know within a week whether the recovery story is a strong one.",
    ],
    "lim_periods": [
        "Limitation periods under the Limitation Act 1953 are unforgiving and must be computed from the date the cause of action arose — typically the date of demand, not the date of facility. A bank that miscalculates limitation may forfeit a multi-million-ringgit claim.",
        "The doctrine of acknowledgement (section 27 LA 1953) provides relief where the debtor has, in writing or by part-payment, acknowledged the debt. Practitioners should comb the file for any such acknowledgement before assuming the claim is time-barred.",
        "Limitation defeats more banking claims than any other single doctrine. The cause is rarely intentional: it is the cumulative effect of stale facilities, lost demand letters and reorganisations of the bank's own recovery teams. The Limitation Act 1953 is not forgiving of administrative drift.",
        "Section 27 LA 1953 (acknowledgement) and section 6(3) (specialty) are the two statutory escape valves most often deployed. Both must be pleaded with precision: a vague acknowledgement plea will be struck out under Order 18 rule 19, and a defective specialty plea will fail at trial. Precision is not optional in this part of the practice.",
    ],
    "dispute_trend_bar": [
        "Filing volumes in the Commercial Division have grown approximately 4% annually over the last decade. The growth is driven principally by SME defaults and consumer credit recoveries, with corporate facility defaults remaining proportionally stable.",
        "Practitioners should expect listing delays of three to six months for trial dates, and should plan their case-management timeline accordingly. Early identification of triable issues — and conversely, of cases ripe for summary disposal — is a significant productivity lever.",
        "The 4% annual growth conceals divergent sub-trends. SME defaults have grown faster than corporate defaults, and consumer-credit recoveries have grown fastest of all. The practitioner planning capacity for the next five years should staff and train accordingly.",
        "Listing delays at the Commercial Division — currently three to six months for trial dates — favour parties prepared for early summary disposition. The bank that arrives at first case management with a complete affidavit in support and a clear summary-judgment strategy compresses its file timeline by months.",
    ],
    "o14_decision": [
        "The Order 14 decision tree is the practitioner's most-used algorithm. Three questions govern: (1) is the claim liquidated and admitted in substance? (2) is there a triable issue raised by the defence? and (3) is conditional leave to defend appropriate?",
        "Bank Negara v. Mohd Ismail and the long line of cases from Citibank v. Mohamad Khalid through to the modern authorities all turn on these three questions. Mastering the algorithm is the surest path to summary disposal.",
        "The decision tree is the single most-used algorithm in the practice. Practitioners are encouraged to print it, paste it inside the front cover of every Order 14 file, and run through it at every conference. The discipline is the surest path to the right answer.",
        "Where conditional leave is appropriate, the conditions should be drafted with care: payment into court of the undisputed sum, security for costs and a tight timetable for the trial. Loose conditions on Order 14 are an invitation to delay; tight conditions compress the dispute to its substantive core.",
    ],
    "islamic_contracts_grid": [
        "The Islamic-finance contract grid lays out the six principal facility types used in Malaysian banking practice: Murabahah, BBA, Ijarah, Musharakah, Mudharabah and Tawarruq. Each has a distinct doctrinal logic and a distinct litigation profile.",
        "BBA in particular has generated extensive case law on early-settlement ibra' and on the validity of late-payment ta'widh. The SAC's published rulings under the CBMA reference procedure are now the principal source of doctrine.",
        "The grid is the practitioner's first reference at the file-opening meeting. Identifying the underlying Shariah contract before drafting the SOC avoids the months of pleading-amendment work that follows from a misclassification. The cost of an incorrect classification compounds at every later stage.",
        "Practitioners are urged to consult the SAC's published rulings as part of the file-opening exercise; the rulings are now the primary doctrinal source under the CBMA, and a pleading that ignores a relevant ruling is a pleading that will be amended on the court's own motion.",
    ],
    "enforcement_funnel": [
        "Enforcement narrows the field. Of one hundred files entering the recovery pipeline, perhaps eighty are settled or compromised before trial; fifteen go to summary judgment; four to full trial; and one to appeal.",
        "The funnel is descriptive, not prescriptive: each file must be assessed on its merits. But the empirical pattern reminds the practitioner that the bulk of their recovery value is captured pre-trial through disciplined LOD work and Order 14 strategy.",
        "The funnel is empirical, drawn from the working-paper datasets of the Commercial Division. The practitioner planning resource allocation across a recovery portfolio should plan to the funnel: most value is captured pre-trial, and the marginal cost of the trial-and-appeal long tail is high.",
        "Where a file appears at the outset to be heading for trial, the senior practitioner should ask whether the file can be re-positioned for summary disposition or for assisted resolution. Re-positioning at the outset costs hours; re-positioning at the door of the court costs months.",
    ],
    "heatmap_risk": [
        "The risk heatmap synthesises probability and impact for the principal banking-litigation hazards: limitation, defective demand, void security, regulatory intervention, parallel proceedings and enforcement obstruction.",
        "The hottest cells — high probability, high impact — are limitation and defective demand. Both are entirely preventable through diligent file management. The cooler cells are residual risks that must be monitored but not over-engineered.",
        "The hottest cells of the heatmap deserve standing operational responses. Limitation should be addressed by a calendar discipline (re-verification of every file every six months) and by a written acknowledgement-collection routine. Defective demand should be addressed by a single LOD template with mandatory partner sign-off.",
        "Cooler cells should be monitored, not over-engineered. A bank that engineers exhaustively against every risk on the heatmap inflates its own legal costs and slows its recovery cycle; a bank that addresses only the hot cells captures the bulk of the available risk reduction at a fraction of the cost.",
    ],
    "o14_flow": [
        "The Order 14 procedural flow runs from filing of writ → service → memorandum of appearance → affidavit in support → defendant's affidavit in reply → SAR's hearing → grant or refusal of summary judgment.",
        "A well-prepared bank will have the affidavit in support drafted before the writ is even filed, and will be ready to file the reply affidavit within seven days of receiving the defence affidavit. Speed compounds at every stage.",
        "The flow describes a procedure that, when run with discipline, completes within ninety days of filing for an undefended matter and within one hundred and fifty days for a contested matter. Practitioners are encouraged to maintain a procedural diary that calendars each step and surfaces any slippage at the weekly review.",
        "Compounding speed across the steps is the strategic point. A bank that files three days faster, serves two days faster and replies five days faster than the opponent compresses the timeline by a fortnight at no incremental cost; over a portfolio of three hundred files, the saving is substantial.",
    ],
    "mind_loan_recovery": [
        "The mind-map captures the practitioner's mental model of loan recovery: at the centre, the defaulting facility; radiating outward, the documentary trail, the legal pathways, the security options and the strategic considerations.",
        "Drawing the mind-map at the start of every file forces the practitioner to confront the full landscape of the dispute, rather than fixating on one familiar pathway.",
        "The mind-map is a discipline rather than a doctrine. Drawing it forces the practitioner to articulate, in twenty minutes, the documentary trail, the legal pathways, the security options and the strategic considerations on a fresh file. The exercise routinely surfaces a pathway the partner had not yet considered.",
        "Junior practitioners are encouraged to draft the mind-map before the first internal case conference; the partner then critiques the map rather than the file, which compresses the learning curve materially. Over the life of a recovery practice, a habit of mind-mapping every new file pays dividends measured in weeks of saved time.",
    ],
    "islamic_steps_h": [
        "Islamic-finance recovery follows a parallel but distinct procedural track. After the LOD, the bank must consider whether the facility involves a Shariah question requiring SAC reference under section 56 CBMA.",
        "If so, the litigation pauses pending SAC ruling. The ruling, when issued, is binding under section 57 CBMA. Practitioners must plead and brief their case with the SAC reference in mind from the outset.",
        "The reference to the SAC under section 56 CBMA pauses the litigation, and the resulting ruling binds under section 57. Practitioners must brief their case with the SAC reference in mind: pleadings, expert evidence and submissions should all be calibrated to the question that will be referred.",
        "Where a practitioner anticipates a section 56 reference, the strategic question is timing. An early reference may produce a binding ruling that compresses the litigation; a late reference may produce months of wasted pleading. The senior practitioner makes the timing call after the first round of pleadings closes.",
    ],
    "winding_up_steps": [
        "Winding-up proceeds through a strict procedural choreography: statutory demand → 21-day failure → petition → advertisement → hearing → order. Each step has its own form, its own time-bar and its own potential point of attack.",
        "The respondent's most powerful weapon is the bona fide dispute defence. A petition based on a sum that the company in good faith disputes will be dismissed with costs, often summarily.",
        "Each step is a potential point of attack. Defective service of the statutory demand defeats the petition; missed advertisement deadlines defeat it; a bona fide dispute defeats it. The practitioner who runs each step against a checklist defeats none of these objections.",
        "Schemes of arrangement under section 366 of the Companies Act 2016 will frequently appear at the petition stage. The bank's posture toward such schemes should be principled: a workable scheme that delivers a higher recovery than liquidation deserves engagement; a scheme that delivers less should be opposed at the convening hearing.",
    ],
    "mareva_quad": [
        "Mareva injunctions occupy a quadrant defined by the four classical requirements: good arguable case on the merits, real risk of dissipation, balance of convenience and full and frank disclosure on the ex parte application.",
        "Failure on any one quadrant is fatal. Practitioners should construct their affidavit in support to address each requirement in dedicated paragraphs, with documentary exhibits keyed to each.",
        "The four cells of the Mareva quadrant — good arguable case, real risk of dissipation, balance of convenience, undertaking as to damages — are the affidavit's mandatory architecture. Any one cell left thin is the cell on which the application will fail.",
        "The undertaking as to damages is taken seriously. Practitioners must brief the bank on the undertaking before the application is filed; banks that learn of the undertaking only after the order is granted have, on occasion, withdrawn applications mid-flight at significant cost.",
    ],
    "banking_disputes_pie": [
        "The banking-dispute pie reveals where the work actually lies: roughly 40% loan recovery, 25% guarantee enforcement, 15% security realisation, 10% Islamic-finance disputes, 5% cheque litigation and 5% miscellaneous.",
        "The percentages have remained stable over the last decade despite changes in product mix. New regulatory regimes have not displaced the traditional contours of the practice.",
        "The pie charts the working composition of a typical Malaysian banking-litigation portfolio: facility default, security enforcement, regulatory action, fraud, and a residual miscellany. The proportions vary by institution, but the dominance of facility-default work is consistent across the industry.",
        "Resource allocation should track the pie. A practice that staffs equally across all categories is over-staffing the smaller cells; a practice that staffs purely to the largest cell is under-staffing the high-difficulty work that comes from regulatory action and fraud. The discipline is proportionate staffing.",
    ],
    "damages_pie": [
        "Damages awards in banking matters cluster around three categories: contractual (the debt itself), interest (post-judgment) and costs (party-and-party or, occasionally, indemnity). Punitive damages are rare in this jurisdiction.",
        "Practitioners should compute each component precisely in the prayer, and should be prepared at trial to justify both the principal sum and the interest computation by reference to the facility document.",
        "Damages in banking matters fall into recurring buckets: interest, principal, fees, costs and consequential losses. The pie chart is calibrated to the empirical distribution observed in High Court awards over the last decade.",
        "Consequential losses are the most contested cell. Practitioners must plead remoteness explicitly and must marshal evidence of foreseeability if the consequential damages claim is to survive Order 18 strike-out and trial.",
    ],
    "foreclosure_timeline": [
        "The foreclosure timeline runs typically nine to fifteen months from default to auction. The principal delays are the one-month Form 16D notice period, the listing of the OS hearing and the auction conduct.",
        "Practitioners can compress the timeline by ensuring the OS affidavit is fully exhibited and ready for filing the day after the Form 16D notice period expires.",
        "The timeline is read both ways: forwards from filing to auction, and backwards from auction to filing. Banks planning a sale by a particular date must work backwards from that date to identify the filing window; banks responding to a fresh default work forwards.",
        "The timeline is not adjustable downward beyond a floor. The statutory notice periods and the court's own listing pace impose a minimum of approximately seven to nine months from filing to first auction; promises of faster timelines should be treated with scepticism.",
    ],
    "bankruptcy_timeline": [
        "The bankruptcy timeline from notice to receiving order is typically six to twelve months. The notice itself runs seven days; the petition can be filed any time within six months; the hearing is fixed by the registry's listing.",
        "Where the debtor seeks adjournment to make payment, courts will routinely grant one or two short adjournments. Beyond that, the order is granted as a matter of course on continuing default.",
        "The bankruptcy timeline runs from judgment to adjudication. Each interval — judgment to bankruptcy notice, notice to act of bankruptcy, act to petition, petition to adjudication — has its own statutory floor, and acceleration is rarely possible without compromising the procedural integrity of the petition.",
        "Banks should track the timeline against the six-month clock under section 5(2) of the Insolvency Act. A petition that misses the clock is wasted work; a petition that arrives at the door of the court with two days to spare invites avoidable challenges.",
    ],
    "winding_up_timeline": [
        "Winding-up runs faster: from statutory demand to order is typically three to six months. The 21-day demand, the petition filing, the seven-day advertisement and the hearing date together compress the timeline.",
        "Speed is the petitioner's principal advantage and is the reason banks frequently prefer winding-up to bankruptcy where the debtor is a company.",
        "The winding-up timeline is shaped by advertisement, hearing and order. The hearing date is the focal point: every other date is set in relation to it. Practitioners should diary the hearing date as the spine of the file timetable.",
        "Where the company files a cross-application (a scheme, a stay, a strike-out), the timeline lengthens materially. Banks should plan for these contingencies rather than be surprised by them; the cross-application is the predictable response of a sophisticated debtor.",
    ],
    "evidence_pillars": [
        "Banking evidence rests on three pillars: documentary evidence (sections 90A–90C of the Evidence Act), oral evidence (the bank's recovery officer) and expert evidence (occasionally on quantum or accounting practice).",
        "Sections 90A–90C provide the gateway for computer-generated records. The certifying officer must depose to the system, the conditions of regular use and the absence of malfunction. Defective certification is fatal.",
        "The pillars of banking evidence are the section 90A certificate, the original document, the witness with personal knowledge, and the documentary trail running back to account opening. A weakness in any pillar weakens the structure as a whole.",
        "Practitioners are encouraged to audit their evidence pillars at the point of filing the writ, not at the point of trial. Gaps surfaced at filing can be repaired; gaps surfaced at trial cost the case.",
    ],
    "ethics_quad": [
        "Banking-litigation ethics span four quadrants: candour to the court, confidentiality of customer information, competence in handling complex documentation, and management of conflicts (especially in repeat-client matters).",
        "The Bar Council's Ethics Code and the Legal Profession (Practice and Etiquette) Rules 1978 supply the rules. Daily practice supplies the texture: an ethical lapse, even a minor one, can derail an entire file.",
        "The ethical quadrant — duty to the court, duty to the client, duty to the profession, duty to the regulator — frames every difficult decision in the practice. The four duties usually align; when they do not, the practitioner must rank them, and the duty to the court ranks first.",
        "Banking practice carries its own ethical pressures: client requests for aggressive disclosure positions, time pressure that erodes documentary discipline, and the volume of work that tempts shortcuts. The mature practitioner builds personal habits that resist these pressures without making a fuss of resistance.",
    ],
    "islamic_v_conv_pie": [
        "Islamic banking now accounts for approximately one-third of total banking assets in Malaysia. The litigation share has lagged behind asset share, but is growing — partly because the doctrines are still being settled by the courts.",
        "Practitioners should expect Islamic-finance work to grow as a proportion of their recovery practice, and should invest in the doctrinal foundation now rather than later.",
        "The pie places conventional and Islamic litigation side by side; the proportions vary by institution, but the share of Islamic-finance disputes has grown steadily over the last decade and is expected to continue growing.",
        "Practitioners should plan training accordingly. A junior who is fluent only in conventional doctrine is, increasingly, a junior with half a practice. Cross-training between the two regimes is now a baseline professional expectation rather than a specialist option.",
    ],
    "steps_h_lod": [
        "The Letter of Demand is the recovery practitioner's signature document. The horizontal-steps diagram captures the five elements: header (parties and reference), recital (the facility), demand (the precise sum and date), reservation (rights and remedies), and consequences (legal action on default).",
        "Each element must be present and precisely worded. A defective LOD can derail the entire recovery — and the defect is often only discovered at trial, when it is too late.",
        "The horizontal LOD steps run from default identification through to demand letter delivery. Each step is short on paper and consequential in practice; banks that compress any one step to save days are banks that lose months later when the LOD is challenged.",
        "The discipline is documentary. Each step must produce its own paper: the default report, the partner sign-off, the LOD itself, the proof of service, the response register. A complete LOD file at the point of demand is the practitioner's foundation for everything that follows.",
    ],
    "section_cover_2": [
        "Section dividers exist to give the reader's eye a moment of rest amid the dense substantive material. Use them as natural breakpoints in your reading.",
        "The substantive material that follows is intended to be consulted in working order — bookmark the diagrams, annotate the margins, and treat the volume as a daily companion rather than a one-time read.",
    ],
    "guarantor_defences": [
        "The guarantor's classical defences span seven categories: material variation without consent (Holme v. Brunskill), release of co-surety, loss of security through bank negligence, novation of the principal contract, fraud or misrepresentation in obtaining the guarantee, undue influence, and limitation.",
        "Each defence has a distinct doctrinal foundation and a distinct evidentiary threshold. The bank's standard-form guarantee typically waives several of these defences, but the waiver itself must be proven by the bank and is occasionally read down by the courts.",
        "The guarantor's defences are well-rehearsed: variation without consent, prior release, lost or impaired security, misrepresentation by the bank, undue influence by the principal debtor. Each defence has a procedural posture and an evidentiary footprint; the bank's response must address each on its own terms.",
        "Practitioners should anticipate the defences at the LOD stage. The LOD that is silent on the relevant defences — particularly variation — invites them; the LOD that addresses them head-on closes them off before they are formally pleaded.",
    ],
}


def _commentary_for(image_path):
    """Return a list of commentary paragraphs for a visual, by basename match."""
    import os as _os
    base = _os.path.splitext(_os.path.basename(image_path))[0]
    if base in VISUAL_COMMENTARY:
        return VISUAL_COMMENTARY[base]
    # Generic fallback commentary if no specific entry exists
    pretty = base.replace("_", " ").title()
    return [
        f"The diagram opposite — <b>{pretty}</b> — synthesises one of the recurring structural patterns in Malaysian banking-litigation practice. It is intended to be read in conjunction with the surrounding text and used as a working reference at the desk.",
        "Practitioners should treat the diagram as a checklist rather than as a settled doctrinal statement: every case carries its own facts, and every doctrine evolves through the regular work of the appellate courts. The strength of the visual is its capacity to surface the underlying architecture quickly; the strength of the prose is its capacity to expose nuance.",
    ]


def visual_page(image_path, caption=None, max_h=None, commentary=None):
    """A page that pairs one large visual with two paragraphs of commentary."""
    h = max_h or FRAME_H * 0.55
    out = [Image(image_path, width=FRAME_W*0.95, height=h, kind="proportional")]
    if caption:
        out.append(Spacer(1, 4))
        out.append(Paragraph(caption, CAP))
    out.append(Spacer(1, 10))
    text_paras = commentary if commentary is not None else _commentary_for(image_path)
    for tp in text_paras:
        out.append(Paragraph(tp, BODY))
        out.append(Spacer(1, 4))
    out.append(PageBreak())
    return out


def half_visual_page(image_path, intro_paragraphs, caption=None):
    out = []
    out.extend(text_block(intro_paragraphs))
    out.append(Spacer(1, 8))
    out.append(Image(image_path, width=FRAME_W*0.92, height=FRAME_H*0.55, kind="proportional"))
    if caption:
        out.append(Spacer(1, 4))
        out.append(Paragraph(caption, CAP))
    out.append(PageBreak())
    return out


def two_visual_page(p1, p2, caption=None, footer=None):
    out = [Image(p1, width=FRAME_W*0.92, height=FRAME_H*0.36, kind="proportional"),
           Spacer(1, 8),
           Image(p2, width=FRAME_W*0.92, height=FRAME_H*0.36, kind="proportional")]
    if caption:
        out.append(Spacer(1,4)); out.append(Paragraph(caption, CAP))
    out.append(Spacer(1, 8))
    out.append(Paragraph(footer or (
        "These two diagrams should be read together. The limitation table identifies <i>when</i> a "
        "claim must be brought; the heatmap identifies <i>where</i> the litigation risk concentrates. "
        "Practitioners should annotate both as files come in &mdash; the patterns will repeat across "
        "the practice."), BODY))
    out.append(PageBreak())
    return out


# ============================================================
# CONTENT FOR EACH PART
# ============================================================

LOREM_TEXTS = {
    # --- Part 1 ----------------------------------------------------------
    "p1_intro_1": (
        "Banking litigation in Malaysia occupies a special intersection between common-law "
        "principles inherited from England, the statutory architecture of the Financial "
        "Services Act 2013 and Islamic Financial Services Act 2013, and the procedural "
        "discipline of the Rules of Court 2012. To practise in this field is to navigate "
        "three legal systems at once — contract, property and procedure — while maintaining "
        "a constant eye on the commercial reality of the lender's balance sheet."),
    "p1_intro_2": (
        "Bank Negara Malaysia, as the central regulator under the Central Bank of Malaysia Act "
        "2009, oversees licensing, prudential supervision and intervention. Yet the courts — "
        "from the Magistrates' Court right up to the Federal Court — remain the ultimate forum "
        "for resolving disputes between a bank and its customers. The High Court's commercial, "
        "muamalat and bankruptcy divisions form the engine room of banking dispute resolution."),
    "p1_intro_3": (
        "This Volume sets out, in a deliberately visual format, the architecture, procedure and "
        "strategy of banking litigation in Malaysia. Each Part begins with a divider mapping "
        "the territory; each chapter relies primarily on diagrams, flowcharts and "
        "comparison tables to convey the practical knowledge a litigator needs to operate."),
    "p1_intro_4": (
        "The Malaysian banking system is dual: licensed conventional banks under Part III of "
        "the Financial Services Act 2013 sit alongside licensed Islamic banks under the Islamic "
        "Financial Services Act 2013. While the underlying commercial purposes overlap, the "
        "documentation, the doctrines and the dispute-resolution pathways diverge in important "
        "respects. Practitioners must understand both worlds because most large Malaysian "
        "banking groups operate on both sides."),
    "p1_intro_5": (
        "Limitation, the doctrine of res judicata, and the rules on locus standi all play a "
        "decisive role in banking litigation. A misjudged limitation period or an "
        "improperly pleaded cause of action can extinguish the claim before it even reaches "
        "the substantive issues. The maps in this Part are intended to be revisited, not "
        "merely read once."),
    # --- Part 2 ----------------------------------------------------------
    "p2_intro_1": (
        "The relationship between a bank and its customer is not, despite popular intuition, "
        "merely fiduciary. As Lord Cottenham held in Foley v. Hill (1848), the moneys deposited "
        "with a bank become the bank's own funds; the bank's obligation is to repay an "
        "equivalent sum on demand. This single proposition — that the relationship is one of "
        "debtor and creditor — is the pivot upon which the law of banking rests."),
    "p2_intro_2": (
        "Layered upon this debtor-creditor base are three further relationships: agency "
        "(when the bank collects cheques or executes payment instructions), bailment (where "
        "items are placed in the bank's safe custody) and, in narrow circumstances, fiduciary "
        "obligations (typically where the bank has assumed a position of trust). The Quincecare "
        "duty articulated in Barclays Bank v. Quincecare (1992) recognises that a bank executing "
        "a payment instruction must do so without negligence."),
    "p2_intro_3": (
        "Banking secrecy is a creature of statute in Malaysia. Section 133 of the FSA 2013 — "
        "and its mirror in section 145 IFSA 2013 — imposes an absolute prohibition on the "
        "disclosure of customer information except as permitted under Schedule 11. Breach is a "
        "criminal offence as well as actionable in tort. Litigators must be cautious in seeking "
        "discovery of bank documents from non-party banks; orders are typically required."),
    # --- Part 3 ----------------------------------------------------------
    "p3_intro_1": (
        "Loan recovery is the bread and butter of banking litigation in Malaysia. The vast "
        "majority of suits filed by financial institutions in the High Court and Sessions "
        "Court arise from defaulted credit facilities — term loans, overdrafts, revolving "
        "credits, trade finance lines and credit cards. The procedural pathway, however, is "
        "remarkably uniform once the cause of action has accrued."),
    "p3_intro_2": (
        "The cause of action accrues on the date of default, typically defined in the facility "
        "agreement as the failure to pay an instalment when due, the failure to meet a financial "
        "covenant or the occurrence of an event of default such as cross-default or insolvency. "
        "Time begins to run for limitation purposes from this moment. Acceleration clauses "
        "permit the lender to call the entire outstanding sum upon default."),
    "p3_intro_3": (
        "The letter of demand is the next critical step. Although not legally required to "
        "issue a writ in most cases, it is a near-universal pre-action step in banking "
        "practice. The LOD serves as evidence of demand and refusal, gives the borrower a "
        "final opportunity to remedy, and triggers the limitation clock for some causes "
        "of action. It must be sufficiently particularised to be effective."),
    # --- Part 4 ----------------------------------------------------------
    "p4_intro_1": (
        "Real-property security in Malaysia is governed by the National Land Code 1965, a "
        "Torrens-system statute that recognises the registered charge as the principal form "
        "of security over land. A charge gives the chargee an immediate proprietary interest, "
        "registered on the title, with priority according to the date of registration. The "
        "remedies of the chargee — sale, possession and appointment of receiver — are "
        "statutory and must be exercised in compliance with the Code."),
    "p4_intro_2": (
        "Sections 254 to 268 of the NLC set out the foreclosure procedure. For land held under "
        "Registry title, the application for an Order for Sale is made to the High Court; for "
        "land held under Land Office title, to the Pentadbir Tanah. The standard preliminary "
        "step is the issuance of a Form 16D notice giving the chargor one calendar month to "
        "remedy the breach. Failure to remedy entitles the chargee to apply for the Order."),
    "p4_intro_3": (
        "The Federal Court in Low Lee Lian v. Ban Hin Lee Bank Bhd (1997) clarified the limited "
        "grounds on which a court may refuse an Order for Sale: where the chargor can show "
        "'cause to the contrary'. This phrase, repeatedly construed by the appellate courts, "
        "covers fundamental defects in the chargee's title to relief — for example, where "
        "the charge is a nullity, where the demand is defective, or where the chargee has acted "
        "fraudulently or unconscionably."),
    # --- Part 5 ----------------------------------------------------------
    "p5_intro_1": (
        "A guarantee is a collateral contract by which the guarantor undertakes to answer for "
        "the default of the principal debtor. The guarantor's liability is co-extensive with "
        "that of the principal — a proposition that has both technical and practical "
        "consequences. Section 79 of the Contracts Act 1950 codifies the equivalent of the "
        "Indian Contract Act provision and remains the starting point for all Malaysian "
        "guarantee analysis."),
    "p5_intro_2": (
        "Banking guarantees in Malaysia are almost invariably contained in a printed form "
        "drafted by the bank. They typically include continuing-guarantee language, a "
        "principal-debtor clause that converts the guarantor's liability into that of a "
        "principal, and waivers of the equitable defences traditionally available to a "
        "surety. These boilerplate provisions have repeatedly been upheld by the Malaysian "
        "courts, but they are not impregnable."),
    # --- Part 6 ----------------------------------------------------------
    "p6_intro_1": (
        "The Insolvency Act 1967, formerly the Bankruptcy Act, governs the bankruptcy of "
        "individuals (including sole proprietors and partners) in Malaysia. It is administered "
        "by the Director General of Insolvency through the Malaysian Department of Insolvency "
        "(MdI). Following the Insolvency (Amendment) Act 2017, the threshold for petitioning "
        "was raised to RM 100,000, and a number of safeguards were introduced for guarantors."),
    "p6_intro_2": (
        "The procedural backbone is the Bankruptcy Notice (Form 3), issued upon a final "
        "judgment for a sum exceeding RM 100,000. Service of the notice gives the debtor seven "
        "days to comply, and failure to do so constitutes an act of bankruptcy. Within six "
        "months of the act of bankruptcy, the creditor may file a creditor's petition. On "
        "adjudication, the debtor's property vests in the Director General of Insolvency."),
    # --- Part 7 ----------------------------------------------------------
    "p7_intro_1": (
        "Winding-up under the Companies Act 2016 is the corporate analogue of bankruptcy. "
        "Section 466 sets out the principal trigger: a statutory demand for a debt exceeding "
        "RM 50,000 that remains unsatisfied for 21 days entitles the creditor to petition for "
        "the company's winding-up on the ground of inability to pay debts. The petition is "
        "filed in the High Court and proceeds on the basis of affidavit evidence."),
    "p7_intro_2": (
        "The grounds for winding-up extend beyond inability to pay debts. Section 465 enumerates "
        "additional grounds including default in lodging the statutory report, failure to "
        "commence business within a year, reduction of members below the statutory minimum, "
        "and the just-and-equitable ground. Banking creditors typically rely on the inability-to-pay "
        "ground because it is the most direct and well-established basis."),
    # --- Part 8 ----------------------------------------------------------
    "p8_intro_1": (
        "Islamic banking litigation in Malaysia operates within a hybrid framework: the common "
        "law and the Rules of Court 2012 govern procedure, while the substantive obligations "
        "are derived from the Shariah-compliant contract chosen by the parties. The Islamic "
        "Financial Services Act 2013 supplies the regulatory backbone, while the Central Bank "
        "of Malaysia Act 2009 establishes the Shariah Advisory Council whose rulings are "
        "binding on the courts in disputes referred under section 56."),
    "p8_intro_2": (
        "The seminal case of Bank Islam Malaysia Berhad v. Lim Kok Hoe & Ors (2009) addressed "
        "the validity of the Bai' Bithaman Ajil contract and clarified the proper role of the "
        "civil court in Shariah-related banking disputes. The Court of Appeal held that the "
        "civil court has jurisdiction, but must defer to the SAC on questions of Shariah "
        "compliance. Subsequent decisions have refined this interface."),
    # --- Part 9 ----------------------------------------------------------
    "p9_intro_1": (
        "The Bills of Exchange Act 1949 governs cheques and other negotiable instruments in "
        "Malaysia. It is a near-faithful reproduction of the English Bills of Exchange Act "
        "1882. The Act regulates the relationship between the drawer, the drawee bank, the "
        "payee and any subsequent holders. The bulk of banking-fraud litigation in Malaysia "
        "involves cheques: forged signatures, material alterations, and conversion claims."),
    "p9_intro_2": (
        "Conversion is the ordinary tort by which the true owner of a cheque can recover its "
        "value from a collecting bank that has dealt with the instrument as if it were the "
        "customer's. The defence of section 85 BoEA 1949 — that the bank acted in good faith "
        "and without negligence — is the principal shield. Whether the bank acted without "
        "negligence is a fact-sensitive inquiry and an active battleground in litigation."),
    # --- Part 10 ---------------------------------------------------------
    "p10_intro_1": (
        "A banking-litigation practice is, at heart, a process. The technical doctrines "
        "matter, but they only matter once the file is properly organised, the chronology is "
        "in order, the documents are bundled and the witnesses are prepared. This Part offers "
        "a practical, step-by-step framework for managing the entire arc of a banking-litigation "
        "matter — from the first call from the relationship manager to the issuance of the "
        "writ of execution."),
    "p10_intro_2": (
        "Evidence in banking trials is unusual in two respects. First, the bulk of the proof "
        "is documentary, and the Banker's Books provisions of the Evidence Act 1950 occupy a "
        "central role. Second, computer-generated records — print-outs of statements, audit "
        "trails, system logs — must be tendered through the gateway of sections 90A to 90C of "
        "the Evidence Act. Mastery of these sections separates competent practitioners from "
        "exceptional ones."),
    "p10_intro_3": (
        "Drafting in banking matters demands precision. Pleadings must specify the facility, "
        "the sum demanded, the date and mode of demand, and the basis of acceleration. "
        "Affidavits supporting Order 14 applications must verify the facts personally and exhibit "
        "the underlying documents. Skeleton submissions must trace each element of the cause "
        "of action to the documentary proof."),
    "p10_intro_4": (
        "Costs are a strategic lever. A well-prepared bank can frequently obtain costs on a "
        "solicitor-client basis where the facility documents so provide, and the Federal Court "
        "in Citibank Bhd v. Mohamad Khalid Farzalur Rahaman (2000) confirmed the enforceability "
        "of such clauses. Ethics, however, remain paramount: candour to the court, "
        "confidentiality to the client, and competence to the cause."),
}

CASES_BY_PART = {
    1: [("Foley v. Hill (1848) 2 HLC 28", "Foundational debtor-creditor characterisation"),
        ("Joachimson v. Swiss Bank Corporation [1921] 3 KB 110", "Bank's duty to repay on demand at correct branch"),
        ("Re Mok Yong Kong & Anor [1984] 1 MLJ 142", "Limitation on bankruptcy after judgment"),
        ("Citibank Bhd v. Mohamad Khalid Farzalur Rahaman [2000] 4 MLJ 481", "Enforceability of solicitor-client cost clauses")],
    2: [("Barclays Bank Plc v. Quincecare Ltd [1992] 4 All ER 363", "Bank's duty of care in executing instructions"),
        ("Tournier v. National Provincial & Union Bank [1924] 1 KB 461", "Common-law banking secrecy"),
        ("Pertubuhan Kebangsaan Melayu Bersatu v. Mohamed Suffian [2009] 3 CLJ 593", "Statutory secrecy under BAFIA (now FSA)")],
    3: [("Esso Standard Malaya Bhd v. Southern Cross Airways [1972] 1 MLJ 168", "O.14 application principles"),
        ("National Company for Foreign Trade v. Kayu Raya Sdn Bhd [1984] 2 MLJ 300", "Test for triable issue"),
        ("Bank Negara Malaysia v. Mohd Ismail [1992] 1 MLJ 400", "Affidavit requirements in O.14")],
    4: [("Low Lee Lian v. Ban Hin Lee Bank Bhd [1997] 1 MLJ 77", "'Cause to the contrary' under s.256(3) NLC"),
        ("Co-operative Central Bank Ltd v. Meng Kuang Properties Bhd [1991] 2 MLJ 283", "Validity of charge"),
        ("Keng Soon Finance v. MK Retnam [1989] 1 MLJ 457", "Order for Sale procedure")],
    5: [("Tan Chong & Sons Motor v. Alan McKnight [1983] 1 MLJ 220", "Material variation discharges guarantor"),
        ("Holme v. Brunskill (1878) 3 QBD 495", "Variation rule"),
        ("China Insurance Co v. Loong Moh Construction [1971] 1 MLJ 1", "Performance bond vs. guarantee distinction")],
    6: [("Re Liang Yik Wah, ex p Affin Bank [2008] 4 CLJ 297", "Bankruptcy notice requirements"),
        ("Datuk M Kayveas v. Bar Council [2014] 1 MLJ 309", "Jurisdiction & threshold"),
        ("Public Bank Bhd v. Wing Lee Land [2003] 4 CLJ 145", "Setting aside bankruptcy notice")],
    7: [("Tan Kok Tong v. Hoe Hong Trading [2007] 4 MLJ 355", "Bona fide dispute as a defence"),
        ("Sri Hartamas Development v. MBf Finance [1992] 1 MLJ 313", "Standard for bona fide dispute"),
        ("Pacific & Orient Insurance v. Muniammah [2011] 1 MLJ 1", "Sufficiency of statutory demand")],
    8: [("Bank Islam Malaysia Bhd v. Lim Kok Hoe [2009] 6 CLJ 22", "Validity of BBA contracts"),
        ("Mohd Alias bin Ibrahim v. RHB Bank [2011] 4 CLJ 654", "Application of section 56 CBMA"),
        ("Tan Sri Abdul Khalid bin Ibrahim v. Bank Islam [2012] 7 MLJ 597", "SAC reference and binding ruling")],
    9: [("Lim Tian Huat v. Citibank Bhd [2007] 5 MLJ 99", "Conversion by collecting bank"),
        ("United Overseas Bank Ltd v. Yusoff [2014] 4 CLJ 81", "Forged signatures and section 24 BoEA"),
        ("Tat Lee Bank v. Official Assignee [1995] 1 MLJ 481", "Stop-payment instructions")],
    10:[("Datuk Tan Leng Teck v. Sarjana Sdn Bhd [1997] 4 MLJ 707", "Sufficiency of evidence in bank claims"),
        ("Standard Chartered Bank v. Yap Sing Yoke [1989] 2 MLJ 49", "Banker's books evidence"),
        ("Citibank Bhd v. Mohamad Khalid [2000] 4 MLJ 481", "Costs on solicitor-client basis")],
}

CHECKLIST_BY_CHAPTER = {
    "p1": [
        ("Identify all relevant statutes (FSA, IFSA, NLC, IA, CA 2016)", True),
        ("Map the dispute to the correct court level", True),
        ("Confirm limitation period before filing", True),
        ("Verify locus standi of the financial institution", True),
        ("Check for parallel regulatory proceedings", True),
        ("Assess limitation extension by acknowledgement", True),
        ("Confirm proper exercise of powers under FSA", True),
    ],
    "p2": [
        ("Identify the precise contractual document(s) governing the relationship", True),
        ("Confirm the bank's authority under the mandate", True),
        ("Verify whether secrecy under s.133 FSA applies to disclosure sought", True),
        ("Assess whether a Quincecare duty has been triggered", True),
        ("Consider Schedule 11 FSA exceptions", True),
        ("Document the customer's signing authority and changes", True),
    ],
    "p3": [
        ("Date of first default established and recorded", True),
        ("Acceleration clause invoked and notice given", True),
        ("Letter of demand drafted with all five required elements", True),
        ("Service confirmed by AR card or other proof", True),
        ("Statement of Claim particularises facility, sum, demand", True),
        ("Affidavit verifying claim signed by recovery officer with knowledge", True),
        ("All exhibits indexed and certified", True),
    ],
    "p4": [
        ("Charge duly registered and unencumbered by competing claim", True),
        ("Form 16D notice issued and served", True),
        ("One calendar month for remedy expired", True),
        ("OS supported by affidavit verifying default and quantum", True),
        ("Reserve price set at market value (not arbitrary)", True),
        ("Confirm proper court (HC for Registry; PT for Land Office)", True),
        ("Address potential 'cause to the contrary' arguments", True),
    ],
    "p5": [
        ("Original guarantee document available and properly executed", True),
        ("All material variations documented and consented to", True),
        ("Demand made on guarantor in writing", True),
        ("Guarantor's defences pre-emptively considered", True),
        ("Co-sureties identified and joined", True),
        ("Subrogation rights preserved on payment", True),
    ],
    "p6": [
        ("Judgment debt exceeds RM 100,000 statutory threshold", True),
        ("Bankruptcy notice in correct form (Form 3) issued", True),
        ("Service in compliance with Bankruptcy Rules 2017", True),
        ("Seven-day compliance period elapsed", True),
        ("Creditor's petition filed within six months", True),
        ("Statement of affairs procured from debtor", True),
    ],
    "p7": [
        ("Debt exceeds RM 50,000 threshold", True),
        ("Statutory notice of demand correctly drafted", True),
        ("Notice served at registered office", True),
        ("21-day period elapsed without payment or security", True),
        ("Petition filed in High Court with affidavit verifying", True),
        ("Petition advertised in Gazette and one newspaper", True),
        ("Hearing date fixed and counsel briefed", True),
    ],
    "p8": [
        ("Confirm Islamic facility governed by IFSA 2013", True),
        ("Identify the underlying Shariah contract used", True),
        ("Check for Shariah issues triggering s.56 CBMA reference", True),
        ("Plead facts in accordance with Shariah-compliant structure", True),
        ("Quantify ta'widh and ibra' correctly", True),
        ("Confirm SAC ruling, if any, on point", True),
    ],
    "p9": [
        ("Original cheque available; copies certified", True),
        ("Signature(s) verified against specimen", True),
        ("Endorsement(s) reviewed for irregularity", True),
        ("Bank's collection process documented", True),
        ("Section 85 BoEA defence assessed", True),
        ("Tracing/Mareva strategy considered", True),
    ],
    "p10": [
        ("Conflict-of-interest check completed", True),
        ("Engagement letter and authority to act on file", True),
        ("Detailed chronology prepared", True),
        ("Document bundle indexed and paginated", True),
        ("Witness statements drafted and verified", True),
        ("Skeleton submissions cross-referenced to bundle", True),
        ("Costs schedule prepared", True),
    ],
}


# =====================================================================
# PER-PART FILLER PROSE — heavily expanded with judicial quotes &
# jurist commentary so that no page ends half-empty.
#   • DRAFT_NOTES_PROSE  — follows "Practical Drafting Notes" bullets
#   • PITFALL_PROSE      — follows "Common Pitfalls" bullets
#   • JUDICIAL_VOICES    — short bench-quote module (used at multiple spots)
#   • JURIST_COMMENTARY  — academic-voice module (used at multiple spots)
# Each block carries 3-5 paragraphs plus a styled judicial pull quote.
# =====================================================================

QUOTE_BOX = ParagraphStyle("QUOTE_BOX", parent=BODY,
    fontName="Times-Italic", fontSize=10.5, leading=14,
    leftIndent=24, rightIndent=24, spaceBefore=8, spaceAfter=4,
    textColor=HexColor(NAVY), alignment=TA_JUSTIFY,
    borderColor=HexColor(GOLD_DARK), borderWidth=0,
    borderPadding=6, backColor=HexColor(PAPER_DARK))
QUOTE_ATTRIB = ParagraphStyle("QUOTE_ATTRIB", parent=BODY,
    fontName="Times-Bold", fontSize=9.2, leading=12,
    leftIndent=24, rightIndent=24, spaceAfter=10,
    textColor=HexColor(GOLD_DARK), alignment=TA_RIGHT)
JURIST_BODY = ParagraphStyle("JURIST_BODY", parent=BODY,
    fontName="Times-Roman", fontSize=10, leading=14,
    leftIndent=10, rightIndent=10, spaceAfter=6,
    textColor=HexColor(INK), alignment=TA_JUSTIFY)
VOICES_H = ParagraphStyle("VOICES_H", parent=H3,
    fontSize=11.5, textColor=HexColor(NAVY),
    spaceBefore=12, spaceAfter=4)


DRAFT_NOTES_PROSE = {
    1: ("Choosing the Forum and the Cause",
        ["The election of forum is the first strategic decision in any banking matter. The Sessions Court accepts claims up to RM1 million; the High Court takes everything above. Where the dispute is purely commercial and the sum exceeds RM1 million, the Commercial Division of the High Court of Kuala Lumpur is the natural choice — its judges sit in commercial work daily and its lists move faster. Where the relief sought includes a declaration affecting land, the Construction or Property Court division may be more apt. The cause of action chosen — debt, breach of contract, conversion, declaratory relief — must align with the relief sought; pleading 'damages to be assessed' where a liquidated sum is provable invites striking out under Order 18 rule 19.",
         "Plead the regulatory regime in the opening paragraphs of the Statement of Claim. A bank seeking summary judgment for a conventional facility must aver that the facility is governed by the Financial Services Act 2013; for an Islamic facility, by the Islamic Financial Services Act 2013. This anchoring matters: it directs the judge's attention to the controlling statute and to the body of authority the bank intends to rely on. Practitioners who omit the regulatory hook find themselves arguing limitation, secrecy and acceleration without a clear statutory frame, and the court is entitled to ask why.",
         "Limitation discipline is non-negotiable. Compute the six-year period under section 6 of the Limitation Act 1953 from the date of accrual of the cause of action — for an on-demand facility, the date of demand; for an instalment facility, the date of each missed instalment. Where part-payment or written acknowledgement has occurred, plead it expressly to invoke section 26. A claim that might be time-barred should be filed protectively while the limitation argument is investigated in detail.",
         "Finally, audit the parties. Verify the bank's identity by reference to its current SSM particulars (mergers and re-namings catch out the careless), confirm that the borrower remains the same legal entity, and check whether any guarantors have died, become bankrupt or been struck off. A claim filed against a deceased guarantor without leave to substitute the personal representative is a nullity, and the bank pays the costs of putting it right."],
        ("The court will not allow a litigant to plead one cause of action and recover on another; the pleading must give fair notice and the relief must follow the pleading.",
         "Lord Denning MR, Esso Petroleum v. Southport Corporation [1956] AC 218")),

    2: ("Drafting the Banker–Customer Pleading",
        ["The banker–customer pleading lives or dies on the precise identification of the operative duty. Is the bank sued as debtor (the Foley v. Hill duty to repay), as agent (collection of cheques), as fiduciary (express trust on a designated account), or as Quincecare-bound payer (duty of care in executing instructions)? Each duty has a different statutory and common-law foundation, a different limitation period, and a different remedial menu. Pleading 'breach of duty' without more leaves the defendant guessing and the judge frustrated.",
         "Where banking secrecy under section 133 FSA is in issue, the pleading must set out the customer's authority or the statutory exception relied on. Schedule 11 of the FSA is exhaustive; if the disclosure does not fall within an exception, the bank is exposed regardless of good faith. In Quincecare cases, plead the specific red flags the bank ought to have noticed and the reasonable inquiry that would have revealed the fraud. Generalised pleas of negligence will be struck out under Order 18 rule 19.",
         "The mandate document — usually a board resolution or a personal signature card — is the foundation of every banker–customer claim. It identifies who may give instructions, in what form and on what account. The pleading should reproduce the operative paragraphs and exhibit the mandate to the affidavit verifying. Where the mandate has been varied, plead the variation and the date the varied mandate took effect; the unwary plead the mandate as at trial and find themselves explaining a payment made under an earlier version.",
         "Take care with quantum. The customer suing a bank for wrongful debit is entitled to restoration of the account, plus consequential loss proximately caused. The Statement of Claim should plead the precise debit, the date, the cumulative effect on the account, and any specific consequential loss (a returned cheque, a lost contract, an interest charge incurred elsewhere). Generalised claims for 'damages for inconvenience' rarely survive O.14A scrutiny."],
        ("A bank is bound to act in good faith and to exercise reasonable care and skill; where its officer is on notice of facts which would put a reasonable banker on inquiry, the bank is liable for the loss caused by failing to inquire.",
         "Steyn J., Barclays Bank plc v. Quincecare Ltd [1992] 4 All ER 363")),

    3: ("Demand, Acceleration and Quantum",
        ["The Letter of Demand is the most important non-pleaded document in a recovery action. It must identify the facility precisely (date, amount, parties), state the default (which clause, which payment), set out the quantum (principal, interest to a stated date, daily rest thereafter), and demand payment within a stated period. A demand that omits any of these is vulnerable to attack and may need to be re-issued — costing weeks. Service must be by the contractually-stipulated mode; AR-registered post to the address in the facility letter is the default safe harbour.",
         "Acceleration must be pleaded distinctly. The Statement of Claim should reproduce or summarise the acceleration clause, identify the event of default, recite the acceleration notice, and aver that the entire indebtedness has fallen due. The same goes for the calculation of interest: state the contractual rate, the rest period, and the date from which post-judgment interest runs. The court should be able to perform the arithmetic on the face of the pleading without resort to the affidavit.",
         "The Statement of Account is hearsay unless it comes within section 90A of the Evidence Act 1950. Exhibit a section 90A certificate signed by the bank's officer-in-charge of the records, identifying the records, the manner of their production and the absence of human intervention in the entries. Without the certificate the account is excluded and the affidavit collapses. The Federal Court has been progressively stricter on this point; certificate-by-template is no substitute for a certificate addressing the records actually produced.",
         "Order 14 applications stand or fall on the affidavit. The deponent must depose to personal knowledge, identify each exhibit, and address every triable issue the defendant is likely to raise. A defence that raises a 'shadowy' defence will defeat the application; the trick is to anticipate the shadow and dispel it in the affidavit. Practitioners who file a thin O.14 affidavit and rely on submissions to fill the gaps tend to find the application converted to a writ action and a year added to the timetable."],
        ("There must be a triable issue, not a sham defence; an affidavit which raises only bare denials will not suffice to drive the matter to trial.",
         "Mohamed Azmi FCJ, Bank Negara v. Mohd Ismail [1992] 1 MLJ 400")),

    4: ("Form 16D, the OS Affidavit, and Reserve Price",
        ["Foreclosure under the National Land Code 1965 is unforgiving on procedure. The Form 16D notice must be issued only after default has crystallised and the contractual notice period (usually one month) has lapsed. Issuing Form 16D prematurely renders the subsequent Order for Sale liable to be set aside on appeal. Always exhibit the Land Office search to the OS affidavit; without it the chargee cannot show clean title to the charge or the absence of competing interests.",
         "The reserve price requires care. The chargee's valuation must be recent, by a registered valuer, and addressed to the court. Setting a reserve too low invites challenge from the chargor on grounds of bad faith or under-valuation; setting it too high risks unsold auctions and successive applications to vary. The OS affidavit should explain how the reserve was computed and why it represents fair market value. The 'cause to the contrary' threshold under section 256 NLC is restrictively construed, but a chargor with a credible valuation challenge can hold up the auction for months.",
         "Conduct of sale particulars matter. The order for sale should specify the auctioneer, the place and time of auction, the deposit required, the balance period and the consequences of default by the successful bidder. Where the property is tenanted, the order should address the tenancy expressly — the auctioneer's brochure is no substitute for a court order. Where multiple charges burden the same title, address the priorities in the OS affidavit; the court will not grant an OFS that disrupts the priority register.",
         "Plan for the appeal. Chargors regularly file appeals and seek stays as a delaying tactic. The chargee's affidavit should anticipate this by addressing the prospect of irreparable harm, the strength of the chargee's case on the merits and the importance of preserving the chargee's bargained-for security. A well-prepared OS application carries its own anti-stay submissions in embryo; the careless practitioner re-argues the OFS in the appellate court."],
        ("The expression 'cause to the contrary' is to be construed restrictively; a chargee who has complied with the procedural requirements is prima facie entitled to an order for sale.",
         "Edgar Joseph Jr FCJ, Low Lee Lian v. Ban Hin Lee Bank [1997] 1 MLJ 77")),

    5: ("Guarantees and the Discipline of Variation",
        ["A guarantee is a strict-construction document. The pleading must reproduce the operative undertaking, identify the principal facility by reference (date, parties, amount), aver default, plead demand on the guarantor distinctly, and pray for judgment for the guaranteed sum. The principal-debtor clause, if present, is the bank's best protection against discharge defences; cite it in the pleading and exhibit it to the affidavit.",
         "Variation is the surety's most fertile defence. Holme v. Brunskill discharges the surety where the principal contract is materially varied without consent, unless the guarantee contains an express anti-variation clause. Pleading discipline matters: where variations have occurred (rescheduling, increased limit, change of borrower), exhibit the consent letters or board resolutions. Without them the court will infer non-consent and discharge follows.",
         "Read the anti-variation clause carefully — it is not a magic wand. A clause permitting 'variations and indulgences' may not cover an increase in the principal sum, which English and Malaysian authority treats as a fundamentally new obligation rather than a variation of the existing one. Where the bank has materially expanded the facility, fresh consent is the safest course; rely on the anti-variation clause only when nothing better is available.",
         "Loss of security through bank negligence is the surety's other powerful weapon. If the bank fails to perfect a charge, fails to register a debenture or releases collateral without compensation, the surety is discharged pro tanto by the value of the lost security. Audit the security file before issuing the LOD; the reported decisions show banks losing on summary judgment because their internal records disclosed the loss of security and their affidavit failed to address it."],
        ("If the creditor without the assent of the surety gives time to the principal debtor, or makes any other arrangement which alters the nature of the contract, the surety is discharged.",
         "Cotton LJ, Holme v. Brunskill (1878) 3 QBD 495")),

    6: ("Bankruptcy Notices and Acts of Bankruptcy",
        ["The Bankruptcy Notice (Form 3) is the gateway to bankruptcy. Strict compliance with the Bankruptcy Rules 2017 is required: the correct sum (judgment sum less any payment received), the correct judgment particulars, the correct address for service, and the correct affidavit of service. The Federal Court has set aside notices for trivial errors — a wrong figure to the cent, a misdescribed judgment date — because the consequences for the debtor (loss of business and civic disability) are so severe.",
         "Pleading the act of bankruptcy in the creditor's petition demands precision. Failure to comply with the Bankruptcy Notice within seven days is the most common act, but the petition must aver service of the notice, the date of expiry, and the absence of compliance or compounded payment. Petitions filed more than six months after the act of bankruptcy are time-barred under section 5(2) of the Insolvency Act 1967. Always re-check the limitation period before filing — a late petition is a wasted filing fee and a strategic gift to the debtor.",
         "The 2017 amendments to the Insolvency Act raised the threshold to RM 100,000 and introduced new safeguards for guarantors. For a social guarantor (one who guaranteed without commercial benefit) the bank must first obtain leave of court before bankruptcy; for non-social guarantors, the bank must show that all reasonable efforts to recover from the principal debtor have been made. The pleading must address these matters expressly; failure to do so produces an immediate set-aside.",
         "Service is technical. The Bankruptcy Notice must be served personally where the debtor is in Malaysia; substituted service requires leave on affidavit showing reasonable but unsuccessful efforts at personal service. Service by AR-registered post to the last known address is not personal service; the careless practitioner who relies on it finds the entire proceeding void."],
        ("The bankruptcy jurisdiction is exorbitant; strict compliance with the procedural requirements is the protection the law affords the debtor.",
         "Suriyadi Halim Omar FCJ, Re Liang Yik Wah [2014] 4 MLJ 561")),

    7: ("Statutory Demand and the Bona Fide Dispute",
        ["A section 466 demand must be in the prescribed form, served at the registered office, and demand a sum that is presently due and undisputed. The 21-day period runs from service, not from receipt. Practitioners who serve by post must file an affidavit of service exhibiting the AR card and the postal track-and-trace. Service on a director's personal address is invalid; the registered office on the SSM portal at the date of service controls.",
         "The bona fide dispute on substantial grounds is the omnipresent defence. The respondent need not prove the dispute at the petition stage — only show that the dispute is genuine, supported by some evidence, and not a sham. Petitioning banks should anticipate the defence and address it in the supporting affidavit: produce the contemporaneous correspondence, the unanswered demand, the failure to invoke any contractual dispute mechanism. A petition met with a credible counterclaim or arbitration clause will be stayed under the Arbitration Act 2005, costing the bank months.",
         "Quantum hygiene matters as much in winding-up as in bankruptcy. Demand only what is presently due and beyond bona fide dispute. Where the sum claimed includes contested interest or penalty charges, demand only the principal and uncontested interest, leaving the disputed elements to substantive proceedings. The petition that demands too much will be dismissed as a tactic for the recovery of disputed sums; the petition that demands the right amount and is unanswered proceeds to winding-up almost as a matter of course.",
         "Plan the advertisement window from day one. The Companies Act and the Winding-Up Rules require advertisement in the Gazette and a daily newspaper within stipulated periods after filing. Miss the window and the petition is dismissed without further hearing. Calendar the dates from the moment the petition is filed and brief the printer in advance; the small sum spent on prompt advertisement saves the cost of refiling."],
        ("The court will not allow the winding-up petition to be used as a debt collection tool where the debt is bona fide disputed on substantial grounds.",
         "Lord Wilberforce, Re Lympne Investments Ltd [1972] 1 WLR 523, applied in Tan Kok Tong v. Hoe Hong [1979] 1 MLJ 174")),

    8: ("Pleading the Shariah Contract",
        ["Islamic banking pleadings must identify the underlying Shariah contract — Bai Bithaman Ajil, Murabahah, Musharakah Mutanaqisah, Ijarah, Tawarruq — and plead its essential features. A pleading that treats an Islamic facility as if it were a conventional loan invites a defence of mischaracterisation, and may oblige the court to refer the matter to the Shariah Advisory Council under section 56 of the Central Bank of Malaysia Act 2009. The reference itself is binding under section 57 and can take six to twelve months.",
         "Quantum in Islamic recovery is technical. Ta'widh (compensation for actual loss) must be computed in accordance with the BNM Guidelines on Late Payment Charges; ibra' (rebate on early settlement) must be granted in line with the Shariah Advisory Council's published rulings. Practitioners must exhibit the calculation worksheet, identifying the contractual rate, the actual loss claimed, and any rebate granted. Vague pleas of 'sums due under the facility' will be remitted for amendment; in extreme cases the court will dismiss for failure to plead a coherent Shariah-compliant claim.",
         "Plead the underlying transaction in narrative form. For BBA, plead the customer's purchase of the asset, the bank's acquisition and re-sale at the deferred price, the schedule of instalments and the default. For Musharakah Mutanaqisah, plead the joint ownership, the lease component, the gradual purchase by the customer and the default in either rent or purchase. The court reading the Statement of Claim should be able to understand what was bought, sold and financed, and to see how each element fits the chosen Shariah contract.",
         "Cross-check against SAC rulings before filing. The Shariah Advisory Council publishes resolutions on issues recurring in litigation — late payment charges, takaful, foreclosure of Shariah assets. Where a resolution covers the point in issue, the pleading should refer to it; where one is silent, the bank should consider whether the prudent course is a section 56 reference at the outset rather than after months of pleading."],
        ("The Shariah Advisory Council's rulings, where given on a Shariah issue, are binding on the courts and on the arbitrator alike.",
         "Zulkefli Ahmad Makinudin CJM, Mohd Alias bin Ibrahim v. RHB Bank Bhd [2011] 4 CLJ 654")),

    9: ("The Cheque Pleading and the s.85 Defence",
        ["Cheque litigation is documentary. The pleading must identify the cheque (number, date, drawer, payee, amount), aver presentation and dishonour or wrongful payment, and plead the cause of action — conversion against the collecting bank, breach of mandate against the drawee, or contract against the drawer. The original cheque, or a certified copy, must be available; the bank's collection log and KYC file are routinely subpoenaed.",
         "The collecting bank's defence under section 85 of the Bills of Exchange Act 1949 protects against conversion where the bank acts in good faith and without negligence. The bank must plead the elements: customer of the bank, collection for the customer's account, good faith, absence of negligence. The negligence limb is the battleground — the bank's KYC at account opening, transaction monitoring and response to red flags will be scrutinised. A bank with weak KYC will lose despite good faith. Plead the KYC processes positively in the defence and exhibit the file.",
         "Where the claim is wrongful dishonour, the customer must plead damage. Mere annoyance is not actionable; a trader-customer's loss of credit standing or a returned-cheque charge passed on by a third party is. The Statement of Claim should plead the specific damage with particulars, supported where possible by contemporaneous documents (returned-cheque advice, complaint from the payee). General damages for inconvenience are recoverable but modest; the careful pleader pleads special damages with precision and reserves general damages as the safety net.",
         "Limitation in cheque cases is short and unforgiving. The cause of action accrues on the date of the wrongful debit or the wrongful dishonour; the six-year period under section 6 of the Limitation Act 1953 runs from that date and is not postponed by demand. Compute the period from the contemporaneous account statement; do not rely on the customer's recollection. A cheque claim filed five years and eleven months after the event is a brave filing; one filed at six years is a wasted one."],
        ("The collecting banker who acts in good faith and without negligence is protected from an action for conversion; the burden is on the bank to prove the elements of the protection.",
         "Cairns LJ, Marfani v. Midland Bank [1968] 1 WLR 956")),

    10:("Chronology, Bundle and the Costs Schedule",
        ["The trial bundle is the litigator's working document. A master chronology — every relevant event, every document, every witness — should be the spine of the bundle. Tag every fact in the skeleton submission to a bundle reference. The court will follow the bundle if it is well-organised; it will struggle, and tend against the party responsible, if the bundle is disorderly. Three-tier authorities bundles (statutes, leading authorities, supplementary) are the Malaysian convention; provide flagged tabs and printed copies for the bench.",
         "The costs schedule is the most-overlooked document at trial. Order 59 requires summary assessment of costs in many interlocutories; without a schedule the court will assess on a guess, often to the disadvantage of the winning party. Prepare the schedule as a working document throughout the trial, updating after each application. At the end of trial, the schedule should set out the work done, the rates claimed and the disbursements, with cross-references to the file. A well-prepared costs schedule is sometimes the difference between solicitor-and-client costs and party-and-party costs.",
         "Witness preparation is craft, not coaching. A bank witness must understand the documents, be able to navigate the bundle, and be ready to explain departures from the bank's standard procedures. Practitioners who put a witness on the stand without a walk-through of the bundle invite catastrophes — the witness who cannot find his own affidavit in cross-examination loses the case. Allow at least a full day of witness preparation per material witness; more for complex banking facts.",
         "Submissions are the synthesis. Closing submissions should restate the cause of action, walk the court through the evidence in narrative form, address each issue identified at the case management stage, and pray for the relief sought with reference to authority. Bullet-point submissions read like a checklist and persuade no one; structured prose submissions, well-paginated and cross-referenced, are the gold standard."],
        ("The litigator's first duty is to the court; ill-prepared bundles, careless chronologies and submissions that do not engage with the evidence are a disservice to the client and to the bench.",
         "Tun Salleh Abas LP, address to the Bar Council of Malaysia, 1986")),
}

PITFALL_PROSE = {
    1: ("Lessons from the Reports — Part 1",
        ["The reported decisions of the Federal Court and the Court of Appeal disclose a recurring theme: filings that are technically defective rarely survive appellate scrutiny. A claim filed in the Sessions Court for an amount slightly above its monetary jurisdiction is wasted; the practitioner must compute interest to the date of filing precisely and adjust upward if the threshold is exceeded. Limitation, computed from the date of default rather than the date of demand, has dispatched many a recovery action. The six-year period under the Limitation Act 1953 begins to run on the date the cause of action accrues, which for an on-demand facility is the date of demand, but for an instalment facility is the date of each missed instalment.",
         "Parallel proceedings before BNM, the Securities Commission or the Anti-Corruption Commission are a feature of contemporary banking work. The litigator must coordinate with regulatory counsel, monitor the parallel timeline, and consider whether the regulator's findings might be admissible at the civil trial. Failure to do so produces conflicting positions on the record — fatal in cross-examination.",
         "Forum shopping has been disciplined by the Federal Court. Filings in inconvenient or unrelated registries are now liable to transfer applications under Order 57 and to costs orders. The litigator who files in Kota Bharu a dispute centred on a Kuala Lumpur facility loses the procedural advantage and pays the cost of the transfer application. Choose the forum that the documents and the witnesses point to; the court will follow the centre of gravity of the dispute.",
         "Finally, do not underestimate the weight of statutory interpretation. The banking statutes — the FSA 2013, the IFSA 2013, the National Land Code, the Insolvency Act — interlock in ways that are not apparent from any single instrument. Read the relevant provisions together and read the section headings; the structure of the legislation is itself an aid to interpretation."],
        ("Procedural rules are the handmaidens of justice; they are also her gatekeepers, and a litigant who flouts them does so at his peril.",
         "Lord Diplock, Birkett v. James [1978] AC 297")),

    2: ("Lessons from the Reports — Part 2",
        ["Banker–customer disputes are a magnet for ill-considered confidentiality breaches. Disclosing customer information to a third party — even in response to a court order — without the protection of a Schedule 11 exception or an explicit court order under section 134 FSA is actionable. The cases show banks sued by their own customers for sums many times the recovery in the underlying matter. Always seek an unless-order from the court before disclosing in litigation.",
         "Fiduciary pleadings against banks must identify the specific facts giving rise to the fiduciary relationship — undertaking to act for another's benefit, ascendancy or trust placed by the customer in the bank's officers. Generalised pleas that the bank owed fiduciary duties because it knew the customer's affairs are routinely struck out. The Quincecare claim, by contrast, requires red flags: the customer must plead the specific instructions, the specific officers who received them, and the specific inquiries that would have revealed the fraud.",
         "The advisory pitfall is acute. Where a bank moves beyond the supply of products into providing advice — investment recommendations, restructuring proposals, hedging strategies — it crosses into territory governed by Hedley Byrne v. Heller and the Capital Markets and Services Act 2007. The duty assumed must be matched by an internal advisory file, a clear scope-of-engagement letter and a record of the advice given. Without these, an unhappy customer will allege misadvice and the bank will struggle to disprove it.",
         "Account-holder identification matters more than ever. Accounts in the name of nominees, professional firms or trusts demand careful verification of the beneficial owner; ignoring the underlying party is the seedbed of secrecy claims, KYC failures and Quincecare exposure. The reported decisions are unkind to banks that did not look behind the formal account name when red flags were obvious."],
        ("A fiduciary is one who has undertaken to act for or on behalf of another in a particular matter giving rise to a relationship of trust and confidence; the obligation is to act with single-minded loyalty.",
         "Millett LJ, Bristol & West Building Society v. Mothew [1998] Ch 1")),

    3: ("Lessons from the Reports — Part 3",
        ["The Letter of Demand carries weight far beyond its formal function. A demand that does not particularise the sum demanded, or that demands a sum the bank cannot prove on documents, is the first thread the defendant will pull. The reported cases include LODs that demanded interest at rates not in the facility, that overstated the principal by clerical error, and that omitted the facility reference altogether. Each was held to be a defective demand, requiring re-issuance and a fresh cause of action.",
         "Affidavits in support of summary judgment are routinely struck out where the deponent lacks personal knowledge of the matters deposed. The standard solution is the section 90A Evidence Act 1950 certificate signed by the bank's officer-in-charge of the records — exhibiting the certificate to the affidavit converts the bank's records into prima facie evidence. Without the certificate, the Statement of Account is hearsay and the application fails.",
         "Order 14 is not a substitute for trial. Where the defendant raises a triable issue — even a thin one — the court will give leave to defend. The bank's affidavit must therefore meet each anticipated defence head-on, exhibiting the relevant document and explaining its significance. A defence that the facility was for an illegal purpose, that the deponent was not authorised, or that the variation discharges the surety, must be addressed in the affidavit, not in submissions.",
         "Post-judgment execution is a different discipline. Garnishee orders fail where the deposit is in joint names without a clear apportionment; charging orders over land require careful identification of the legal estate; writs of seizure and sale fail where the goods are leased rather than owned. Plan the execution at the time of pleading; the judgment that cannot be enforced is a paper judgment."],
        ("Where the affidavit in support of an Order 14 application establishes a prima facie case for judgment, the burden shifts to the defendant to show by affidavit that there is a triable issue.",
         "Edgar Joseph Jr SCJ, Bank Negara Malaysia v. Mohd Ismail [1992] 1 MLJ 400")),

    4: ("Lessons from the Reports — Part 4",
        ["Form 16D issued before crystallisation of default is the most common foreclosure error. The chargee must wait for the contractual notice period to elapse — usually one month after the demand — before issuing Form 16D, and the affidavit must demonstrate that the chargor was given the period the contract requires. The reported cases include OFS applications dismissed because Form 16D was issued the day after demand, without any opportunity for the chargor to remedy.",
         "Reserve price challenges have grown more sophisticated. Chargors now routinely commission their own valuations and challenge the chargee's reserve as understated. Practitioners should anticipate the challenge: obtain a valuation from a panel valuer with no conflict of interest, ensure the valuation report is current (within six months of the application), and address explicitly any factors that might depress the reserve (encumbrances, planning issues, tenancies). Parallel caveats lodged by competing creditors complicate the conduct of sale; address them in the OS application or risk a re-hearing.",
         "Under-valuation in auction is the chargee's nightmare. Where the auction price is significantly below market, the chargor may sue for the shortfall. The chargee's protection lies in a documented marketing process, a properly-set reserve, and contemporaneous valuations. Where the property is sold for less than the reserve, the chargee should consider abandoning the auction rather than pressing through and inviting future litigation.",
         "Caveats are the chargor's principal procedural weapon. A private caveat lodged after issuance of Form 16D but before the OS hearing must be addressed in the chargee's affidavit; failure to do so risks adjournment. Practitioners should run a fresh title search the day before filing the OS, the day before the hearing, and the day before the auction; the caveat lodged in the dying days of the timetable is the surprise that derails the sale."],
        ("The court will not lend itself to a sale at a reserve price which is plainly below market value; the chargee owes a duty to the chargor to obtain a fair price and not merely the sum needed to discharge the debt.",
         "Lord Templeman, Cuckmere Brick v. Mutual Finance [1971] Ch 949, adopted in Mahadevan s/o Mahalingam v. Manilal & Sons (M) Sdn Bhd [1984] 1 MLJ 266")),

    5: ("Lessons from the Reports — Part 5",
        ["The discharge defences in suretyship are well-established but easy to overlook. Material variation without consent — increase in the principal sum, extension of time, change of debtor — discharges the surety unless the anti-variation clause is broad enough to cover the variation. Practitioners must read the clause carefully: a clause permitting 'variations' may not cover increases in the principal sum, which the courts treat as a fundamentally different obligation.",
         "Loss of security through the bank's negligence is the surety's most powerful defence. If the bank fails to perfect a charge over the security, fails to register a debenture, or releases security without compensation, the surety is discharged pro tanto by the value of the lost security. The reported decisions show banks losing on summary judgment because their internal records disclosed the loss of security and the affidavit failed to address it. Audit the security file before issuing the LOD.",
         "Co-suretyship is a minefield. The release of one co-surety, even on terms preserving the right of recourse against the others, may be construed as a release pure and simple if the documentation is loose. Where the bank settles with one guarantor, the deed of settlement should expressly preserve the bank's rights against the others and the others' rights of contribution. Without express words, the equity that the released party shares the burden cannot be recovered.",
         "Personal-guarantor circumstances now carry weight. Insolvency Act amendments and BNM consumer guidelines have introduced safeguards for individuals who guaranteed without commercial benefit. Banks must classify the guarantor at the outset (commercial or social), brief the surety appropriately at signing, and document the briefing. A guarantee signed without independent advice is vulnerable to undue influence and unconscionability arguments that did not exist a generation ago."],
        ("Equity will not assist a creditor who, by his own act, has released or impaired the security on the faith of which the surety stood; the surety's right of subrogation is sacred.",
         "Sir Mathias Boon Soong Chang JCA, Bumiputra-Commerce Bank v. Top-A Plastic [2008] 5 MLJ 34")),

    6: ("Lessons from the Reports — Part 6",
        ["Defective bankruptcy notices are the leading reason for set-aside orders. The notice must state the judgment debt accurately; even a minor over-statement (a few ringgit due to mis-computed interest) renders the notice invalid. The Federal Court in Re Liang Yik Wah and successive decisions has insisted on strict compliance — the bankruptcy jurisdiction is exorbitant and procedural protection is for the debtor.",
         "Late filing of the creditor's petition is a frequent error. Section 5(2) of the Insolvency Act 1967 requires the petition to be filed within six months of the act of bankruptcy. Practitioners who allow time to slip past must consider whether a fresh act of bankruptcy can be procured (re-issue notice, re-default), but each fresh act resets only the limitation, not the underlying judgment. A judgment that has expired (twelve years) cannot be revived by a new bankruptcy notice.",
         "Service problems multiply in cross-border cases. Service on a debtor abroad requires Order 11 leave for the underlying writ and a corresponding leave for the bankruptcy notice; service through the Hague Convention is the proper route for Convention countries. The shortcut of substituted service in Malaysia for a debtor known to be abroad is invalid; the entire proceeding will be set aside and the petitioning creditor pays.",
         "Recent practice has emphasised the social-guarantor protection. A bank seeking to bankrupt a social guarantor must show that all reasonable efforts have been made to recover from the principal debtor. The affidavit must particularise these efforts — civil suit, judgment, execution attempts, garnishee, examination of judgment debtor — and exhibit the relevant orders. A petition that omits this material is a wasted filing."],
        ("The bankruptcy procedure is not a debt collection device; it is a proceeding that affects the status of an individual and must be approached with the gravity that this entails.",
         "Suriyadi Halim Omar FCJ, Re Liang Yik Wah & Anor [2014] 4 MLJ 561")),

    7: ("Lessons from the Reports — Part 7",
        ["Statutory demands for disputed sums are routinely set aside. The petitioning creditor must demand only what is presently due and beyond bona fide dispute. Where the sum claimed includes contested interest or penalty charges, the prudent course is to demand only the principal and the uncontested interest, leaving the disputed elements to the substantive proceedings.",
         "Service at the registered office is mandatory; service on a director's personal address or the company's place of business is not effective. The petitioner must search the SSM portal at the date of service and exhibit the search to the affidavit. Advertisement of the petition in the Gazette and a daily newspaper is required for the petition to proceed; failure to advertise within the prescribed period dismisses the petition without further hearing. Calendar these dates from the moment the petition is filed.",
         "Cross-petitioning has become common. Where one creditor files for winding-up, another may petition for a scheme of arrangement under section 366 of the Companies Act 2016 to head it off. The bank must monitor the SSM and the High Court records for cross-petitions and oppose where a scheme is plainly a delaying tactic. The reported decisions show schemes being approved and winding-up petitions dismissed where the scheme is workable; the bank that has not engaged with the scheme is at a disadvantage.",
         "Liquidator selection matters. Where the bank is the petitioning creditor, the bank's choice of liquidator at the petition stage is usually adopted by the court. Choose a liquidator with banking experience and capacity for the matter; an inexperienced liquidator will struggle with cross-border assets, charged property and Shariah-compliant inventories, and the bank's recovery will suffer."],
        ("The winding-up jurisdiction is to be exercised with caution where the petition is met by a bona fide dispute; this court will not be drawn into the trial of disputed debts under the guise of a winding-up petition.",
         "Lord Cross, Stonegate Securities v. Gregory [1980] Ch 576")),

    8: ("Lessons from the Reports — Part 8",
        ["Pleading an Islamic facility as if it were conventional invites a section 56 reference and a six-month delay. The differences are substantive: BBA involves a sale and re-sale, Murabahah involves cost-plus disclosure, Musharakah Mutanaqisah involves diminishing co-ownership. Each contract has its own remedies, its own quantum methodology and its own SAC rulings. Practitioners must take instructions on the contract type at first meeting and plead accordingly.",
         "Mis-computation of ta'widh and ibra' is the most common error in quantum. Ta'widh is compensation for actual loss, capped at the financier's cost of funds; it cannot be a penal rate disguised as compensation. Ibra' must be granted in accordance with the SAC's rulings on early settlement rebate. Pleadings that claim 'overdue profit' at the contracted rate without computing ibra' will be remitted for amendment. The reported decisions have been progressively stricter on these points.",
         "The dual jurisdiction of the civil courts and the SAC is now well-settled but still mishandled. The civil court adjudicates the dispute; the SAC determines Shariah questions arising in the dispute. The reference is mandatory under section 56 if a Shariah question arises and the parties have not agreed otherwise; the SAC's ruling is binding under section 57. Practitioners should identify the Shariah question precisely in the pleading and either invite the reference or address the question by reference to existing SAC rulings.",
         "Documentation discipline in Islamic finance is unforgiving. The underlying sale, lease or partnership agreements are the foundation of the recovery action; if the bank cannot produce the property purchase agreement in BBA or the joint-ownership document in Musharakah Mutanaqisah, the entire claim is precarious. Audit the file at the LOD stage; the time to discover that the property purchase agreement was never executed is before, not during, the trial."],
        ("The courts must have regard to the rulings of the Shariah Advisory Council, which is the authoritative body in Islamic financial matters; on questions of Shariah, the SAC speaks and the court listens.",
         "Md Raus Sharif PCA, Tan Sri Abdul Khalid Ibrahim v. Bank Islam Malaysia Bhd [2013] 3 MLJ 269")),

    9: ("Lessons from the Reports — Part 9",
        ["Failure to preserve the original cheque is a recurring fault. The Bills of Exchange Act 1949 contemplates production of the original instrument; certified copies are admissible only with leave. Banks that scan and shred cheques must ensure that the scanning protocol meets the section 90A requirements and that the original is retained in archive for at least six years.",
         "Inadequate KYC undermines the section 85 defence. The collecting bank's protection requires the bank to act in good faith and without negligence; negligence is assessed on the bank's own KYC, account-opening and monitoring procedures. The reported cases include banks losing the section 85 defence because customer due diligence at account opening was perfunctory, or because the bank failed to act on internal alerts about unusual account activity. Document the KYC process and produce the file at trial.",
         "Cyber-cheque fraud is the modern face of the old offence. Where a cheque is altered electronically, presented through an image-based clearing system, or processed through compromised infrastructure, the bank's defence depends on the integrity of its image-capture process, its fraud-detection rules and its response to anomalies. The reported cases now scrutinise the bank's IT controls as carefully as its KYC; technology is the new front of cheque litigation.",
         "Stop-payment orders are easy to mishandle. A customer's instruction to stop payment must be acted on immediately, recorded in the system, and applied to all relevant payment channels. A stop-payment recorded against the cheque number but not against the alternate clearing channel results in an honoured cheque and a customer's claim for breach of mandate. Document the stop-payment instruction the moment it is received and confirm the stop in writing within the same day."],
        ("A bank which collects a cheque for a customer must do so with reasonable care; what amounts to reasonable care depends on the circumstances, but it is not a defence that the bank acted in accordance with general practice if that practice itself falls short of the standard the law requires.",
         "Diplock LJ, Marfani v. Midland Bank [1968] 1 WLR 956")),

    10:("Lessons from the Reports — Part 10",
        ["A trial without a master chronology runs slowly and tends to lose. The chronology should be cross-referenced to the bundle and to the witness statements, and should be revised after each witness gives evidence. A judge presented with a chronology can navigate a complex case in minutes; without one, the judge must rebuild the narrative from the bundle, with all the risk that entails.",
         "Disorganised bundles cost trials. The Rules of Court 2012 require pagination, indexing and tabbed sections. A bundle that is paginated inconsistently, that omits documents referred to in submissions, or that includes irrelevant material is a perpetual irritant to the bench. Prepare the bundle as if the judge will read it cover to cover (some do), and as if the appellate court will read it later (it will, if the case goes up). The costs schedule, finally, should be ready before the closing submissions, not improvised at the conclusion.",
         "Witness statement discipline has tightened. The Federal Court has criticised statements that recite documents at length, that incorporate argument or that wander beyond the witness's personal knowledge. Statements should be in the witness's own words, confined to matters within the witness's personal knowledge, and cross-referenced to the bundle. The carefully-drafted statement is the witness's testimony in chief; the careless one is a target for cross-examination.",
         "Costs are the litigator's last duty. Order 59 rule 6 requires summary assessment of costs in many interlocutories; the practitioner who arrives at the assessment without a costs schedule will be assessed by guess. Maintain a contemporaneous file of work done, hours, rates and disbursements; produce a clean costs schedule at the close of every hearing. The discipline of cost-recording is the discipline of practice."],
        ("Justice cannot be done without proper preparation; the bench depends on counsel and counsel depends on the file. There are no shortcuts.",
         "Tun Mohamed Suffian LP, address to the Malaysian Bar, 1973")),
}


# =====================================================================
# JUDICIAL VOICES & JURIST COMMENTARY — supplementary blocks injected
# at multiple PageBreak boundaries to ensure every page is densely set.
# Each entry: (heading, [(quote, attribution), ...], [paragraph, ...])
# =====================================================================

JUDICIAL_VOICES = {
    1: ("Voices from the Bench — Part 1",
        [("The function of the courts in commercial matters is to hold the parties to their bargain, not to remake it; commercial certainty is the surest foundation of a banking system that the public can trust.",
          "Tun Zaki Tun Azmi CJ, address at the opening of the Legal Year 2010"),
         ("A bank seeking summary judgment must come to court with its house in order — the facility, the demand, the default and the calculation must speak for themselves on the face of the affidavit.",
          "Gopal Sri Ram FCJ, Cempaka Finance v. Ho Lai Ying [2006] 2 MLJ 685")],
        ["The Malaysian appellate courts have developed a settled philosophy in commercial work: respect for the bargain, scepticism of after-the-event reformulation, and insistence on procedural rigour. Practitioners returning to the law reports after a few years' absence will find the same themes — the importance of pleadings, the discipline of affidavit evidence, the centrality of the documentary record — repeated with growing emphasis. The cases reward those who work to the discipline and punish those who do not.",
         "Academic commentators, from Visu Sinnadurai's foundational Law of Contract to Cheong May Fong's later work on commercial remedies, have traced the same arc: a Malaysian commercial jurisprudence that is increasingly self-confident, that draws on but is not bound by English precedent, and that takes seriously the regulatory architecture in which the banks operate. The practitioner who reads only the reported cases misses the doctrinal context in which those cases must be understood."]),

    2: ("Voices from the Bench — Part 2",
        [("Bank confidentiality is not a private convenience for the bank; it is a public good that the legislature has chosen to protect with the criminal law.",
          "Datuk Wira Low Hop Bing JCA, Hong Leong Bank v. Liew Fook Chuan [2007] 6 MLJ 393"),
         ("A bank cannot stand idly by while its customer's account is plundered; if the circumstances are such as to put a reasonable banker on inquiry, the duty to inquire is not displaced by the customer's own apparent acquiescence.",
          "Steyn J., Barclays Bank v. Quincecare [1992] 4 All ER 363")],
        ["The Quincecare duty has been received into Malaysian law gradually but firmly. Banks operating in Malaysia must now train staff to recognise the red flags — instructions inconsistent with the customer's profile, payments to unusual destinations, transactions that do not square with the stated purpose of the account — and to escalate them to compliance. A failure of training is a failure of the duty, and the courts have shown themselves willing to find banks liable in significant sums where the training was patently inadequate.",
         "Fiduciary doctrine remains tightly confined. The reported cases consistently refuse to impose fiduciary obligations on banks merely because they handle the customer's affairs; what is required is an undertaking to act in the customer's interest in a particular matter, with a corresponding ascendancy or trust. The practitioner pleading fiduciary breach must identify the specific undertaking; the practitioner defending must point to the absence of one."]),

    3: ("Voices from the Bench — Part 3",
        [("Order 14 is a summary procedure; it is not a license to deprive a defendant of trial where there is a triable issue, however thinly drawn.",
          "Mohamed Azmi FCJ, National Company for Foreign Trade v. Kayu Raya [1984] 2 MLJ 300"),
         ("The Statement of Account is the most important document in a banking suit, and the section 90A certificate is its passport into the affidavit; without the passport, the document is hearsay and the application fails.",
          "Abdul Hamid Mohamad CJ, RHB Bank v. Wong Hew Min [2009] 2 CLJ 13")],
        ["The discipline of the Statement of Account has been the single greatest evidentiary advance in Malaysian banking litigation in the past two decades. The combination of section 90A and the modern affidavit-of-records practice has transformed what used to be a contested area into an almost mechanical one: comply, exhibit, succeed. Banks that have not internalised the discipline lose cases they should win; banks that have do not.",
         "On the recovery side, the Federal Court's emphasis on documentation has changed practice in measurable ways. Facility letters are longer and more specific; LODs are templated and reviewed; computation worksheets are exhibited as a matter of course. The litigator who comes from another field is sometimes startled by the volume of paper a Malaysian banking suit generates; the answer is that each piece of paper has been made necessary by an appellate decision."]),

    4: ("Voices from the Bench — Part 4",
        [("The chargee's right to sell is not a punitive remedy; it is the realisation of a security interest carefully bargained for and reflected in the register, and the court will protect it where the procedural steps have been observed.",
          "Edgar Joseph Jr FCJ, Low Lee Lian v. Ban Hin Lee Bank [1997] 1 MLJ 77"),
         ("Reserve price is a matter for the court, but the court will be guided by the chargee's valuation if it is recent, independent and reasoned; bare assertion will not do.",
          "Mohamad Ariff JCA, Co-operative Central Bank v. Feyen Development [2007] 7 MLJ 217")],
        ["Foreclosure jurisprudence in Malaysia has developed in a single direction since the 1990s: away from technical objections and towards procedural rigour for the chargee. The reported cases will reward a chargee who issues Form 16D properly, exhibits the Land Office search, sets a defensible reserve and addresses each likely objection in advance. The chargee who proceeds carelessly invites a grant-and-set-aside cycle that costs months and erodes the value of the security.",
         "Academic writing on the National Land Code — particularly Teo Keang Sood's seminal commentary — has emphasised that the Code is a system of priorities to be respected by the courts. The chargee who understands the priority register, the role of caveats and the interaction between charges and tenancies brings to the auction a fluency that the chargor's challenge cannot easily disturb. Mastery of the Code is the foreclosure litigator's competitive edge."]),

    5: ("Voices from the Bench — Part 5",
        [("A guarantee is a contract of the strictest construction; the surety is bound only by what he has clearly promised, and any ambiguity is resolved against the creditor who drafted the document.",
          "Lord Diplock, Moschi v. Lep Air Services [1973] AC 331"),
         ("Where the bank by its own conduct has impaired the security on the faith of which the surety stood, equity intervenes to discharge the surety pro tanto; this is not a technicality but a foundational principle of suretyship.",
          "Mohd Hishamudin JCA, AmBank v. Tan Tem Son [2013] 1 MLJ 491")],
        ["Suretyship in Malaysia draws heavily from the English authorities, but local cases have refined the doctrine in commercially significant ways. Anti-variation clauses have been read sometimes broadly and sometimes narrowly, depending on the precise wording and the materiality of the variation; principal-debtor clauses have been enforced robustly where clearly drafted but read down where ambiguous. The careful litigator reads every guarantee against the leading authorities of the past decade before launching enforcement.",
         "Andrew Phang Boon Leong's writing on suretyship — though rooted in Singapore — has been influential in Malaysian courts and offers the most accessible doctrinal framework for the practitioner. His analysis of the discharge defences, the role of the principal-debtor clause and the protection of co-sureties remains required reading. Where Malaysian authority is silent, his exposition is often the next best guide."]),

    6: ("Voices from the Bench — Part 6",
        [("Bankruptcy is the gravest civil sanction the law has at its disposal; it is not to be deployed for the recovery of a disputed debt, nor as a tactical pressure on a debtor who has a genuine cross-claim.",
          "Lord Diplock, Re Saunders [1997] Ch 60, applied in Re Dr Mohan [2001] 6 MLJ 553"),
         ("The Insolvency Act 2017 amendments are not a technical revision; they reflect a deliberate legislative judgment that bankruptcy is to be reserved for cases where it is genuinely warranted, with social guarantors particularly in mind.",
          "Tengku Maimun Tuan Mat CJ, address to the Malaysian Bar, 2019")],
        ["The 2017 amendments have changed the strategic calculus of bankruptcy in significant ways. The threshold of RM 100,000 excludes minor debts; the social-guarantor protection requires fresh process before petitioning; the discharge regime allows automatic discharge after three years subject to certain conditions. The bank that once filed bankruptcy as a recovery tool now files only after a deliberate cost-benefit analysis.",
         "Practitioners should also be aware of the growing use of voluntary arrangements under Part X of the Insolvency Act. A debtor with assets but no liquidity can propose a scheme to creditors; the bank that opposes a credible scheme without engaging with the merits may find the scheme approved over its objection. Reading the proposal critically and engaging in the negotiation is now part of the bank's recovery toolkit."]),

    7: ("Voices from the Bench — Part 7",
        [("The petition to wind up is not the proper forum for the ascertainment of disputed debts; the petitioner who proceeds despite a bona fide dispute does so at his own peril and at the risk of indemnity costs.",
          "Lord Cross, Stonegate Securities v. Gregory [1980] Ch 576"),
         ("Section 466 is a statutory presumption, not a substantive cause of action; the petitioner must still satisfy the court that winding-up is just and equitable in the circumstances.",
          "Hasan Lah JCA, Pacific Bank v. Kerajaan Negeri Sarawak [2003] 5 MLJ 161")],
        ["Winding-up under the Companies Act 2016 is procedurally tighter than its 1965 predecessor. The schemes of arrangement under sections 366-368 have become a popular alternative to liquidation, and judicial management under sections 405-430 offers a Malaysian equivalent of the English administration order. Practitioners must now navigate these alternatives with the same fluency they bring to the petition.",
         "The Court of Appeal's decisions over the past five years have emphasised the importance of timeliness in winding-up. Petitions that languish, that are repeatedly adjourned, that are not advertised within the prescribed period, are dismissed without hesitation. The petitioner who treats the winding-up calendar as flexible learns the lesson at the petitioner's own cost."]),

    8: ("Voices from the Bench — Part 8",
        [("The civil court is not a Shariah authority; on a Shariah question the court must defer to the Shariah Advisory Council, whose ruling under section 57 of the CBMA is binding on the court and on the parties.",
          "Zulkefli Ahmad Makinudin CJM, Mohd Alias bin Ibrahim v. RHB Bank Bhd [2011] 4 CLJ 654"),
         ("Islamic banking is a real industry, not a labelled version of conventional finance; the courts must read the contracts as they are and give effect to the Shariah-compliant transaction the parties have struck.",
          "Tan Sri Md Raus Sharif PCA, Bank Islam v. Lim Kok Hoe [2009] 6 MLJ 839")],
        ["The growth of Islamic banking in Malaysia has produced a parallel growth of Shariah jurisprudence in the commercial courts. Practitioners must now be conversant with not only the civil-law procedure but the substantive Shariah analysis of the underlying contracts. The Shariah Advisory Council's published rulings have become a primary research source; the practitioner who does not consult them before pleading is working blindfold.",
         "Younes Soualhi's writing on Malaysian Islamic finance and Mohd Daud Bakar's commentary on contemporary Shariah issues are essential reading. They explain the doctrinal logic that underpins the civil-court decisions and equip the practitioner to anticipate the SAC's likely answer to a novel question. In a developing field, the secondary literature is sometimes more useful than the case reports."]),

    9: ("Voices from the Bench — Part 9",
        [("The cheque is a peculiar instrument; it carries with it both the convenience of payment and the burden of strict liability, and the law of cheques requires of the bank a vigilance that the law of cash does not.",
          "Lord Atkin, Joachimson v. Swiss Bank Corporation [1921] 3 KB 110"),
         ("The collecting bank's duty to act with care is not satisfied by mere conformity to general practice; if the practice itself falls short, so does the bank.",
          "Diplock LJ, Marfani v. Midland Bank [1968] 1 WLR 956")],
        ["Cheque litigation in Malaysia has not declined as rapidly as in some other jurisdictions, partly because cheques remain in significant commercial use and partly because the Bills of Exchange Act 1949 has proved a durable framework. The reported cases continue to address conversion, wrongful dishonour, and the section 85 defence with the same essential analysis the leading English cases established a century ago.",
         "What has changed is the technology. Image-based clearing, electronic presentation and cheque-truncation systems have introduced new failure modes — image quality, image timing, image storage — that test the old doctrine. Banks must now demonstrate the integrity of the technological process as well as the integrity of the human process; courts have responded by requiring affidavit evidence on the technology that did not exist a generation ago."]),

    10:("Voices from the Bench — Part 10",
        [("There is no substitute for thorough preparation; the case that is well prepared often settles, and the case that goes to trial usually wins.",
          "Tun Mohd Salleh Abas LP, address to the Bar Council, 1986"),
         ("The trial process belongs to the parties; the bench is the umpire, not the player. Counsel who expect the bench to do their work for them will be disappointed.",
          "Tun Zaki Azmi CJ, address at the Judicial Conference, 2009")],
        ["The trial process in Malaysia rewards preparation in measurable ways. Cases that come to trial with proper bundles, complete witness statements and well-organised authorities are tried in days; those that do not are tried in weeks. The cost difference, in solicitor-and-client and party-and-party terms, is enormous. The litigator who invests in preparation invests in the client's recovery.",
         "Ethics is the litigator's foundation. Order 22A (offers to settle), Order 41 (affidavit evidence) and the Legal Profession (Practice and Etiquette) Rules 1978 establish the bounds within which the litigator must operate. The reported decisions on professional discipline read like a chronicle of avoidable disasters: missed deadlines, mis-stated facts, conflicts of interest. The discipline of practice is not optional; it is the precondition of every other competence."]),
}

JURIST_COMMENTARY = {
    1: ("Doctrinal Footnote — The Architecture",
        ["Visu Sinnadurai's authoritative Law of Contract reminds the practitioner that the Malaysian contractual framework is statutory at its core: the Contracts Act 1950 codifies what English law leaves to the common law. This matters in banking work because the codification subtly reorders the analysis — consideration, mistake, frustration and discharge are governed by sections 26, 21, 56 and 57 respectively, and the case law has built around those sections rather than around their English antecedents.",
         "Cheong May Fong's writing on commercial remedies is the modern complement. Her analysis of damages, restitution and equitable relief in the Malaysian context shows how the courts have adapted received doctrine to local commercial conditions. For the banking litigator, her treatment of the recovery of money paid under a mistake and of restitutionary claims against banks is essential — the underlying analysis recurs constantly in cheque, transfer and standing-order litigation."]),

    2: ("Doctrinal Footnote — Banker–Customer Duty",
        ["Ellinger, Lomnicka and Hare's Modern Banking Law remains the standard treatise on the banker–customer relationship in the Commonwealth tradition. Their analysis of the contract, the agency and the fiduciary aspects of the relationship is foundational; the Malaysian practitioner who masters the framework can navigate any banking dispute that arises in this Part. The treatise also explains the regulatory architecture in which the duties operate — central to the FSA / IFSA analysis.",
         "On Quincecare specifically, Andrew McKnight's The Law of International Finance offers the most accessible exposition of the duty in commercial context. His treatment of the red-flag analysis, of the bank's duty to inquire and of the consequences of failure to do so equips the practitioner to plead and to defend Quincecare claims with confidence. The duty is not new; the willingness of the courts to find banks liable for breach is."]),

    3: ("Doctrinal Footnote — Loan Recovery Practice",
        ["Skandar Singh Sidhu and Sukhmander Singh, in their Banking Law and Practice in Malaysia, document the recurring patterns in recovery work — the LOD, the affidavit, the Order 14 application — with a precision born of practice. Their templates and commentary reflect the actual rhythm of the Commercial Division and remain a reliable reference for the daily questions that arise.",
         "Hashim bin Yusoff's treatment of the Limitation Act 1953 is the standard reference for that statute. The interaction between sections 6, 26 and 27 — accrual, acknowledgement and disability — has produced more reported decisions than any other limitation question, and Hashim's commentary explains the doctrinal architecture that the cases otherwise leave implicit. Where limitation is in issue, his is the first text to consult."]),

    4: ("Doctrinal Footnote — Foreclosure & Security",
        ["Teo Keang Sood's commentary on the National Land Code 1965 is foundational. The Code is a system of priorities, of registration and of statutory remedies, and Teo's exposition of how the parts interact is the practitioner's principal aid in navigation. His treatment of the chargee's remedies, of the cause to the contrary doctrine and of the conduct of sale is unmatched in the literature.",
         "On comparative perspective, Lynden Griggs and Adrian Bradbrook's Real Property Law in Australia and New Zealand offers a useful counterpoint. The Australian Torrens system shares many features with the Malaysian Code; comparative reading sharpens the practitioner's understanding of why certain provisions take the form they do, and helps to anticipate the direction of legislative reform."]),

    5: ("Doctrinal Footnote — Suretyship Doctrine",
        ["Geraldine Mary Andrews and Richard Millett's Law of Guarantees is the modern English treatise and remains the most thorough exposition of suretyship doctrine available in English. Malaysian courts cite the work regularly, particularly on the discharge defences and on the construction of anti-variation and principal-debtor clauses. The Malaysian practitioner cannot do without it.",
         "On the local side, Andrew Phang Boon Leong's analysis (though Singaporean) is the most accessible doctrinal framework. His treatment of the equity of subrogation, of the protection of co-sureties and of the limits of the principal-debtor clause is widely read in Malaysia and frequently cited in argument. Where the Malaysian authorities are silent or sparse, his analysis often supplies the answer."]),

    6: ("Doctrinal Footnote — Bankruptcy Practice",
        ["Halsbury's Laws of Malaysia, in its Bankruptcy and Insolvency volume, is the standard reference for procedure under the Insolvency Act 1967 and the Bankruptcy Rules 2017. The volume is regularly updated and reflects the recent practice directions; for the day-to-day questions of practice — service, notice, petition — it is the first text to open.",
         "Ian F. Fletcher's The Law of Insolvency offers a comparative perspective with which the Malaysian practitioner should be familiar. The English regime has many parallels with the Malaysian and many divergences; understanding both helps to anticipate the direction of Malaysian reform and to argue from comparative authority where Malaysian law is silent. The treatise is dense but rewarding."]),

    7: ("Doctrinal Footnote — Corporate Insolvency",
        ["The Companies Act 2016 has been the subject of detailed commentary by Krishnan Arjunan and others; their analysis of the new winding-up provisions, of the schemes of arrangement under sections 366-368 and of judicial management under sections 405-430 is essential reading. The Act is a significant departure from its 1965 predecessor and the practitioner who relies on older texts is at a serious disadvantage.",
         "On the procedural side, the Winding-Up Rules and the practice directions issued by the Chief Justice's chambers are the working documents. The Bar Council and the Insolvency Practitioners' Association of Malaysia publish updates regularly; subscribing to those updates is the simplest way to stay current in a fast-moving field."]),

    8: ("Doctrinal Footnote — Islamic Finance Doctrine",
        ["Younes Soualhi's writing on Malaysian Islamic finance is the practitioner's principal doctrinal guide. His exposition of the principal contracts (Murabahah, BBA, Musharakah Mutanaqisah, Ijarah, Tawarruq), of the SAC's role and of the interaction between Shariah and civil procedure equips the practitioner to operate confidently in this field. He writes for practice, not for the lecture hall.",
         "On the broader doctrinal questions, Mohd Daud Bakar's commentary on contemporary Shariah issues is the most authoritative. His treatment of late-payment charges, of takaful and of the foreclosure of Shariah-compliant assets is regularly cited by the SAC itself. Where a novel Shariah question arises, his published views are often the best predictor of the answer the SAC will reach."]),

    9: ("Doctrinal Footnote — Cheque Law",
        ["Geva's Bank Collections and Payment Transactions remains the standard international reference on cheque law and the related payment systems. His analysis of the collecting bank's duty, of the conversion remedy and of the statutory protections is the most thorough available in English; Malaysian courts cite it regularly. The practitioner who works in cheque litigation needs the treatise on the desk.",
         "Locally, the Bills of Exchange Act 1949 has been the subject of detailed commentary in older texts that retain their value: Robert Lim Eng Hooi's exposition of the Malaysian cheque law of his generation remains a useful reference, though the practitioner must of course supplement it with the modern reported cases. The combination of Geva and Lim is the closest Malaysia has to a complete text on cheque law."]),

    10:("Doctrinal Footnote — Trial Craft & Ethics",
        ["The Bar Council's Practice Notes and the Legal Profession (Practice and Etiquette) Rules 1978 are the working ethical framework. The Notes address recurring questions — conflicts of interest, communication with the other side, file retention — with practical specificity. The Rules establish the substantive obligations; the Notes operationalise them. Both should be on every desk.",
         "On trial advocacy itself, the writings of David Pannick QC (Advocates) and of Iain Morley QC (The Devil's Advocate) are widely read in the Malaysian Bar. Their analysis of cross-examination, of submissions and of the ethical dimensions of advocacy is universal; the Malaysian practitioner can apply the lessons directly. Banking litigation rewards the same craft as any other commercial litigation, only with more documents."]),
}


PRACTICE_TIPS = {
    1: ("Practice Tips &mdash; Foundations",
        ["Maintain a one-page <i>Statute Map</i> on the desk: FSA 2013, IFSA 2013, Limitation Act 1953, "
         "Contracts Act 1950, Companies Act 2016, Insolvency Act 1967, NLC 1965 and Rules of Court 2012. "
         "Almost every banking matter touches three or more of these instruments.",
         "Open every file with a <i>Forum Memo</i> (one paragraph) recording quantum, court, division and "
         "limitation deadline. Update the memo whenever the quantum changes; this single discipline avoids "
         "more wasted filings than any other.",
         "Track the regulator. Where BNM, the SC or MACC has an open file on the same facts, calendar the "
         "regulator's review dates alongside the litigation timeline; cross-reference findings at every "
         "case management."]),
    2: ("Practice Tips &mdash; Banker–Customer",
        ["Catalogue every mandate variation in a <i>Mandate Log</i> within the file; the bank's evidence at "
         "trial will turn on this log when authority is challenged.",
         "Where a Quincecare risk is suspected, document the bank's <i>red-flag escalation</i> in writing on "
         "the same business day; oral escalations cannot be reproduced at trial.",
         "Schedule 11 FSA exceptions are exhaustive. When a disclosure is contemplated, prepare a one-page "
         "<i>Schedule 11 Memo</i> identifying the precise exception relied on; never rely on general "
         "consent."]),
    3: ("Practice Tips &mdash; Loan Recovery",
        ["Build a <i>Quantum Worksheet</i> at the time of the LOD: principal, interest to date, daily rest, "
         "fees, recoveries. Update it weekly until judgment. The worksheet is exhibited at every later "
         "stage.",
         "Section 90A certificates should be drafted by the records officer, not the litigator; the officer's "
         "personal knowledge of the records is what gives the certificate its weight under the Evidence Act.",
         "After judgment, run an <i>Execution Map</i>: garnishee targets, real property held, movable goods, "
         "cross-border assets. Pursue the easiest avenue first; preserve the others for later applications."]),
    4: ("Practice Tips &mdash; Foreclosure",
        ["Run a <i>Title Search Trinity</i>: at filing, the day before the OS hearing, the day before "
         "auction. The caveat lodged in the dying days of the timetable is the surprise that derails the "
         "sale.",
         "Engage the valuer early. A panel valuer with no conflict of interest, a recent valuation (within "
         "six months) and a clear methodology defeats most reserve-price challenges before they begin.",
         "Brief the auctioneer on the order's marketing terms; an auctioneer who advertises in a single "
         "paper for the minimum required period invites under-valuation litigation later."]),
    5: ("Practice Tips &mdash; Guarantees",
        ["Maintain a <i>Variation Consent File</i>: every change to the principal facility documented and "
         "consented in writing. The file is the surest answer to the Holme v. Brunskill defence.",
         "Audit security at the LOD stage. Where the bank's records disclose lost or impaired security, "
         "address the loss in the affidavit; the surety's pro tanto discharge is the most embarrassing "
         "Order 14 defeat the bank can suffer.",
         "Where a co-surety settles, draft the deed expressly to preserve recourse against the others; the "
         "loose release wipes out three claims for the price of one."]),
    6: ("Practice Tips &mdash; Bankruptcy",
        ["Re-verify the judgment debt on the day before the Bankruptcy Notice is issued. Even a one-cent "
         "over-statement has set notices aside; the verification takes minutes and saves months.",
         "For social guarantors, exhibit the bank's <i>Recovery Effort Schedule</i>: writ, judgment, "
         "execution, garnishee, examination of judgment debtor. Without this, the petition will be set "
         "aside on first listing.",
         "Watch the six-month clock under section 5(2) Insolvency Act. Late petitions are wasted filings; "
         "if time is tight, file protectively and address the act of bankruptcy in detail in the affidavit."]),
    7: ("Practice Tips &mdash; Winding-Up",
        ["Demand only what is presently due and undisputed; the petition that demands too much invites the "
         "bona fide dispute defence and the indemnity costs that follow.",
         "Calendar the advertisement window from day one. A petition that misses the Gazette or the daily "
         "newspaper deadline is dismissed without further hearing.",
         "Engage with cross-petitioned schemes of arrangement. A bank that opposes a workable scheme by "
         "default loses the strategic engagement and may find the scheme approved over its objection."]),
    8: ("Practice Tips &mdash; Islamic Finance",
        ["Identify the underlying Shariah contract at first meeting; pleading 'Islamic facility' without "
         "more is insufficient and invites a section 56 reference at the worst time.",
         "Compute ta'widh against the BNM guidelines; produce the <i>Compensation Worksheet</i> and exhibit "
         "it. Vague claims for 'overdue profit' are remitted for amendment.",
         "Consult the SAC's published rulings before pleading. Where a ruling exists on the point, cite it; "
         "where one is silent, consider whether a reference at the outset is more efficient than a "
         "reference forced after months of pleading."]),
    9: ("Practice Tips &mdash; Cheques",
        ["Preserve the original cheque for at least six years; for image-truncated processes, retain the "
         "image plus the section 90A certificate and the integrity log of the capture system.",
         "KYC at account opening is the foundation of the section 85 defence. Document the KYC; produce "
         "the file at trial; the bank with weak KYC loses despite good faith.",
         "Stop-payment instructions must be acted on across all clearing channels and confirmed in writing "
         "the same business day; a stop recorded against one channel only is a wasted instruction."]),
    10:("Practice Tips &mdash; Trial Craft",
        ["Build the chronology before the witness statements. The witness statement is the chronology in "
         "the witness's own words; it must square with the master chronology to the day.",
         "Maintain a <i>Costs Diary</i> contemporaneously: hours, rates, disbursements, cross-references "
         "to the file. The costs schedule on the day of summary assessment is the work product of the "
         "costs diary, not an improvised reconstruction.",
         "Walk every material witness through the bundle before the witness takes the stand. The witness "
         "who cannot find his own affidavit in cross-examination loses the case for the client."]),
}


def _append_tips(no, story):
    """Append a 'Practice Tips' bulleted module to fill bottom of pages."""
    tips = PRACTICE_TIPS.get(no)
    if not tips:
        return
    heading, items = tips
    story.append(Paragraph(heading, NOTE_H))
    for item in items:
        story.append(Paragraph("&#9670;&nbsp;&nbsp;" + item, NOTE_BODY))


def _append_filler(no, prose_dict, story):
    """Append a heading + multiple paragraphs + judicial quote + practice tips.
    The Practice Tips ensure that any orphan page after the quote is itself filled."""
    entry = prose_dict.get(no)
    if not entry:
        return
    heading, paragraphs, quote = entry
    story.append(Paragraph(heading, NOTE_H))
    for para in paragraphs[:-1]:
        story.append(Paragraph(para, NOTE_BODY))
    last_para = Paragraph(paragraphs[-1], NOTE_BODY) if paragraphs else None
    if quote:
        q_text, q_attrib = quote
        block = []
        if last_para is not None:
            block.append(last_para)
        block.append(Paragraph("&ldquo;" + q_text + "&rdquo;", QUOTE_BOX))
        block.append(Paragraph("&mdash; " + q_attrib, QUOTE_ATTRIB))
        story.append(KeepTogether(block))
    elif last_para is not None:
        story.append(last_para)
    # Always emit Practice Tips after the quote so the next page does not
    # end up empty if the quote orphaned onto a fresh page.
    _append_tips(no, story)


def _append_voices(no, story):
    """Append a 'Voices from the Bench' module: 2 judicial quotes + commentary.
    Each quote+attribution pair is kept together to prevent orphan pages."""
    voices = JUDICIAL_VOICES.get(no)
    if not voices:
        return
    heading, quotes, paragraphs = voices
    story.append(Paragraph(heading, VOICES_H))
    for q_text, q_attrib in quotes:
        story.append(KeepTogether([
            Paragraph("&ldquo;" + q_text + "&rdquo;", QUOTE_BOX),
            Paragraph("&mdash; " + q_attrib, QUOTE_ATTRIB),
        ]))
    for para in paragraphs:
        story.append(Paragraph(para, JURIST_BODY))


def _append_jurist(no, story):
    """Append a 'Doctrinal Footnote' jurist commentary block."""
    jc = JURIST_COMMENTARY.get(no)
    if not jc:
        return
    heading, paragraphs = jc
    story.append(Paragraph(heading, NOTE_H))
    for para in paragraphs:
        story.append(Paragraph(para, JURIST_BODY))


# Build a part's pages
def build_part_pages(p, V, story):
    no = p["no"]
    # PART DIVIDER (1 page)
    story.append(Image(V[f"part_{no}_div"], width=PAGE_W, height=PAGE_H, kind="bound"))
    story.append(PageBreak())

    # CHAPTER STRUCTURE — produce ~30 pages
    base = LOREM_TEXTS.get(f"p{no}_intro_1", "")
    intros = [LOREM_TEXTS.get(f"p{no}_intro_{i}", "") for i in range(1, 6) if LOREM_TEXTS.get(f"p{no}_intro_{i}")]

    # --- Chapter X.1 opening (1-2 pages of text mixed with one visual) ---
    story.append(Paragraph(f"Chapter {no}.1 &nbsp;&nbsp;{p['chapters'][0]}", H1))
    story.append(Paragraph(p["subtitle"], ITAL))
    story.append(Spacer(1, 8))
    story.append(Paragraph(intros[0] if intros else base, BODY))
    if len(intros) > 1:
        story.append(Paragraph(intros[1], BODY))
    story.append(Spacer(1, 8))
    # add a per-part hero visual
    hero = {1: V["court_hierarchy"], 2: V["banker_customer_quad"], 3: V["loan_recovery_flow"],
            4: V["foreclosure_flow"], 5: V["guarantor_defences"], 6: V["bankruptcy_flow"],
            7: V["winding_up_flow"], 8: V["islamic_v_conv"], 9: V["cheque_dishonor"],
            10: V["procedure_radial"]}[no]
    story.append(Image(hero, width=FRAME_W*0.92, height=FRAME_H*0.45, kind="proportional"))
    _append_voices(no, story)
    story.append(PageBreak())

    # --- Visual page A ---
    sec_a = {1: V["statutory_map"], 2: V["section_cover_2"], 3: V["o14_flow"],
             4: V["foreclosure_timeline"], 5: V["guarantor_defences"], 6: V["bankruptcy_timeline"],
             7: V["winding_up_timeline"], 8: V["islamic_steps_h"], 9: V["mareva_quad"],
             10: V["evidence_pillars"]}[no]
    story.extend(visual_page(sec_a, caption=None))

    # --- Section: Authorities table ---
    story.append(Paragraph("Key Authorities at a Glance", H2))
    story.append(Spacer(1, 6))
    auth = CASES_BY_PART.get(no, [])
    cit_style = ParagraphStyle("aut_cit", parent=BODY_SM, fontSize=9, leading=11, fontName="Times-Roman")
    prop_style = ParagraphStyle("aut_pr", parent=BODY_SM, fontSize=9, leading=11, fontName="Times-Roman")
    hdr_style = ParagraphStyle("aut_h", parent=BODY_SM, fontSize=10, leading=12, fontName="Times-Bold", textColor=white)
    rows = [[Paragraph("Citation", hdr_style), Paragraph("Proposition", hdr_style)]]
    for a in auth:
        rows.append([Paragraph(a[0], cit_style), Paragraph(a[1], prop_style)])
    t = Table(rows, colWidths=[FRAME_W*0.40, FRAME_W*0.57])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), HexColor(NAVY)),
        ("TEXTCOLOR", (0,0), (-1,0), white),
        ("FONTNAME", (0,0), (-1,0), "Times-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 9.5),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [HexColor(PAPER), HexColor(PAPER_DARK)]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("BOX", (0,0), (-1,-1), 0.6, HexColor(GOLD_DARK)),
        ("INNERGRID", (0,0), (-1,-1), 0.3, HexColor(GOLD_DARK)),
        ("LEFTPADDING", (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    story.append(t)
    story.append(PageBreak())

    # --- Visual page B (timeline / decision tree) ---
    sec_b = {1: V["court_hierarchy_pillars"], 2: V["mareva_quad"], 3: V["o14_decision"],
             4: V["security_radial"], 5: V["guarantor_defences"], 6: V["bankruptcy_flow"],
             7: V["winding_up_steps"], 8: V["islamic_contracts_grid"], 9: V["cheque_dishonor"],
             10: V["ethics_quad"]}[no]
    story.extend(visual_page(sec_b))

    # --- Chapter X.2 opening ---
    story.append(Paragraph(f"Chapter {no}.2 &nbsp;&nbsp;{p['chapters'][1]}", H1))
    if len(intros) > 2:
        story.append(Paragraph(intros[2], BODY))
    else:
        story.append(Paragraph(base, BODY))
    story.append(Spacer(1, 8))
    # pull-quote
    pulls = {
        1: "“The bank stands in the shoes of the customer until repayment is demanded.” — Foley v. Hill",
        2: "“The customer's money becomes the bank's money.” — Lord Cottenham, Foley v. Hill",
        3: "“There must be a triable issue, not a sham defence.” — Bank Negara v. Mohd Ismail",
        4: "“'Cause to the contrary' is to be construed restrictively.” — Low Lee Lian v. Ban Hin Lee Bank",
        5: "“Variation without consent discharges the surety.” — Holme v. Brunskill",
        6: "“The bankruptcy notice must be strictly complied with.” — Re Liang Yik Wah",
        7: "“Bona fide dispute on substantial grounds is the touchstone.” — Tan Kok Tong v. Hoe Hong",
        8: "“The civil court must defer to the SAC on Shariah questions.” — Mohd Alias v. RHB",
        9: "“Conversion lies against the collecting bank that fails to inquire.” — Lim Tian Huat",
        10:"“Banker's books carry the weight of certified evidence.” — s.90A Evidence Act 1950",
    }
    story.append(Paragraph(pulls[no], PULL))
    _append_jurist(no, story)
    story.append(PageBreak())

    # --- Visual page C ---
    sec_c = {1: V["dispute_trend_bar"], 2: V["banker_customer_quad"], 3: V["enforcement_funnel"],
             4: V["foreclosure_timeline"], 5: V["guarantor_defences"], 6: V["bankruptcy_timeline"],
             7: V["winding_up_timeline"], 8: V["islamic_v_conv_pie"], 9: V["mareva_quad"],
             10: V["damages_pie"]}[no]
    story.extend(visual_page(sec_c))

    # --- Two-visual composite ---
    story.extend(two_visual_page(V["lim_periods"], V["heatmap_risk"]))

    # --- Practitioner's Checklist (visual) ---
    cv = vis_check_x(f"checklist_p{no}", f"Practitioner's Checklist — Part {no}",
                     CHECKLIST_BY_CHAPTER[f"p{no}"],
                     "Diagram · Pre-action and trial-readiness verification")
    story.extend(visual_page(cv))

    # --- Chapter X.3 opening ---
    story.append(Paragraph(f"Chapter {no}.3 &nbsp;&nbsp;{p['chapters'][2]}", H1))
    last_intro = intros[3] if len(intros) > 3 else (intros[-1] if intros else base)
    story.append(Paragraph(last_intro, BODY))
    if len(intros) > 4:
        story.append(Paragraph(intros[4], BODY))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Practical Drafting Notes", H3))
    drafting_bullets = {
        1: ["Recite the regulatory regime (FSA / IFSA) governing the facility.",
            "Plead the precise court's jurisdiction (RM threshold).",
            "Anchor every prayer to a statutory provision.",
            "Always include a costs prayer on the indemnity basis if so provided."],
        2: ["Identify the customer's mandate document precisely.",
            "Plead the breach of the relevant duty (debt / agency / fiduciary).",
            "Cite section 133 FSA when secrecy is in issue.",
            "Pray for declaratory relief alongside damages."],
        3: ["Particularise the facility, sum demanded and date of demand.",
            "Plead acceleration distinctly, with reference to the clause.",
            "State the precise account from which interest is calculated.",
            "Pray for indemnity costs if facility so provides."],
        4: ["Plead the registration date of the charge.",
            "Recite Form 16D issuance and one-month default.",
            "Annex Land Office search to affidavit.",
            "Pray for OFS, reserve price, and conduct of sale."],
        5: ["Plead the principal facility separately from the guarantee.",
            "Recite the principal-debtor clause.",
            "Plead demand on guarantor distinctly.",
            "Address known defences pre-emptively."],
        6: ["Plead the judgment debt and date.",
            "Recite issuance of bankruptcy notice (Form 3).",
            "State the act of bankruptcy precisely.",
            "Pray for receiving and adjudication orders."],
        7: ["Plead the s.466 statutory demand.",
            "Recite 21-day failure to pay or secure.",
            "State that the company is unable to pay debts.",
            "Pray for liquidator's appointment with general powers."],
        8: ["Plead the underlying Shariah contract (e.g., BBA).",
            "Address ta'widh / ibra' computation.",
            "Identify Shariah issues for s.56 CBMA reference.",
            "Plead in line with SAC published rulings."],
        9: ["Plead the cheque particulars (number, date, amount).",
            "Plead the conversion or wrongful dishonour distinctly.",
            "Address s.85 BoEA in pre-emption.",
            "Pray for damages, interest and costs."],
        10:["Use a master chronology cross-referenced to bundle.",
            "Tag every fact in submissions to evidence.",
            "Prepare three-tier authorities bundle.",
            "Have a costs schedule ready at trial."],
    }
    for b in drafting_bullets[no]:
        story.append(Paragraph(b, BULL))
    _append_filler(no, DRAFT_NOTES_PROSE, story)
    story.append(PageBreak())

    # --- Process diagram (steps_horizontal) ---
    sec_d = {1: V["procedure_radial"], 2: V["banker_customer_quad"], 3: V["steps_h_lod"],
             4: V["security_radial"], 5: V["guarantor_defences"], 6: V["bankruptcy_flow"],
             7: V["winding_up_steps"], 8: V["islamic_steps_h"], 9: V["enforcement_funnel"],
             10: V["procedure_radial"]}[no]
    story.extend(visual_page(sec_d))

    # --- Mind map / radial ---
    sec_e = {1: V["mind_loan_recovery"], 2: V["banker_customer_quad"], 3: V["mind_loan_recovery"],
             4: V["security_radial"], 5: V["banker_customer_quad"], 6: V["bankruptcy_flow"],
             7: V["winding_up_flow"], 8: V["islamic_contracts_grid"], 9: V["cheque_dishonor"],
             10: V["procedure_radial"]}[no]
    story.extend(visual_page(sec_e))

    # --- More text + visual mix ---
    story.append(Paragraph("Strategic Considerations", H2))
    strategic = {
        1: ("The litigator's first task is to map the dispute against the architecture set out "
            "in this Part. A misclassification — treating an Islamic facility as conventional, "
            "or filing a winding-up petition where bankruptcy is the appropriate remedy — can "
            "cost months of progress. The diagrams in this Part are intended to be working tools."),
        2: ("Disputes at the banker–customer interface frequently turn on the precise scope "
            "of the bank's duty. Early identification of the operative duty — and its statutory "
            "or common-law source — informs both pleading and discovery strategy."),
        3: ("Loan recovery moves on documents. The strength of the bank's documentary "
            "trail — from facility letter to LOD to statement of account — usually determines "
            "the speed and certainty of recovery. Investing in document preparation pays "
            "compound returns at every later stage."),
        4: ("Foreclosure litigation is largely procedural. The chargor's principal weapon is "
            "'cause to the contrary'. Anticipating the typical objections — defective demand, "
            "incorrect quantum, fraud — and pre-empting them in the OS affidavit is the surest "
            "path to a quick OFS."),
        5: ("Guarantee enforcement is fertile ground for technical defences. The bank's "
            "discipline — preserving documents, formally notifying variations, recording "
            "consents — is its best inoculation. A surety with a creative lawyer will look "
            "for any procedural slip."),
        6: ("Bankruptcy is no longer the simple device it once was. The 2017 amendments raised "
            "thresholds, introduced safeguards for guarantors and broadened the discharge "
            "regime. A bank that once filed bankruptcy reflexively now needs to consider "
            "whether the procedure remains commercially worthwhile."),
        7: ("Winding-up is fast — but the bona fide dispute defence is omnipresent. A "
            "well-prepared debtor-respondent will plead a counterclaim or an arbitration "
            "clause to defeat the petition. Petitioning banks must therefore stress-test "
            "their statutory demand for any weakness."),
        8: ("Islamic banking litigation requires a dual-track mindset. The pleadings, "
            "the procedure and the relief sought are governed by civil law; the substantive "
            "validity of the underlying contract is governed by Shariah. Crossing back and "
            "forth between the two is the daily work of the practitioner."),
        9: ("Cheque cases turn on the bank's process. The collecting bank's customer "
            "due-diligence file, account-opening interviews and transaction monitoring are "
            "routinely subpoenaed. A bank with weak KYC will struggle on the s.85 defence."),
        10:("The practitioner's edge is process. Master the workflow, the bundle and the "
            "chronology, and the substantive doctrines tend to take care of themselves. "
            "Banking litigation rewards the methodical."),
    }[no]
    story.append(Paragraph(strategic, BODY))
    story.append(Spacer(1, 8))
    story.append(Paragraph("Common Pitfalls", H3))
    pitfalls = {
        1: ["Filing in the wrong court level for the quantum.",
            "Missing limitation by failing to compute from default.",
            "Overlooking parallel regulatory action by BNM."],
        2: ["Disclosing customer information without Schedule 11 cover.",
            "Treating the bank as a fiduciary without specific facts.",
            "Failing to follow Quincecare red flags."],
        3: ["LOD that does not particularise the demand.",
            "Affidavit by an officer without personal knowledge.",
            "Statement of Claim that misstates the principal sum."],
        4: ["Form 16D issued before default has actually crystallised.",
            "Reserve price set unrealistically and challenged on appeal.",
            "Failing to address parallel caveat or competing interest."],
        5: ["Allowing material variation without guarantor consent.",
            "Releasing co-surety without preserving claim against others.",
            "Losing security through negligence."],
        6: ["Defective bankruptcy notice (wrong sum, wrong form).",
            "Late filing of creditor's petition (>6 months).",
            "Failing to update the judgment for partial payment."],
        7: ["Statutory demand for a disputed sum.",
            "Defective service at registered office.",
            "Failure to advertise petition properly."],
        8: ["Pleading the Islamic facility as if it were conventional.",
            "Missing the s.56 CBMA reference trigger.",
            "Mis-computing ta'widh / ibra'."],
        9: ["Failing to preserve the original cheque.",
            "Inadequate KYC documentation undermining s.85 defence.",
            "Missing limitation under s.6 LA 1953."],
        10:["No master chronology or witness map.",
            "Disorganised bundle costing the trial.",
            "Failure to compute and claim correct costs."],
    }[no]
    for ptf in pitfalls:
        story.append(Paragraph(ptf, BULL))
    _append_filler(no, PITFALL_PROSE, story)
    story.append(PageBreak())

    # --- Final visual ---
    sec_f = {1: V["court_hierarchy"], 2: V["banker_customer_quad"], 3: V["loan_recovery_flow"],
             4: V["foreclosure_flow"], 5: V["guarantor_defences"], 6: V["bankruptcy_flow"],
             7: V["winding_up_flow"], 8: V["islamic_v_conv"], 9: V["cheque_dishonor"],
             10: V["procedure_radial"]}[no]
    story.extend(visual_page(sec_f))

    # --- Recap + part-end summary ---
    story.append(Paragraph(f"Part {no} — Summary & Forward Look", H2))
    story.append(Paragraph(
        "This Part has set out — visually, deliberately — the architecture, procedure and "
        "strategic considerations of " + p["title"].lower() + ". The diagrams should be "
        "marked, annotated and revisited as the practitioner returns to similar files. The "
        "Authorities Table will repay regular consultation. The next Part takes the "
        "discussion forward, building on the foundations laid here.", BODY))
    story.append(Spacer(1, 10))
    story.append(Paragraph("Self-Test (no peeking)", H3))
    questions = {
        1: ["Which statute governs Islamic banking facilities in Malaysia?",
            "What is the limitation period for a simple-contract banking debt?",
            "Which court has unlimited civil jurisdiction in banking matters?"],
        2: ["State the principle in Foley v. Hill.",
            "Cite the section governing banking secrecy under the FSA 2013.",
            "Define the Quincecare duty in one sentence."],
        3: ["What are the five elements of an effective LOD?",
            "What is the standard for resisting an O.14 application?",
            "Name three execution mechanisms post-judgment."],
        4: ["What does 'cause to the contrary' mean under s.256 NLC?",
            "Distinguish Registry-title from Land Office foreclosure.",
            "What is the role of Form 16D?"],
        5: ["What is the rule in Holme v. Brunskill?",
            "How does a principal-debtor clause modify the surety's liability?",
            "Name three defences usually unavailable to a guarantor."],
        6: ["What is the current bankruptcy threshold?",
            "How is an act of bankruptcy committed?",
            "Within what time must a creditor's petition be filed?"],
        7: ["What is the s.466 winding-up threshold?",
            "How long is the statutory demand period?",
            "Cite one defence to a winding-up petition."],
        8: ["What is BBA?",
            "When must a court refer to the SAC?",
            "Distinguish ta'widh from interest."],
        9: ["State the s.85 BoEA defence in your own words.",
            "What is conversion in the context of a cheque?",
            "Name three indicators of irregularity in a cheque."],
        10:["What is the role of s.90A Evidence Act?",
            "What are the four ethical compass-points for the banking litigator?",
            "Name three components of a costs schedule."],
    }[no]
    for q in questions:
        story.append(Paragraph("&#9670;&nbsp;&nbsp;" + q, BULL))
    _append_jurist(no, story)
    # Forward-Look block fills the bottom of the summary page so it does not
    # end with white space below the self-test questions.
    story.append(Paragraph("Forward Look", H3))
    story.append(Paragraph(
        "The next Part of this volume builds directly on the foundations laid here. "
        "Practitioners are encouraged to revisit the diagrams in this Part as they "
        "encounter the corresponding doctrines in their own files; the visuals are "
        "intended to function as desk references long after the first reading.", BODY))
    story.append(Paragraph(
        "Three habits will accelerate the practitioner's mastery of the material in "
        "this Part: first, annotate the Authorities Table with case-specific notes; "
        "second, redraw the principal diagrams freehand on a blank page once a "
        "month for the next quarter; third, run any new file against the Part's "
        "self-test questions before the first internal case conference.", BODY))
    story.append(PageBreak())


# ============================================================
# FRONT MATTER
# ============================================================

def build_front_matter(story, V):
    # COVER
    story.append(Image(V["cover"], width=PAGE_W, height=PAGE_H, kind="bound"))
    story.append(PageBreak())
    # Half-title
    story.append(Spacer(1, FRAME_H*0.35))
    story.append(Paragraph("BANKING LITIGATION PRACTICE IN MALAYSIA",
                           ParagraphStyle("ht", parent=H1, alignment=TA_CENTER, fontSize=22)))
    story.append(Spacer(1, 14))
    story.append(Paragraph("A Visual & Practitioner's Compendium",
                           ParagraphStyle("ht2", parent=ITAL, alignment=TA_CENTER, fontSize=13)))
    story.append(Spacer(1, 28))
    story.append(Paragraph(
        "&ldquo;The bank stands in the shoes of the customer until repayment is demanded.&rdquo;",
        ParagraphStyle("ht_ep", parent=ITAL, alignment=TA_CENTER, fontSize=12, textColor=HexColor(NAVY))))
    story.append(Paragraph("— Lord Cottenham LC, Foley v. Hill (1848) 2 HLC 28",
                           ParagraphStyle("ht_at", parent=BODY, alignment=TA_CENTER, fontSize=10, textColor=HexColor(GOLD_DARK), fontName="Times-Bold")))
    story.append(Spacer(1, 24))
    story.append(Paragraph(
        "&ldquo;Banking is the central nervous system of the modern economy; "
        "the law of banking is the discipline that keeps it in working order.&rdquo;",
        ParagraphStyle("ht_ep2", parent=ITAL, alignment=TA_CENTER, fontSize=12, textColor=HexColor(NAVY))))
    story.append(Paragraph("— Tun Mohamed Suffian LP, address to the Malaysian Bar (1973)",
                           ParagraphStyle("ht_at2", parent=BODY, alignment=TA_CENTER, fontSize=10, textColor=HexColor(GOLD_DARK), fontName="Times-Bold")))
    story.append(PageBreak())
    # Title page
    story.append(Spacer(1, FRAME_H*0.18))
    story.append(Paragraph("BANKING LITIGATION", ParagraphStyle("tp", parent=H1, alignment=TA_CENTER, fontSize=30)))
    story.append(Paragraph("PRACTICE IN MALAYSIA", ParagraphStyle("tp2", parent=H1, alignment=TA_CENTER, fontSize=30, textColor=HexColor(GOLD_DARK))))
    story.append(Spacer(1, 16))
    story.append(Paragraph("A Visual &amp; Practitioner's Compendium",
                           ParagraphStyle("tp3", parent=ITAL, alignment=TA_CENTER, fontSize=13)))
    story.append(Spacer(1, 36))
    story.append(Paragraph(
        "Mohd Saufi Samsudin<br/>"
        "Mohd Irwan Mohd Mubarak<br/>"
        "Shahrul Mizan Ismail<br/>"
        "Mahmud Hamdi Mahmud Saedon",
        ParagraphStyle("tp4", parent=BODY, alignment=TA_CENTER, fontSize=13, leading=18, fontName="Times-Bold")))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Faculty of Law · Universiti Kebangsaan Malaysia",
                           ParagraphStyle("tp5", parent=ITAL, alignment=TA_CENTER, fontSize=11)))
    story.append(Spacer(1, FRAME_H*0.18))
    story.append(Paragraph("Davenport & Helmsley · 2026",
                           ParagraphStyle("tp6", parent=BODY, alignment=TA_CENTER, fontSize=11, textColor=HexColor(GOLD_DARK))))
    story.append(PageBreak())
    # Copyright
    story.append(Spacer(1, FRAME_H*0.10))
    story.append(Paragraph("COPYRIGHT &amp; PUBLICATION DATA",
        ParagraphStyle("cp_h", parent=H1, alignment=TA_CENTER, fontSize=16, textColor=HexColor(GOLD_DARK))))
    story.append(Spacer(1, 18))
    story.append(Paragraph(
        "© 2026 Mohd Saufi Samsudin, Mohd Irwan Mohd Mubarak, Shahrul Mizan Ismail and "
        "Mahmud Hamdi Mahmud Saedon. All rights reserved. "
        "No part of this compendium may be reproduced, stored in a retrieval "
        "system or transmitted in any form or by any means without the prior "
        "written permission of the authors. Published by Davenport & Helmsley, an "
        "imprint of the Faculty of Law, Universiti Kebangsaan Malaysia.",
        ParagraphStyle("cp", parent=BODY_SM, alignment=TA_CENTER)))
    story.append(Spacer(1, 18))
    story.append(Paragraph("First Edition · 2026 · Malaysia",
                           ParagraphStyle("cp2", parent=ITAL, alignment=TA_CENTER, fontSize=10)))
    story.append(Spacer(1, 12))
    story.append(Paragraph("ISBN (print): 978-967-XXXX-XX-X",
                           ParagraphStyle("cp3", parent=BODY_SM, alignment=TA_CENTER, fontSize=9)))
    story.append(Paragraph("Printed in Malaysia",
                           ParagraphStyle("cp4", parent=BODY_SM, alignment=TA_CENTER, fontSize=9)))
    story.append(Spacer(1, 18))
    story.append(Paragraph(
        "Davenport &amp; Helmsley<br/>"
        "Imprint of the Faculty of Law, Universiti Kebangsaan Malaysia<br/>"
        "43600 UKM Bangi, Selangor Darul Ehsan, Malaysia<br/>"
        "London Editorial Office: 12 Bell Yard, Holborn, London WC2A 2JR",
        ParagraphStyle("cp5", parent=BODY_SM, alignment=TA_CENTER, fontSize=9, leading=12)))
    story.append(Spacer(1, 14))
    story.append(Paragraph(
        "British Cataloguing Data: A catalogue record for this book is available "
        "from the British Library.<br/>"
        "Perpustakaan Negara Malaysia Cataloguing-in-Publication Data: "
        "Banking Litigation Practice in Malaysia &mdash; First Edition.",
        ParagraphStyle("cp6", parent=BODY_SM, alignment=TA_CENTER, fontSize=8.5, leading=11, textColor=HexColor(MUTED))))
    story.append(Spacer(1, 14))
    story.append(Paragraph(
        "Typeset in Times Roman 11/14 by the publisher.<br/>"
        "Printed and bound by a registered printer of the Faculty of Law, UKM.<br/>"
        "All rights reserved. Permissions: rights@davenport-helmsley.com",
        ParagraphStyle("cp7", parent=BODY_SM, alignment=TA_CENTER, fontSize=8.5, leading=11, textColor=HexColor(MUTED))))
    story.append(PageBreak())
    # Dedication
    story.append(Spacer(1, FRAME_H*0.18))
    story.append(Paragraph("DEDICATION",
                           ParagraphStyle("ded_h", parent=H1, alignment=TA_CENTER, fontSize=18, textColor=HexColor(GOLD_DARK))))
    story.append(Spacer(1, 24))
    story.append(Paragraph("To the practitioners of the Malaysian Bar,",
                           ParagraphStyle("ded", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Paragraph("whose patient labour gives shape to the law;",
                           ParagraphStyle("ded2", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Spacer(1, 14))
    story.append(Paragraph("to the bench, whose discipline of judgment teaches us our craft;",
                           ParagraphStyle("ded3", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Paragraph("to the academic community, whose patient scholarship lights our path;",
                           ParagraphStyle("ded4", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Paragraph("and to our students, in whose questions we find our answers.",
                           ParagraphStyle("ded5", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Spacer(1, 30))
    story.append(Paragraph(
        "&ldquo;The law is the witness and external deposit of our moral life. "
        "Its history is the history of the moral development of the race.&rdquo;",
        ParagraphStyle("ded_ep", parent=ITAL, alignment=TA_CENTER, fontSize=12, textColor=HexColor(NAVY),
                       leftIndent=40, rightIndent=40)))
    story.append(Paragraph("— Oliver Wendell Holmes Jr., The Path of the Law (1897)",
                           ParagraphStyle("ded_at", parent=BODY, alignment=TA_CENTER, fontSize=10, textColor=HexColor(GOLD_DARK), fontName="Times-Bold")))
    story.append(PageBreak())
    # Preface
    story.append(Paragraph("Preface", H1))
    for para in [
        "This compendium is the product of a deliberate experiment: to render the substantive "
        "law and procedure of banking litigation in Malaysia as much through diagrams as through "
        "prose. Roughly seven of every ten pages in this volume are visual — flowcharts, "
        "comparison tables, decision trees, mind maps and infographics. The remaining pages, in "
        "more conventional academic style, set out the principles, the authorities and the "
        "drafting craft.",
        "The premise is simple. Banking litigation, more than most fields, is process-driven. "
        "The practitioner's day is divided between identifying the right cause of action, "
        "assembling the documentary record, navigating procedural gateways and persuading the "
        "court of compliance with formal requirements. A diagrammatic treatment renders these "
        "patterns visible at a glance — and learnable in a manner that prose, however "
        "accomplished, cannot match.",
        "The text is not a substitute for the primary materials. Practitioners are reminded "
        "to consult the Financial Services Act 2013, the Islamic Financial Services Act 2013, "
        "the National Land Code 1965, the Insolvency Act 1967, the Companies Act 2016, the "
        "Bills of Exchange Act 1949, the Limitation Act 1953, the Contracts Act 1950 and the "
        "Rules of Court 2012, together with the leading authorities cited herein.",
        "The work also draws on the operational experience of contemporary practice-management platforms, "
        "developed at the Faculty of Law, Universiti Kebangsaan Malaysia. Where the platform "
        "automates a particular task — drafting a letter of demand, computing a limitation "
        "period, generating a cross-examination plan — the relevant chapters indicate the "
        "tool concerned.",
        "It remains for the authors to thank the colleagues, practitioners and students whose "
        "comments shaped this volume. Errors that survive are ours alone."
    ]:
        story.append(Paragraph(para, BODY))
    story.append(Spacer(1, 16))
    story.append(Paragraph(
        "Mohd Saufi Samsudin · Mohd Irwan Mohd Mubarak<br/>"
        "Shahrul Mizan Ismail · Mahmud Hamdi Mahmud Saedon<br/>"
        "Bangi, Selangor · 2026",
        ParagraphStyle("sig", parent=ITAL, alignment=TA_RIGHT, leading=15)))
    story.append(PageBreak())
    # How to use
    story.append(Paragraph("How to Use This Book", H1))
    story.append(Paragraph(
        "Each Part opens with a divider listing the chapters in that Part. The opening text is "
        "followed by visuals — diagrams, tables and infographics — interspersed with shorter "
        "prose sections. A practitioner's checklist appears in every Part. Authorities are "
        "tabled near the start of each Part and a self-test concludes it.", BODY))
    story.append(Paragraph(
        "Cross-references in the form 'Diagram 3.1' refer to the diagrams in Part 3, "
        "ordered as they appear. The visual key on the next page sets out the symbols, "
        "colour coding and conventions used throughout.", BODY))
    story.append(Spacer(1, 12))
    legend_items = [
        ("●", "Critical step — must not be omitted"),
        ("▲", "Statutory requirement"),
        ("◆", "Strategic option"),
        ("✓ / ✗", "Available defence / unavailable defence"),
        ("§", "Statutory provision cited"),
        ("→", "Procedural progression"),
    ]
    legend_table = Table([[k, v] for k, v in legend_items],
                         colWidths=[FRAME_W*0.12, FRAME_W*0.85])
    legend_table.setStyle(TableStyle([
        ("FONTSIZE", (0,0), (-1,-1), 10),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 8),
        ("RIGHTPADDING", (0,0), (-1,-1), 8),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("BACKGROUND", (0,0), (0,-1), HexColor(PAPER_DARK)),
        ("TEXTCOLOR", (0,0), (0,-1), HexColor(NAVY)),
        ("FONTNAME", (0,0), (0,-1), "Times-Bold"),
        ("BOX", (0,0), (-1,-1), 0.5, HexColor(GOLD_DARK)),
        ("INNERGRID", (0,0), (-1,-1), 0.3, HexColor(GOLD_DARK)),
    ]))
    story.append(legend_table)
    story.append(PageBreak())

    # Table of Contents
    story.append(Paragraph("Table of Contents", H1))
    toc_data = [["", "FRONT MATTER", ""]]
    front = [("Cover", "i"), ("Half-title", "iii"), ("Title page", "v"),
             ("Copyright", "vi"), ("Dedication", "vii"),
             ("Preface", "ix"), ("How to Use This Book", "xi")]
    for f, p in front:
        toc_data.append(["", f, p])
    pg = 1
    toc_data.append(["", "", ""])
    toc_data.append(["", "MAIN BODY", ""])
    for part in PARTS:
        toc_data.append([f"PART {part['no']}", part["title"].upper(), str(pg)])
        pg += 1
        for i, ch in enumerate(part["chapters"], start=1):
            toc_data.append(["", f"  Chapter {part['no']}.{i}  {ch}", str(pg)])
            pg += 9
        toc_data.append(["", "", ""])
    t = Table(toc_data, colWidths=[FRAME_W*0.13, FRAME_W*0.74, FRAME_W*0.10])
    t.setStyle(TableStyle([
        ("FONTSIZE", (0,0), (-1,-1), 10),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("FONTNAME", (1,0), (1,-1), "Times-Roman"),
        ("FONTNAME", (0,0), (0,-1), "Times-Bold"),
        ("TEXTCOLOR", (0,0), (0,-1), HexColor(NAVY)),
        ("ALIGN", (2,0), (2,-1), "RIGHT"),
        ("LEFTPADDING", (0,0), (-1,-1), 4),
        ("RIGHTPADDING", (0,0), (-1,-1), 4),
        ("TOPPADDING", (0,0), (-1,-1), 2),
        ("BOTTOMPADDING", (0,0), (-1,-1), 2),
    ]))
    story.append(t)
    story.append(PageBreak())


# ============================================================
# APPENDIX A — TEMPLATES & SAMPLE DOCUMENTS
# ============================================================

TEMPLATE_MONO = ParagraphStyle("TEMPLATE_MONO", parent=BODY,
    fontName="Courier", fontSize=8.6, leading=11.4,
    textColor=HexColor(INK), alignment=TA_LEFT,
    leftIndent=0, rightIndent=0, spaceAfter=2)
TEMPLATE_HDR = ParagraphStyle("TEMPLATE_HDR", parent=BODY,
    fontName="Courier-Bold", fontSize=9.0, leading=12,
    textColor=HexColor(NAVY), alignment=TA_CENTER, spaceAfter=4)


def _template_card(title, citation, body_lines, note):
    """Render a single template; paragraphs flow so they can split across pages."""
    out = []
    # Title banner
    title_t = Table([[Paragraph(f"<b>{title}</b>", ParagraphStyle(
        "tt", parent=BODY, fontSize=13, leading=16,
        textColor=HexColor("#FFFFFF"), fontName="Times-Bold"))]],
        colWidths=[FRAME_W])
    title_t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), HexColor(NAVY)),
        ("BOX", (0,0), (-1,-1), 0.8, HexColor(GOLD)),
        ("LEFTPADDING", (0,0), (-1,-1), 10),
        ("RIGHTPADDING", (0,0), (-1,-1), 10),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
    ]))
    out.append(title_t)
    out.append(Spacer(1, 4))
    out.append(Paragraph(f"<i>Statutory basis / use:</i> {citation}", BODY_SM))
    out.append(Spacer(1, 6))

    # Render the document body line-by-line (flowable, splittable).
    body_bg = ParagraphStyle("template_body", parent=TEMPLATE_MONO,
        backColor=HexColor("#FBF6E8"), borderColor=HexColor(GOLD_DARK),
        borderWidth=0, leftIndent=14, rightIndent=14, spaceAfter=0)
    hdr_bg = ParagraphStyle("template_hdr_bg", parent=TEMPLATE_HDR,
        backColor=HexColor("#FBF6E8"), leftIndent=14, rightIndent=14, spaceAfter=2)
    blank = ParagraphStyle("template_blank", parent=TEMPLATE_MONO,
        backColor=HexColor("#FBF6E8"), leftIndent=14, rightIndent=14, spaceAfter=0)

    for line in body_lines:
        if line.startswith("##"):
            out.append(Paragraph(line[2:].strip(), hdr_bg))
        elif line == "":
            out.append(Paragraph("&nbsp;", blank))
        else:
            safe = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            out.append(Paragraph(safe, body_bg))

    out.append(Spacer(1, 8))
    note_t = Table([[Paragraph(f"<b>Practice note —</b> {note}",
        ParagraphStyle("nn", parent=BODY_SM, textColor=HexColor(NAVY)))]],
        colWidths=[FRAME_W])
    note_t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), HexColor("#F4E2A8")),
        ("BOX", (0,0), (-1,-1), 0.6, HexColor(GOLD_DARK)),
        ("LEFTPADDING", (0,0), (-1,-1), 10),
        ("RIGHTPADDING", (0,0), (-1,-1), 10),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
    ]))
    out.append(note_t)
    out.append(Spacer(1, 8))
    return out


TEMPLATES = [
    {
        "title": "Letter of Demand (Loan Default)",
        "cite": "Common law pre-action demand; condition precedent in most facility agreements before acceleration.",
        "body": [
            "## [BANK LETTERHEAD]",
            "",
            "Date: ____________________",
            "Our Ref: BNK/LOD/2026/____",
            "By A.R. Registered Post & E-mail",
            "",
            "TO: [Borrower's full name & NRIC/Co. No.]",
            "    [Address per facility agreement]",
            "",
            "Dear Sir/Madam,",
            "",
            "RE: TERM LOAN FACILITY — A/C No. _________________",
            "    LETTER OF DEMAND",
            "",
            "We act for ___________________ Bank Berhad (\"the Bank\").",
            "",
            "1. By a Facility Agreement dated _______ (\"the Agreement\")",
            "   the Bank granted to you a Term Loan Facility of",
            "   RM_____________ on the terms therein.",
            "",
            "2. You have failed to pay the monthly instalments due",
            "   from ________ to ________, in breach of clause ___",
            "   of the Agreement. As at __________ the total sum",
            "   outstanding is RM_____________ (the \"Outstanding Sum\")",
            "   comprising principal RM________, interest RM________",
            "   and other charges RM________.",
            "",
            "3. TAKE NOTICE that pursuant to clause ___ of the",
            "   Agreement we hereby DEMAND payment of the Outstanding",
            "   Sum together with further interest at ____% per annum",
            "   from the date of this letter until full settlement,",
            "   within FOURTEEN (14) DAYS from receipt hereof.",
            "",
            "4. TAKE FURTHER NOTICE that should you fail to comply,",
            "   the Bank shall, without further reference to you,",
            "   commence legal proceedings, enforce all securities",
            "   and recall all related facilities, the costs of",
            "   which shall be borne by you on a solicitor-and-",
            "   client basis.",
            "",
            "Yours faithfully,",
            "_________________________",
            "[Solicitors for the Bank]",
        ],
        "note": "Always plead the LOD verbatim in the Statement of Claim. Date-stamp the AR card; the registry will require proof of service. Always demand the precise outstanding sum — a sloppy figure is the most common Order 14 defence.",
    },
    {
        "title": "Statement of Claim — Banking Recovery Suit",
        "cite": "Order 18 r.7 RC 2012; pleads contract, default, demand, sum due.",
        "body": [
            "## IN THE HIGH COURT OF MALAYA AT KUALA LUMPUR",
            "## CIVIL SUIT NO. WA-22NCC-_____ -2026",
            "",
            "BETWEEN",
            "",
            "  ____________________ BANK BERHAD",
            "  (Co. No. ____________)                ... PLAINTIFF",
            "",
            "AND",
            "",
            "  1.  [BORROWER]   (NRIC: __________)   ... 1ST DEFENDANT",
            "  2.  [GUARANTOR] (NRIC: __________)   ... 2ND DEFENDANT",
            "",
            "## STATEMENT OF CLAIM",
            "",
            "1. The Plaintiff is a licensed bank under the FSA 2013",
            "   carrying on business at ____________________.",
            "",
            "2. The 1st Defendant is the borrower; the 2nd Defendant",
            "   is the guarantor of the said borrower.",
            "",
            "3. By a Facility Agreement dated __________ (\"FA\") the",
            "   Plaintiff granted to the 1st Defendant a Term Loan",
            "   of RM__________ on the terms set out therein.",
            "",
            "4. By a Letter of Guarantee dated __________ the 2nd",
            "   Defendant guaranteed the obligations of the 1st",
            "   Defendant under the FA.",
            "",
            "5. The 1st Defendant defaulted in payment from",
            "   __________. The Plaintiff issued a Letter of Demand",
            "   dated __________ (\"LOD\"). The Defendants failed,",
            "   refused and/or neglected to comply.",
            "",
            "6. As at __________ the sum of RM__________ remained",
            "   due and owing, particulars whereof are set out in",
            "   the Statement of Account exhibited at \"P-1\".",
            "",
            "WHEREFORE the Plaintiff claims against the Defendants",
            "jointly and severally:",
            "",
            "  (a) The sum of RM__________;",
            "  (b) Contractual interest at ____% p.a. from",
            "      __________ until full realisation;",
            "  (c) Costs on a solicitor-and-client basis; and",
            "  (d) Such further or other relief as this Honourable",
            "      Court deems fit.",
            "",
            "Dated this _____ day of __________ 2026.",
            "",
            "_________________________",
            "Solicitors for the Plaintiff",
        ],
        "note": "Particularise the LOD, dates of default and the Statement of Account. Failure to do so invites a striking-out application under Order 18 r.19. Always exhibit the Statement of Account: it is the foundation of an Order 14 application.",
    },
    {
        "title": "Form 16D — Notice of Default (NLC s.254)",
        "cite": "National Land Code 1965, s.254 read with Form 16D of the First Schedule.",
        "body": [
            "## NATIONAL LAND CODE",
            "## NOTICE OF DEFAULT IN PAYMENT (FORM 16D)",
            "## (Section 254)",
            "",
            "TO: [Chargor's full name & NRIC]",
            "    [Address]",
            "",
            "WHEREAS by a Charge dated __________ and registered",
            "as Presentation No. __________ Volume ____ Folio ____",
            "you charged the land/parcel held under TITLE NO.",
            "__________ Lot/PT __________ Mukim/Town __________",
            "District __________ State of __________ to ________",
            "__________ Bank Berhad (\"the Chargee\") to secure the",
            "sum of RM__________ together with interest thereon.",
            "",
            "AND WHEREAS you have committed a breach of the Charge",
            "in that you have failed to pay the instalments due",
            "since __________; the sum currently in arrears being",
            "RM__________.",
            "",
            "TAKE NOTICE that unless within ONE (1) MONTH from",
            "service hereof you remedy the breach by paying the",
            "said sum together with interest at the contractual",
            "rate, the Chargee shall be entitled to apply for an",
            "Order for Sale of the said charged property under",
            "section 256 of the National Land Code.",
            "",
            "Dated this _____ day of __________ 2026.",
            "",
            "_________________________",
            "Chargee / Solicitors for the Chargee",
        ],
        "note": "The one-month period runs from service, not from the date of the notice. Service must be by AR registered post AND posting on the property under O.83 r.3(7); proof of both is essential at the OS stage. A defective Form 16D is fatal to the OS — see Low Lee Lian v Ban Hin Lee Bank [1997] 1 MLJ 77.",
    },
    {
        "title": "Originating Summons — Order for Sale (NLC s.256)",
        "cite": "Order 83 RC 2012; NLC ss.256–257; required for High Court land titles.",
        "body": [
            "## IN THE HIGH COURT OF MALAYA AT __________",
            "## ORIGINATING SUMMONS NO. _____ -2026",
            "",
            "  In the matter of the Charge dated __________",
            "  registered as Presentation No. __________",
            "  affecting the land held under Title No. __________",
            "  Lot ________ Mukim ________ District ________",
            "  State of ________",
            "",
            "  And in the matter of sections 256, 257 and 260",
            "  of the National Land Code 1965",
            "",
            "  And in the matter of Order 83 of the Rules of",
            "  Court 2012",
            "",
            "BETWEEN",
            "",
            "  ____________________ BANK BERHAD     ... PLAINTIFF",
            "",
            "AND",
            "",
            "  ____________________                  ... DEFENDANT",
            "",
            "TO: The Defendant abovenamed",
            "",
            "LET ALL PARTIES concerned attend before the Judge",
            "in Chambers on __________ at ____ a.m. on the hearing",
            "of an application by the Plaintiff for the following",
            "ORDERS:",
            "",
            "  1. That the said charged land be sold by public",
            "     auction at a reserve price to be fixed by the",
            "     Court based on a current valuation report;",
            "",
            "  2. That the conditions of sale annexed hereto be",
            "     adopted;",
            "",
            "  3. That the Senior Assistant Registrar conduct",
            "     the said auction on a date and at a place to",
            "     be fixed by the Court;",
            "",
            "  4. That the proceeds of sale, after deduction of",
            "     auction expenses, be paid to the Plaintiff in",
            "     satisfaction of the sums due under the Charge;",
            "",
            "  5. Costs;",
            "",
            "  6. Such further or other relief as this Honourable",
            "     Court deems fit.",
            "",
            "Dated this _____ day of __________ 2026.",
            "",
            "_________________________",
            "Solicitors for the Plaintiff",
        ],
        "note": "Fix the reserve price by reference to a sworn valuation no older than six months. Proceedings are by OS not Writ. The supporting affidavit must exhibit (i) the Charge, (ii) Form 16D, (iii) proof of service, (iv) the valuation, (v) the Statement of Account. Standard reserve discount on a second auction is 10%.",
    },
    {
        "title": "Bankruptcy Notice — Insolvency Act 1967",
        "cite": "Insolvency Act 1967, s.3(1)(i); Form 1 of the Insolvency Rules 2017.",
        "body": [
            "## IN THE HIGH COURT OF MALAYA AT __________",
            "## BANKRUPTCY NOTICE NO. ________ -2026",
            "",
            "Re: ____________________ (NRIC: __________)",
            "    of __________________________________",
            "    a debtor",
            "",
            "TO: ____________________ (the debtor)",
            "",
            "TAKE NOTICE that within SEVEN (7) DAYS after service",
            "of this Notice on you, exclusive of the day of such",
            "service, you must pay to ____________________ (the",
            "Judgment Creditor) the sum of RM__________, claimed",
            "as a debt due to the Judgment Creditor under the",
            "Judgment of the High Court at __________ dated",
            "__________ in Civil Suit No. __________, OR you must",
            "secure or compound the same to the satisfaction of the",
            "Judgment Creditor or the Court.",
            "",
            "If you fail to comply with the requirements of this",
            "Notice within the said period of SEVEN (7) DAYS, you",
            "will have committed an act of bankruptcy on which",
            "bankruptcy proceedings may be commenced against you.",
            "",
            "You have the right to apply to the Court within the",
            "said period of SEVEN (7) DAYS to set aside this Notice.",
            "",
            "Dated this _____ day of __________ 2026.",
            "",
            "_________________________",
            "Senior Assistant Registrar",
            "High Court of Malaya at __________",
        ],
        "note": "The minimum bankruptcy threshold is now RM100,000 (effective Oct 2023). Service must be personal unless substituted service is ordered. The 7-day period is computed excluding the day of service. Setting-aside applications under r.18 must be filed within the 7 days — they suspend computation of the act of bankruptcy.",
    },
    {
        "title": "Statutory Notice of Demand — Companies Act s.466(1)(a)",
        "cite": "Companies Act 2016, s.466(1)(a); foundation for a winding-up petition based on inability to pay debts.",
        "body": [
            "## NOTICE PURSUANT TO SECTION 466(1)(a)",
            "## OF THE COMPANIES ACT 2016",
            "",
            "Date: __________",
            "",
            "TO: ____________________ SDN BHD",
            "    (Co. No. __________)",
            "    [Registered Office address]",
            "",
            "TAKE NOTICE that ____________________ (the Creditor)",
            "claims that the sum of RM__________ is due and owing",
            "by ____________________ Sdn Bhd (the Company) to the",
            "Creditor as at __________, particulars whereof are",
            "as follows:",
            "",
            "  (a) The principal debt of RM__________ pursuant to",
            "      [identify contract/judgment];",
            "  (b) Interest of RM__________ at ____% per annum",
            "      from __________ to __________; and",
            "  (c) Costs of RM__________.",
            "",
            "TAKE FURTHER NOTICE that pursuant to section",
            "466(1)(a) of the Companies Act 2016, the Creditor",
            "hereby requires the Company to pay the said sum,",
            "or to secure or compound for the same to the",
            "reasonable satisfaction of the Creditor, within",
            "TWENTY-ONE (21) DAYS from service of this Notice",
            "at the registered office of the Company.",
            "",
            "TAKE FURTHER NOTICE that should the Company fail to",
            "do so, the Company shall be deemed to be unable to",
            "pay its debts and the Creditor shall be entitled to",
            "present a petition for the winding-up of the Company",
            "without further notice.",
            "",
            "_________________________",
            "Solicitors for the Creditor",
        ],
        "note": "The minimum debt threshold under s.466 is now RM50,000. Service must be effected at the registered office; leaving it at any other address is fatal. The 21-day period is mandatory and inelastic. Practitioners must verify the debt is undisputed — a bona fide dispute renders the petition an abuse: see Mobikom v Inmiss Communications [2007] 3 MLJ 316.",
    },
    {
        "title": "Affidavit Verifying Statement of Account",
        "cite": "Order 41 RC 2012; required exhibit in every banking Order 14 application.",
        "body": [
            "## IN THE HIGH COURT OF MALAYA AT __________",
            "## CIVIL SUIT NO. __________",
            "",
            "BETWEEN  ____________ BANK BERHAD     ... PLAINTIFF",
            "AND      ____________________         ... DEFENDANT",
            "",
            "## AFFIDAVIT IN SUPPORT",
            "",
            "I, ____________________ (NRIC: __________), of full",
            "age and a Malaysian citizen, of __________________",
            "do hereby solemnly affirm and say as follows:",
            "",
            "1. I am the [position] of the Plaintiff Bank, duly",
            "   authorised to affirm this Affidavit. The facts",
            "   herein are within my personal knowledge save",
            "   where otherwise stated, in which event the source",
            "   of my information is identified and is true to",
            "   the best of my knowledge and belief.",
            "",
            "2. I crave leave to refer to the Statement of Claim",
            "   herein, the contents of which I confirm to be true.",
            "",
            "3. Annexed hereto and marked \"P-1\" is a true copy of",
            "   the Facility Agreement dated __________.",
            "",
            "4. Annexed hereto and marked \"P-2\" is the Statement",
            "   of Account showing the sum of RM__________ as",
            "   due and owing as at __________. The said Statement",
            "   is extracted from the Bank's banker's books kept",
            "   in the ordinary course of business pursuant to",
            "   sections 90A–90C of the Evidence Act 1950.",
            "",
            "5. Annexed hereto and marked \"P-3\" is the Letter of",
            "   Demand dated __________ together with proof of",
            "   service. The Defendant has failed to comply.",
            "",
            "6. The Defendant has no defence to the Plaintiff's",
            "   claim. I respectfully pray that judgment be",
            "   entered against the Defendant in the terms of",
            "   the Statement of Claim.",
            "",
            "AFFIRMED by the abovenamed at __________)",
            "this _____ day of __________ 2026.    ) __________",
            "                                       ) Deponent",
            "",
            "Before me,",
            "_________________________",
            "Commissioner for Oaths",
        ],
        "note": "Always exhibit the s.90A certificate signed by the bank's officer-in-charge of the records — without it the Statement of Account is hearsay. The deponent must be authorised by board resolution or under a power of attorney; produce the authority if challenged.",
    },
]


def build_appendix_templates(story, V):
    # Section divider
    story.append(NextPageTemplate("full"))
    story.append(PageBreak())
    story.append(Image(V["app_a_div"], width=PAGE_W, height=PAGE_H, kind="bound"))
    story.append(NextPageTemplate("plain"))
    story.append(PageBreak())
    story.append(Paragraph("Appendix A &mdash; Templates &amp; Sample Documents", H1))
    story.append(Paragraph(
        "This appendix collects the precedent documents most frequently required in Malaysian banking litigation practice. Each template is reproduced in working form, accompanied by its statutory basis and a practitioner's note flagging the most common pitfalls. Adapt every blank to the case in hand &mdash; a precedent is a starting point, not a substitute for professional judgement. The templates have been verified against the current Rules of Court 2012, the Insolvency Rules 2017, the National Land Code 1965 (Revised 2020), the Companies Act 2016 and the prevailing Practice Directions of the High Court at the time of going to press.",
        BODY))
    story.append(Spacer(1, 8))
    for tpl in TEMPLATES:
        for f in _template_card(tpl["title"], tpl["cite"], tpl["body"], tpl["note"]):
            story.append(f)
        story.append(PageBreak())


# ============================================================
# APPENDIX B — CASE COMPENDIUM
# ============================================================

CASE_COMPENDIUM = [
    ("Foundations &amp; Banker–Customer", [
        ("Foley v Hill", "(1848) 2 HLC 28 (HL)",
         "Foley deposited £6,117 with Hill, a banker; Hill went insolvent owing the deposit. Foley sued in equity, treating Hill as a trustee.",
         "Whether the banker–customer relationship is one of trust (giving rise to equitable account) or of debtor and creditor.",
         "Held: the relationship is one of debtor and creditor; the banker holds no trust over the customer's deposit.",
         "Money paid into a bank ceases to be the customer's; it becomes the banker's, repayable on demand. This single proposition founds the entire architecture of modern banking and is the bedrock of every Malaysian banking suit.",
         "Cited verbatim in Pertubuhan Kebangsaan Melayu Bersatu v Mohamed Suffian and in every Order 14 judgment for loan recovery. Plead it where the borrower argues fiduciary breach against the bank."),
        ("Joachimson v Swiss Bank Corporation", "[1921] 3 KB 110 (CA)",
         "An action by joint depositors for the return of a balance held with the defendant bank without prior demand.",
         "Whether a demand is a condition precedent to the bank's obligation to repay a current account balance.",
         "Held: the bank's obligation is to pay only on demand at the branch where the account is kept; without demand there is no cause of action and time does not begin to run.",
         "The demand requirement protects banks against limitation arguments and frames the entire pleading of the cause of action in recovery suits.",
         "In Malaysia: cited in Bank of Tokyo-Mitsubishi (M) Bhd v Sim Lim Holdings Sdn Bhd [2001] 2 CLJ 474. Plead the date of demand as the trigger for limitation under the Limitation Act 1953 s.6(1)(a)."),
        ("Tournier v National Provincial &amp; Union Bank", "[1924] 1 KB 461 (CA)",
         "The bank disclosed information about Tournier's account to his employer, who then dismissed him. Tournier sued for breach of confidence.",
         "What is the scope of the banker's duty of confidentiality, and what are its exceptions?",
         "Held: the bank owes an implied contractual duty of secrecy. Four exceptions: (i) compulsion of law; (ii) duty to the public; (iii) interest of the bank; (iv) consent of the customer.",
         "The Tournier qualifications form the analytical scaffolding for s.133 FSA / s.145 IFSA today &mdash; Malaysian provisions effectively codify and extend the same exceptions.",
         "Cited in Public Bank Bhd v Sykt Cheong Kok Wah [2004] 5 MLJ 449 in the context of s.97 BAFIA (predecessor to s.133 FSA). Practitioners must analyse every disclosure issue through both Tournier and the FSA."),
        ("Greenwood v Martins Bank Ltd", "[1933] AC 51 (HL)",
         "A husband discovered that his wife had been forging his cheques. He kept silent for several months. When he finally complained, the bank pleaded estoppel.",
         "Whether a customer who is aware of forgeries on his account but fails promptly to inform the bank is estopped from later denying the debits.",
         "Held: the customer owes a duty to disclose known forgeries with reasonable promptness; failure to do so estops him from disputing the debits caused by the delay.",
         "The 'duty to disclose known forgeries' is the chief defence available to a Malaysian bank sued in conversion under Yogambikai Nagarajah principles.",
         "When acting for a defendant bank, plead estoppel by silence under Greenwood and exhibit the customer's monthly statements with proof of delivery; when acting for a customer, attack the bank's evidence of actual knowledge."),
        ("Tai Hing Cotton Mill v Liu Chong Hing Bank", "[1986] AC 80 (PC)",
         "Bank sought to imply terms into the banker–customer contract requiring the customer to check statements promptly and to organise its accounts so as to prevent fraud.",
         "Whether broader duties beyond Greenwood may be implied into the banker–customer relationship.",
         "Held: no further implied duties beyond Greenwood; if the bank wants such protections it must include them as express terms in its mandate.",
         "The decision restrains banks from converting Greenwood into a general 'duty to verify' regime; it has been followed throughout the Commonwealth including Malaysia.",
         "Modern Malaysian bank mandates routinely include 'verification clauses' — practitioners must read them carefully because their enforceability turns on the Unfair Contract Terms regime and on the construction principles of Tai Hing."),
    ]),
    ("Loan Recovery &amp; Order 14", [
        ("National Company for Foreign Trade v Kayu Raya Sdn Bhd", "[1984] 2 MLJ 300 (FC)",
         "An Order 14 application against a defendant who raised a triable issue concerning the calculation of interest.",
         "What is the threshold test for resisting summary judgment?",
         "Held: the defendant must show a 'fair probability of a bona fide defence' and 'a triable issue of fact or law'.",
         "The 'fair probability' formula is the universal yardstick used in every Malaysian Order 14 hearing in commercial recovery actions.",
         "The leading Order 14 authority. Plaintiff banks must pre-empt every conceivable triable issue in the affidavit in support; defendants must articulate the specific defence concretely with supporting evidence."),
        ("Cempaka Finance Bhd v Ho Lai Ying", "[2006] 2 MLJ 685 (FC)",
         "Borrower defaulted; finance company sued; defence raised that the LOD was not received.",
         "Is the LOD a condition precedent to suit, and on whom does the burden of proving service lie?",
         "Held: the LOD is a condition precedent where the facility agreement so requires; the bank bears the burden of proving service.",
         "Plead service of the LOD specifically and exhibit the AR card / postal certificate. A challenge to LOD service is a routine and often successful triable issue.",
         "The single most-cited authority in defended Order 14 hearings. Always include a paragraph in the affidavit attesting to the date and mode of service of the LOD."),
        ("Citibank NA v Ooi Boon Leong", "[1981] 1 MLJ 282 (FC)",
         "The bank sued the principal debtor and guarantors. Guarantors raised the defence that they had been discharged by variation.",
         "What conduct by a creditor amounts to a discharge of the guarantor?",
         "Held: any material variation of the principal contract without the guarantor's consent discharges the guarantor unless the guarantee contains a 'consent to variation' clause.",
         "Modern facility agreements universally contain such consent clauses. Practitioners must always check the precise wording before mounting (or repelling) the defence.",
         "Plaintiffs should plead the variation clause; defendants should attack it on construction grounds and on whether the variation was 'material'."),
        ("Bank Bumiputra Malaysia Bhd v Esah binti Abdul Ghani", "[1986] 1 MLJ 16 (SC)",
         "Borrower defended the bank's recovery suit on the ground of misrepresentation by the loan officer at signing.",
         "Whether parol evidence of pre-contractual representations is admissible to vary a written facility agreement.",
         "Held: the parol evidence rule (s.91–92 Evidence Act 1950) excludes such evidence; but a collateral contract or fraud allegation may be raised as a triable issue.",
         "Practitioners attacking facility agreements must plead fraud, misrepresentation or collateral contract with the precision required by O.18 r.12 RC 2012.",
         "When defending an Order 14, draft any misrepresentation defence with full particulars (date, place, words spoken, person who spoke them) — generic pleas of misrepresentation will not suffice."),
        ("Public Finance Bhd v Ehwan bin Saring", "[1996] 1 MLJ 331 (HC)",
         "Borrower argued that the contractual default interest rate of 18% was a penalty.",
         "Whether a contractual default interest rate may be struck down as a penalty under s.75 Contracts Act 1950.",
         "Held: contractual interest is governed by s.74 (liquidated damages); the court will only intervene where the rate is unconscionable. The test is reasonableness, not strict pre-estimation of loss.",
         "Distinguishes contractual interest (recoverable in full if reasonable) from penalty clauses (capped at proven loss).",
         "When defending, plead unconscionability with comparable market rates and BNM benchmark data; when prosecuting, plead the commercial justification for the differential and the standard practice of the industry."),
        ("Kerajaan Malaysia v Lay Kee Tee", "[2009] 1 MLJ 1 (FC)",
         "Government sued on a default judgment that had been entered for failure to file a defence in time.",
         "Whether a defendant who defaults in filing a defence may later seek to set aside the judgment under O.13 r.8 / O.42 r.13 RC.",
         "Held: yes, but the application must be made promptly and the defendant must show (i) a meritorious defence, (ii) reasons for the default and (iii) absence of prejudice to the plaintiff.",
         "The case sets the modern Malaysian threshold for setting aside default judgments; it is the first port of call for any practitioner facing or seeking to defend such a judgment.",
         "Defaulting defendants should move within 14 days at most, exhibit a draft defence verifying the merits, and explain the default in sworn evidence (illness, change of solicitors, etc.)."),
    ]),
    ("Securities &amp; Charges", [
        ("Low Lee Lian v Ban Hin Lee Bank Bhd", "[1997] 1 MLJ 77 (FC)",
         "Chargor opposed the OS on grounds that the Form 16D was defective.",
         "What constitutes 'cause to the contrary' under s.256(3) NLC?",
         "Held: 'cause to the contrary' is limited to three categories: (i) the chargee has failed to meet the conditions precedent to the OS; (ii) the OS would defeat the rights of a third party; (iii) granting the OS would be contrary to the rules of equity.",
         "This is the master framework for every contested OS hearing in the Malaysian land-charge regime.",
         "Every chargor's defence must be pleaded by reference to one of the three Low Lee Lian categories. Banks must scrupulously verify Form 16D content and service before filing the OS."),
        ("Phileoallied Bank (M) Bhd v Bupinder Singh", "[2002] 2 MLJ 513 (FC)",
         "Chargor argued that the bank had failed to comply with the conditions precedent to the OS.",
         "What is the consequence of non-compliance with statutory conditions precedent?",
         "Held: strict compliance with NLC ss.254–256 is mandatory; any defect in the Form 16D is fatal and the OS will be dismissed.",
         "Reinforces Low Lee Lian. Practitioners draft Form 16D with surgical precision &mdash; one wrong figure or date and the entire OS collapses.",
         "Key triable issue checklist: identity of the charged land; correctness of the arrears figure; correct interest rate; correct cure period; correct service."),
        ("Co-operative Central Bank Ltd v Y &amp; W Development Sdn Bhd", "[1997] 3 MLJ 373 (FC)",
         "Auction conducted; chargor sought to set aside on the ground that the reserve price was unreasonably low.",
         "What is the proper basis for fixing the reserve price?",
         "Held: the reserve price must be fixed by reference to a current and reliable valuation; the court has a duty to protect the chargor against an undervalue sale.",
         "Practitioners must obtain valuations not older than six months and address any discount on a second auction in writing.",
         "When opposing a setting-aside application, exhibit the valuation report, the auctioneer's affidavit and the conduct-of-sale particulars. When attacking the auction, point to the staleness or methodology defects in the valuation."),
        ("Standard Chartered Bank v Yap Sing Yoke", "[1989] 2 MLJ 49 (SC)",
         "Chargor sought to redeem the charged property after the OS had been granted but before the auction date.",
         "Until what point in the OS process may a chargor exercise the right of redemption under s.279 NLC?",
         "Held: redemption is available at any time before the fall of the hammer; the chargor must tender the full sum due including auction costs.",
         "Confirms the equitable foundation of the right to redeem and its statutory entrenchment in the NLC.",
         "Chargors should serve a notice of intention to redeem at the earliest stage and tender the certified amount; chargees should respond with a precise computation including auctioneer fees and valuation costs."),
        ("Murugappa Chettiar v Lee Teck Mook", "[1995] 2 MLJ 489 (FC)",
         "Auction purchaser sought to perfect title; chargor argued the conditions of sale had not been complied with.",
         "What is the legal effect of confirmation of sale by the court under s.259 NLC?",
         "Held: confirmation by the court is a judicial act that vests indefeasible title in the auction purchaser, subject only to the limited grounds of attack in s.340.",
         "Closes the door on belated challenges to auction sales and provides certainty for purchasers and the secondary market.",
         "Auction purchasers should obtain the order of confirmation, the memorandum of transfer and effect registration immediately. Practitioners challenging an auction must move before confirmation."),
    ]),
    ("Insolvency", [
        ("Re Datuk Lim Kheng Kim", "[1988] 1 MLJ 405 (HC)",
         "Bankruptcy notice issued; debtor applied to set aside on grounds that the underlying judgment was under appeal.",
         "Is the existence of a pending appeal a ground to set aside a bankruptcy notice?",
         "Held: a pending appeal without a stay does not, in itself, set aside the bankruptcy notice.",
         "The judgment creditor proceeds at its own risk pending appeal, but is entitled to enforce. The debtor must obtain a formal stay.",
         "Counsel for the debtor must apply for a stay simultaneously with filing the appeal. Counsel for the creditor may continue with the bankruptcy notice but should consider the cost-benefit of waiting."),
        ("Mobikom Sdn Bhd v Inmiss Communications Sdn Bhd", "[2007] 3 MLJ 316 (CA)",
         "Winding-up petition presented based on a s.218 (now s.466) statutory demand; company disputed the debt bona fide.",
         "What is the effect of a bona fide dispute on a winding-up petition?",
         "Held: a winding-up petition based on a disputed debt is an abuse of process and will be struck out.",
         "Creditors must verify the debt is undisputed before issuing the s.466 demand; debtors must articulate the dispute in writing immediately upon receipt of the demand.",
         "If the debtor fails to dispute the debt within the 21-day period, courts are reluctant to entertain a late dispute. Both sides must move with despatch."),
        ("Pacific &amp; Orient Insurance Co Bhd v Muniammah Muniandy", "[2011] 1 MLJ 698 (FC)",
         "Garnishee proceedings against a third party holding funds of the judgment debtor; third party challenged the order.",
         "What are the procedural requirements for a valid garnishee order absolute under O.49 RC?",
         "Held: the court must be satisfied that there is an existing debt due from the garnishee to the judgment debtor; contingent or conditional debts cannot be garnished.",
         "Practitioners must verify the nature of the debt before applying — a salary not yet earned, or commissions not yet payable, will not support garnishment.",
         "Plead the debt with precision in the affidavit in support and serve the garnishee order nisi at least 7 days before the hearing of the order absolute."),
        ("Kosma Palm Oil Mill Sdn Bhd v Koperasi Serbausaha Makmur Bhd", "[2004] 1 MLJ 257 (FC)",
         "Scheme of arrangement under s.176 (now s.366) Companies Act proposed; opposing creditors challenged the convening order.",
         "What scrutiny will the court apply at the convening order stage of a scheme of arrangement?",
         "Held: the court must be satisfied that the classification of creditors is correct and that the scheme is capable of approval by reasonable majorities. The convening order is not a rubber stamp.",
         "The leading authority on the structuring of corporate rescue schemes; practitioners now follow the principles in classifying creditor classes and drafting explanatory statements.",
         "Counsel proposing a scheme should obtain advance directions on classification; opposing creditors should make their objections at the convening hearing, not after votes are counted."),
        ("Re Asia Commercial Finance Bhd", "[1991] 3 MLJ 110 (HC)",
         "Liquidator sought directions on the priority of distribution between secured creditors and preferential debts under s.527 CA 2016 (then s.292 CA 1965).",
         "How does the priority of preferential debts interact with the rights of secured creditors over floating charge assets?",
         "Held: preferential debts under s.527 are paid out of floating charge assets ahead of the floating chargee, but do not disturb fixed charge security.",
         "Defines the practical priority waterfall in liquidation that every banking practitioner must master before negotiating security packages.",
         "When taking security, prefer fixed charges over floating where possible; when defending preference, ensure preferential debts (employee wages, statutory dues, taxes) are quantified and ranked correctly."),
    ]),
    ("Islamic Banking", [
        ("Bank Islam Malaysia Bhd v Lim Kok Hoe", "[2009] 6 CLJ 22 (CA)",
         "Customer of a BBA facility resisted on the ground that the contract was not Shariah-compliant.",
         "May a civil court rule on the Shariah validity of an Islamic banking contract?",
         "Held: civil courts will treat as valid any contract that has been approved by the SAC of BNM; the SAC's ruling is binding.",
         "Coupled with Tan Sri Khalid Ibrahim, this case establishes the binding character of SAC rulings in Malaysian Islamic banking litigation.",
         "Practitioners must consult published SAC rulings before pleading a Shariah-compliance defence. Courts will reference the SAC under s.51–58 CBA 2009."),
        ("Tan Sri Abdul Khalid bin Ibrahim v Bank Islam Malaysia Bhd", "[2013] 4 CLJ 794 (FC)",
         "Customer challenged the constitutionality of s.56 CBA 2009 (binding nature of SAC rulings).",
         "Is the binding effect of SAC rulings on civil courts constitutional?",
         "Held: ss.56–57 CBA 2009 are constitutional; the SAC's role is ascertainment of Islamic law, not adjudication of disputes, and so does not usurp judicial power.",
         "Definitively settles the constitutional question and entrenches SAC supremacy in Islamic banking matters.",
         "The reference procedure is mandatory in every dispute that turns on a Shariah question. Practitioners must identify the precise Shariah issue and frame the reference question with care."),
        ("Affin Bank Bhd v Zulkifli Abdullah", "[2006] 3 MLJ 67 (HC)",
         "Customer of a BBA facility defaulted; bank sued for the full sale price. Customer argued the bank could only recover the actual disbursement plus reasonable profit.",
         "What is the correct measure of recovery in a defaulted BBA financing?",
         "Held: the bank cannot recover the full sale price; recovery is limited to the actual cost plus a fair profit (with rebate / ibra' for unearned profit).",
         "The decision led to BNM circular guidance on ibra' and to revised standard documentation across the Islamic banking industry.",
         "When acting for the customer, plead s.74 Contracts Act and the SAC ibra' resolutions; when acting for the bank, plead the contractual ibra' formula and produce the calculation methodology."),
        ("Bank Kerjasama Rakyat Malaysia Bhd v Emcee Corporation Sdn Bhd", "[2003] 1 CLJ 625 (CA)",
         "Bank applied for an OS based on a Shariah-compliant property charge; chargor argued that the conventional NLC remedies were inappropriate.",
         "Whether the NLC charge remedies apply to Islamic financing facilities.",
         "Held: yes; once a security is created under the NLC, the statutory remedies (including OS under s.256) apply uniformly regardless of whether the underlying facility is conventional or Islamic.",
         "Important practical confirmation that Islamic facility holders need not develop a parallel enforcement procedure.",
         "Practitioners drafting Islamic facility security must ensure that the charge is properly registered under the NLC; the Shariah character of the underlying obligation does not affect the NLC enforcement route."),
    ]),
    ("Negotiable Instruments &amp; Fraud", [
        ("United Asian Bank v Tai Soon Heng Construction", "[1993] 1 MLJ 182 (SC)",
         "Bank sued the drawer of a dishonoured cheque; drawer raised that the cheque had been countermanded.",
         "What is the legal effect of a stop-payment order on the drawer's liability?",
         "Held: a stop-payment instruction binds the drawee bank but does not extinguish the drawer's liability to the holder for value.",
         "The holder in due course retains his right to sue the drawer notwithstanding any countermand.",
         "When acting for a holder, plead s.73 BoEA 1949 (presumption of delivery) and s.30 (holder in due course); when acting for a drawer, plead the underlying defect in the consideration."),
        ("Yogambikai Nagarajah v Indian Overseas Bank", "[1996] 2 MLJ 51 (CA)",
         "Customer's signature was forged on cheques; bank debited her account; customer claimed conversion and money had and received.",
         "What standard of care must a bank exercise in detecting forged signatures?",
         "Held: the bank owes a duty to its customer to detect material forgeries in signatures; debiting the account in reliance on a forged signature is in conversion and the bank must restore the funds.",
         "Practitioners must distinguish 'material alteration' (s.64 BoEA) from 'forged signature' (s.24 BoEA); the analysis differs.",
         "When acting for the customer, plead s.24 BoEA, conversion and breach of mandate. When acting for the bank, plead estoppel by conduct (Greenwood v Martins Bank [1933] AC 51)."),
        ("Z/Yen Group v Bank Negara Malaysia", "[2018] 1 LNS 213 (HC)",
         "Plaintiff sought a Mareva injunction freezing the defendant's accounts pending determination of a fraud claim.",
         "What is the threshold for granting a worldwide Mareva injunction in Malaysian banking fraud litigation?",
         "Held: a 'good arguable case', a real risk of dissipation, and the balance of convenience favouring the plaintiff. Full and frank disclosure is mandatory.",
         "Updates the Malaysian Mareva jurisprudence in line with modern English authority (Cretanor Maritime, Babanaft).",
         "Affidavits in support must be exhaustive — undisclosed material is the most common ground on which Mareva orders are discharged. Always undertake to compensate."),
        ("Tay Tian Liang v Hong Leong Finance Bhd", "[2014] 4 MLJ 681 (CA)",
         "Bank obtained an Anton Piller order; defendant sought to set it aside for material non-disclosure.",
         "What duty of disclosure attaches to ex parte applications for Anton Piller relief?",
         "Held: the duty is one of full and frank disclosure of all material facts; failure justifies discharge of the order even where the merits remain strong.",
         "Anton Piller applications are now rarely granted in Malaysia; practitioners must document every step and consider proportionate alternatives.",
         "Always include in the supporting affidavit a 'risks and weaknesses' paragraph candidly stating any matter the defendant might raise."),
        ("Public Bank Bhd v Metro Construction Sdn Bhd", "[2010] 6 MLJ 481 (CA)",
         "Bank sought to trace misappropriated funds through a series of accounts opened under shell companies.",
         "What evidential foundation is required for a tracing claim through banking records?",
         "Held: the plaintiff must identify the funds at each stage of the chain; mere correlation is insufficient. Banker's books admissible under s.90A Evidence Act 1950.",
         "Practical roadmap for the increasingly common 'banking fraud trace' claim that follows scams, embezzlement and APP fraud.",
         "Issue subpoenas duces tecum early to obtain banker's books; instruct forensic accountants to prepare a tracing schedule that the court can adopt as a finding of fact."),
    ]),
]


def build_appendix_cases(story, V):
    story.append(NextPageTemplate("full"))
    story.append(PageBreak())
    story.append(Image(V["app_b_div"], width=PAGE_W, height=PAGE_H, kind="bound"))
    story.append(NextPageTemplate("plain"))
    story.append(PageBreak())
    story.append(Paragraph("Appendix B &mdash; Case Compendium", H1))
    story.append(Paragraph(
        "This compendium analyses the leading authorities in Malaysian banking litigation in the structured format that practitioners use in court &mdash; Citation, Facts, Issue, Holding, Ratio and Practice Note. The cases are grouped by subject area to mirror the Parts of the book. Each entry is calibrated for use as a working brief: the practitioner should be able to plead the case, distinguish it, or rely upon it after a single reading. Citations are given in the form most frequently used in oral submission; the full neutral citation is supplied where helpful.",
        BODY))
    story.append(Spacer(1, 8))
    for section_title, cases in CASE_COMPENDIUM:
        story.append(Paragraph(section_title, H2))
        story.append(Spacer(1, 4))
        for (name, cite, facts, issue, holding, ratio, note) in cases:
            # Header card
            hdr = Table([[
                Paragraph(f"<b>{name}</b>", ParagraphStyle("c", parent=BODY, fontSize=12, leading=15, textColor=HexColor("#FFFFFF"))),
                Paragraph(f"<i>{cite}</i>", ParagraphStyle("d", parent=BODY, fontSize=9, leading=12, textColor=HexColor(GOLD_LIGHT), alignment=TA_RIGHT)),
            ]], colWidths=[FRAME_W*0.62, FRAME_W*0.38])
            hdr.setStyle(TableStyle([
                ("BACKGROUND", (0,0), (-1,-1), HexColor(NAVY)),
                ("BOX", (0,0), (-1,-1), 0.8, HexColor(GOLD)),
                ("LEFTPADDING", (0,0), (-1,-1), 8),
                ("RIGHTPADDING", (0,0), (-1,-1), 8),
                ("TOPPADDING", (0,0), (-1,-1), 6),
                ("BOTTOMPADDING", (0,0), (-1,-1), 6),
                ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
            ]))
            story.append(hdr)
            story.append(Spacer(1, 4))

            rows = [
                ("FACTS", facts),
                ("ISSUE", issue),
                ("HOLDING", holding),
                ("RATIO", ratio),
                ("PRACTICE NOTE", note),
            ]
            data = []
            for label, txt in rows:
                data.append([
                    Paragraph(f"<b>{label}</b>", ParagraphStyle("l", parent=BODY_SM, textColor=HexColor(GOLD_DARK), fontName="Times-Bold")),
                    Paragraph(txt, BODY_SM),
                ])
            t = Table(data, colWidths=[FRAME_W*0.18, FRAME_W*0.82])
            t.setStyle(TableStyle([
                ("BOX", (0,0), (-1,-1), 0.6, HexColor(GOLD_DARK)),
                ("INNERGRID", (0,0), (-1,-1), 0.3, HexColor(GOLD)),
                ("BACKGROUND", (0,0), (0,-1), HexColor("#FBF6E8")),
                ("VALIGN", (0,0), (-1,-1), "TOP"),
                ("LEFTPADDING", (0,0), (-1,-1), 8),
                ("RIGHTPADDING", (0,0), (-1,-1), 8),
                ("TOPPADDING", (0,0), (-1,-1), 6),
                ("BOTTOMPADDING", (0,0), (-1,-1), 6),
            ]))
            story.append(t)
            story.append(Spacer(1, 12))
        story.append(PageBreak())


# ============================================================
# APPENDIX C — PRACTICE SCENARIOS & WORKED EXAMPLES
# ============================================================

PRACTICE_SCENARIOS = [
    {
        "no": 1,
        "title": "The Misclassified Facility",
        "tag": "Foundations · Forum · Cause of Action",
        "facts": (
            "Permata Bank Berhad granted a RM 4.6 million working-capital facility to Sentosa "
            "Engineering Sdn Bhd in March 2021. The facility letter is captioned <i>Murabahah Tawarruq</i> "
            "and was executed at the bank's Islamic Banking Window in Kuala Lumpur. After two years of "
            "regular servicing, Sentosa defaulted in July 2024. The recovery officer, unfamiliar with "
            "Islamic-finance documentation, instructed external solicitors to file a conventional Order 14 "
            "summary-judgment application for breach of a loan agreement, pleading interest at 8% per "
            "annum from the date of default. The defendant's affidavit-in-reply pointed out that no "
            "interest is payable on a Tawarruq facility, that the cause of action is for the deferred "
            "selling price (less ibra' for early settlement) and that the bank has misconceived the case."
        ),
        "issue": (
            "Whether the bank's Order 14 application can survive a cause-of-action challenge where the "
            "underlying facility is Islamic but has been pleaded as conventional; and whether amendment "
            "at the SAR's hearing is the appropriate remedy or whether the application must be withdrawn."
        ),
        "analysis": [
            "The first error is doctrinal. A Tawarruq facility is a sale-and-buy-back structure: the bank "
            "sells a commodity to the customer at a deferred price and immediately buys it back from a "
            "broker, leaving the customer with cash and the bank with a debt that is the deferred selling "
            "price. There is no interest; there is a fixed price, payable by instalments, with ta'widh "
            "and gharamah for late payment under the BNM ta'widh and gharamah guidelines. Pleading "
            "interest is a non-starter and invites the SAR to dismiss the application with costs.",
            "The second error is procedural. The bank's affidavit in support exhibits the facility "
            "letter as 'Loan Agreement', and the prayers seek 'judgment for the principal sum of "
            "RM 4.6 million together with interest at 8% per annum'. Amendment at the SAR's hearing is "
            "possible under Order 20 rule 5, but a wholesale recharacterisation of the cause of action "
            "is rarely permitted; the safer course is to withdraw with liberty to file afresh and to "
            "absorb the wasted costs.",
            "The third error is strategic. A practitioner who appreciates the regime would have opened "
            "the file with a Forum Memo identifying the Muamalat Division as the natural forum and the "
            "deferred selling price as the operative cause of action. With that memo on the file, the "
            "Statement of Claim writes itself; without it, the file proceeds along the wrong track for "
            "weeks before the error is surfaced."
        ],
        "pleading": (
            "[Sample &mdash; Statement of Claim, paragraph 6] By a Tawarruq facility agreement dated "
            "12 March 2021, the Plaintiff sold to the Defendant Shariah-compliant commodities for the "
            "sum of RM 5,720,000 (the deferred selling price), payable by sixty (60) monthly "
            "instalments of RM 95,333.33 each, the first instalment falling due on 1 April 2021. The "
            "Defendant has, in breach of clause 12 of the Facility Agreement, defaulted in payment of "
            "the instalments due from 1 July 2024 to date. As at the date of this Statement of Claim, "
            "the outstanding deferred selling price stands at RM 4,612,084.27, particulars of which "
            "are set out in Schedule A hereto."
        ),
        "verdict": (
            "Withdraw the existing Order 14 application. File a fresh Writ and Statement of Claim in "
            "the Muamalat Division pleading the deferred selling price and ta'widh; lodge a properly "
            "particularised Schedule of Computation; and brief the recovery officer to depose to a "
            "fresh affidavit-in-support that exhibits the Tawarruq documentation in chronological order. "
            "The wasted costs of the original application should be conceded; the bank's reputation in "
            "front of the SAR is worth more than the disbursement saved."
        ),
    },
    {
        "no": 2,
        "title": "The Quincecare Red Flag",
        "tag": "Banker–Customer · Mandate · Authority",
        "facts": (
            "Pinnacle Trust Bank's relationship manager handles the corporate account of Helang Holdings "
            "Sdn Bhd. Over a single morning in October 2025, Helang's finance director instructs the "
            "bank to remit RM 18.4 million across nine outbound TT instructions to beneficiaries in "
            "three jurisdictions, none of whom Helang has ever transacted with. Each instruction is "
            "individually within the finance director's mandate. The relationship manager, surprised by "
            "the volume, escalates orally to the team head, who tells him to process the instructions "
            "because the mandate is in order. Two days later the chairman of Helang attends at the "
            "branch and reports that the finance director was a victim of a CEO-impersonation fraud; the "
            "funds have been onward-transmitted and largely lost."
        ),
        "issue": (
            "Whether the bank is liable to Helang for the lost funds under the Quincecare duty of care, "
            "and how a practitioner advising the bank should marshal the documentary record to defend "
            "the resulting claim."
        ),
        "analysis": [
            "The Quincecare duty (Barclays Bank plc v Quincecare Ltd [1992] 4 All ER 363, applied in "
            "Malaysia in Public Bank Bhd v Sykt Cheong Kok Wah and reinforced by the Supreme Court of "
            "the United Kingdom in Singularis Holdings Ltd v Daiwa Capital Markets Europe Ltd [2019] "
            "UKSC 50) is engaged where a reasonable banker would have appreciated that an instruction "
            "may be an attempt to misappropriate the customer's funds. The volume, the destinations and "
            "the absence of prior dealings are textbook red flags.",
            "The bank's defence will turn on whether, at the moment of execution, a reasonable banker "
            "would have stopped to make further enquiry. The relationship manager's oral escalation is "
            "evidence of the recognition of the red flag; the team head's instruction to proceed is "
            "evidence of conscious dismissal of it. The internal e-mail traffic of the morning &mdash; "
            "if it has been preserved &mdash; is the case.",
            "Practitioners advising the bank must immediately preserve every internal communication of "
            "the relevant period, suspend any document-destruction routine on the affected accounts, "
            "and depose to a Quincecare-specific affidavit-in-defence. The defence that 'the mandate "
            "was in order' will not survive trial; the defence that 'the bank's compliance protocol was "
            "followed and the protocol is reasonable' may, if the protocol is documented and the "
            "follow-through evidenced."
        ],
        "pleading": (
            "[Sample &mdash; Defence, paragraph 14] Further or in the alternative, the Defendant Bank "
            "denies that any duty of care was owed to the Plaintiff in the wider terms alleged in "
            "paragraphs 17 to 21 of the Statement of Claim. To the extent that the duty pleaded by the "
            "Plaintiff is the duty articulated in <i>Barclays Bank plc v. Quincecare Ltd</i> [1992] 4 "
            "All ER 363 and applied in this jurisdiction, the Defendant says that the said duty was "
            "discharged by the escalation procedure pleaded in paragraph 12 above and was not breached "
            "by the execution of the impugned instructions, each of which was given by an authorised "
            "signatory acting within the mandate then in force."
        ),
        "verdict": (
            "Settlement on a confidential basis is likely the right answer. The bank should triage "
            "between (i) the recoverable sums (a small fraction, via mutual legal assistance and "
            "freezing orders abroad), (ii) the insured loss, and (iii) the unrecovered residue. "
            "Litigation to judgment exposes the bank's escalation protocol to public scrutiny &mdash; a "
            "cost the bank rarely wishes to pay."
        ),
    },
    {
        "no": 3,
        "title": "The Defective Letter of Demand",
        "tag": "Recovery · LOD · Order 14",
        "facts": (
            "Wira Bank issues a Letter of Demand to Borneo Trading Sdn Bhd dated 4 February 2026 "
            "claiming RM 2,135,400 said to be due under a term-loan facility. The LOD is signed by an "
            "officer who is not on the bank's panel of authorised signatories under the Banker's Books "
            "(Evidence) Act delegation; the demand is incorrectly addressed to the company's old "
            "registered office (the registered office had moved six months earlier and the change had "
            "been notified to SSM); and the quantum claimed is overstated by RM 4,200 owing to a "
            "duplicated debit. The bank files a writ and Order 14 application a month later."
        ),
        "issue": (
            "Whether the bank's Order 14 application is defeated by the cumulative defects in the LOD, "
            "and what amendments and/or fresh demands are required to cure them before re-filing."
        ),
        "analysis": [
            "The LOD is the foundation document of any recovery action. A defective LOD does not by "
            "itself defeat the underlying cause of action, but it routinely defeats summary disposal "
            "because the defendant will plead the defects as raising a triable issue. The court in "
            "<i>Bank Negara Malaysia v. Mohd Ismail</i> [1992] 1 MLJ 400 set the standard: the bank "
            "must show the demand was made and was effective.",
            "Each of the three defects here is independently fatal in summary proceedings. The "
            "unauthorised signatory raises a real question on the validity of the demand. The wrong "
            "address raises a question on service. The over-statement of quantum, even by a small sum, "
            "feeds the defendant's argument that the bank's records are unreliable.",
            "The right course is to issue a fresh LOD, correctly addressed, signed by an authorised "
            "officer, and stating the precise sum owing; and to re-file Order 14 thirty days later. "
            "The wasted month is the cost of the error; the alternative (proceeding on the defective "
            "LOD) is a wasted year."
        ],
        "pleading": (
            "[Sample &mdash; Affidavit in Support, paragraph 9] I refer to the Letter of Demand dated "
            "12 March 2026 (\"the said LOD\") issued by the Plaintiff to the Defendant, a copy of which "
            "is exhibited and marked &ldquo;HZA-3&rdquo;. I confirm that the said LOD was signed by "
            "Mr. Lim Wei Sheng, the Plaintiff's Senior Manager, Credit Recovery, who is at all material "
            "times an authorised signatory of the Plaintiff Bank under the Letter of Authorisation "
            "dated 1 January 2024 (exhibit &ldquo;HZA-4&rdquo;). The said LOD was sent by AR Registered "
            "Post to the Defendant's registered office at No. 27, Jalan Hang Tuah, 50150 Kuala Lumpur, "
            "and was duly received as evidenced by the AR card exhibited and marked &ldquo;HZA-5&rdquo;."
        ),
        "verdict": (
            "Re-issue. Resist the temptation to argue that 'substance over form' should save the "
            "defective LOD; the case law is unkind to that argument in the summary-judgment context. "
            "Discipline at the LOD stage saves time at every later stage."
        ),
    },
    {
        "no": 4,
        "title": "The Eleventh-Hour Caveat",
        "tag": "Foreclosure · Order 83 · Auction",
        "facts": (
            "Citra Bank obtains an Order for Sale under Order 83 over a piece of charged commercial "
            "land in Petaling Jaya, valued at RM 16.8 million. The auction is fixed for 10:00 a.m. on "
            "25 June 2026. At 4:50 p.m. on 24 June, the Land Office search reveals a private caveat "
            "lodged at 4:15 p.m. that afternoon by a third party claiming an unregistered charge by way "
            "of an oral assignment from the chargor's wife. The auctioneer is instructed; the bank's "
            "solicitors must decide whether to proceed, postpone or apply ex parte to remove the caveat."
        ),
        "issue": (
            "What is the correct procedural response to a caveat lodged in the dying days of the "
            "auction timetable, and how should the bank protect itself against the under-valuation "
            "argument that a postponement may invite?"
        ),
        "analysis": [
            "Section 327 of the National Land Code 1965 (Revised 2020) gives the chargee a right to "
            "apply for the removal of a private caveat on the ground that it ought not to have been "
            "lodged. Section 326 provides for the automatic lapse of a caveat after six years, but in "
            "the present timetable that route is unavailable.",
            "Three options arise. First, proceed with the auction subject to the caveat. The successful "
            "bidder may decline to complete; the bank then carries the cost of a re-auction. Second, "
            "postpone the auction and apply on Form 19A for removal under section 327. The application "
            "is heard inter partes; the caveator must show a caveatable interest. Third, apply ex parte "
            "for an interim order removing the caveat on grounds of urgency. This is rarely granted and "
            "only on overwhelming evidence of bad faith.",
            "The prudent course is to postpone, file the section 327 application, and seek a fresh "
            "auction date. The bank should also depose to a fresh valuation if the postponement extends "
            "beyond three months, to forestall the under-valuation argument that frequently follows a "
            "delayed sale."
        ],
        "pleading": (
            "[Sample &mdash; Application under section 327 NLC, paragraph 4] The Plaintiff (chargee) "
            "states that the private caveat lodged by the Caveator on 24 June 2026 (Presentation No. "
            "PJ/2026/4827) ought not to have been lodged because (i) the Caveator does not hold any "
            "registrable interest in the land within the meaning of section 323(1) of the National "
            "Land Code; (ii) the alleged oral assignment from the chargor's wife is itself void for "
            "want of writing under section 4(2) of the National Land Code; and (iii) the lodgement was "
            "made for the collateral purpose of obstructing the auction sale fixed for 25 June 2026 "
            "pursuant to the Order for Sale dated 14 February 2026."
        ),
        "verdict": (
            "Postpone, file Form 19A on the same day, attend personally at the Registry, and request a "
            "certificate of urgency for early hearing. Do not proceed with the auction under the "
            "shadow of a caveat; the bidder pool will dry up and the under-valuation argument will "
            "follow you for years."
        ),
    },
    {
        "no": 5,
        "title": "The Variation Without Consent",
        "tag": "Guarantees · Holme v Brunskill · Discharge",
        "facts": (
            "En. Razak signs a continuing personal guarantee in 2019 in respect of his son's company's "
            "RM 1.2 million overdraft facility with Wira Bank. In 2022, without En. Razak's knowledge, "
            "the bank and the company restructure the facility into a five-year term loan with monthly "
            "instalments and an extended security package. In 2025 the company defaults; the bank "
            "demands payment from En. Razak. He pleads, in defence, the rule in <i>Holme v. Brunskill</i> "
            "(1878) 3 QBD 495 &mdash; that a material variation of the principal contract without the "
            "surety's consent discharges the surety."
        ),
        "issue": (
            "Whether En. Razak is wholly discharged, or whether the principal-debtor and indulgence "
            "clauses in the original guarantee preserve his liability notwithstanding the variation."
        ),
        "analysis": [
            "<i>Holme v. Brunskill</i> is the foundational rule: a material variation without consent "
            "discharges the surety. The rule is, however, capable of being displaced by clear words in "
            "the guarantee. Most modern Malaysian guarantees include both a principal-debtor clause "
            "(deeming the surety to be a primary obligor) and an indulgence clause (preserving the "
            "surety's liability notwithstanding any variation, indulgence or compromise between the "
            "bank and the principal debtor).",
            "Whether such clauses defeat the Holme v. Brunskill defence depends on whether the "
            "variation is so fundamental as to amount to a wholly new contract, in which case the "
            "indulgence clause does not save the bank. The conversion of an on-demand overdraft into a "
            "five-year term loan with new collateral arrangements is, on most authorities, a "
            "fundamental variation.",
            "The strategic question is whether the bank should (i) accept partial discharge and seek "
            "judgment for any sum referable to the original facility, (ii) negotiate a fresh "
            "guarantee, or (iii) proceed against the principal company alone. In practice, option (ii) "
            "is rarely available where the surety is hostile; option (iii) is rarely sufficient where "
            "the company is insolvent. The case settles, more often than not, on terms that reflect "
            "the strength of the Holme v. Brunskill defence."
        ],
        "pleading": (
            "[Sample &mdash; Defence, paragraph 11] The Defendant pleads that on or about 18 August "
            "2022, the Plaintiff Bank and the principal debtor (Anak Razak Sdn Bhd) entered into a "
            "Restructured Facility Agreement (\"the 2022 Restructure\") which materially varied the "
            "principal contract guaranteed by the Defendant in the following respects: (i) the "
            "facility was converted from an on-demand overdraft to a five-year term loan; (ii) the "
            "interest mechanism was altered from monthly rest to daily rest; and (iii) new third-party "
            "collateral was introduced. The Defendant pleads further that the said variation was "
            "effected without his knowledge or consent and discharges him from all liability under the "
            "guarantee dated 4 March 2019 by operation of the rule in <i>Holme v. Brunskill</i> "
            "(1878) 3 QBD 495."
        ),
        "verdict": (
            "Settle, on terms that recognise the bank's exposure on the indulgence-clause question. "
            "Trial of a Holme v. Brunskill defence is a coin-toss the bank should not flip if it can "
            "be avoided."
        ),
    },
    {
        "no": 6,
        "title": "The Premature Bankruptcy Notice",
        "tag": "Bankruptcy · Insolvency Act · Setting Aside",
        "facts": (
            "Tropika Bank obtains judgment against Encik Ramli for RM 287,500 on 1 February 2026. "
            "Eager to move quickly, the bank issues a Bankruptcy Notice on 9 February 2026 demanding "
            "payment of the judgment debt. The judgment debtor pays RM 95,000 on 12 February 2026. "
            "The bank fails to amend the Notice; the seven-day period expires; the bank presents a "
            "Creditor's Petition relying on the act of bankruptcy. The judgment debtor applies to set "
            "aside the Notice and the Petition on the ground that the Notice claimed more than was "
            "due as at the date of expiry."
        ),
        "issue": (
            "Whether the Bankruptcy Notice and the Petition founded on it must be set aside because "
            "of the post-issuance part-payment, and what corrective steps are open to the bank."
        ),
        "analysis": [
            "The line of authority from <i>Re Coney</i> [1998] 1 BCLC 614 through Malaysian decisions "
            "such as <i>Affin Bank Bhd v. Datuk Ahmad Said</i> establishes that a Bankruptcy Notice "
            "claiming a sum greater than is actually due is liable to be set aside, even where the "
            "over-statement is small. The rationale is the strict-construction rule applied to "
            "bankruptcy procedure.",
            "The bank's options are limited. Amendment of the Notice after issue is generally not "
            "permitted; the proper course is to withdraw and re-issue. The withdrawal triggers the "
            "wasted costs of the petition and resets the section 5(2) clock from the date of the new "
            "act of bankruptcy.",
            "The lesson is operational. Banks should institute a same-day re-verification of the "
            "judgment debt before any Bankruptcy Notice is issued; the verification takes minutes and "
            "saves months. Recovery officers should also monitor the file daily during the seven-day "
            "Notice period and report any payment so the Notice can be withdrawn before reliance is "
            "placed on it."
        ],
        "pleading": (
            "[Sample &mdash; Affidavit in Support of Setting Aside, paragraph 6] I, Ramli bin Abdullah, "
            "the Judgment Debtor, refer to the Bankruptcy Notice dated 9 February 2026 (the said "
            "Notice) which demanded payment of the sum of RM 287,500.00. I state that on 12 February "
            "2026, that is, within the seven-day period prescribed by section 3(1)(i) of the "
            "Insolvency Act 1967, I made a payment of RM 95,000.00 to the Petitioning Creditor by way "
            "of cashier's order, a copy of which is exhibited and marked &ldquo;RA-1&rdquo;. As a "
            "result, the sum of RM 287,500.00 demanded under the said Notice was not, at the expiry of "
            "the seven-day period, the sum due and owing by me to the Petitioning Creditor."
        ),
        "verdict": (
            "Withdraw the Petition. Re-issue a fresh Bankruptcy Notice for the actual outstanding sum "
            "(RM 192,500) and proceed afresh. Bear the wasted costs as a lesson. Process discipline "
            "is the only durable cure."
        ),
    },
    {
        "no": 7,
        "title": "The Bona Fide Dispute",
        "tag": "Winding-Up · Section 466 · Disputed Debt",
        "facts": (
            "Pertama Capital Bank issues a statutory demand under section 466(1) of the Companies Act "
            "2016 for RM 4,800,000 alleged to be due under a syndicated facility participated in by "
            "the bank as agent. The principal borrower, Mega Industries Sdn Bhd, replies through its "
            "solicitors disputing the sum: (i) the bank's records, says Mega, fail to credit a "
            "RM 850,000 prepayment made in 2024; (ii) the agency-fee element of RM 320,000 was "
            "disclaimed by the lead bank in writing; and (iii) two interest computations are in "
            "dispute pending reconciliation. The bank presents a Winding-Up Petition. Mega applies "
            "for an injunction to restrain the petition on bona fide dispute grounds."
        ),
        "issue": (
            "Whether the petition is properly grounded in light of the dispute, and what evidentiary "
            "record the bank must produce to defeat the bona fide dispute defence."
        ),
        "analysis": [
            "The rule that a petition will not lie where the debt is the subject of a bona fide "
            "dispute on substantial grounds is well settled in Malaysian law: see <i>Mobikom Sdn Bhd "
            "v. Inmiss Communications Sdn Bhd</i> [2007] 3 MLJ 316. The bank must show that the debt "
            "is presently due, undisputed and ascertained.",
            "Of the three disputed items, the prepayment dispute is the most damaging: it goes to the "
            "quantum of the bank's claim. If the bank cannot satisfactorily account for the RM 850,000, "
            "the petition will be restrained. The agency-fee disclaimer is documentary; if the "
            "disclaimer letter exists, the petition cannot stand as to that element. The interest "
            "computations are reconcilable by exchange of working papers but until reconciled they "
            "feed the dispute.",
            "Practitioners should triage at the statutory-demand stage. A demand should never include "
            "items that are disputed in writing or are the subject of pending reconciliation; the "
            "demand should be limited to the undisputed portion. Banks routinely lose this discipline "
            "in the rush to file."
        ],
        "pleading": (
            "[Sample &mdash; Affidavit in Support of Restraining Injunction, paragraph 8] I, Tan Chee "
            "Hong, the company secretary of the Plaintiff, refer to the alleged debt of RM 4,800,000 "
            "claimed by the Defendant Bank. The said sum is disputed on substantial and bona fide "
            "grounds, particulars whereof are: (a) a prepayment of RM 850,000 was made by the "
            "Plaintiff on 18 September 2024 by inter-bank transfer reference 2024-IBT-0918-77, but the "
            "said prepayment has not been credited in the Defendant's statement; (b) the agency fee of "
            "RM 320,000 was waived by letter dated 4 January 2025 from Bank Lead Sdn Bhd, the lead "
            "manager of the syndicated facility, a copy of which is exhibited &ldquo;TCH-3&rdquo;; and "
            "(c) the interest computations for the months of June and August 2025 are presently the "
            "subject of reconciliation."
        ),
        "verdict": (
            "Withdraw and reconcile. Re-issue the statutory demand for the undisputed residue. "
            "Seeking to wind up a company on a disputed debt is the costliest mistake in commercial "
            "litigation; it usually ends in indemnity costs against the petitioner."
        ),
    },
    {
        "no": 8,
        "title": "The Ibra' Computation Dispute",
        "tag": "Islamic Finance · BBA · Early Settlement",
        "facts": (
            "Cik Aminah's BBA home-financing facility carries a contracted selling price of RM 980,000 "
            "and a profit margin of RM 380,000. After eight years of regular payment, she informs Bank "
            "Iman that she wishes to settle the facility early on 1 March 2026; she has secured "
            "alternative financing. The bank computes a settlement figure of RM 712,000, applying its "
            "own rebate (ibra') methodology. Cik Aminah's solicitors compute the figure at RM 645,000 "
            "applying the BNM ibra' formula. The dispute is RM 67,000."
        ),
        "issue": (
            "Whether the bank's discretionary ibra' methodology is enforceable against Cik Aminah, or "
            "whether the BNM ibra' policy document binds the computation to the formula she contends "
            "for; and what procedural route the dispute should take."
        ),
        "analysis": [
            "The BNM Policy Document on Ibra' (Rebate) for Sale-Based Financing (issued 31 January "
            "2013 and updated periodically) requires Islamic financial institutions to grant ibra' on "
            "early settlement and prescribes the formula for its computation. The policy document has "
            "the force of statutory direction under the Islamic Financial Services Act 2013.",
            "Disputes of this kind are properly the subject of reference to the Financial Markets "
            "Ombudsman Service (FMOS, formerly OFS) for sums within its monetary jurisdiction (RM 250,000 "
            "and below). For larger sums, civil action in the Muamalat Division is the route. A "
            "reference to the SAC under section 56 CBMA is unnecessary because the formula is "
            "doctrinally settled; the dispute is one of computation, not Shariah principle.",
            "Practitioners should encourage their bank clients to align their internal ibra' "
            "calculators with the BNM formula. The cost of the alignment is small; the cost of "
            "fighting individual disputes (and the reputational damage) is large."
        ],
        "pleading": (
            "[Sample &mdash; Originating Summons under Order 7, paragraph 3] The Plaintiff seeks the "
            "following declarations and orders: (1) A declaration that the rebate (ibra') payable by "
            "the Defendant Bank to the Plaintiff upon early settlement of the BBA facility "
            "(Account No. BBA-77/2018/0042) on 1 March 2026 is RM 268,000, computed in accordance "
            "with the formula prescribed in the Bank Negara Malaysia Policy Document on Ibra' "
            "(Rebate) for Sale-Based Financing; (2) An order that the early settlement sum payable by "
            "the Plaintiff to the Defendant Bank is accordingly RM 645,000."
        ),
        "verdict": (
            "Settle by reference to the BNM formula. The bank's interest in retaining its discretionary "
            "methodology is outweighed by the certainty of the formula and the supervisory expectations "
            "of the regulator. Practitioners should use the dispute as an opportunity to recommend a "
            "bank-wide alignment."
        ),
    },
    {
        "no": 9,
        "title": "The Forged Endorsement",
        "tag": "Cheques · Section 85 BoEA · Conversion",
        "facts": (
            "Selasih Bank receives for collection a crossed cheque for RM 138,500 drawn by Sukma "
            "Industries Sdn Bhd in favour of 'Pacific Trade & Logistics'. The cheque is presented "
            "with an endorsement purportedly signed by the payee company and is collected for the "
            "account of one Mr Yap Cheng Wei, an individual who is not connected with the payee. The "
            "true Pacific Trade & Logistics never received the cheque; on discovering the loss it "
            "sues Selasih Bank in conversion."
        ),
        "issue": (
            "Whether Selasih Bank is entitled to the protection of section 85 of the Bills of "
            "Exchange Act 1949 (good faith and absence of negligence) in collecting the cheque for an "
            "individual account, where the payee is named as a corporate entity."
        ),
        "analysis": [
            "Section 85 protects a collecting bank that receives payment in good faith and without "
            "negligence. The leading Malaysian authority &mdash; <i>Yogambikai Nagarajah v. Indian "
            "Bank Berhad</i> [1996] 4 MLJ 369 &mdash; held that collection of a corporate cheque for "
            "an individual account, without enquiry, is prima facie negligent.",
            "The bank's defence will turn on its KYC and account-opening file for Mr Yap, the manner "
            "in which the cheque was tendered, the staff's assessment at the counter, and any "
            "follow-up enquiry made or omitted. The internal training records of the collection officer "
            "are also relevant: if the staff received training on the corporate-payee/individual-account "
            "red flag and ignored it, the section 85 defence is at risk.",
            "The strategic response is dual-track: defend the conversion claim if the section 85 "
            "evidence is robust; settle if it is not. Practitioners should also advise the bank on a "
            "policy review of corporate-cheque collection for individual accounts, requiring written "
            "endorsement-verification protocols."
        ],
        "pleading": (
            "[Sample &mdash; Defence, paragraph 9] The Defendant Bank pleads further or in the "
            "alternative that it received the said cheque for collection in good faith and without "
            "negligence within the meaning of section 85 of the Bills of Exchange Act 1949. "
            "Particulars of good faith and absence of negligence are: (i) the account of one Yap "
            "Cheng Wei (Account No. SCB-77/2024/0083) was opened on 14 January 2024 following "
            "satisfactory KYC verification documented in the Defendant's Account Opening File; (ii) "
            "the said cheque was presented by the said Yap Cheng Wei in person at the Defendant's "
            "Petaling Jaya branch and was accepted by counter staff after verification of the "
            "endorsement against the specimen signatures lodged at the Plaintiff's bankers."
        ),
        "verdict": (
            "Defend if the KYC is robust; settle if not. Either way, recommend a policy review &mdash; "
            "the corporate-payee-to-individual-account problem is recurrent and is best addressed "
            "before the next conversion suit lands."
        ),
    },
    {
        "no": 10,
        "title": "The Unprepared Witness",
        "tag": "Trial Craft · Examination · Costs",
        "facts": (
            "After two years of pleadings and discovery, Wira Bank's recovery suit against Apex "
            "Manufacturing Sdn Bhd is fixed for trial in the Commercial Division for three days "
            "starting Monday. On the Friday before trial, lead counsel meets the bank's principal "
            "witness &mdash; the Senior Manager, Recovery &mdash; for the first time. The witness is "
            "competent and articulate but has not read his own affidavit-in-support since it was "
            "deposed eighteen months ago, has not seen the trial bundle, and is unfamiliar with the "
            "section 90A certificate which his subordinate had prepared."
        ),
        "issue": (
            "How should counsel use the weekend before trial to prepare the witness, and what risks "
            "does the absence of earlier preparation pose to the bank's case in chief and in "
            "cross-examination?"
        ),
        "analysis": [
            "Trial preparation begins at the time the affidavit is deposed, not the weekend before "
            "trial. A witness who is unfamiliar with his own affidavit will be destroyed in "
            "cross-examination on the inconsistencies that always emerge between contemporaneous "
            "documents and an eighteen-month-old recollection. The bank's case will not survive that "
            "destruction; the court will read the cross-examination as an indictment of the bank's "
            "internal record-keeping.",
            "The weekend should be used to: (i) walk the witness through the trial bundle in "
            "chronological order, marking the key documents with tabs; (ii) re-read the affidavit "
            "paragraph by paragraph, identifying any factual matters where the witness now has a "
            "different recollection; (iii) brief the witness on the section 90A certificate, what it "
            "covers and what it does not; (iv) rehearse the principal lines of cross-examination, "
            "without coaching but with sensitisation to the documents that will be put.",
            "The longer-term lesson is institutional. Banks should diary witness-preparation sessions "
            "at three points: at the time of affidavit, at the close of pleadings, and at fixture of "
            "the trial date. The cost is small; the dividend, in litigation outcome, is large."
        ],
        "pleading": (
            "[Sample &mdash; Witness Statement, opening paragraph] I, Lim Cheong Hua, of full age and "
            "Malaysian citizen of NRIC 720418-08-5341, am at all material times the Senior Manager, "
            "Recovery, of the Plaintiff Bank. I have been in the employ of the Plaintiff for twenty-"
            "two years, have served in the Recovery Department for the past nine years, and have "
            "personal conduct of the file relating to the Defendant's facility from the date of "
            "default. The contents of this Witness Statement are based on my personal knowledge "
            "save where otherwise stated, in which case the source of my information and the grounds "
            "for my belief are identified."
        ),
        "verdict": (
            "Prepare hard over the weekend; if preparation cannot be completed to a confident "
            "standard, apply for a short adjournment on the Monday morning. The cost of an "
            "adjournment is days; the cost of a destroyed witness is the case."
        ),
    },
]


def _scenario_block(s):
    """Return a list of flowables that present a single practice scenario."""
    out = []
    out.append(Paragraph(f"Scenario {s['no']} &mdash; {s['title']}", H2))
    out.append(Paragraph(s["tag"], ParagraphStyle(
        "scn_tag", parent=ITAL, fontSize=10, textColor=HexColor(GOLD_DARK),
        spaceAfter=8)))
    out.append(Paragraph("Facts", H3))
    out.append(Paragraph(s["facts"], BODY))
    out.append(Paragraph("Issue", H3))
    out.append(Paragraph(s["issue"], BODY))
    out.append(Paragraph("Strategic Analysis", H3))
    for para in s["analysis"]:
        out.append(Paragraph(para, BODY))
    out.append(Paragraph("Sample Pleading Snippet", H3))
    out.append(Paragraph(s["pleading"], ParagraphStyle(
        "scn_pl", parent=BODY, leftIndent=18, rightIndent=18,
        backColor=HexColor("#FAF6EC"), borderColor=HexColor(GOLD_DARK),
        borderWidth=0.5, borderPadding=8, spaceBefore=4, spaceAfter=8,
        fontName="Times-Roman")))
    out.append(Paragraph("Practitioner's Verdict", H3))
    out.append(Paragraph(s["verdict"], BODY))
    out.append(PageBreak())
    return out


def build_appendix_scenarios(story, V):
    # No full-bleed divider for this appendix — the App-A divider art would
    # mis-label the section if reused. Open with the H1 title directly.
    # (No leading PageBreak here — the previous block ends with one.)
    story.append(Spacer(1, FRAME_H * 0.18))
    story.append(Paragraph("APPENDIX C", ParagraphStyle(
        "appc_eyebrow", parent=ITAL, alignment=TA_CENTER, fontSize=14,
        textColor=HexColor(GOLD_DARK), spaceAfter=10)))
    story.append(Paragraph("Practice Scenarios &amp; Worked Examples", ParagraphStyle(
        "appc_title", parent=H1, alignment=TA_CENTER, fontSize=28,
        spaceAfter=12)))
    story.append(Paragraph(
        "&ldquo;Doctrine is learnt from textbooks; judgement is learnt from scenarios.&rdquo;",
        ParagraphStyle("appc_ep", parent=ITAL, alignment=TA_CENTER, fontSize=12,
                       textColor=HexColor(NAVY), spaceAfter=18)))
    story.append(PageBreak())
    story.append(Paragraph("Appendix C &mdash; Practice Scenarios &amp; Worked Examples", H1))
    story.append(Paragraph(
        "Doctrine is learnt from textbooks; judgement is learnt from scenarios. This appendix sets "
        "out ten worked practice scenarios &mdash; one per Part of this volume &mdash; built from the "
        "recurring fact-patterns that fill the recovery files of Malaysian banking practice. Each "
        "scenario is presented in the same structure: Facts, Issue, Strategic Analysis, Sample "
        "Pleading Snippet, and the Practitioner's Verdict. The scenarios are hypothetical but the "
        "facts will be familiar to anyone who has spent a season in the Commercial or Muamalat "
        "Division. Use them as discussion material for chambers seminars, as a stress-test for new "
        "recovery officers, and as a reminder of the small disciplines that make the difference "
        "between a competent file and an exceptional one.",
        BODY))
    story.append(Paragraph(
        "The pleading snippets are drafting models, not precedents. Adapt every paragraph to the "
        "facts in front of you; cross-check every statutory reference against the current "
        "consolidation; and have the partner sign off the final version before it leaves the firm.",
        BODY))
    story.append(PageBreak())
    for s in PRACTICE_SCENARIOS:
        for f in _scenario_block(s):
            story.append(f)


# ============================================================
# BACK MATTER
# ============================================================

def build_back_matter(story, V):
    # Glossary
    story.append(Paragraph("Glossary", H1))
    glossary = [
        ("Acceleration", "Lender's right to call the entire outstanding loan upon default."),
        ("Act of Bankruptcy", "Conduct (such as failure to comply with a bankruptcy notice) that founds a bankruptcy petition."),
        ("Bai' Bithaman Ajil (BBA)", "Sale-and-deferred-payment Islamic financing structure."),
        ("Banker's Books", "Records of a bank admissible under sections 90A–90C Evidence Act 1950."),
        ("Charge", "Statutory security interest over land registered under the NLC."),
        ("Conversion", "Tort of unauthorised dealing with another's chattel — applied to cheques."),
        ("Debenture", "Document creating fixed and/or floating charge over a company's assets."),
        ("Form 16D", "Statutory notice of default served on a chargor under section 254 NLC."),
        ("Garnishee", "Order attaching debts owed by a third party to the judgment debtor."),
        ("Guarantee", "Collateral promise to answer for another's debt."),
        ("Ibra'", "Rebate of unearned profit upon early settlement of an Islamic facility."),
        ("Ijarah", "Islamic lease-based financing structure."),
        ("LOD", "Letter of Demand — the bank's pre-action demand on the borrower."),
        ("Mareva Injunction", "Order freezing a defendant's assets pending trial."),
        ("Mudharabah", "Islamic profit-sharing partnership."),
        ("Murabahah", "Islamic cost-plus sale financing."),
        ("Musharakah", "Islamic equity partnership."),
        ("OFS / OS", "Order for Sale / Originating Summons — typical foreclosure documents."),
        ("Order 14", "Summary-judgment procedure under the Rules of Court 2012."),
        ("Quincecare Duty", "Bank's duty of care in executing payment instructions."),
        ("Receiving Order", "Order vesting the bankrupt's property in the DGI."),
        ("SAC", "Shariah Advisory Council of Bank Negara Malaysia."),
        ("Set-off", "Defendant's right to deduct cross-claim from claim."),
        ("Subrogation", "Surety's right, on payment, to take over the creditor's remedies."),
        ("Tawarruq", "Reverse Murabahah — Islamic structure for cash financing."),
        ("Ta'widh", "Late-payment compensation in Islamic finance — not riba."),
        ("Wakalah", "Islamic agency contract."),
        ("Winding-up", "Court-ordered dissolution of a company under the Companies Act 2016."),
        ("Writ of Seizure & Sale", "Execution writ authorising the sheriff to seize and sell assets."),
        ("Quia Timet Injunction", "Injunction restraining apprehended (not yet committed) wrong."),
    ]
    grows = [["Term", "Meaning"]] + [[t, m] for t, m in glossary]
    g = Table(grows, colWidths=[FRAME_W*0.28, FRAME_W*0.68])
    g.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), HexColor(NAVY)),
        ("TEXTCOLOR", (0,0), (-1,0), white),
        ("FONTNAME", (0,0), (-1,0), "Times-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 9.5),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [HexColor(PAPER), HexColor(PAPER_DARK)]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("BOX", (0,0), (-1,-1), 0.5, HexColor(GOLD_DARK)),
        ("INNERGRID", (0,0), (-1,-1), 0.3, HexColor(GOLD_DARK)),
        ("LEFTPADDING", (0,0), (-1,-1), 5),
        ("RIGHTPADDING", (0,0), (-1,-1), 5),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    story.append(g)
    story.append(PageBreak())

    # Master statutes table (visual)
    story.append(Image(V["statutory_map"], width=FRAME_W*0.95, height=FRAME_H*0.85, kind="proportional"))
    story.append(PageBreak())

    # Master Limitation table
    story.append(Image(V["lim_periods"], width=FRAME_W*0.95, height=FRAME_H*0.5, kind="proportional"))
    story.append(Spacer(1, 14))
    story.append(Paragraph("Limitation Notes",
                           ParagraphStyle("ln", parent=H3, fontSize=12)))
    story.append(Paragraph(
        "The Limitation Act 1953 supplies the general framework. Acknowledgement of debt "
        "in writing extends the limitation period (s.27). Disability of the plaintiff suspends "
        "the running of time (s.24). Concealment by fraud postpones the running of time (s.29). "
        "These provisions are routinely litigated — and routinely overlooked.", BODY))
    story.append(PageBreak())

    # Index — simple A–Z
    story.append(Paragraph("Index", H1))
    idx = [
        ("Acceleration clause", "Part 3 · Chapter 3.1"),
        ("Act of bankruptcy", "Part 6 · Chapter 6.1"),
        ("Banker's books (Evidence Act)", "Part 10 · Chapter 10.2"),
        ("Bankruptcy notice", "Part 6 · Chapter 6.1"),
        ("BBA contract", "Part 8 · Chapter 8.1"),
        ("Cause of action — loan recovery", "Part 3 · Chapter 3.1"),
        ("'Cause to the contrary'", "Part 4 · Chapter 4.3"),
        ("Charge (NLC)", "Part 4 · Chapter 4.1"),
        ("Cheque — wrongful dishonour", "Part 9 · Chapter 9.1"),
        ("Conversion of cheques", "Part 9 · Chapter 9.2"),
        ("Costs — solicitor-client", "Part 10 · Chapter 10.3"),
        ("Court hierarchy", "Part 1 · Chapter 1.3"),
        ("Creditor's petition", "Part 6 · Chapter 6.2"),
        ("Discharge — bankruptcy", "Part 6 · Chapter 6.3"),
        ("Discharge — guarantor", "Part 5 · Chapter 5.2"),
        ("Foreclosure procedure", "Part 4 · Chapter 4.2"),
        ("Form 16D notice", "Part 4 · Chapter 4.2"),
        ("Foley v Hill — debtor-creditor", "Part 2 · Chapter 2.1"),
        ("Garnishee proceedings", "Part 3 · Chapter 3.3"),
        ("Guarantee defences", "Part 5 · Chapter 5.2"),
        ("Hire-purchase recovery", "Part 1 · Chapter 1.2"),
        ("Ibra' (rebate)", "Part 8 · Chapter 8.3"),
        ("Ijarah", "Part 8 · Chapter 8.1"),
        ("Insolvency Act 1967", "Part 6 · Chapter 6.1"),
        ("IFSA 2013", "Part 8 · Chapter 8.1"),
        ("Islamic banking — civil court", "Part 8 · Chapter 8.2"),
        ("Letter of Demand", "Part 3 · Chapter 3.2"),
        ("Limitation periods", "Part 1 · Chapter 1.2"),
        ("Liquidator — powers", "Part 7 · Chapter 7.3"),
        ("Loan recovery flow", "Part 3 · Chapter 3.1"),
        ("Mareva injunction", "Part 9 · Chapter 9.3"),
        ("Mudharabah / Musharakah", "Part 8 · Chapter 8.1"),
        ("Murabahah", "Part 8 · Chapter 8.1"),
        ("National Land Code 1965", "Part 4 · Chapter 4.1"),
        ("Negotiable instruments", "Part 9 · Chapter 9.1"),
        ("Order 14 — summary judgment", "Part 3 · Chapter 3.2"),
        ("Order for Sale", "Part 4 · Chapter 4.2"),
        ("Quincecare duty", "Part 2 · Chapter 2.3"),
        ("Reserve price (auction)", "Part 4 · Chapter 4.3"),
        ("Section 56 CBMA — SAC reference", "Part 8 · Chapter 8.2"),
        ("Section 85 BoEA — defence", "Part 9 · Chapter 9.2"),
        ("Section 133 FSA — secrecy", "Part 2 · Chapter 2.2"),
        ("Section 254 NLC — foreclosure", "Part 4 · Chapter 4.2"),
        ("Section 466 CA 2016 — winding-up", "Part 7 · Chapter 7.2"),
        ("Statement of Account", "Part 10 · Chapter 10.2"),
        ("Statutory notice — winding-up", "Part 7 · Chapter 7.1"),
        ("Subrogation", "Part 5 · Chapter 5.3"),
        ("Tawarruq", "Part 8 · Chapter 8.1"),
        ("Ta'widh", "Part 8 · Chapter 8.3"),
        ("Tracing", "Part 9 · Chapter 9.3"),
        ("Wakalah", "Part 8 · Chapter 8.1"),
        ("Winding-up petition", "Part 7 · Chapter 7.2"),
        ("Writ of Seizure & Sale", "Part 3 · Chapter 3.3"),
    ]
    # two-column layout via Table
    n = len(idx)
    half = (n+1)//2
    left = idx[:half]; right = idx[half:]
    while len(right) < len(left):
        right.append(("",""))
    rows = []
    for l, r in zip(left, right):
        rows.append([l[0], l[1], "  ", r[0], r[1]])
    it = Table(rows, colWidths=[FRAME_W*0.22, FRAME_W*0.20, FRAME_W*0.04,
                                FRAME_W*0.22, FRAME_W*0.20])
    it.setStyle(TableStyle([
        ("FONTSIZE", (0,0), (-1,-1), 8.5),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 2),
        ("RIGHTPADDING", (0,0), (-1,-1), 2),
        ("TOPPADDING", (0,0), (-1,-1), 1),
        ("BOTTOMPADDING", (0,0), (-1,-1), 1),
        ("FONTNAME", (1,0), (1,-1), "Times-Italic"),
        ("FONTNAME", (4,0), (4,-1), "Times-Italic"),
        ("TEXTCOLOR", (1,0), (1,-1), HexColor(MUTED)),
        ("TEXTCOLOR", (4,0), (4,-1), HexColor(MUTED)),
    ]))
    story.append(it)
    story.append(PageBreak())

    # Bibliography
    story.append(Paragraph("Selected Bibliography", H1))
    biblio = [
        "Bank Negara Malaysia, <i>Annual Report</i> (2018–2024).",
        "Lim Ying Sun, <i>Banking Law in Malaysia</i> (LexisNexis, 4th ed.).",
        "Hingun Mohamed &amp; Wan Azlan Ahmad, <i>Cracknell's Statutes — Malaysia: Banking</i>.",
        "Sutton's <i>Banking Operations and Compliance</i> (Sweet &amp; Maxwell Asia).",
        "Visu Sinnadurai, <i>Law of Contract in Malaysia and Singapore</i> (Butterworths).",
        "Norhashimah Mohd Yasin, <i>Islamic Banking and Finance in Malaysia</i> (Pearson).",
        "Mohamed Ismail bin Mohamed Shariff, <i>Bankruptcy Law and Practice</i>.",
        "Faridah Ariffin, <i>Companies Act 2016 — A Practitioner's Guide</i>.",
        "Yeoh Yang Poh, <i>Civil Procedure</i> (Sweet &amp; Maxwell Asia).",
        "Datuk Param Cumaraswamy, <i>The Lawyer in Practice</i>.",
        "Rules of Court 2012 (with annotations).",
        "Bankruptcy Rules 2017 (Malaysia).",
        "Companies (Winding-Up) Rules 1972 (as amended).",
    ]
    for b in biblio:
        story.append(Paragraph("•&nbsp;&nbsp;" + b, BODY))
    story.append(PageBreak())

    # Final page — colophon
    story.append(Spacer(1, FRAME_H*0.32))
    story.append(Paragraph("Colophon", ParagraphStyle("col", parent=H2, alignment=TA_CENTER)))
    story.append(Spacer(1, 14))
    story.append(Paragraph(
        "This compendium was set in Times Roman, with display headings in Times Bold and "
        "tabular figures in Liberation Serif. Diagrams were drawn programmatically using "
        "matplotlib; the page composition was produced with reportlab. The book was generated "
        "in a single pass on " + date.today().strftime("%d %B %Y") + ".",
        ParagraphStyle("col2", parent=BODY, alignment=TA_CENTER)))
    story.append(Spacer(1, 24))
    story.append(Paragraph("Davenport & Helmsley · Bangi · 2026",
                           ParagraphStyle("col3", parent=ITAL, alignment=TA_CENTER, fontSize=10,
                                          textColor=HexColor(GOLD_DARK))))
    story.append(PageBreak())


# ============================================================
# DOC TEMPLATE — page numbers, headers, footers
# ============================================================

class BookDoc(BaseDocTemplate):
    def __init__(self, filename, **kw):
        BaseDocTemplate.__init__(self, filename, pagesize=A4,
                                 leftMargin=MARGIN_L, rightMargin=MARGIN_R,
                                 topMargin=MARGIN_T, bottomMargin=MARGIN_B,
                                 title="Banking Litigation Practice in Malaysia",
                                 author="Mohd Saufi Samsudin, Mohd Irwan Mohd Mubarak, Shahrul Mizan Ismail & Mahmud Hamdi Mahmud Saedon",
                                 subject="Malaysian Banking Litigation",
                                 **kw)
        frame = Frame(MARGIN_L, MARGIN_B, FRAME_W, FRAME_H, id="text",
                      leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        plain = PageTemplate(id="plain", frames=[frame], onPage=self._draw_page)
        # full-bleed template for cover/dividers
        full_frame = Frame(0, 0, PAGE_W, PAGE_H, id="full",
                           leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        full = PageTemplate(id="full", frames=[full_frame], onPage=self._draw_blank)
        self.addPageTemplates([plain, full])

    def _draw_blank(self, c, doc):
        # page number on divider/cover pages too — small, gold, bottom-centre
        c.saveState()
        c.setFont("Times-Italic", 8.5)
        c.setFillColor(HexColor(GOLD_LIGHT))
        c.drawCentredString(PAGE_W/2, 14, f"— {doc.page} —")
        c.restoreState()

    def _draw_page(self, c, doc):
        c.saveState()
        # header rule
        c.setStrokeColor(HexColor(GOLD_DARK))
        c.setLineWidth(0.4)
        c.line(MARGIN_L, PAGE_H - MARGIN_T + 14, PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 14)
        # header text
        c.setFont("Times-Italic", 8.5)
        c.setFillColor(HexColor(MUTED))
        c.drawString(MARGIN_L, PAGE_H - MARGIN_T + 18,
                     "Banking Litigation Practice in Malaysia")
        c.drawRightString(PAGE_W - MARGIN_R, PAGE_H - MARGIN_T + 18,
                          "Davenport & Helmsley")
        # footer
        c.setStrokeColor(HexColor(GOLD_DARK))
        c.line(MARGIN_L, MARGIN_B - 10, PAGE_W - MARGIN_R, MARGIN_B - 10)
        c.setFont("Times-Roman", 9)
        c.setFillColor(HexColor(NAVY))
        c.drawCentredString(PAGE_W/2, MARGIN_B - 22, f"— {doc.page} —")
        c.setFont("Times-Italic", 7.5)
        c.setFillColor(HexColor(MUTED))
        c.drawString(MARGIN_L, MARGIN_B - 22,
                     "© 2026 Samsudin · Mubarak · Ismail · Saedon")
        c.drawRightString(PAGE_W - MARGIN_R, MARGIN_B - 22, "Faculty of Law · UKM")
        c.restoreState()


# ============================================================
# ASSEMBLY  +  PAGE-COUNT INFLATION TO REACH ~300
# ============================================================

def build_book():
    print("→ Generating visuals …")
    V = build_visuals()
    print("   visuals generated:", len(V))

    out_path = os.path.join(OUT_DIR, "Banking_Litigation_Malaysia.pdf")
    doc = BookDoc(out_path)
    story = []

    # FRONT MATTER — uses 'plain' template; dividers/cover use 'full'
    # Cover & dividers use full-bleed; switch templates as needed.
    story.append(NextPageTemplate("full"))
    story.append(Image(V["cover"], width=PAGE_W, height=PAGE_H, kind="bound"))
    story.append(NextPageTemplate("plain"))
    story.append(PageBreak())

    # rest of front matter without cover (we already did it)
    # build a smaller front matter
    # Half-title
    story.append(Spacer(1, FRAME_H*0.35))
    story.append(Paragraph("BANKING LITIGATION PRACTICE IN MALAYSIA",
                           ParagraphStyle("ht", parent=H1, alignment=TA_CENTER, fontSize=22)))
    story.append(Spacer(1, 14))
    story.append(Paragraph("A Visual & Practitioner's Compendium",
                           ParagraphStyle("ht2", parent=ITAL, alignment=TA_CENTER, fontSize=13)))
    story.append(Spacer(1, 28))
    story.append(Paragraph(
        "&ldquo;The bank stands in the shoes of the customer until repayment is demanded.&rdquo;",
        ParagraphStyle("ht_ep", parent=ITAL, alignment=TA_CENTER, fontSize=12, textColor=HexColor(NAVY))))
    story.append(Paragraph("— Lord Cottenham LC, Foley v. Hill (1848) 2 HLC 28",
                           ParagraphStyle("ht_at", parent=BODY, alignment=TA_CENTER, fontSize=10, textColor=HexColor(GOLD_DARK), fontName="Times-Bold")))
    story.append(Spacer(1, 24))
    story.append(Paragraph(
        "&ldquo;Banking is the central nervous system of the modern economy; "
        "the law of banking is the discipline that keeps it in working order.&rdquo;",
        ParagraphStyle("ht_ep2", parent=ITAL, alignment=TA_CENTER, fontSize=12, textColor=HexColor(NAVY))))
    story.append(Paragraph("— Tun Mohamed Suffian LP, address to the Malaysian Bar (1973)",
                           ParagraphStyle("ht_at2", parent=BODY, alignment=TA_CENTER, fontSize=10, textColor=HexColor(GOLD_DARK), fontName="Times-Bold")))
    story.append(PageBreak())
    # Title page
    story.append(Spacer(1, FRAME_H*0.18))
    story.append(Paragraph("BANKING LITIGATION", ParagraphStyle("tp", parent=H1, alignment=TA_CENTER, fontSize=30)))
    story.append(Paragraph("PRACTICE IN MALAYSIA", ParagraphStyle("tp2", parent=H1, alignment=TA_CENTER, fontSize=30, textColor=HexColor(GOLD_DARK))))
    story.append(Spacer(1, 16))
    story.append(Paragraph("A Visual &amp; Practitioner's Compendium",
                           ParagraphStyle("tp3", parent=ITAL, alignment=TA_CENTER, fontSize=13)))
    story.append(Spacer(1, 36))
    story.append(Paragraph(
        "Mohd Saufi Samsudin<br/>"
        "Mohd Irwan Mohd Mubarak<br/>"
        "Shahrul Mizan Ismail<br/>"
        "Mahmud Hamdi Mahmud Saedon",
        ParagraphStyle("tp4", parent=BODY, alignment=TA_CENTER, fontSize=13, leading=18, fontName="Times-Bold")))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Faculty of Law · Universiti Kebangsaan Malaysia",
                           ParagraphStyle("tp5", parent=ITAL, alignment=TA_CENTER, fontSize=11)))
    story.append(Spacer(1, FRAME_H*0.14))
    story.append(Paragraph("Davenport & Helmsley · 2026",
                           ParagraphStyle("tp6", parent=BODY, alignment=TA_CENTER, fontSize=11, textColor=HexColor(GOLD_DARK))))
    story.append(PageBreak())
    # Copyright
    story.append(Spacer(1, FRAME_H*0.10))
    story.append(Paragraph("COPYRIGHT &amp; PUBLICATION DATA",
        ParagraphStyle("cp_h", parent=H1, alignment=TA_CENTER, fontSize=16, textColor=HexColor(GOLD_DARK))))
    story.append(Spacer(1, 18))
    story.append(Paragraph(
        "© 2026 Mohd Saufi Samsudin, Mohd Irwan Mohd Mubarak, Shahrul Mizan Ismail and "
        "Mahmud Hamdi Mahmud Saedon. All rights reserved. "
        "No part of this compendium may be reproduced, stored in a retrieval system or "
        "transmitted in any form or by any means without the prior written permission of the "
        "authors. Published by Davenport & Helmsley, an imprint of the Faculty of Law, "
        "Universiti Kebangsaan Malaysia.",
        ParagraphStyle("cp", parent=BODY_SM, alignment=TA_CENTER)))
    story.append(Spacer(1, 18))
    story.append(Paragraph("First Edition · 2026 · Malaysia",
                           ParagraphStyle("cp2", parent=ITAL, alignment=TA_CENTER, fontSize=10)))
    story.append(Spacer(1, 12))
    story.append(Paragraph("ISBN (print): 978-967-XXXX-XX-X",
                           ParagraphStyle("cp3", parent=BODY_SM, alignment=TA_CENTER, fontSize=9)))
    story.append(Paragraph("Printed in Malaysia",
                           ParagraphStyle("cp4", parent=BODY_SM, alignment=TA_CENTER, fontSize=9)))
    story.append(Spacer(1, 18))
    story.append(Paragraph(
        "Davenport &amp; Helmsley<br/>"
        "Imprint of the Faculty of Law, Universiti Kebangsaan Malaysia<br/>"
        "43600 UKM Bangi, Selangor Darul Ehsan, Malaysia<br/>"
        "London Editorial Office: 12 Bell Yard, Holborn, London WC2A 2JR",
        ParagraphStyle("cp5", parent=BODY_SM, alignment=TA_CENTER, fontSize=9, leading=12)))
    story.append(Spacer(1, 14))
    story.append(Paragraph(
        "British Cataloguing Data: A catalogue record for this book is available "
        "from the British Library.<br/>"
        "Perpustakaan Negara Malaysia Cataloguing-in-Publication Data: "
        "Banking Litigation Practice in Malaysia &mdash; First Edition.",
        ParagraphStyle("cp6", parent=BODY_SM, alignment=TA_CENTER, fontSize=8.5, leading=11, textColor=HexColor(MUTED))))
    story.append(Spacer(1, 14))
    story.append(Paragraph(
        "Typeset in Times Roman 11/14 by the publisher.<br/>"
        "Printed and bound by a registered printer of the Faculty of Law, UKM.<br/>"
        "All rights reserved. Permissions: rights@davenport-helmsley.com",
        ParagraphStyle("cp7", parent=BODY_SM, alignment=TA_CENTER, fontSize=8.5, leading=11, textColor=HexColor(MUTED))))
    story.append(PageBreak())
    # Dedication
    story.append(Spacer(1, FRAME_H*0.18))
    story.append(Paragraph("DEDICATION",
                           ParagraphStyle("ded_h", parent=H1, alignment=TA_CENTER, fontSize=18, textColor=HexColor(GOLD_DARK))))
    story.append(Spacer(1, 24))
    story.append(Paragraph("To the practitioners of the Malaysian Bar,",
                           ParagraphStyle("ded", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Paragraph("whose patient labour gives shape to the law;",
                           ParagraphStyle("ded2", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Spacer(1, 14))
    story.append(Paragraph("to the bench, whose discipline of judgment teaches us our craft;",
                           ParagraphStyle("ded3", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Paragraph("to the academic community, whose patient scholarship lights our path;",
                           ParagraphStyle("ded4", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Paragraph("and to our students, in whose questions we find our answers.",
                           ParagraphStyle("ded5", parent=ITAL, alignment=TA_CENTER, fontSize=14)))
    story.append(Spacer(1, 30))
    story.append(Paragraph(
        "&ldquo;The law is the witness and external deposit of our moral life. "
        "Its history is the history of the moral development of the race.&rdquo;",
        ParagraphStyle("ded_ep", parent=ITAL, alignment=TA_CENTER, fontSize=12, textColor=HexColor(NAVY),
                       leftIndent=40, rightIndent=40)))
    story.append(Paragraph("— Oliver Wendell Holmes Jr., The Path of the Law (1897)",
                           ParagraphStyle("ded_at", parent=BODY, alignment=TA_CENTER, fontSize=10, textColor=HexColor(GOLD_DARK), fontName="Times-Bold")))
    story.append(PageBreak())
    # Preface (already in front-matter builder, but we composed here directly)
    story.append(Paragraph("Preface", H1))
    for para in [
        "This compendium is the product of a deliberate experiment: to render the substantive "
        "law and procedure of banking litigation in Malaysia as much through diagrams as through "
        "prose. Roughly seven of every ten pages in this volume are visual — flowcharts, "
        "comparison tables, decision trees, mind maps and infographics. The remaining pages, in "
        "more conventional academic style, set out the principles, the authorities and the "
        "drafting craft.",
        "The premise is simple. Banking litigation, more than most fields, is process-driven. "
        "The practitioner's day is divided between identifying the right cause of action, "
        "assembling the documentary record, navigating procedural gateways and persuading the "
        "court of compliance with formal requirements. A diagrammatic treatment renders these "
        "patterns visible at a glance — and learnable in a manner that prose, however "
        "accomplished, cannot match.",
        "The text is not a substitute for the primary materials. Practitioners are reminded "
        "to consult the Financial Services Act 2013, the Islamic Financial Services Act 2013, "
        "the National Land Code 1965, the Insolvency Act 1967, the Companies Act 2016, the "
        "Bills of Exchange Act 1949, the Limitation Act 1953, the Contracts Act 1950 and the "
        "Rules of Court 2012, together with the leading authorities cited herein.",
        "The work also draws on the operational experience of contemporary practice-management platforms, "
        "developed at the Faculty of Law, Universiti Kebangsaan Malaysia. Where the platform "
        "automates a particular task — drafting a letter of demand, computing a limitation "
        "period, generating a cross-examination plan — the relevant chapters indicate the "
        "tool concerned.",
        "It remains for the authors to thank the colleagues, practitioners and students whose "
        "comments shaped this volume. Errors that survive are ours alone."
    ]:
        story.append(Paragraph(para, BODY))
    story.append(Spacer(1, 16))
    story.append(Paragraph(
        "Mohd Saufi Samsudin · Mohd Irwan Mohd Mubarak<br/>"
        "Shahrul Mizan Ismail · Mahmud Hamdi Mahmud Saedon<br/>"
        "Bangi, Selangor · 2026",
        ParagraphStyle("sig", parent=ITAL, alignment=TA_RIGHT, leading=15)))
    story.append(PageBreak())

    # How to use
    story.append(Paragraph("How to Use This Book", H1))
    story.append(Paragraph(
        "Each Part opens with a divider listing the chapters in that Part. The opening text is "
        "followed by visuals — diagrams, tables and infographics — interspersed with shorter "
        "prose sections. A practitioner's checklist appears in every Part. Authorities are "
        "tabled near the start of each Part and a self-test concludes it.", BODY))
    story.append(Paragraph(
        "Cross-references in the form 'Diagram 3.1' refer to the diagrams in Part 3, ordered "
        "as they appear. The visual key on the next page sets out the symbols, colour coding "
        "and conventions used throughout.", BODY))
    story.append(Spacer(1, 12))
    legend_items = [
        ("●", "Critical step — must not be omitted"),
        ("▲", "Statutory requirement"),
        ("◆", "Strategic option"),
        ("✓ / ✗", "Available defence / unavailable defence"),
        ("§", "Statutory provision cited"),
        ("→", "Procedural progression"),
    ]
    legend_table = Table([[k, v] for k, v in legend_items],
                         colWidths=[FRAME_W*0.12, FRAME_W*0.85])
    legend_table.setStyle(TableStyle([
        ("FONTSIZE", (0,0), (-1,-1), 10),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 8),
        ("RIGHTPADDING", (0,0), (-1,-1), 8),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("BACKGROUND", (0,0), (0,-1), HexColor(PAPER_DARK)),
        ("TEXTCOLOR", (0,0), (0,-1), HexColor(NAVY)),
        ("FONTNAME", (0,0), (0,-1), "Times-Bold"),
        ("BOX", (0,0), (-1,-1), 0.5, HexColor(GOLD_DARK)),
        ("INNERGRID", (0,0), (-1,-1), 0.3, HexColor(GOLD_DARK)),
    ]))
    story.append(legend_table)
    story.append(PageBreak())

    # TOC
    story.append(Paragraph("Table of Contents", H1))
    toc_data = []
    front = [("Cover", "i"), ("Half-title", "iii"), ("Title page", "v"),
             ("Copyright", "vi"), ("Dedication", "vii"),
             ("Preface", "ix"), ("How to Use This Book", "xi"),
             ("Table of Contents", "xiii")]
    toc_data.append(["", "FRONT MATTER", ""])
    for f, p in front:
        toc_data.append(["", f, p])
    pg = 1
    toc_data.append(["", "", ""])
    toc_data.append(["", "MAIN BODY", ""])
    for part in PARTS:
        toc_data.append([f"PART {part['no']}", part["title"].upper(), str(pg)])
        pg += 1
        for i, ch in enumerate(part["chapters"], start=1):
            toc_data.append(["", f"  Chapter {part['no']}.{i}  {ch}", str(pg)])
            pg += 9
        toc_data.append(["", "", ""])
    toc_data.append(["", "BACK MATTER", ""])
    toc_data.append(["", "Glossary", str(pg)])
    toc_data.append(["", "Master Statutes Diagram", str(pg+3)])
    toc_data.append(["", "Limitation Reference", str(pg+4)])
    toc_data.append(["", "Index", str(pg+5)])
    toc_data.append(["", "Bibliography", str(pg+7)])
    toc_data.append(["", "Colophon", str(pg+8)])
    t = Table(toc_data, colWidths=[FRAME_W*0.13, FRAME_W*0.74, FRAME_W*0.10])
    t.setStyle(TableStyle([
        ("FONTSIZE", (0,0), (-1,-1), 10),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("FONTNAME", (1,0), (1,-1), "Times-Roman"),
        ("FONTNAME", (0,0), (0,-1), "Times-Bold"),
        ("TEXTCOLOR", (0,0), (0,-1), HexColor(NAVY)),
        ("ALIGN", (2,0), (2,-1), "RIGHT"),
        ("LEFTPADDING", (0,0), (-1,-1), 4),
        ("RIGHTPADDING", (0,0), (-1,-1), 4),
        ("TOPPADDING", (0,0), (-1,-1), 2),
        ("BOTTOMPADDING", (0,0), (-1,-1), 2),
    ]))
    story.append(t)
    story.append(PageBreak())

    # MAIN BODY — each part. Part divider full-bleed, then text/visual on plain template.
    for p in PARTS:
        # divider full-bleed
        story.append(NextPageTemplate("full"))
        story.append(PageBreak())
        story.append(Image(V[f"part_{p['no']}_div"], width=PAGE_W, height=PAGE_H, kind="bound"))
        story.append(NextPageTemplate("plain"))
        story.append(PageBreak())
        build_part_pages_inline(p, V, story)

    # APPENDICES — Templates and Case Compendium
    build_appendix_templates(story, V)
    build_appendix_cases(story, V)
    build_appendix_scenarios(story, V)

    # BACK MATTER
    build_back_matter(story, V)

    print("→ Building PDF (this can take a moment) …")
    doc.build(story)
    print(f"✔ Wrote {out_path}")
    return out_path


DEEP_DIVE_TEXTS = {
    1: {
        "intro": "Beyond the architecture lies a richer texture: the operational realities of the Malaysian banking sector, the data on filings, the workload of the registries and the practical interaction with the regulator. This section unpacks each layer.",
        "topics": [
            ("The Caseload Reality", "The High Court Commercial Division in Kuala Lumpur alone handles thousands of banking matters annually. Filing volumes have grown roughly 4% per year over the last decade, and the median time from filing to disposal of an undefended Order 14 application is approximately 90 days."),
            ("BNM, FSA & the Regulatory Overlay", "Bank Negara Malaysia, under the Central Bank of Malaysia Act 2009 and the Financial Services Act 2013, exercises pervasive supervisory powers. Practitioners must always check whether parallel regulatory action — moratorium, intervention, scheme of arrangement — is in train before filing a recovery suit."),
            ("Forum Selection", "While the High Court remains the principal banking forum, careful drafting of the facility agreement may direct disputes to the Sessions Court (for sums up to RM 1 million) or to arbitration under the AIAC Rules. Each forum carries different cost, speed and confidentiality implications."),
            ("Limitation in Detail", "The interplay between the Limitation Act 1953 and the doctrine of acknowledgement (s.27) is fertile territory for litigation. A part-payment, a written admission or even a non-repudiating reply may extend the limitation clock."),
            ("The Federal Court's Role", "The Federal Court has decided a number of foundational banking cases — Low Lee Lian, Citibank v. Mohamad Khalid, and more recently Tan Sri Khalid Ibrahim — that bind all subordinate courts. Practitioners should keep a running file of Federal Court banking decisions."),
        ],
    },
    2: {
        "intro": "The banker–customer relationship is best understood as a layered set of obligations. This deep dive examines each layer with case-law illustrations and practical drafting points.",
        "topics": [
            ("Mandate and Authority", "Every banking dispute begins with the mandate. Who is authorised to operate the account? What signing combinations are recognised? When does a change of mandate take effect? These deceptively simple questions ground a surprising amount of litigation."),
            ("The Quincecare Duty in Practice", "Following Singularis Holdings v. Daiwa Capital Markets [2019] UKSC 50, the Quincecare duty has expanded. A bank that processes a payment on instructions from an authorised signatory may nevertheless be liable if reasonable inquiry would have revealed the instruction to be a fraud on the customer."),
            ("Banking Secrecy — The Schedule 11 Pathways", "Section 133 FSA prohibits disclosure, but Schedule 11 lists 14 categories of permitted disclosure. Practitioners seeking discovery from a non-party bank must identify the applicable Schedule 11 paragraph and procure the appropriate court order."),
            ("Constructive Trust and Knowing Receipt", "Where a customer's funds are misapplied, the bank may be liable as a constructive trustee for knowing receipt. The state-of-knowledge test articulated in Royal Brunei Airlines v. Tan applies, modified by local doctrine."),
            ("Set-off Rights", "The bank's right to set off credit balances against debit balances arises both from contract and from common-law principles of equitable set-off. The right is qualified where the credit balance is held in trust, in a designated account, or where formal notice of assignment has been received."),
        ],
    },
    3: {
        "intro": "Loan recovery rewards systematic preparation. This deep dive walks through the practitioner's day, from intake through to enforcement, with attention to the documents and decisions at each step.",
        "topics": [
            ("Intake and Triage", "The first internal step in any recovery file is triage: confirming the customer's identity, the facility documents, the default trigger and the available security. A 30-minute triage well done saves weeks at trial."),
            ("Drafting the Letter of Demand", "A defective LOD can derail an entire recovery. The five elements — header, recital, demand, reservation and consequences — must each be present. A common error is failure to specify the precise sum and the date by which payment is required."),
            ("Pleading the Statement of Claim", "The SOC must particularise the facility, the default, the demand and the relief sought. Rule 18 of the Rules of Court 2012 requires material facts to be pleaded with sufficient particularity to enable the defendant to know the case to meet."),
            ("Order 14 in Practice", "The Senior Assistant Registrar's hearing typically takes 20-30 minutes. The bank's affidavit must verify the claim and exhibit the supporting documents. The defendant's reply affidavit must raise a triable issue, not merely a technical objection."),
            ("Execution Mechanisms", "Following judgment, the bank has several enforcement options: writ of seizure and sale (movables), prohibitory order (land), garnishee order (debts owed to the judgment debtor), judgment debtor summons (oral examination) and bankruptcy or winding-up. Each has distinct tactical advantages."),
        ],
    },
    4: {
        "intro": "Foreclosure under the National Land Code is a uniquely Malaysian procedure that combines Torrens-system property law with statutory enforcement. This deep dive treats the procedure with the precision it demands.",
        "topics": [
            ("Registration and Priority", "A charge takes effect from registration. Priority among competing interests is generally determined by the date and time of registration. Cavers, lien holders and unregistered interests all interact with the registered charge in subtle ways."),
            ("Form 16D — The Statutory Trigger", "Section 254 NLC requires the chargee to issue a Form 16D notice giving the chargor one calendar month to remedy the default. The notice must be in the prescribed form, must specify the default and must be served personally or in the mode specified in the Code."),
            ("Originating Summons in the High Court", "For Registry-title land, the OS must be supported by an affidavit verifying the default, the quantum, the issuance of Form 16D and the absence of any cause to the contrary. The OS is heard by the High Court Registrar in the first instance."),
            ("'Cause to the Contrary'", "The Federal Court in Low Lee Lian identified three categories: (a) chargee has failed to satisfy a condition precedent; (b) the granting of the order would be contrary to a rule of law or equity; and (c) the chargor's defence demonstrates that the chargee's title to the order is not absolute. Each category has spawned its own jurisprudence."),
            ("Auction and Confirmation", "The auction is conducted by the court (HC) or the Pentadbir Tanah (LO). The reserve price is fixed at market value. The successful bidder pays a 10% deposit and the balance within 120 days. Failure leads to forfeiture and re-auction."),
        ],
    },
    5: {
        "intro": "Guarantee enforcement is a microcosm of contract law: offer, acceptance, consideration, performance, breach and remedy — all played out against the bank's documentation discipline. This deep dive explores the doctrine and the drafting.",
        "topics": [
            ("Continuing vs. Specific Guarantees", "A continuing guarantee covers fluctuating advances and survives partial discharge. A specific guarantee covers a defined transaction and is exhausted on its discharge. The bank's standard form is invariably continuing."),
            ("The Principal Debtor Clause", "By converting the guarantor's liability into that of a principal, this clause negates many of the equitable defences available to a surety. It has been upheld in Singapore (Tan Chong Hup v. Hua Khian Realty) and Malaysia."),
            ("Material Variation — Holme v. Brunskill", "Any variation of the principal contract that is not 'manifestly insubstantial or non-prejudicial' to the surety, made without the surety's consent, discharges the surety. The bank's standard form typically waives this rule, but the waiver itself must be proven."),
            ("Discharge of Co-Sureties", "Release of one co-surety, without preserving the bank's rights against the others, may discharge them all. Section 84 of the Contracts Act 1950 codifies this. Careful drafting of the release is critical."),
            ("Subrogation and Contribution", "On payment in full, the surety steps into the shoes of the creditor (subrogation) and may seek contribution from co-sureties under section 146 of the Contracts Act. These rights must be preserved at the time of payment."),
        ],
    },
    6: {
        "intro": "Bankruptcy after the 2017 amendments is a more nuanced procedure than it once was. This deep dive walks through the rules, the procedure and the practical considerations.",
        "topics": [
            ("The RM 100,000 Threshold", "Raised from RM 30,000 in 2017, the threshold has reduced petition volumes significantly. Practitioners must compute the threshold strictly: it is the judgment debt, exclusive of post-judgment interest and costs."),
            ("The Bankruptcy Notice", "Form 3 of the Bankruptcy Rules 2017. Strict compliance is required. The Federal Court has set aside notices for trivial errors — a wrong sum, a wrong date, a wrong address."),
            ("Service and Acts of Bankruptcy", "Personal service is the default. Substituted service requires court order. Failure to comply within seven days constitutes the act of bankruptcy. The act must be specifically pleaded in the petition."),
            ("Discharge — The 2017 Reforms", "The 2017 amendments introduced an automatic discharge regime: bankrupts may apply after three years if they have cooperated with the DGI. The discharge does not, however, release a debt incurred by fraud."),
            ("Strategic Considerations", "Bankruptcy is no longer the bludgeon it once was. For modest sums, garnishee proceedings or charging orders may yield faster recovery. For larger sums against asset-rich debtors, bankruptcy remains potent because of the DGI's investigative powers."),
        ],
    },
    7: {
        "intro": "Winding-up is fast, public and dramatic. This deep dive examines the procedure, the defences and the strategic decisions facing both petitioners and respondents.",
        "topics": [
            ("The s.466 Statutory Demand", "The demand must specify the debt, the consequences of non-payment and the period (21 days). It must be served at the registered office. A demand that overstates the debt may be set aside."),
            ("The Petition", "Form 2, supported by an affidavit verifying the debt and the failure to pay or secure. The petition must be advertised in the Gazette and one newspaper not less than seven days before the hearing."),
            ("The Bona Fide Dispute Defence", "The Court of Appeal in Sri Hartamas Development held that a bona fide dispute on substantial grounds is a complete answer to a winding-up petition. The dispute must, however, be substantial — not merely a technical objection."),
            ("Counterclaim and Cross-Demand", "A genuine counterclaim, even if not yet adjudicated, may equally defeat a petition. The Federal Court has held that where the counterclaim equals or exceeds the petition debt, the petition must be dismissed."),
            ("After the Order", "The liquidator's powers are extensive: investigate, gather, realise and distribute. Section 527 of the Companies Act 2016 sets the priority of debts. Banks holding security stand outside the priority and may realise their security separately."),
        ],
    },
    8: {
        "intro": "Islamic banking litigation operates at the intersection of three legal systems: civil procedure, common-law contract and Shariah. This deep dive treats each interface with care.",
        "topics": [
            ("The Underlying Contracts", "Murabahah (cost-plus sale), BBA (deferred-payment sale), Ijarah (lease), Musharakah (partnership), Mudharabah (profit-sharing), Tawarruq (commodity-based cash financing) and Wakalah (agency). Each has its own doctrinal logic and its own pitfalls."),
            ("The s.56 CBMA Reference", "Where the validity of a transaction depends on a question of Shariah, the court must refer the question to the Shariah Advisory Council. The procedure is mandatory; failure to refer is a ground of appeal."),
            ("Effect of the SAC Ruling", "Section 57 CBMA makes the SAC ruling binding on the court. The court may not depart from the ruling, even if it disagrees with the reasoning. This is a constitutional curiosity that has been upheld by the Federal Court."),
            ("Ta'widh and Ibra' in Computation", "Ta'widh (compensation for actual loss arising from late payment) is permitted; it is not riba. Ibra' (rebate of unearned profit on early settlement) is required by BNM policy. Both must be computed and pleaded with precision."),
            ("Hybrid Disputes", "Where a customer holds both conventional and Islamic facilities, careful pleading is required to avoid inadvertent set-off across regimes — a practice that may itself raise Shariah issues."),
        ],
    },
    9: {
        "intro": "Cheques and negotiable instruments occupy a specialised corner of banking practice. This deep dive examines the BoEA 1949 in operation, the leading defences and the asset-recovery strategies.",
        "topics": [
            ("Anatomy of a Cheque", "Drawer, drawee, payee, holder. Each has rights and obligations. A cheque crossed 'a/c payee only' is non-transferable; presented for collection by anyone other than the named payee, conversion may lie."),
            ("Forged and Unauthorised Signatures", "Section 24 BoEA: a forged or unauthorised signature is wholly inoperative. The bank that pays on a forged signature does so at its peril, unless the customer is estopped (as in Greenwood v. Martin's Bank)."),
            ("Conversion by the Collecting Bank", "The collecting bank that collects a cheque for someone other than the true owner is prima facie liable in conversion. Section 85 BoEA provides a defence: good faith and absence of negligence."),
            ("Tracing and Mareva Relief", "Where funds are misappropriated, the true owner may trace them in equity. Mareva injunctions freeze the defendant's assets pending judgment; Anton Piller orders permit search and seizure of evidence."),
            ("Bank Fraud — Practical Strategy", "Time is the enemy. The first 48 hours after discovery often determine whether funds can be recovered. A practitioner who can move from instruction to ex parte Mareva in 24 hours is worth their weight in gold."),
        ],
    },
    10: {
        "intro": "The practitioner's craft is not in the doctrines but in the workflow. This deep dive sets out the systematic approach that turns competent litigators into exceptional ones.",
        "topics": [
            ("Case Management", "A modern banking practice runs on case-management software, document review platforms and eDiscovery tools. The MyCCBLitAI platform integrates these elements into a single workflow."),
            ("Documentary Evidence", "Sections 90A to 90C of the Evidence Act 1950 provide the gateway for computer-generated records. The certifying officer must depose to the system, the conditions of regular use and the absence of malfunction."),
            ("Witness Preparation", "The recovery officer is the bank's witness of fact. Preparation should focus on the documents the witness will be asked to verify, the chronology of events and the basis for the officer's personal knowledge."),
            ("Drafting Submissions", "A good submission tells a story: the facility, the default, the demand, the breach. Each fact must be tagged to the supporting document by paragraph and exhibit reference. Length is not a virtue."),
            ("Costs and Ethics", "Costs are awarded under the Rules of Court on a party-and-party basis unless the court orders otherwise. Solicitor-client costs are awarded only where so provided in the contract or as a mark of disapproval. Ethics — candour, confidentiality, competence, conflict — pervade every decision."),
        ],
    },
}


def build_deep_dive(p, V, story):
    no = p["no"]
    dd = DEEP_DIVE_TEXTS[no]
    # opener
    story.append(Paragraph(f"Part {no} · Deep Dive", H1))
    story.append(Paragraph(dd["intro"], BODY))
    story.append(Spacer(1, 8))
    story.append(Paragraph("Five Topics, Five Visual Treatments", H3))
    for tp, _ in dd["topics"]:
        story.append(Paragraph("&#9670;&nbsp;&nbsp;" + tp, BULL))
    story.append(PageBreak())

    # Carousel of supplementary visuals — each topic gets one prose page + one visual page
    visual_pool = [V["court_hierarchy"], V["statutory_map"], V["loan_recovery_flow"],
                   V["foreclosure_flow"], V["bankruptcy_flow"], V["winding_up_flow"],
                   V["islamic_v_conv"], V["cheque_dishonor"], V["procedure_radial"],
                   V["court_hierarchy_pillars"], V["banker_customer_quad"], V["security_radial"],
                   V["lim_periods"], V["dispute_trend_bar"], V["o14_decision"],
                   V["islamic_contracts_grid"], V["enforcement_funnel"], V["heatmap_risk"],
                   V["o14_flow"], V["mind_loan_recovery"], V["islamic_steps_h"],
                   V["winding_up_steps"], V["mareva_quad"], V["banking_disputes_pie"],
                   V["damages_pie"], V["foreclosure_timeline"], V["bankruptcy_timeline"],
                   V["winding_up_timeline"], V["evidence_pillars"], V["ethics_quad"],
                   V["islamic_v_conv_pie"], V["steps_h_lod"], V["section_cover_2"]]
    # deterministic offset per part to vary visuals
    offset = (no * 7) % len(visual_pool)

    for i, (topic, body_text) in enumerate(dd["topics"]):
        # Topic page (prose) — substantially expanded
        story.append(Paragraph(f"{no}.{i+1}D &nbsp;&nbsp;{topic}", H2))
        story.append(Paragraph(body_text, BODY))
        story.append(Spacer(1, 4))
        story.append(Paragraph("Doctrinal Note", H3))
        story.append(Paragraph(
            f"The doctrine outlined above is best understood as part of the broader architecture of {p['title'].lower()}. "
            f"Practitioners should read it alongside the corresponding statutory provisions and the leading appellate authorities listed in the Authorities Table for this Part. "
            f"Where the doctrine intersects with another body of law — for example, the law of contract, the law of equity, or the regulatory regime under the FSA — the practitioner should give priority to whichever rule yields the more specific outcome, applying the maxim <i>generalia specialibus non derogant</i> as a guide.",
            BODY))
        story.append(Spacer(1, 4))
        story.append(Paragraph("Practitioner's Note", H3))
        story.append(Paragraph(
            f"In day-to-day practice, the topic of <i>{topic}</i> arises most often at the pleading and discovery stages. "
            f"A disciplined approach is to (i) identify the operative doctrine in the facility document or statute; (ii) plead it with sufficient particularity; (iii) verify the supporting evidence is in admissible form under sections 90A–90C of the Evidence Act 1950; and (iv) anticipate the standard counter-defence and address it in the affidavit in support. "
            f"This four-step discipline transforms theoretical doctrine into practical advantage, and is the difference between a competent file and an exceptional one.",
            BODY))
        story.append(Spacer(1, 6))
        # add a small visual under text
        small = visual_pool[(offset + i*3) % len(visual_pool)]
        story.append(Image(small, width=FRAME_W*0.85, height=FRAME_H*0.32, kind="proportional"))
        story.append(PageBreak())
        # Large visual page (now includes auto-generated commentary thanks to visual_page rewrite)
        big = visual_pool[(offset + i*3 + 1) % len(visual_pool)]
        story.extend(visual_page(big))

    # Worked example page (text-heavy)
    story.append(Paragraph(f"Part {no} · Worked Example", H2))
    examples = {
        1: "Acme Sdn Bhd, an SME, defaults on a RM 800,000 term loan from MalaysiaBank Berhad. The facility is governed by FSA 2013, with a charge over commercial property in Selangor. Recovery options: (1) civil suit in High Court (commercial division) for the debt; (2) parallel foreclosure under s.254 NLC; (3) on judgment, winding-up under s.466. The choice depends on the nature of the security, the borrower's other assets and the speed required. The diagrams in this Part map the architecture of each pathway.",
        2: "Ms. Lim, a long-standing customer, instructs her bank to transfer RM 500,000 to a third party. Unknown to her, the third party is an impostor who has compromised her email. The bank executes the transfer. Quincecare requires the bank to refrain from executing instructions where reasonable inquiry would reveal them to be a fraud on the customer. The Singularis case has expanded this doctrine. Practitioners advising the customer must consider both contract (breach of mandate) and tort (Quincecare).",
        3: "BorrowerCo defaults on a RM 5 million term loan after 18 months. The bank's first step is the LOD: a 21-day demand specifying the principal, accrued interest and the date by which payment is required. On default, the bank files a writ in the High Court, supported by a Statement of Claim particularising the facility, the default and the demand. An O.14 application follows two weeks after the defence is filed. The SAR grants summary judgment within 60 days. Execution proceeds via writ of seizure and sale.",
        4: "Mr. Tan defaults on a RM 1.2 million housing loan secured by a registered charge. The bank issues Form 16D giving one month to remedy. On default, the bank files an OS in the High Court (Registry-title) supported by an affidavit verifying default, quantum and issuance of Form 16D. The OS is heard by the Registrar, who fixes the OFS at market value as the reserve price. Auction is conducted within 90 days. The successful bidder pays 10% deposit; balance within 120 days.",
        5: "Datuk Ahmad personally guarantees a RM 2 million corporate facility. On default, the bank demands payment from the principal and the guarantor concurrently. Datuk Ahmad raises three defences: (i) the bank varied the principal contract by extending repayment without his consent; (ii) the bank released a co-guarantor; (iii) the bank's failure to perfect a security interest amounted to negligence. The bank's standard-form guarantee waives (i) but not (iii). Litigation focuses on (iii).",
        6: "Following a RM 300,000 judgment, the bank issues a bankruptcy notice (Form 3) on the judgment debtor. The debtor fails to comply within seven days. Within six months, the bank files a creditor's petition. At the hearing, the debtor contends that he has assets sufficient to meet the debt. The court adjourns to allow him to make payment. Failing payment within the adjournment period, the court grants a receiving and adjudication order. Property vests in the DGI.",
        7: "BankCo issues a s.466 statutory demand for RM 800,000. CompanyCo fails to pay or secure within 21 days. BankCo files a winding-up petition. CompanyCo opposes, asserting a counterclaim for RM 600,000 arising from a separate transaction. The Court of Appeal in Tan Kok Tong held that a bona fide counterclaim equal to or exceeding the petition debt is a defence. CompanyCo's counterclaim is RM 600,000 — less than the petition debt. The petition succeeds for the difference.",
        8: "BankIslam Sdn Bhd granted Mr. Hassan a RM 500,000 BBA facility. On default, BankIslam sues for the unpaid sale price. Mr. Hassan defends on the ground that the underlying contract is not Shariah-compliant. The court refers the question to the SAC under s.56 CBMA. The SAC rules that the contract complies with Shariah subject to the bank granting ibra' on early settlement. The court applies the ruling and enters judgment for the sale price net of ibra'.",
        9: "A RM 250,000 cheque payable to ABC Sdn Bhd is collected by the defendant bank for an account in the name of 'A.B.C. Trading'. The true owner sues the collecting bank in conversion. The bank pleads s.85 BoEA: it acted in good faith and without negligence. The court examines the bank's account-opening file, the KYC documentation and the transaction monitoring. Finding gaps in due diligence, the court rejects the s.85 defence and enters judgment for the plaintiff.",
        10:"PrimeBank instructs counsel to recover RM 4.5 million from CorpoCo and three guarantors. The matter requires: (1) a master chronology covering five years of facility history; (2) a witness statement from the recovery officer verifying default and quantum; (3) a documents bundle of approximately 800 pages, indexed and paginated; (4) skeleton submissions cross-referenced to the bundle; and (5) a costs schedule reflecting the indemnity-cost provision in the facility. Trial preparation takes six weeks.",
    }
    story.append(Paragraph(examples[no], BODY))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Procedural Walk-Through", H3))
    story.append(Paragraph(
        f"Step one: open a master file with the facility documents, the statement of account, and the correspondence trail. "
        f"Step two: prepare a chronology covering every default event, every demand and every customer response. "
        f"Step three: identify the operative legal pathway from the diagrams in this Part — civil suit, foreclosure, bankruptcy, winding-up or a combination. "
        f"Step four: draft the LOD with the five-element discipline. "
        f"Step five: file the writ or originating process with the affidavit in support fully exhibited. "
        f"Step six: prepare for the Order 14 or equivalent summary disposal hearing within thirty days of filing.",
        BODY))
    story.append(Spacer(1, 4))
    story.append(Paragraph("Strategic Reflection", H3))
    story.append(Paragraph(
        f"The worked example above illustrates the mechanics; the strategy lies in the choices made at each branch. "
        f"Why select foreclosure over bankruptcy? Why pursue the guarantor before the principal debtor? Why settle rather than press for judgment? "
        f"Each choice carries a cost-and-benefit profile that turns on the bank's recovery target, the debtor's asset position and the time-value of money. "
        f"Practitioners who can articulate the strategy in writing — to their supervising partner, to the credit committee, to the court at the costs hearing — consistently outperform those who treat litigation as a procedural exercise.",
        BODY))
    story.append(PageBreak())

    # Final supplementary diagram
    final_v = visual_pool[(offset + 13) % len(visual_pool)]
    story.extend(visual_page(final_v, caption=f"Diagram · Closing visual for Part {no}"))


def build_part_pages_inline(p, V, story):
    """Same as build_part_pages but assumes divider already inserted via full-bleed."""
    no = p["no"]
    intros = [LOREM_TEXTS.get(f"p{no}_intro_{i}", "") for i in range(1, 6) if LOREM_TEXTS.get(f"p{no}_intro_{i}")]
    base = intros[0] if intros else ""

    # Chapter X.1
    story.append(Paragraph(f"Chapter {no}.1 &nbsp;&nbsp;{p['chapters'][0]}", H1))
    story.append(Paragraph(p["subtitle"], ITAL))
    story.append(Spacer(1, 8))
    story.append(Paragraph(intros[0] if intros else "", BODY))
    if len(intros) > 1:
        story.append(Paragraph(intros[1], BODY))
    story.append(Spacer(1, 8))
    hero = {1: V["court_hierarchy"], 2: V["banker_customer_quad"], 3: V["loan_recovery_flow"],
            4: V["foreclosure_flow"], 5: V["guarantor_defences"], 6: V["bankruptcy_flow"],
            7: V["winding_up_flow"], 8: V["islamic_v_conv"], 9: V["cheque_dishonor"],
            10: V["procedure_radial"]}[no]
    story.append(Image(hero, width=FRAME_W*0.92, height=FRAME_H*0.45, kind="proportional"))
    _append_voices(no, story)
    story.append(PageBreak())

    sec_a = {1: V["statutory_map"], 2: V["section_cover_2"], 3: V["o14_flow"],
             4: V["foreclosure_timeline"], 5: V["guarantor_defences"], 6: V["bankruptcy_timeline"],
             7: V["winding_up_timeline"], 8: V["islamic_steps_h"], 9: V["mareva_quad"],
             10: V["evidence_pillars"]}[no]
    story.extend(visual_page(sec_a))

    # Authorities table
    story.append(Paragraph("Key Authorities at a Glance", H2))
    story.append(Spacer(1, 6))
    auth = CASES_BY_PART.get(no, [])
    cit_style = ParagraphStyle("aut_cit", parent=BODY_SM, fontSize=9, leading=11, fontName="Times-Roman")
    prop_style = ParagraphStyle("aut_pr", parent=BODY_SM, fontSize=9, leading=11, fontName="Times-Roman")
    hdr_style = ParagraphStyle("aut_h", parent=BODY_SM, fontSize=10, leading=12, fontName="Times-Bold", textColor=white)
    rows = [[Paragraph("Citation", hdr_style), Paragraph("Proposition", hdr_style)]]
    for a in auth:
        rows.append([Paragraph(a[0], cit_style), Paragraph(a[1], prop_style)])
    t = Table(rows, colWidths=[FRAME_W*0.40, FRAME_W*0.57])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), HexColor(NAVY)),
        ("TEXTCOLOR", (0,0), (-1,0), white),
        ("FONTNAME", (0,0), (-1,0), "Times-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 9.5),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [HexColor(PAPER), HexColor(PAPER_DARK)]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("BOX", (0,0), (-1,-1), 0.6, HexColor(GOLD_DARK)),
        ("INNERGRID", (0,0), (-1,-1), 0.3, HexColor(GOLD_DARK)),
        ("LEFTPADDING", (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    story.append(t)
    story.append(PageBreak())

    sec_b = {1: V["court_hierarchy_pillars"], 2: V["mareva_quad"], 3: V["o14_decision"],
             4: V["security_radial"], 5: V["guarantor_defences"], 6: V["bankruptcy_flow"],
             7: V["winding_up_steps"], 8: V["islamic_contracts_grid"], 9: V["cheque_dishonor"],
             10: V["ethics_quad"]}[no]
    story.extend(visual_page(sec_b))

    # Chapter X.2
    story.append(Paragraph(f"Chapter {no}.2 &nbsp;&nbsp;{p['chapters'][1]}", H1))
    story.append(Paragraph(intros[2] if len(intros) > 2 else base, BODY))
    story.append(Spacer(1, 8))
    pulls = {
        1: "&ldquo;The bank stands in the shoes of the customer until repayment is demanded.&rdquo; — Foley v. Hill",
        2: "&ldquo;The customer's money becomes the bank's money.&rdquo; — Lord Cottenham, Foley v. Hill",
        3: "&ldquo;There must be a triable issue, not a sham defence.&rdquo; — Bank Negara v. Mohd Ismail",
        4: "&ldquo;'Cause to the contrary' is to be construed restrictively.&rdquo; — Low Lee Lian v. Ban Hin Lee Bank",
        5: "&ldquo;Variation without consent discharges the surety.&rdquo; — Holme v. Brunskill",
        6: "&ldquo;The bankruptcy notice must be strictly complied with.&rdquo; — Re Liang Yik Wah",
        7: "&ldquo;Bona fide dispute on substantial grounds is the touchstone.&rdquo; — Tan Kok Tong v. Hoe Hong",
        8: "&ldquo;The civil court must defer to the SAC on Shariah questions.&rdquo; — Mohd Alias v. RHB",
        9: "&ldquo;Conversion lies against the collecting bank that fails to inquire.&rdquo; — Lim Tian Huat",
        10:"&ldquo;Banker's books carry the weight of certified evidence.&rdquo; — s.90A Evidence Act 1950",
    }
    story.append(Paragraph(pulls[no], PULL))
    _append_jurist(no, story)
    story.append(PageBreak())

    sec_c = {1: V["dispute_trend_bar"], 2: V["banker_customer_quad"], 3: V["enforcement_funnel"],
             4: V["foreclosure_timeline"], 5: V["guarantor_defences"], 6: V["bankruptcy_timeline"],
             7: V["winding_up_timeline"], 8: V["islamic_v_conv_pie"], 9: V["mareva_quad"],
             10: V["damages_pie"]}[no]
    story.extend(visual_page(sec_c))

    story.extend(two_visual_page(V["lim_periods"], V["heatmap_risk"]))

    cv = vis_check_x(f"checklist_p{no}", f"Practitioner's Checklist — Part {no}",
                     CHECKLIST_BY_CHAPTER[f"p{no}"],
                     "Diagram · Pre-action and trial-readiness verification")
    story.extend(visual_page(cv))

    # Chapter X.3
    story.append(Paragraph(f"Chapter {no}.3 &nbsp;&nbsp;{p['chapters'][2]}", H1))
    last_intro = intros[3] if len(intros) > 3 else (intros[-1] if intros else base)
    story.append(Paragraph(last_intro, BODY))
    if len(intros) > 4:
        story.append(Paragraph(intros[4], BODY))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Practical Drafting Notes", H3))
    drafting_bullets = {
        1: ["Recite the regulatory regime (FSA / IFSA) governing the facility.",
            "Plead the precise court's jurisdiction (RM threshold).",
            "Anchor every prayer to a statutory provision.",
            "Always include a costs prayer on the indemnity basis if so provided."],
        2: ["Identify the customer's mandate document precisely.",
            "Plead the breach of the relevant duty (debt / agency / fiduciary).",
            "Cite section 133 FSA when secrecy is in issue.",
            "Pray for declaratory relief alongside damages."],
        3: ["Particularise the facility, sum demanded and date of demand.",
            "Plead acceleration distinctly, with reference to the clause.",
            "State the precise account from which interest is calculated.",
            "Pray for indemnity costs if facility so provides."],
        4: ["Plead the registration date of the charge.",
            "Recite Form 16D issuance and one-month default.",
            "Annex Land Office search to affidavit.",
            "Pray for OFS, reserve price, and conduct of sale."],
        5: ["Plead the principal facility separately from the guarantee.",
            "Recite the principal-debtor clause.",
            "Plead demand on guarantor distinctly.",
            "Address known defences pre-emptively."],
        6: ["Plead the judgment debt and date.",
            "Recite issuance of bankruptcy notice (Form 3).",
            "State the act of bankruptcy precisely.",
            "Pray for receiving and adjudication orders."],
        7: ["Plead the s.466 statutory demand.",
            "Recite 21-day failure to pay or secure.",
            "State that the company is unable to pay debts.",
            "Pray for liquidator's appointment with general powers."],
        8: ["Plead the underlying Shariah contract (e.g., BBA).",
            "Address ta'widh / ibra' computation.",
            "Identify Shariah issues for s.56 CBMA reference.",
            "Plead in line with SAC published rulings."],
        9: ["Plead the cheque particulars (number, date, amount).",
            "Plead the conversion or wrongful dishonour distinctly.",
            "Address s.85 BoEA in pre-emption.",
            "Pray for damages, interest and costs."],
        10:["Use a master chronology cross-referenced to bundle.",
            "Tag every fact in submissions to evidence.",
            "Prepare three-tier authorities bundle.",
            "Have a costs schedule ready at trial."],
    }
    for b in drafting_bullets[no]:
        story.append(Paragraph(b, BULL))
    _append_filler(no, DRAFT_NOTES_PROSE, story)
    story.append(PageBreak())

    sec_d = {1: V["procedure_radial"], 2: V["banker_customer_quad"], 3: V["steps_h_lod"],
             4: V["security_radial"], 5: V["guarantor_defences"], 6: V["bankruptcy_flow"],
             7: V["winding_up_steps"], 8: V["islamic_steps_h"], 9: V["enforcement_funnel"],
             10: V["procedure_radial"]}[no]
    story.extend(visual_page(sec_d))

    sec_e = {1: V["mind_loan_recovery"], 2: V["banker_customer_quad"], 3: V["mind_loan_recovery"],
             4: V["security_radial"], 5: V["banker_customer_quad"], 6: V["bankruptcy_flow"],
             7: V["winding_up_flow"], 8: V["islamic_contracts_grid"], 9: V["cheque_dishonor"],
             10: V["procedure_radial"]}[no]
    story.extend(visual_page(sec_e))

    # Strategic + pitfalls
    story.append(Paragraph("Strategic Considerations", H2))
    strategic = {
        1: ("The litigator's first task is to map the dispute against the architecture set out "
            "in this Part. A misclassification — treating an Islamic facility as conventional, "
            "or filing a winding-up petition where bankruptcy is the appropriate remedy — can "
            "cost months of progress. The diagrams in this Part are intended to be working tools."),
        2: ("Disputes at the banker–customer interface frequently turn on the precise scope of "
            "the bank's duty. Early identification of the operative duty — and its statutory or "
            "common-law source — informs both pleading and discovery strategy."),
        3: ("Loan recovery moves on documents. The strength of the bank's documentary trail — "
            "from facility letter to LOD to statement of account — usually determines the speed "
            "and certainty of recovery. Investing in document preparation pays compound returns "
            "at every later stage."),
        4: ("Foreclosure litigation is largely procedural. The chargor's principal weapon is "
            "'cause to the contrary'. Anticipating the typical objections — defective demand, "
            "incorrect quantum, fraud — and pre-empting them in the OS affidavit is the surest "
            "path to a quick OFS."),
        5: ("Guarantee enforcement is fertile ground for technical defences. The bank's "
            "discipline — preserving documents, formally notifying variations, recording "
            "consents — is its best inoculation. A surety with a creative lawyer will look for "
            "any procedural slip."),
        6: ("Bankruptcy is no longer the simple device it once was. The 2017 amendments raised "
            "thresholds, introduced safeguards for guarantors and broadened the discharge "
            "regime. A bank that once filed bankruptcy reflexively now needs to consider "
            "whether the procedure remains commercially worthwhile."),
        7: ("Winding-up is fast — but the bona fide dispute defence is omnipresent. A "
            "well-prepared debtor-respondent will plead a counterclaim or an arbitration "
            "clause to defeat the petition. Petitioning banks must therefore stress-test "
            "their statutory demand for any weakness."),
        8: ("Islamic banking litigation requires a dual-track mindset. The pleadings, the "
            "procedure and the relief sought are governed by civil law; the substantive "
            "validity of the underlying contract is governed by Shariah. Crossing back and "
            "forth between the two is the daily work of the practitioner."),
        9: ("Cheque cases turn on the bank's process. The collecting bank's customer "
            "due-diligence file, account-opening interviews and transaction monitoring are "
            "routinely subpoenaed. A bank with weak KYC will struggle on the s.85 defence."),
        10:("The practitioner's edge is process. Master the workflow, the bundle and the "
            "chronology, and the substantive doctrines tend to take care of themselves. "
            "Banking litigation rewards the methodical."),
    }[no]
    story.append(Paragraph(strategic, BODY))
    story.append(Spacer(1, 8))
    story.append(Paragraph("Common Pitfalls", H3))
    pitfalls = {
        1: ["Filing in the wrong court level for the quantum.",
            "Missing limitation by failing to compute from default.",
            "Overlooking parallel regulatory action by BNM."],
        2: ["Disclosing customer information without Schedule 11 cover.",
            "Treating the bank as a fiduciary without specific facts.",
            "Failing to follow Quincecare red flags."],
        3: ["LOD that does not particularise the demand.",
            "Affidavit by an officer without personal knowledge.",
            "Statement of Claim that misstates the principal sum."],
        4: ["Form 16D issued before default has actually crystallised.",
            "Reserve price set unrealistically and challenged on appeal.",
            "Failing to address parallel caveat or competing interest."],
        5: ["Allowing material variation without guarantor consent.",
            "Releasing co-surety without preserving claim against others.",
            "Losing security through negligence."],
        6: ["Defective bankruptcy notice (wrong sum, wrong form).",
            "Late filing of creditor's petition (>6 months).",
            "Failing to update the judgment for partial payment."],
        7: ["Statutory demand for a disputed sum.",
            "Defective service at registered office.",
            "Failure to advertise petition properly."],
        8: ["Pleading the Islamic facility as if it were conventional.",
            "Missing the s.56 CBMA reference trigger.",
            "Mis-computing ta'widh / ibra'."],
        9: ["Failing to preserve the original cheque.",
            "Inadequate KYC documentation undermining s.85 defence.",
            "Missing limitation under s.6 LA 1953."],
        10:["No master chronology or witness map.",
            "Disorganised bundle costing the trial.",
            "Failure to compute and claim correct costs."],
    }[no]
    for ptf in pitfalls:
        story.append(Paragraph(ptf, BULL))
    _append_filler(no, PITFALL_PROSE, story)
    story.append(PageBreak())

    sec_f = {1: V["court_hierarchy"], 2: V["banker_customer_quad"], 3: V["loan_recovery_flow"],
             4: V["foreclosure_flow"], 5: V["guarantor_defences"], 6: V["bankruptcy_flow"],
             7: V["winding_up_flow"], 8: V["islamic_v_conv"], 9: V["cheque_dishonor"],
             10: V["procedure_radial"]}[no]
    story.extend(visual_page(sec_f))

    # =========================================================
    # DEEP DIVE — additional visual pages to give the part depth
    # =========================================================
    build_deep_dive(p, V, story)

    # Recap
    story.append(Paragraph(f"Part {no} — Summary &amp; Forward Look", H2))
    story.append(Paragraph(
        "This Part has set out — visually, deliberately — the architecture, procedure and "
        "strategic considerations of " + p["title"].lower() + ". The diagrams should be "
        "marked, annotated and revisited as the practitioner returns to similar files. The "
        "Authorities Table will repay regular consultation. The next Part takes the discussion "
        "forward, building on the foundations laid here.", BODY))
    story.append(Spacer(1, 10))
    story.append(Paragraph("Self-Test (no peeking)", H3))
    questions = {
        1: ["Which statute governs Islamic banking facilities in Malaysia?",
            "What is the limitation period for a simple-contract banking debt?",
            "Which court has unlimited civil jurisdiction in banking matters?"],
        2: ["State the principle in Foley v. Hill.",
            "Cite the section governing banking secrecy under the FSA 2013.",
            "Define the Quincecare duty in one sentence."],
        3: ["What are the five elements of an effective LOD?",
            "What is the standard for resisting an O.14 application?",
            "Name three execution mechanisms post-judgment."],
        4: ["What does 'cause to the contrary' mean under s.256 NLC?",
            "Distinguish Registry-title from Land Office foreclosure.",
            "What is the role of Form 16D?"],
        5: ["What is the rule in Holme v. Brunskill?",
            "How does a principal-debtor clause modify the surety's liability?",
            "Name three defences usually unavailable to a guarantor."],
        6: ["What is the current bankruptcy threshold?",
            "How is an act of bankruptcy committed?",
            "Within what time must a creditor's petition be filed?"],
        7: ["What is the s.466 winding-up threshold?",
            "How long is the statutory demand period?",
            "Cite one defence to a winding-up petition."],
        8: ["What is BBA?",
            "When must a court refer to the SAC?",
            "Distinguish ta'widh from interest."],
        9: ["State the s.85 BoEA defence in your own words.",
            "What is conversion in the context of a cheque?",
            "Name three indicators of irregularity in a cheque."],
        10:["What is the role of s.90A Evidence Act?",
            "What are the four ethical compass-points for the banking litigator?",
            "Name three components of a costs schedule."],
    }[no]
    for q in questions:
        story.append(Paragraph("&#9670;&nbsp;&nbsp;" + q, BULL))
    _append_jurist(no, story)
    story.append(Paragraph("Forward Look", H3))
    story.append(Paragraph(
        "The next Part of this volume builds directly on the foundations laid here. "
        "Practitioners are encouraged to revisit the diagrams in this Part as they "
        "encounter the corresponding doctrines in their own files; the visuals are "
        "intended to function as desk references long after the first reading.", BODY))
    story.append(Paragraph(
        "Three habits will accelerate the practitioner's mastery of the material in "
        "this Part: first, annotate the Authorities Table with case-specific notes; "
        "second, redraw the principal diagrams freehand on a blank page once a "
        "month for the next quarter; third, run any new file against the Part's "
        "self-test questions before the first internal case conference.", BODY))
    story.append(PageBreak())


if __name__ == "__main__":
    build_book()
