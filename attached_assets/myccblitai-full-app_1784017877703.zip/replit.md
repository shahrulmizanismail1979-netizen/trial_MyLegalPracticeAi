# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## MyCCBLitAI

**Malaysian Corporate, Commercial & Banking Litigation AI Practice Platform**

Full-stack AI-powered legal practice platform by Mohd Saufi Samsudin, Mohd Irwan Mohd Mubarak, Shahrul Mizan Ismail and Mahmud Hamdi Mahmud Saedon (Faculty of Law, UKM). Part of the family: MyLitAI, MySyariahAI, MyConveyAI, MyCorpAI.

- **Artifact**: `artifacts/myccblitai` (react-vite, preview at `/`, port 18959)
- **API Server**: `artifacts/api-server` (Express 5, port 8080)
- **Design**: Dark navy/charcoal theme with gold/amber accents (#D4AF37)
- **Font**: Inter (sans), Playfair Display (serif headings)
- **AI**: Gemini 2.5 Flash via `@workspace/integrations-gemini-ai`. Client supports user-supplied `GEMINI_API_KEY` (Google AI Studio) or `sk-...` (OpenAI fallback adapter, mapped to gpt-4o/gpt-4o-mini). Falls back to Replit AI Integrations proxy if neither is set.
- **Auth**: Access code verification (codes: CCBLIT2024, MYCCBLIT, UKM2024, PRACTITIONER)

### Pages & Routes
- `/` — Landing page (hero, coverage badges, three pillars, AI features, CTA, footer)
- `/access` — Access code entry (gated authentication)
- `/workspace` — Dashboard with 38 AI legal tools grouped by 7 categories, hero stats, quick actions
- `/workspace/tool/:toolId` — Individual tool page with form + SSE streaming output
- `/workspace/chat` — Legal AI Chat assistant with conversation history
- `/workspace/calculators` — Client-side legal calculators (Limitation Period, Court Filing Fees, Legal Interest)
- `/workspace/reference` — Legal reference library (Malaysian statutes, case law, court rules)
- `/workspace/strategy` — Case Strategy Wizard (multi-step AI-powered strategy planner)

### AI Tools (38 total)
Each tool now ships with a "Load Sample" button (Wand2 icon) that fills the form with realistic Malaysian sample inputs. Examples + sampleNotes live in `artifacts/api-server/src/data/tool-examples.ts` and are merged into `/api/tools/list` responses.

**Corporate Litigation (6)**: Statement of Claim, Written Submission, Affidavit, Legal Opinion, Securities Claim, Originating Summons
**Commercial Litigation (6)**: Demand Letter, Contract Review, Defence & Counterclaim, Injunction Application, Arbitration Clause, Reply Pleading
**Banking Litigation (4)**: Banking Recovery Advisor, Winding Up Petition, Guarantee Enforcement, Islamic Banking Dispute Advisor
**General Practice (5)**: Case Research, Litigation Risk, Costs Calculator, Legal Memo, Case Summary
**Strategic Intelligence (7)**: Case Strategy Planner, Cross-Examination Generator, Cause of Action Identifier, Opposing Argument Predictor, Judicial Approach Analyzer, Settlement Value Analyzer, Appeal Merit Assessor
**Litigation Support (7)**: Witness Statement Crafter, Chronology Builder, Pleading Consistency Checker, Judgment Enforcement Strategist, Notice of Appeal, Bill of Costs, Notice of Discontinuance
**Corporate Practice (3)**: Board Resolution Drafter, PDPA Compliance Checker, Shareholders' Agreement Analyzer

### API Endpoints
- `POST /api/auth/verify` — Access code verification (returns JWT)
- `GET /api/tools/list` — List all 38 AI tools (each with `example` and `sampleNote` for one-click sample loading)
- `POST /api/tools/generate` — SSE streaming tool output via Gemini AI
- `GET/POST/DELETE /api/gemini/conversations` — CRUD conversations
- `GET/POST /api/gemini/conversations/:id/messages` — Chat messages (POST streams via SSE)

### Proxy Configuration
Vite dev server proxies `/api` requests to `http://localhost:8080` (API server).

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (ESM bundle)
- **Frontend**: React + Vite + Tailwind CSS v4 + shadcn/ui
- **AI**: Gemini 2.5 Flash (`@google/genai`) via Replit integrations
- **Auth**: JWT (`jsonwebtoken`) for access code tokens

### Important Notes
- Tailwind v4: Do NOT use `@apply dark` in CSS. Use `color-scheme: dark` and `document.documentElement.classList.add("dark")` in main.tsx
- SSE streaming: Use raw `fetch()` + `ReadableStream` for tool generation and chat messages, NOT generated React Query hooks
- `@google/genai` must NOT be in esbuild externals — removed `@google/*` from `build.mjs` externals list
- DB schema exports `conversations` and `messages` (not `conversationsTable`/`messagesTable`)
- In JSX text content, use `{'<'}` or `{'>'}` instead of raw `<` or `>` characters to avoid parse errors

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
