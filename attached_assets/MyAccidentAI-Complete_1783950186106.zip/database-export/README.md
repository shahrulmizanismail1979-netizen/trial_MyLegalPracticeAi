# MyAccidentAI — Database Export (generated 13 July 2026)

This folder contains a full export of all user data (access codes + login usage history).

## Files
- `production-users.sql` — ALL 83 live access codes (legacy users) + 33 login session records from the PUBLISHED app. Run this against a fresh database to restore every existing user.
- `development-users.sql` — the 4 test codes from the development database.
- `production-access-codes.csv` / `production-usage.csv` — the same production data in spreadsheet form (open in Excel).
- `development-access-codes.csv` / `development-usage.csv` — development data in spreadsheet form.
- `schema.sql` — the table structure (run this FIRST on a new database, then the users .sql file).

## How to restore on a new server
1. Create a PostgreSQL database.
2. Run `schema.sql`.
3. Run `production-users.sql`.
All existing access codes (AIKOL, MMU, HSG Legal, Mohd Irwan, individual lawyer emails, etc.) will work immediately.
