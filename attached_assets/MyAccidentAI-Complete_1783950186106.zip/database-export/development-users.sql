-- MyAccidentAI DEVELOPMENT (test data) database export — generated 2026-07-13
  -- Tables: access_codes (user access codes / legacy users), access_code_usage (login sessions)
  -- Restore into a PostgreSQL database that already has the schema (see schema.sql).

  INSERT INTO access_codes (id, code, label, max_users, current_users, is_active, expires_at, created_at) VALUES
  (1, '6558EAE8', 'Test Batch', 10, 1, TRUE, NULL, '2026-04-16T04:29:30.601241+00:00'),
  (2, 'F7B65F2E', 'E2E Test Code', 5, 1, TRUE, NULL, '2026-04-16T04:33:00.425376+00:00'),
  (3, 'TESTCODE', 'Test', 50, 8, TRUE, NULL, '2026-04-16T05:28:50.103923+00:00'),
  (4, 'MYAI-EA6EB7', 'Owner Access', 100, 14, TRUE, NULL, '2026-04-23T23:35:05.060961+00:00')
ON CONFLICT (id) DO NOTHING;

INSERT INTO access_code_usage (id, access_code_id, session_id, used_at) VALUES
  (1, 1, 'bd24b21a-1728-4260-9e38-0b14b274076d', '2026-04-16T04:29:35.136845+00:00'),
  (2, 2, '05519bc5-375d-4b18-b9d2-2d550a959166', '2026-04-16T04:33:11.094239+00:00'),
  (3, 3, '1b1b20f3-cbcd-4338-89a2-35fe8f45115b', '2026-04-16T05:28:50.392968+00:00'),
  (4, 3, 'da5f81b8-23be-4fcc-bb6e-c97f43613158', '2026-04-16T05:29:38.577274+00:00'),
  (5, 4, 'b60667cf-b074-491b-9c1b-5cdf79ee4389', '2026-04-23T23:36:13.854116+00:00'),
  (6, 4, '6f00de77-2967-4bab-a393-91cfcfa2fe30', '2026-05-05T01:34:05.369019+00:00'),
  (7, 4, 'd282bbc1-a24f-4272-84ed-aad7e15a66ad', '2026-05-05T01:38:54.58473+00:00'),
  (8, 4, '49aaf3c9-5b2d-4110-b4ee-f99b3bc252a1', '2026-05-05T01:39:08.465937+00:00'),
  (9, 4, 'b61c443b-8293-4d08-9d46-e958e926e765', '2026-05-05T01:41:14.041272+00:00'),
  (11, 4, 'a30650d5-5434-4578-a275-71f5ad9000ad', '2026-05-05T02:00:58.513449+00:00'),
  (12, 4, '7794786d-daf2-41ff-b7b9-3e89abfe8333', '2026-05-05T02:05:59.232311+00:00'),
  (13, 4, '06cc0d89-563a-4256-bce3-f6f820165728', '2026-05-18T04:29:26.46542+00:00'),
  (14, 4, '02ba69c6-0f19-46c7-bd48-f73d97417a74', '2026-05-18T04:29:31.45629+00:00'),
  (15, 4, '29702edb-d7c3-4042-99f7-4f6ae1811354', '2026-05-18T04:30:34.989877+00:00'),
  (16, 4, '666eba21-5611-4465-9358-46724e3733ce', '2026-05-18T04:36:11.64417+00:00'),
  (17, 4, 'c1fbe446-9ed3-44dc-8504-7b29dbdbeb4c', '2026-05-18T04:36:17.714917+00:00'),
  (18, 4, '52a331c9-4f55-4018-a9d1-e1a62350d1da', '2026-05-18T04:36:43.600936+00:00'),
  (19, 4, 'b20a748f-c5a4-4828-b2fa-ae66bec9be92', '2026-05-18T04:37:26.220819+00:00'),
  (24, 3, 'badd9085-98db-4255-8574-0190f28fde51', '2026-07-13T12:38:23.38432+00:00'),
  (26, 3, '976dd2ea-b880-4ed9-8ed8-5c2a8e268a2b', '2026-07-13T12:40:11.912334+00:00'),
  (27, 3, 'dc97ea0d-e9ff-4ae0-b15e-708381f1dfc9', '2026-07-13T12:42:48.12843+00:00'),
  (29, 3, '8e006fca-979b-4bed-b975-2d3cbc38de0d', '2026-07-13T12:47:52.440505+00:00'),
  (30, 3, '1af137bc-cdee-48d1-845b-9fd3ca593afd', '2026-07-13T12:54:28.312082+00:00'),
  (32, 3, 'd2d57a51-74ca-4004-bc72-f3f809a7794b', '2026-07-13T12:56:17.366079+00:00')
ON CONFLICT (id) DO NOTHING;

  SELECT setval(pg_get_serial_sequence('access_codes','id'), COALESCE((SELECT MAX(id) FROM access_codes), 1));
  SELECT setval(pg_get_serial_sequence('access_code_usage','id'), COALESCE((SELECT MAX(id) FROM access_code_usage), 1));
  