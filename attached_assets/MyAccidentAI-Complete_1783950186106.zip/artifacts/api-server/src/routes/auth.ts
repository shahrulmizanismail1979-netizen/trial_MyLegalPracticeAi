import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, accessCodesTable, accessCodeUsageTable } from "@workspace/db";
import { VerifyAccessCodeBody, VerifyAccessCodeResponse, CheckSessionResponse, LogoutResponse } from "@workspace/api-zod";
import crypto from "crypto";

const router: IRouter = Router();

const MASTER_ACCESS_PASSWORD = process.env.MASTER_ACCESS_PASSWORD || "240680";
const SESSION_SECRET = process.env.SESSION_SECRET || "dev-session-secret-change-me";
const MASTER_LABEL = "Master Access";

function signMasterNonce(nonce: string): string {
  return crypto.createHmac("sha256", SESSION_SECRET).update(`master:${nonce}`).digest("hex");
}

function createMasterToken(): string {
  const nonce = crypto.randomBytes(16).toString("hex");
  return `master.${nonce}.${signMasterNonce(nonce)}`;
}

export function isMasterToken(token: string | undefined): boolean {
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3 || parts[0] !== "master") return false;
  const expected = signMasterNonce(parts[1]);
  const provided = Buffer.from(parts[2]);
  const valid = Buffer.from(expected);
  return provided.length === valid.length && crypto.timingSafeEqual(provided, valid);
}

function setSessionCookies(res: any, sessionId: string, label: string): void {
  res.cookie("session_id", sessionId, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  });

  res.cookie("code_label", label, {
    httpOnly: false,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  });
}

router.post("/auth/verify-code", async (req, res): Promise<void> => {
  const parsed = VerifyAccessCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const code = parsed.data.code.trim().toUpperCase();

  if (
    parsed.data.code.trim() === MASTER_ACCESS_PASSWORD ||
    code === MASTER_ACCESS_PASSWORD.trim().toUpperCase()
  ) {
    const masterToken = createMasterToken();
    setSessionCookies(res, masterToken, MASTER_LABEL);
    res.json(VerifyAccessCodeResponse.parse({
      valid: true,
      message: "Master access granted",
      sessionId: masterToken,
    }));
    return;
  }

  const [accessCode] = await db
    .select()
    .from(accessCodesTable)
    .where(and(eq(accessCodesTable.code, code), eq(accessCodesTable.isActive, true)));

  if (!accessCode) {
    res.status(401).json({ error: "Invalid access code" });
    return;
  }

  if (accessCode.expiresAt && new Date(accessCode.expiresAt) < new Date()) {
    res.status(401).json({ error: "This access code has expired" });
    return;
  }

  if (accessCode.currentUsers >= accessCode.maxUsers) {
    res.status(401).json({ error: "This access code has reached its maximum number of users" });
    return;
  }

  const sessionId = crypto.randomUUID();

  await db.insert(accessCodeUsageTable).values({
    accessCodeId: accessCode.id,
    sessionId,
  });

  await db
    .update(accessCodesTable)
    .set({ currentUsers: sql`${accessCodesTable.currentUsers} + 1` })
    .where(eq(accessCodesTable.id, accessCode.id));

  res.cookie("session_id", sessionId, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  });

  res.cookie("code_label", accessCode.label, {
    httpOnly: false,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  });

  res.json(VerifyAccessCodeResponse.parse({
    valid: true,
    message: "Access granted",
    sessionId,
  }));
});

router.get("/auth/check-session", async (req, res): Promise<void> => {
  const sessionId = req.cookies?.session_id;

  if (!sessionId) {
    res.json(CheckSessionResponse.parse({ authenticated: false, codeLabel: null }));
    return;
  }

  if (isMasterToken(sessionId)) {
    res.json(CheckSessionResponse.parse({ authenticated: true, codeLabel: MASTER_LABEL }));
    return;
  }

  const [usage] = await db
    .select()
    .from(accessCodeUsageTable)
    .where(eq(accessCodeUsageTable.sessionId, sessionId));

  if (!usage) {
    res.json(CheckSessionResponse.parse({ authenticated: false, codeLabel: null }));
    return;
  }

  const [code] = await db
    .select()
    .from(accessCodesTable)
    .where(eq(accessCodesTable.id, usage.accessCodeId));

  res.json(CheckSessionResponse.parse({
    authenticated: true,
    codeLabel: code?.label || null,
  }));
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const sessionId = req.cookies?.session_id;
  if (sessionId) {
    const [usage] = await db
      .select()
      .from(accessCodeUsageTable)
      .where(eq(accessCodeUsageTable.sessionId, sessionId));
    if (usage) {
      await db.delete(accessCodeUsageTable).where(eq(accessCodeUsageTable.sessionId, sessionId));
      await db
        .update(accessCodesTable)
        .set({ currentUsers: sql`GREATEST(${accessCodesTable.currentUsers} - 1, 0)` })
        .where(eq(accessCodesTable.id, usage.accessCodeId));
    }
  }
  res.clearCookie("session_id", { path: "/" });
  res.clearCookie("code_label", { path: "/" });
  res.json(LogoutResponse.parse({ message: "Logged out successfully" }));
});

export default router;
