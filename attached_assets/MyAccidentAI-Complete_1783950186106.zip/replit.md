# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + Tailwind CSS v4 + shadcn/ui

## Artifacts

### MyAccidentAi (`artifacts/my-accident-ai`)
- AI-powered legal practice platform for Accident, Personal Injury & Running Down matters in Malaysian law
- Created by Prof Madya Dr Shahrul Mizan Ismail (UKM)
- Dark theme with amber/gold accent colors
- Preview path: `/`
- Uses: wouter routing, framer-motion animations, lucide-react icons, Playfair Display + Inter fonts

#### Content Verification System
- `CaseLaw` type in `data.ts` includes optional `verified?: false` and `verifyNote?: string` fields. Missing fields = "not yet editor-reviewed" (no badge); `verified: false` = explicitly flagged.
- CasesTab renders an amber "Unverified — verify before citing" badge + italic note only for explicitly flagged entries, plus a "Flagged unverified only" filter button and a "Recent (2020+)" year filter.
- Three Maisarah-flagged Malaysian cases (Sivamani v Valliammal [1965]; Govt v Jumat bin Mahmud [1977]; Lim Eng Kay v Jaafar [1982]) and all newly added post-2022 entries (AmGeneral v Sa'Amran [2022]; Chen Boon Kwee [2025]; Ahmad Zulfendi [2022]) are marked `verified: false` pending Prof's review.
- All workspace search tabs (Theory, Cases, Statutes, Workflows, Documents, Glossary, Applications, AI Assistant) use the shared `tokenize` / `matchesTokens` helpers in `workspace.tsx` — every search token must appear somewhere in the row's combined text (name/desc/category/etc.), giving robust order-insensitive search.

#### Pages
- **Home** (`/`): Landing page with hero, AI feature previews (6 interactive tabs), legal database section, practice areas, testimonials
- **Login** (`/login`): Access code entry for practitioners
- **Workspace** (`/workspace`): Authenticated workspace with 10 sidebar tabs:
  - Theory & Principles (theory topics — Core Principles, Defences, Liability, Damages, Claims, Procedure, Insurance, Evidence; incl. multiplier-multiplicand, Smith v Manchester, dependency/estate claims, Roberts v Johnstone, life care plans, seat belt reductions, vicarious liability, Bolam-Bolitho, interest, mitigation, court hierarchy/jurisdiction)
  - Case Law Database (landmark Malaysian cases, sort by year/name, category filtering)
  - Statutes & Sections (statutes incl. Rules of Court 2012, GPA 1956, PAPA 1948, Road Transport Act 1987, Courts of Judicature Act 1964, Subordinate Courts Act 1948, Evidence Act 1950 — expandable sections)
  - Notices of Application (interlocutory NoAs with rule, purpose, requirements, outcome — Interim Payment, Summary Judgment, Striking Out, Default Judgment, Discovery, Mareva, Anton Piller, Norwich Pharmacal, Third Party, Amendment, Further Particulars, Set Aside Default, Security for Costs, Stay of Execution, Substituted Service, Consolidation, all enforcement NoAs)
  - Practice Workflows (step-by-step workflows incl. fatal/dependency, pedestrian knockdown, settlement & court approval, appeal to Court of Appeal, interlocutory application workflows)
  - Document Templates (templates incl. all NoA templates, supporting affidavits, fatal/estate SOCs, Scott Schedule, future loss schedule, Calderbank offer, conditional fee retainer, expert instruction)
  - Practice Checklists (interactive checklists incl. Interim Payment, Summary Judgment, Discovery, Enforcement, Fatal/Dependency, Quantum Prep, Limitation Diary, Expert Brief, Settlement Negotiation)
  - Legal Glossary (terms incl. multiplier, multiplicand, lost years, Smith v Manchester, Roberts v Johnstone, bereavement, dependency, novus actus, volenti, WPI, provisional damages, plus all interlocutory and enforcement terminology)
  - AI Damages Calculator (4 modes with multiplier-multiplicand, contributory negligence slider, comparable awards guide)
  - AI Legal Assistant (detailed Q&As with filter search and expand/collapse — limitation, contributory negligence, future loss calculation, court hierarchy/jurisdiction, dependency calculation, seat belt reductions, key deadlines/timelines, LFE vs earning capacity, interlocutory applications, Mareva, enforcement, MIB, government liability, s.96 RTA, discovery)
- **Admin** (`/admin`): Admin dashboard for managing access codes (create, toggle, delete, stats)

#### Key Content Files
- `src/components/workspace/data.ts` — all legal content data (theory, cases, statutes, workflows, documents, checklists, glossary)
- `src/components/workspace/calculator-tab.tsx` — comprehensive AI damages calculator component

#### Authentication
- Cookie-based sessions: `session_id` (httpOnly) + `code_label` for users; `admin_session` (signed token) for admin
- Access codes with per-code user limits tracked via `access_codes` and `access_code_usage` DB tables
- Access codes are case-insensitive: input is uppercased on client and server, and admin-created codes are stored uppercase
- Logout decrements user count and removes session record
- Admin password: set via `ADMIN_PASSWORD` env var (fallback: "admin123")
- Admin tokens are server-validated random hex strings (not forgeable)

### API Server (`artifacts/api-server`)
- Express 5 API serving at `/api` prefix
- Routes: auth (verify-code, check-session, logout), admin (login, check, CRUD access codes, dashboard)
- Cookie-parser for session management
- CORS with credentials enabled

## Database Schema
- `access_codes`: id, code (unique), label, maxUsers, currentUsers, isActive, expiresAt, createdAt
- `access_code_usage`: id, accessCodeId (FK), sessionId, usedAt

## Practice Checklists

`artifacts/my-accident-ai/src/components/workspace/checklists-tab.tsx` — interactive checklists with:
- Per-item toggle, add/delete custom items, per-checklist reset
- localStorage persistence under stable string IDs (key: `myaccidentai.checklists.v2`); resilient to data.ts reordering
- Export to Word (.docx via `docx` + `file-saver`), Send to Google Docs (downloads .docx + opens docs.google.com upload), Print/PDF, Copy as plain text

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
