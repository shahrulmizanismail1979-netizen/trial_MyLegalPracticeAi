MYCorpLegalAI — Legacy User Export
==================================

This folder contains all 94 user access codes exported from the LIVE
(production) database, including legacy full-access users and Stripe
subscribers.

Files:
- access_codes.csv          — spreadsheet-friendly list of every user
                              (code, label, tier, active status, Stripe
                              customer/subscription IDs, expiry)
- restore_access_codes.sql  — run this against a PostgreSQL database that
                              already has the app's schema to re-create
                              all users exactly as they are in production.

To restore users into a new database:
1. Set up the app and push the schema:  pnpm --filter @workspace/db run push
2. Run the SQL file:                    psql "$DATABASE_URL" -f restore_access_codes.sql

Notes:
- Active login sessions were NOT exported (they are temporary; users simply
  log in again with their code).
- Treat these files as confidential — access codes are login credentials.
