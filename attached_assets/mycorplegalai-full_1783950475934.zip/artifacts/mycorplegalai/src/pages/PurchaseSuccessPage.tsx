import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { Scale, Loader2, CheckCircle2, Copy, Check, AlertTriangle } from "lucide-react";

const API_BASE = import.meta.env.VITE_API_URL || "";

const TIER_LABELS: Record<string, string> = {
  legacy_full: "Full Access",
  firm: "Firm",
  practitioner: "Practitioner",
  student: "Student",
};

type State =
  | { status: "loading" }
  | { status: "complete"; code: string; tier: string }
  | { status: "error"; message: string };

export default function PurchaseSuccessPage() {
  const [state, setState] = useState<State>({ status: "loading" });
  const [copied, setCopied] = useState(false);
  const pollRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const sessionId = new URLSearchParams(window.location.search).get("session_id");
    if (!sessionId) {
      setState({ status: "error", message: "Missing checkout session. Please contact support." });
      return;
    }

    let attempts = 0;
    let active = true;

    const poll = async () => {
      attempts += 1;
      try {
        const res = await fetch(`${API_BASE}/api/billing/order/${sessionId}`);
        const data = await res.json();
        if (!active) return;
        if (data.status === "complete" && data.code) {
          setState({ status: "complete", code: data.code, tier: data.tier });
          return;
        }
        if (data.error) {
          setState({ status: "error", message: data.error });
          return;
        }
      } catch {
        /* keep polling */
      }
      if (!active) return;
      if (attempts >= 20) {
        setState({
          status: "error",
          message:
            "Your payment is processing. If you don't receive your code shortly, contact support with your email.",
        });
        return;
      }
      pollRef.current = setTimeout(poll, 2000);
    };

    poll();
    return () => {
      active = false;
      if (pollRef.current) clearTimeout(pollRef.current);
    };
  }, []);

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full bg-purple-600/8 blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-primary/6 blur-[100px]" />
      </div>

      <div className="w-full max-w-md bg-card border border-purple-500/15 p-8 rounded-xl shadow-2xl z-10 relative">
        <div className="flex items-center gap-2 mb-6 justify-center">
          <Scale className="w-6 h-6 text-primary" />
          <span className="font-serif text-lg font-bold text-primary">MYCorpLegalAI</span>
        </div>

        {state.status === "loading" && (
          <div className="flex flex-col items-center text-center py-6 gap-4">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
            <div>
              <h1 className="font-serif text-xl font-bold text-foreground">Confirming your payment…</h1>
              <p className="text-sm text-muted-foreground mt-1">
                This usually takes a few seconds. Please don't close this page.
              </p>
            </div>
          </div>
        )}

        {state.status === "complete" && (
          <div className="flex flex-col items-center text-center">
            <CheckCircle2 className="w-14 h-14 text-green-400 mb-4" />
            <h1 className="font-serif text-2xl font-bold text-foreground">You're all set!</h1>
            <p className="text-sm text-muted-foreground mt-2">
              Your <span className="text-primary font-semibold">{TIER_LABELS[state.tier] ?? state.tier}</span>{" "}
              subscription is active. Here is your access code — keep it safe.
            </p>

            <div className="w-full mt-6 bg-background border border-purple-500/20 rounded-lg p-4 flex items-center justify-between gap-3">
              <code className="font-mono text-lg text-foreground tracking-wider">{state.code}</code>
              <button
                onClick={() => copyCode(state.code)}
                className="text-muted-foreground hover:text-foreground transition-colors shrink-0"
                title="Copy code"
              >
                {copied ? <Check className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>

            <p className="text-[11px] text-muted-foreground mt-3">
              Single-device login. Signing in elsewhere ends the previous session.
            </p>

            <Link
              href="/login"
              className="w-full mt-6 py-3 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-lg transition-colors text-center"
            >
              Sign in with my code
            </Link>
          </div>
        )}

        {state.status === "error" && (
          <div className="flex flex-col items-center text-center py-4">
            <AlertTriangle className="w-12 h-12 text-yellow-400 mb-4" />
            <h1 className="font-serif text-xl font-bold text-foreground">Almost there</h1>
            <p className="text-sm text-muted-foreground mt-2">{state.message}</p>
            <Link
              href="/pricing"
              className="mt-6 text-sm text-primary hover:underline font-medium"
            >
              Back to plans
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
