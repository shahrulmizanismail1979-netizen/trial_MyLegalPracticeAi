import { Router, type IRouter, type Request } from "express";
import { PLANS, getPlan, type PurchasableTier, PURCHASABLE_TIERS } from "@workspace/tiers";
import { getUncachableStripeClient } from "../../lib/stripeClient";
import { fulfillCheckoutSession } from "../../lib/access";

const router: IRouter = Router();

function getPublicOrigin(req: Request): string {
  const domain =
    process.env.REPLIT_DOMAINS?.split(",")[0]?.trim() || process.env.REPLIT_DEV_DOMAIN;
  if (domain) return `https://${domain}`;
  return `${req.protocol}://${req.get("host")}`;
}

function isPurchasableTier(value: unknown): value is PurchasableTier {
  return typeof value === "string" && (PURCHASABLE_TIERS as readonly string[]).includes(value);
}

// Public: list plans for the pricing page.
router.get("/billing/plans", (_req, res) => {
  res.json({ plans: PLANS });
});

// Public: start a Stripe Checkout session for a tier.
router.post("/billing/checkout", async (req, res): Promise<void> => {
  const { tier } = req.body ?? {};
  if (!isPurchasableTier(tier)) {
    res.status(400).json({ error: "A valid tier is required" });
    return;
  }

  try {
    const plan = getPlan(tier);
    const stripe = await getUncachableStripeClient();

    const prices = await stripe.prices.list({
      lookup_keys: [plan.stripeLookupKey],
      active: true,
      limit: 1,
    });
    const price = prices.data[0];
    if (!price) {
      req.log.error({ tier, lookupKey: plan.stripeLookupKey }, "Stripe price not found for tier");
      res.status(500).json({
        error: "This plan is not available for purchase yet. Please contact the administrator.",
      });
      return;
    }

    const origin = getPublicOrigin(req);
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: price.id, quantity: 1 }],
      metadata: { tier },
      subscription_data: { metadata: { tier } },
      allow_promotion_codes: true,
      success_url: `${origin}/purchase-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/pricing?canceled=1`,
    });

    res.json({ url: session.url });
  } catch (err) {
    req.log.error({ err }, "Failed to create checkout session");
    res.status(500).json({ error: "Could not start checkout. Please try again." });
  }
});

// Public: reveal the access code after a successful purchase (idempotent fulfillment).
router.get("/billing/order/:sessionId", async (req, res): Promise<void> => {
  const { sessionId } = req.params;
  try {
    const stripe = await getUncachableStripeClient();
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ["subscription", "customer"],
    });

    if (session.payment_status !== "paid") {
      res.json({ status: "pending" });
      return;
    }

    const code = await fulfillCheckoutSession(session);
    if (!code) {
      res.json({ status: "processing" });
      return;
    }

    res.json({
      status: "complete",
      code: code.code,
      tier: code.tier,
    });
  } catch (err) {
    req.log.error({ err, sessionId }, "Failed to fetch order");
    res.status(500).json({ error: "Could not retrieve your order. Please contact support." });
  }
});

export default router;
