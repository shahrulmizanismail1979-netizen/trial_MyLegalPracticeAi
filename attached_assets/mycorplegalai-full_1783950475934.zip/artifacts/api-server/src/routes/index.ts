import { Router, type IRouter } from "express";
import healthRouter from "./health";
import legalRouter from "./legal";
import geminiRouter from "./gemini";
import adminRouter from "./admin";
import billingRouter from "./billing";

const router: IRouter = Router();

router.use(healthRouter);
router.use(legalRouter);
router.use(geminiRouter);
router.use(adminRouter);
router.use(billingRouter);

export default router;
