import { getStripeSync } from "./stripeClient";

/**
 * Minimal Stripe webhook handler. stripe-replit-sync verifies the signature
 * (managed webhook secret) and syncs Stripe data into the `stripe` schema.
 * Access-code fulfillment happens on-demand at the purchase-success endpoint;
 * subscription status gating reads the synced `stripe.subscriptions` table.
 */
export class WebhookHandlers {
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    if (!Buffer.isBuffer(payload)) {
      throw new Error(
        "STRIPE WEBHOOK ERROR: Payload must be a Buffer. Ensure the webhook route is registered BEFORE express.json().",
      );
    }
    const sync = await getStripeSync();
    await sync.processWebhook(payload, signature);
  }
}
