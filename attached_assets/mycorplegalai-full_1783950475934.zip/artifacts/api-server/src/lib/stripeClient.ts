// Stripe integration (Replit connector "stripe").
// Credentials are fetched fresh from the Replit connection API on every call —
// never cache the client, since tokens rotate. Field names (`secret`/`publishable`)
// match the actual connection settings for this Repl.
import Stripe from "stripe";

let connectionSettings:
  | { settings?: { secret?: string; publishable?: string } }
  | undefined;

async function getCredentials(): Promise<{ publishableKey: string; secretKey: string }> {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY
    ? "repl " + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
      ? "depl " + process.env.WEB_REPL_RENEWAL
      : null;

  if (!hostname || !xReplitToken) {
    throw new Error("X-Replit-Token / connectors hostname not found for repl/depl");
  }

  const connectorName = "stripe";
  const isProduction = process.env.REPLIT_DEPLOYMENT === "1";
  const targetEnvironment = isProduction ? "production" : "development";

  const url = new URL(`https://${hostname}/api/v2/connection`);
  url.searchParams.set("include_secrets", "true");
  url.searchParams.set("connector_names", connectorName);
  url.searchParams.set("environment", targetEnvironment);

  const response = await fetch(url.toString(), {
    headers: { Accept: "application/json", "X-Replit-Token": xReplitToken },
    signal: AbortSignal.timeout(10_000),
  });

  const data = (await response.json()) as {
    items?: Array<{ settings?: { secret?: string; publishable?: string } }>;
  };
  connectionSettings = data.items?.[0];

  const secret = connectionSettings?.settings?.secret;
  const publishable = connectionSettings?.settings?.publishable;
  if (!secret || !publishable) {
    throw new Error(
      `Stripe ${targetEnvironment} connection not found. Connect Stripe via the Integrations tab.`,
    );
  }

  return { publishableKey: publishable, secretKey: secret };
}

/** Fresh authenticated Stripe client for server-side operations. Never cache. */
export async function getUncachableStripeClient(): Promise<Stripe> {
  const { secretKey } = await getCredentials();
  return new Stripe(secretKey);
}

/** Publishable key for client-side Stripe.js. */
export async function getStripePublishableKey(): Promise<string> {
  const { publishableKey } = await getCredentials();
  return publishableKey;
}

/** Secret key for server-side operations requiring it directly. */
export async function getStripeSecretKey(): Promise<string> {
  const { secretKey } = await getCredentials();
  return secretKey;
}

// StripeSync singleton for managed webhook processing + data sync.
let stripeSync: unknown = null;

export async function getStripeSync(): Promise<{
  processWebhook: (payload: Buffer | string, signature: string | undefined) => Promise<void>;
  findOrCreateManagedWebhook: (url: string) => Promise<{ url?: string }>;
  syncBackfill: () => Promise<unknown>;
}> {
  if (!stripeSync) {
    const { StripeSync } = await import("stripe-replit-sync");
    const secretKey = await getStripeSecretKey();
    stripeSync = new StripeSync({
      poolConfig: { connectionString: process.env.DATABASE_URL!, max: 2 },
      stripeSecretKey: secretKey,
    });
  }
  return stripeSync as never;
}
