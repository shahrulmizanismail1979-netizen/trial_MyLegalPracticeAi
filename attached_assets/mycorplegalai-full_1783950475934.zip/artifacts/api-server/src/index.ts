import { runMigrations } from "stripe-replit-sync";
import app from "./app";
import { logger } from "./lib/logger";
import { getStripeSync } from "./lib/stripeClient";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Initialize the Stripe `stripe` schema + managed webhook + data backfill.
// Runs in the BACKGROUND after the server is already listening — slow/fallible
// network + DB work here must never delay binding the port, or the deployment's
// startup health check (GET /api/healthz) times out and the promote step fails.
async function initStripe(): Promise<void> {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    logger.warn("DATABASE_URL not set — skipping Stripe initialization.");
    return;
  }
  try {
    await runMigrations({ databaseUrl });
    logger.info("Stripe schema ready");

    const stripeSync = await getStripeSync();
    const domain =
      process.env.REPLIT_DOMAINS?.split(",")[0]?.trim() || process.env.REPLIT_DEV_DOMAIN;
    if (domain) {
      const webhook = await stripeSync.findOrCreateManagedWebhook(
        `https://${domain}/api/stripe/webhook`,
      );
      logger.info({ url: webhook?.url }, "Stripe managed webhook configured");
    } else {
      logger.warn("No REPLIT domain found — skipping managed webhook setup");
    }

    stripeSync
      .syncBackfill()
      .then(() => logger.info("Stripe data backfill complete"))
      .catch((err) => logger.error({ err }, "Stripe data backfill failed"));
  } catch (err) {
    logger.error({ err }, "Stripe initialization failed");
  }
}

// Bind the port FIRST so health checks succeed immediately, then kick off
// Stripe initialization in the background (never awaited before listen()).
app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  void initStripe().catch((err) =>
    logger.error({ err }, "Stripe initialization crashed"),
  );
});
