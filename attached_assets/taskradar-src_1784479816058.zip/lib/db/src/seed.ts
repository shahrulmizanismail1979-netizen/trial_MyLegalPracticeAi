import { inArray } from "drizzle-orm";
import {
  db,
  pool,
  usersTable,
  tasksTable,
  taskNotesTable,
  goalsTable,
  kpisTable,
} from "./index";

function daysAgo(days: number): Date {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000);
}

function hoursAgo(hours: number): Date {
  return new Date(Date.now() - hours * 60 * 60 * 1000);
}

function daysAhead(days: number): Date {
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
}

async function seed(): Promise<void> {
  // Clear existing data (children first).
  await db.delete(taskNotesTable);
  await db.delete(kpisTable);
  await db.delete(tasksTable);
  await db.delete(goalsTable);
  await db.delete(usersTable);

  const [nurul, weijie, muthu] = await db
    .insert(usersTable)
    .values([
      {
        name: "Nurul Aiman binti Abdullah",
        role: "manager",
        email: "nurul.aiman@contoh.com.my",
        activeStatus: true,
      },
      {
        name: "Tan Wei Jie",
        role: "staff",
        email: "tan.weijie@contoh.com.my",
        activeStatus: true,
      },
      {
        name: "Muthu Krishnan",
        role: "staff",
        email: "muthu.krishnan@contoh.com.my",
        activeStatus: true,
      },
    ])
    .returning();

  // ---- GOALS (top of the cascade) ----
  const [compliance, retention, modernize] = await db
    .insert(goalsTable)
    .values([
      {
        title: "Achieve regulatory compliance readiness",
        description:
          "Close out the SSM and LHDN audit findings and clear all open items before the Q2 review.",
        ownerId: nurul.id,
        timeframe: "Q2 2026",
        status: "active",
        createdAt: daysAgo(40),
      },
      {
        title: "Improve client retention & satisfaction",
        description:
          "Lift client satisfaction and drive adoption of the new MyPortal client portal.",
        ownerId: nurul.id,
        timeframe: "Q2 2026",
        status: "active",
        createdAt: daysAgo(35),
      },
      {
        title: "Modernise firm operations",
        description:
          "Replace legacy tooling and remove manual, error-prone processes across the Petaling Jaya office.",
        ownerId: nurul.id,
        timeframe: "H1 2026",
        status: "active",
        createdAt: daysAgo(60),
      },
    ])
    .returning();

  // ---- KPIs (measurable targets per goal) ----
  await db.insert(kpisTable).values([
    {
      goalId: compliance.id,
      name: "Audit items closed",
      unit: "%",
      targetValue: 100,
      currentValue: 62,
      direction: "up",
    },
    {
      goalId: compliance.id,
      name: "Open compliance findings",
      unit: "findings",
      targetValue: 0,
      currentValue: 3,
      direction: "down",
    },
    {
      goalId: retention.id,
      name: "Client satisfaction (NPS)",
      unit: "NPS",
      targetValue: 50,
      currentValue: 38,
      direction: "up",
    },
    {
      goalId: retention.id,
      name: "Client portal adoption",
      unit: "%",
      targetValue: 80,
      currentValue: 45,
      direction: "up",
    },
    {
      goalId: modernize.id,
      name: "Systems migrated",
      unit: "systems",
      targetValue: 3,
      currentValue: 1,
      direction: "up",
    },
    {
      goalId: modernize.id,
      name: "Manual processes eliminated",
      unit: "processes",
      targetValue: 10,
      currentValue: 4,
      direction: "up",
    },
  ]);

  // ---- URGENT tasks (>=5) ----
  const urgent = await db
    .insert(tasksTable)
    .values([
      {
        // Unacknowledged + overdue => critical
        title: "Respond to LHDN inquiry on SST filing",
        description:
          "LHDN requested a formal response regarding our SST submission for the last quarter. Hard deadline.",
        category: "urgent",
        reason: "compliance",
        status: "todo",
        ownerId: weijie.id,
        createdById: nurul.id,
        createdAt: hoursAgo(9),
        lastUpdatedAt: hoursAgo(9),
        dueAt: daysAgo(1),
        acknowledgedAt: null,
      },
      {
        // Unacknowledged, > 4h old => critical
        title: "Partner escalation: Sime Property contract review",
        description:
          "Senior partner flagged the Sime Property contract for immediate review before signing.",
        category: "urgent",
        reason: "partner",
        status: "todo",
        ownerId: muthu.id,
        createdById: nurul.id,
        createdAt: hoursAgo(6),
        lastUpdatedAt: hoursAgo(6),
        dueAt: daysAhead(1),
        acknowledgedAt: null,
      },
      {
        // Acknowledged, in progress
        title: "Client wire transfer discrepancy (Maybank)",
        description:
          "Client reported a mismatch in the trust account transfer via Maybank. Finance needs to reconcile today.",
        category: "urgent",
        reason: "finance",
        status: "in_progress",
        ownerId: weijie.id,
        createdById: nurul.id,
        createdAt: hoursAgo(20),
        lastUpdatedAt: hoursAgo(2),
        dueAt: daysAhead(0),
        acknowledgedAt: hoursAgo(19),
      },
      {
        // Blocked without note => critical
        title: "Court filing deadline for Lim & Sons case",
        description:
          "Filing must be submitted to the Mahkamah Tinggi registrar. Blocked pending signature.",
        category: "urgent",
        reason: "client",
        status: "blocked",
        ownerId: muthu.id,
        createdById: nurul.id,
        createdAt: hoursAgo(30),
        lastUpdatedAt: hoursAgo(5),
        dueAt: daysAhead(2),
        acknowledgedAt: hoursAgo(29),
      },
      {
        // Acknowledged, urgent (still owned)
        title: "Security incident: suspicious login attempts",
        description:
          "IT flagged repeated failed logins on the document portal. Needs investigation.",
        category: "urgent",
        reason: "internal",
        status: "acknowledged",
        ownerId: weijie.id,
        createdById: nurul.id,
        createdAt: hoursAgo(3),
        lastUpdatedAt: hoursAgo(1),
        dueAt: daysAhead(1),
        acknowledgedAt: hoursAgo(2),
      },
      {
        // Unacknowledged manager-reason urgent
        title: "Prepare board briefing on Q2 litigation risk",
        description:
          "Managing partner needs a one-page litigation risk summary before the board call.",
        category: "urgent",
        reason: "manager",
        status: "todo",
        ownerId: muthu.id,
        createdById: nurul.id,
        createdAt: hoursAgo(5),
        lastUpdatedAt: hoursAgo(5),
        dueAt: daysAhead(2),
        acknowledgedAt: null,
      },
    ])
    .returning();

  // ---- BACKLOG tasks (>=8) ----
  const backlog = await db
    .insert(tasksTable)
    .values([
      {
        // Stale: no update 5d+
        title: "Update client intake form template",
        description:
          "Refresh the intake form to capture MyKad and conflict-check fields.",
        category: "backlog",
        reason: "internal",
        status: "in_progress",
        ownerId: weijie.id,
        createdById: nurul.id,
        createdAt: daysAgo(20),
        lastUpdatedAt: daysAgo(8),
        dueAt: daysAhead(14),
        acknowledgedAt: null,
      },
      {
        // Stale: no owner 3d+
        title: "Digitise archived case files (2019-2021)",
        description:
          "Scan and index physical case files into the document system.",
        category: "backlog",
        reason: "internal",
        status: "todo",
        ownerId: null,
        createdById: nurul.id,
        createdAt: daysAgo(6),
        lastUpdatedAt: daysAgo(6),
        dueAt: null,
        acknowledgedAt: null,
      },
      {
        // Stale: due within 7d & not started
        title: "Renew professional liability insurance",
        description: "Annual renewal paperwork for the firm's PII policy.",
        category: "backlog",
        reason: "finance",
        status: "todo",
        ownerId: muthu.id,
        createdById: nurul.id,
        createdAt: daysAgo(10),
        lastUpdatedAt: daysAgo(4),
        dueAt: daysAhead(5),
        acknowledgedAt: null,
      },
      {
        // Inactive over a week
        title: "Draft updated remote work policy",
        description: "HR requested a refreshed remote/hybrid work policy.",
        category: "backlog",
        reason: "manager",
        status: "in_progress",
        ownerId: muthu.id,
        createdById: nurul.id,
        createdAt: daysAgo(25),
        lastUpdatedAt: daysAgo(9),
        dueAt: daysAhead(20),
        acknowledgedAt: null,
      },
      {
        title: "Migrate billing system to new provider",
        description:
          "Evaluate and migrate from the legacy billing tool. Multi-week effort.",
        category: "backlog",
        reason: "finance",
        status: "in_progress",
        ownerId: weijie.id,
        createdById: nurul.id,
        createdAt: daysAgo(12),
        lastUpdatedAt: daysAgo(2),
        dueAt: daysAhead(30),
        acknowledgedAt: null,
      },
      {
        title: "Organise firm-wide compliance training",
        description: "Schedule annual ethics and compliance CPD sessions.",
        category: "backlog",
        reason: "compliance",
        status: "todo",
        ownerId: muthu.id,
        createdById: nurul.id,
        createdAt: daysAgo(3),
        lastUpdatedAt: daysAgo(1),
        dueAt: daysAhead(21),
        acknowledgedAt: null,
      },
      {
        title: "Review and renew office lease terms",
        description: "Lease is up in 4 months; begin negotiation prep.",
        category: "backlog",
        reason: "manager",
        status: "todo",
        ownerId: null,
        createdById: nurul.id,
        createdAt: daysAgo(2),
        lastUpdatedAt: daysAgo(2),
        dueAt: daysAhead(60),
        acknowledgedAt: null,
      },
      {
        title: "Build client satisfaction survey",
        description:
          "Create a quarterly NPS-style survey for active clients.",
        category: "backlog",
        reason: "client",
        status: "todo",
        ownerId: weijie.id,
        createdById: nurul.id,
        createdAt: daysAgo(1),
        lastUpdatedAt: daysAgo(1),
        dueAt: daysAhead(18),
        acknowledgedAt: null,
      },
      {
        // Blocked backlog with a note
        title: "Standardise matter numbering scheme",
        description:
          "Define a firm-wide matter numbering convention. Blocked on partner input.",
        category: "backlog",
        reason: "internal",
        status: "blocked",
        ownerId: muthu.id,
        createdById: nurul.id,
        createdAt: daysAgo(14),
        lastUpdatedAt: daysAgo(3),
        dueAt: daysAhead(25),
        acknowledgedAt: null,
      },
      {
        // Recently completed (for trend + avg completion)
        title: "Set up secure client document portal",
        description: "Stand up an encrypted portal for client file sharing.",
        category: "backlog",
        reason: "client",
        status: "done",
        ownerId: weijie.id,
        createdById: nurul.id,
        createdAt: daysAgo(9),
        lastUpdatedAt: daysAgo(1),
        dueAt: daysAgo(2),
        acknowledgedAt: null,
      },
    ])
    .returning();

  // ---- Link deliverables to goals (bottom of the cascade) ----
  await db
    .update(tasksTable)
    .set({ goalId: compliance.id })
    .where(inArray(tasksTable.id, [urgent[0].id, urgent[5].id, backlog[5].id]));
  await db
    .update(tasksTable)
    .set({ goalId: retention.id })
    .where(
      inArray(tasksTable.id, [urgent[3].id, backlog[7].id, backlog[9].id]),
    );
  await db
    .update(tasksTable)
    .set({ goalId: modernize.id })
    .where(
      inArray(tasksTable.id, [
        backlog[0].id,
        backlog[4].id,
        backlog[8].id,
      ]),
    );

  // ---- Notes ----
  await db.insert(taskNotesTable).values([
    {
      taskId: urgent[2].id,
      authorId: weijie.id,
      body: "Reconciling against the Maybank statement now, will update within the hour.",
      createdAt: hoursAgo(2),
    },
    {
      taskId: backlog[8].id,
      authorId: muthu.id,
      body: "Blocked: waiting on partner sign-off for the numbering format.",
      createdAt: daysAgo(3),
    },
    {
      taskId: backlog[4].id,
      authorId: weijie.id,
      body: "Vendor demo completed; comparing pricing tiers next.",
      createdAt: daysAgo(2),
    },
  ]);

  // eslint-disable-next-line no-console
  console.log(
    `Seeded ${urgent.length} urgent + ${backlog.length} backlog tasks, 3 users, 3 notes.`,
  );
}

seed()
  .then(async () => {
    await pool.end();
    process.exit(0);
  })
  .catch(async (err) => {
    console.error(err);
    await pool.end();
    process.exit(1);
  });
