# Threat Model

## Project Overview

TaskRadar is a publicly deployed team task-management application built with a React frontend, an Express API, PostgreSQL via Drizzle ORM, object storage for evidence files, and AI-backed meeting / voice / document ingestion. Its production deployment is public, so every `/api` route must be treated as internet-reachable. The mockup sandbox is dev-only and out of scope unless separately exposed.

## Assets

- **Team identity and contact data** — user names, email addresses, phone numbers, role assignments, and opt-in state. Exposure enables phishing, impersonation, and unauthorized privilege changes.
- **Operational task data** — tasks, notes, attempts, assessments, due dates, owners, and management metrics. This is sensitive business workflow data and controls the application’s core state.
- **Meeting and ingestion content** — meeting transcripts, minutes, screenshots, uploaded documents, Gmail-derived drafts, and voice recordings. These can contain confidential internal or client information.
- **Evidence files and stored objects** — uploaded proof-of-work files plus mirrored Drive copies. Unauthorized reads can expose sensitive documents; unauthorized writes can create storage abuse.
- **Privileged management actions** — role changes, goal/KPI edits, manager recommendations, and AI-backed task creation. Unauthorized access lets attackers control the org workflow.
- **Third-party AI and connector capacity** — OpenAI / ElevenLabs / connector-backed processing and storage are billable, finite resources that public attackers can abuse.

## Trust Boundaries

- **Browser to API** — the frontend is untrusted. Every request field, including `actingUserId`, must be treated as attacker-controlled.
- **API to PostgreSQL** — the API has broad read/write access to all operational records. Broken access control at the API layer exposes the full data set.
- **API to Object Storage** — the API can mint upload URLs and serve stored objects. Missing authorization here exposes private evidence and enables storage abuse.
- **API to External AI / connector services** — public callers can trigger expensive transcription, parsing, and document-processing flows. Abuse here can convert anonymous traffic into cost and availability impact.
- **Public to manager-only actions** — manager operations exist, but there is no production session boundary in the backend. This is the highest-risk boundary in the system.
- **Dev-only to production** — `artifacts/mockup-sandbox/**` is not treated as deployed production code unless separately proven reachable.

## Scan Anchors

- Production API entry point: `artifacts/api-server/src/app.ts` and `artifacts/api-server/src/routes/*.ts`.
- Highest-risk code areas: `routes/tasks.ts`, `routes/users.ts`, `routes/goals.ts`, `routes/meetings.ts`, `routes/ingest.ts`, `routes/storage.ts`, `routes/insights.ts`, `lib/objectStorage.ts`.
- Public vs privileged boundary: many routes are fully public; privileged routes rely on caller-supplied `actingUserId` checked by `isManagerUser()` in `lib/goalService.ts`.
- Dev-only area to usually ignore: `artifacts/mockup-sandbox/**`.

## Threat Categories

### Spoofing

The application does not establish a real server-side identity for callers. The frontend stores the selected user in localStorage, and the backend often authorizes sensitive actions by reading an `actingUserId` directly from the request and checking whether that database row has `role = manager`. Because the client is untrusted, the API must not treat caller-supplied user IDs as proof of identity. The required guarantee is that privileged and user-scoped endpoints MUST bind actions to a server-verified session or equivalent trusted identity, not to request parameters or body fields.

### Tampering

Task state, notes, attempts, evidence records, meetings, goals, KPIs, and user roles are all sensitive mutable records. Public or weakly checked write endpoints let attackers alter workflow state, delete records, inject misleading notes, and manipulate manager-visible analytics. The required guarantee is that every state-changing route MUST enforce server-side authorization based on the authenticated caller, with role checks applied before any database or storage mutation for privileged operations.

Note on the intentional open-team model: TaskRadar is a small-org collaborative tool, so task-level mutations (editing a task's fields, reassigning its owner, soft-archiving it, and adding/removing collaborators) are deliberately authorized at the **staff-session level** rather than by per-task ownership. Any authenticated staff member may mutate any task. This is an accepted product decision, NOT a missing check: the staff session gate is still a hard server-side boundary (anonymous callers are fully blocked), and `actingUserId` in those request bodies remains attribution-only and is never trusted for authorization. Privileged operations that escape this open model — role changes, goal/KPI administration, assessments, recommendations, AI task creation, and the manager dashboard — MUST still require a verified manager session (`requireManagerSession`).

### Information Disclosure

TaskRadar stores internal workflow records, meeting transcripts, evidence files, contact data, and management insights. Public read endpoints or unprotected object-serving routes can expose confidential business information to anyone on the internet. The required guarantee is that all non-public records and stored objects MUST be scoped to authorized users, and routes that return sensitive business data MUST require verified identity and access checks.

### Denial of Service

The API accepts large JSON payloads and exposes unauthenticated endpoints for audio transcription, image/document parsing, and object upload URL generation. These flows can consume CPU, memory, storage, and third-party AI spend. The required guarantee is that expensive or storage-allocating routes MUST require trusted identity, enforce tight size/rate limits, and avoid giving anonymous users a direct path to billable or high-resource operations.

### Elevation of Privilege

Manager-only functions exist, including role changes, goal administration, assessments, AI briefings, and recommendations, but the backend’s trust model allows privilege decisions to hinge on attacker-controlled identifiers. This creates a direct path from public access to manager-equivalent actions. The required guarantee is that admin and manager capabilities MUST only be reachable through a server-enforced privilege boundary tied to authenticated identity, and public discovery endpoints MUST not supply the information needed to bypass that boundary.