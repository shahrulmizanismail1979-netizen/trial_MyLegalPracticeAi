import { test, expect } from "@playwright/test";

/**
 * E2E: the AI-capture DraftReview "edit-then-create" path.
 *
 * Flow: staff login -> enter manager mode -> Inbox > Document -> upload a small
 * text file -> the AI returns task drafts -> edit the first draft's title ->
 * create -> verify the edited title becomes a real task.
 *
 * This is the deterministic UI contract of DraftReview (editing a draft before
 * committing it). The document-ingest step makes one real AI call to produce
 * drafts; the assertion is on the edit-then-create behaviour, not the AI text.
 *
 * Requires the API Server + web workflows running, and the staff/manager
 * passcodes (defaults: "spice" / "240680"; override via env).
 */

const STAFF_PASSCODE = process.env.STAFF_PASSCODE ?? "spice";
const MANAGER_PASSCODE = process.env.MANAGER_PASSCODE ?? "240680";

// Unique per run so the created task is easy to find and never collides.
const EDITED_TITLE = `E2E Draft Edit ${Date.now()}`;

const DOCUMENT_TEXT = [
  "Team action items from today's meeting:",
  "1. Aisyah must submit the SSM annual return by Friday.",
  "2. Lim to follow up with the client about the outstanding invoice.",
  "3. Prepare the LHDN tax filing documents next week.",
].join("\n");

test("DraftReview: edit a draft title then create the task", async ({ page }) => {
  // --- Staff gate ---------------------------------------------------------
  await page.goto("/");
  const passcodeInput = page.getByPlaceholder("Team passcode");
  await passcodeInput.waitFor({ state: "visible" });
  await passcodeInput.fill(STAFF_PASSCODE);
  await page.getByRole("button", { name: "Enter" }).click();

  // --- Enter manager mode (DraftReview controls are manager-only) ---------
  const enterManager = page.getByRole("button", { name: "Enter Manager Mode" });
  await enterManager.waitFor({ state: "visible" });
  await enterManager.click();
  const mgrInput = page.getByPlaceholder("Passcode");
  await mgrInput.waitFor({ state: "visible" });
  await mgrInput.fill(MANAGER_PASSCODE);
  await page.getByRole("button", { name: "Unlock" }).click();
  // The dialog closes and the sidebar shows manager mode is active.
  await expect(page.getByRole("button", { name: "Exit Manager Mode" })).toBeVisible();

  // --- Inbox > Document: upload a text file to produce drafts --------------
  await page.goto("/inbox");
  await page.getByRole("tab", { name: "Document" }).click();
  await page.locator('input[type="file"]').setInputFiles({
    name: "action-items.txt",
    mimeType: "text/plain",
    buffer: Buffer.from(DOCUMENT_TEXT, "utf-8"),
  });

  // --- DraftReview appears with at least one draft card -------------------
  // The first draft card's title is the first text Input inside the review.
  const firstTitle = page.locator('input[type="text"]').first();
  await firstTitle.waitFor({ state: "visible", timeout: 90_000 });

  // --- Edit the first draft's title, then create --------------------------
  await firstTitle.fill(EDITED_TITLE);
  await page.getByRole("button", { name: /Create \d+ task/ }).click();

  // Success toast confirms creation.
  await expect(page.getByText(/task\(s\) created/)).toBeVisible({
    timeout: 30_000,
  });

  // --- Verify the edited title became a real task -------------------------
  await page.goto("/");
  await expect(page.getByText(EDITED_TITLE).first()).toBeVisible({
    timeout: 30_000,
  });
});
