import { test, expect } from "@playwright/test";

/**
 * E2E: the Meetings "transcript -> minutes -> action item -> task" path.
 *
 * Flow: staff login -> enter manager mode -> Meetings > New Meeting ->
 * Paste transcript -> Generate minutes (one real AI call) -> land on the
 * meeting detail page -> edit the first action item (assign an owner) ->
 * Create task -> verify the action item became a real task in the task list.
 *
 * This exercises the meeting-detail `ActionItemRow` create-tasks UI, which is
 * distinct from the shared DraftReview component covered elsewhere. The action
 * item's text is rendered read-only and is used verbatim as the new task's
 * title (see POST /meetings/:id/create-tasks `fallbackTitle`), so the "edit"
 * here is choosing the owner before committing — the assertion is that the
 * action item turns into a findable task.
 *
 * Creation is manager-gated, so the flow runs in manager mode.
 *
 * Requires the API Server + web workflows running, and the staff/manager
 * passcodes (defaults: "spice" / "240680"; override via env).
 */

const STAFF_PASSCODE = process.env.STAFF_PASSCODE ?? "spice";
const MANAGER_PASSCODE = process.env.MANAGER_PASSCODE ?? "240680";

// Unique per run so the created meeting is easy to spot and never collides.
const MEETING_TITLE = `E2E Meeting ${Date.now()}`;

// A small, explicit transcript so the LLM reliably extracts an action item.
const TRANSCRIPT = [
  "Aisyah: We need to submit the SSM annual return by this Friday.",
  "Lim: I will prepare the supporting accounts before then.",
  "Aisyah: Action item — Lim to file the SSM annual return by Friday.",
].join("\n");

test("Meeting action item -> assigned task", async ({ page }) => {
  // --- Staff gate ---------------------------------------------------------
  await page.goto("/");
  const passcodeInput = page.getByPlaceholder("Team passcode");
  await passcodeInput.waitFor({ state: "visible" });
  await passcodeInput.fill(STAFF_PASSCODE);
  await page.getByRole("button", { name: "Enter" }).click();

  // --- Enter manager mode (action-item creation is manager-only) ----------
  const enterManager = page.getByRole("button", { name: "Enter Manager Mode" });
  await enterManager.waitFor({ state: "visible" });
  await enterManager.click();
  const mgrInput = page.getByPlaceholder("Passcode");
  await mgrInput.waitFor({ state: "visible" });
  await mgrInput.fill(MANAGER_PASSCODE);
  await page.getByRole("button", { name: "Unlock" }).click();
  await expect(
    page.getByRole("button", { name: "Exit Manager Mode" }),
  ).toBeVisible();

  // --- Meetings > New Meeting > Paste transcript --------------------------
  await page.goto("/meetings");
  await page.getByRole("button", { name: "New Meeting" }).click();

  await page.getByPlaceholder("e.g. Weekly compliance sync").fill(MEETING_TITLE);
  await page.getByRole("tab", { name: "Paste transcript" }).click();
  await page.locator("textarea").fill(TRANSCRIPT);

  // --- Generate minutes (one real AI call) -> meeting detail page ---------
  await page.getByRole("button", { name: "Generate minutes" }).click();

  // The dialog navigates to /meeting/:id; an action item's "Create task"
  // button appears once minutes (incl. action items) are ready.
  await page
    .getByRole("button", { name: "Create task" })
    .first()
    .waitFor({ state: "visible", timeout: 120_000 });

  // Read the first uncreated action item's text. It becomes the task title
  // verbatim, and we use it to anchor a STABLE row locator below — anchoring
  // by the (transient) "Create task" button is unsafe because that button
  // disappears once the task is created, shifting `.first()` to another row.
  const actionText = (
    await page
      .locator(".glass-card")
      .filter({ has: page.getByRole("button", { name: "Create task" }) })
      .first()
      .locator("p.font-medium")
      .first()
      .innerText()
  ).trim();
  expect(actionText.length).toBeGreaterThan(0);

  // Stable locator for that specific action-item card (its text persists
  // through the create -> "Task created" transition).
  const row = page
    .locator(".glass-card")
    .filter({ has: page.getByText(actionText, { exact: true }) });

  // --- Edit the action item: assign an owner ------------------------------
  // The first Select is the owner picker (placeholder "Unassigned"); index 0
  // of its options is "Unassigned", so the first real user is index 1.
  await row.getByRole("combobox").first().click();
  const ownerOption = page.getByRole("option").nth(1);
  await ownerOption.waitFor({ state: "visible" });
  await ownerOption.click();

  // --- Create the task from the action item -------------------------------
  await row.getByRole("button", { name: "Create task" }).click();

  // On success the row flips to a persistent "Task created" confirmation
  // (the create UI is replaced once the action item gains a taskId). This is
  // the durable success signal — the success toast is transient/racy.
  await expect(row.getByText("Task created")).toBeVisible({ timeout: 30_000 });

  // --- Verify the action item became a real task in the task list ---------
  await page.goto("/");
  await expect(page.getByText(actionText, { exact: false }).first()).toBeVisible({
    timeout: 30_000,
  });
});
