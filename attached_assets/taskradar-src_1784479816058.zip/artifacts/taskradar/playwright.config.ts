import { execSync } from "node:child_process";
import { defineConfig, devices } from "@playwright/test";

/**
 * Resolve a browser executable. Playwright's bundled Chromium needs system
 * libraries that aren't present in this NixOS environment, so we prefer a
 * system-installed Chromium when available (CHROMIUM_PATH or `which chromium`).
 * When unset, Playwright falls back to its own downloaded browser.
 */
function resolveChromiumPath(): string | undefined {
  if (process.env.CHROMIUM_PATH) return process.env.CHROMIUM_PATH;
  try {
    const found = execSync("which chromium", { encoding: "utf-8" }).trim();
    return found || undefined;
  } catch {
    return undefined;
  }
}

const executablePath = resolveChromiumPath();

/**
 * Playwright config for the TaskRadar web artifact's e2e tests.
 *
 * The app is served behind the shared Replit proxy, so we hit it through the
 * dev domain (HTTPS) rather than a service port. Set TEST_BASE_URL to override
 * (e.g. a published domain). Both the API server and web workflow must be
 * running for these tests to pass.
 */
const baseURL =
  process.env.TEST_BASE_URL ??
  (process.env.REPLIT_DEV_DOMAIN
    ? `https://${process.env.REPLIT_DEV_DOMAIN}`
    : "http://localhost:80");

export default defineConfig({
  testDir: "./e2e",
  timeout: 120_000,
  expect: { timeout: 15_000 },
  fullyParallel: false,
  retries: 0,
  reporter: [["list"]],
  use: {
    baseURL,
    headless: true,
    ignoreHTTPSErrors: true,
    screenshot: "only-on-failure",
    trace: "retain-on-failure",
  },
  projects: [
    {
      name: "chromium",
      use: {
        ...devices["Desktop Chrome"],
        launchOptions: executablePath ? { executablePath } : {},
      },
    },
  ],
});
