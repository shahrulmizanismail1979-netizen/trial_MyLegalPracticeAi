import { createRoot } from "react-dom/client";
import { setApiSecret } from "@workspace/api-client-react";
import App from "./App";
import "./index.css";

// Injected at build time by Vite (`define` in vite.config.ts). The server's
// coarse API-secret gate (`X-TaskRadar-Secret`) blocks every /api request —
// including the staff-login route — unless this header is present, so it must
// be attached before the app makes any request. Empty string in dev when the
// secret is unset (the server then skips the gate).
declare const __TASKRADAR_API_SECRET__: string;
setApiSecret(__TASKRADAR_API_SECRET__ || null);

createRoot(document.getElementById("root")!).render(<App />);
