// Injected at build time by Vite (`define` in vite.config.ts). The server's
// coarse API-secret gate (`X-TaskRadar-Secret`) blocks every /api request unless
// this header is present. The generated API client attaches it via setApiSecret,
// but raw `fetch()` calls (e.g. the storage-session bootstrap) bypass that client
// and must attach it themselves — otherwise they 401 under the gate. Empty string
// in dev when the secret is unset (the server then skips the gate).
declare const __TASKRADAR_API_SECRET__: string;

export const API_SECRET: string | null = __TASKRADAR_API_SECRET__ || null;

export function apiSecretHeaders(): Record<string, string> {
  return API_SECRET ? { "X-TaskRadar-Secret": API_SECRET } : {};
}
