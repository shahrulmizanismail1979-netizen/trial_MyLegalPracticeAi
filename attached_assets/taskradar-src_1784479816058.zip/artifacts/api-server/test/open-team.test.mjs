// Integration tests for the open-team editing, guided-drafting backend, the
// "My Tasks" (memberId) filter, and the manager-only authorization boundary.
//
// These run against a LIVE server reached through the shared Replit proxy
// (localhost:80). They are deliberately dependency-free (Node's global fetch
// only) so the repo needs no test-runner setup. Run with:
//
//   pnpm --filter @workspace/api-server run test
//
// Requires the API Server + proxy to be up and TASKRADAR_API_SECRET to be set
// in the environment (it is in this workspace). The script logs in for real
// session cookies; it never prints the secret or any cookie value.

const BASE = process.env.TEST_BASE_URL ?? "http://localhost:80/api";
const SECRET = process.env.TASKRADAR_API_SECRET ?? "";
const STAFF_PASSCODE = process.env.STAFF_PASSCODE ?? "spice";
const MANAGER_PASSCODE = process.env.MANAGER_PASSCODE ?? "240680";

let passed = 0;
let failed = 0;
const failures = [];

function check(name, cond, detail = "") {
  if (cond) {
    passed += 1;
    console.log(`  \u2713 ${name}`);
  } else {
    failed += 1;
    failures.push(`${name}${detail ? ` \u2014 ${detail}` : ""}`);
    console.error(`  \u2717 ${name}${detail ? ` \u2014 ${detail}` : ""}`);
  }
}

function baseHeaders(extra = {}) {
  const h = { "Content-Type": "application/json", ...extra };
  if (SECRET) h["X-TaskRadar-Secret"] = SECRET;
  return h;
}

// Extract a single cookie name=value pair from a fetch Response's Set-Cookie.
function cookieFrom(res, name) {
  const all =
    typeof res.headers.getSetCookie === "function"
      ? res.headers.getSetCookie()
      : [res.headers.get("set-cookie")].filter(Boolean);
  for (const line of all) {
    const m = line.match(new RegExp(`${name}=([^;]+)`));
    if (m) return `${name}=${m[1]}`;
  }
  return null;
}

async function req(method, path, { cookie, body } = {}) {
  const headers = baseHeaders(cookie ? { Cookie: cookie } : {});
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let json = null;
  const text = await res.text();
  if (text) {
    try {
      json = JSON.parse(text);
    } catch {
      json = text;
    }
  }
  return { status: res.status, json, res };
}

async function main() {
  if (!SECRET) {
    console.error(
      "TASKRADAR_API_SECRET is not set in this environment \u2014 cannot run.",
    );
    process.exit(2);
  }

  // --- Sessions -----------------------------------------------------------
  console.log("\nSession gate");
  const noSession = await req("GET", "/tasks");
  check(
    "GET /tasks without a session is rejected (401)",
    noSession.status === 401,
    `got ${noSession.status}`,
  );

  const staffLogin = await req("POST", "/auth/staff", {
    body: { passcode: STAFF_PASSCODE },
  });
  const staffCookie = cookieFrom(staffLogin.res, "tr_staff");
  check(
    "Staff passcode mints a staff session",
    staffLogin.status === 200 && !!staffCookie,
    `status ${staffLogin.status}`,
  );

  const mgrLogin = await req("POST", "/auth/manager", {
    body: { passcode: MANAGER_PASSCODE },
  });
  const mgrCookie = cookieFrom(mgrLogin.res, "tr_mgr");
  check(
    "Manager passcode mints a manager session",
    mgrLogin.status === 200 && !!mgrCookie && mgrLogin.json?.manager === true,
    `status ${mgrLogin.status}`,
  );

  if (!staffCookie || !mgrCookie) {
    console.error("\nCannot continue without sessions.");
    finish();
    return;
  }

  // --- Pick two distinct staff (non-manager) users ------------------------
  const usersRes = await req("GET", "/users", { cookie: staffCookie });
  const users = Array.isArray(usersRes.json) ? usersRes.json : [];
  const staffUsers = users.filter((u) => u.role !== "manager");
  check(
    "There are at least two staff users to test ownership/collaboration",
    staffUsers.length >= 2,
    `found ${staffUsers.length}`,
  );
  if (staffUsers.length < 2) {
    finish();
    return;
  }
  const owner = staffUsers[0];
  const collaborator = staffUsers[1];

  // --- Open-team task lifecycle under a STAFF session ---------------------
  console.log("\nOpen-team editing (staff session)");
  const suffix = `${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
  const created = await req("POST", "/tasks", {
    cookie: staffCookie,
    body: {
      title: `OpenTeam Test ${suffix}`,
      category: "backlog",
      reason: "internal",
      ownerId: owner.id,
      createdById: owner.id,
    },
  });
  check(
    "Staff can create a task",
    created.status === 201 && typeof created.json?.id === "number",
    `status ${created.status}`,
  );
  const taskId = created.json?.id;
  if (typeof taskId !== "number") {
    finish();
    return;
  }

  // Edit (PATCH) any task as staff.
  const newTitle = `OpenTeam Edited ${suffix}`;
  const patched = await req("PATCH", `/tasks/${taskId}`, {
    cookie: staffCookie,
    body: { title: newTitle, actingUserId: owner.id },
  });
  check(
    "Staff can PATCH (edit) any task",
    patched.status === 200 && patched.json?.title === newTitle,
    `status ${patched.status}`,
  );

  // Reassign owner as staff.
  const reassigned = await req("PATCH", `/tasks/${taskId}`, {
    cookie: staffCookie,
    body: { ownerId: collaborator.id, actingUserId: owner.id },
  });
  check(
    "Staff can reassign a task's owner",
    reassigned.status === 200 && reassigned.json?.ownerId === collaborator.id,
    `status ${reassigned.status}`,
  );
  // Put ownership back to `owner` so the collaborator role is distinct below.
  await req("PATCH", `/tasks/${taskId}`, {
    cookie: staffCookie,
    body: { ownerId: owner.id, actingUserId: owner.id },
  });

  // Add a collaborator as staff.
  const added = await req("POST", `/tasks/${taskId}/collaborators`, {
    cookie: staffCookie,
    body: { userId: collaborator.id, actingUserId: owner.id },
  });
  const hasCollab =
    Array.isArray(added.json) &&
    added.json.some((c) => c.userId === collaborator.id);
  check(
    "Staff can add a collaborator",
    added.status === 200 && hasCollab,
    `status ${added.status}`,
  );

  // --- "My Tasks": memberId returns owner OR collaborator tasks -----------
  console.log("\nMy Tasks (memberId filter)");
  const asOwner = await req("GET", `/tasks?memberId=${owner.id}`, {
    cookie: staffCookie,
  });
  check(
    "memberId of the OWNER includes the task",
    Array.isArray(asOwner.json) && asOwner.json.some((t) => t.id === taskId),
    `status ${asOwner.status}`,
  );

  const asCollab = await req("GET", `/tasks?memberId=${collaborator.id}`, {
    cookie: staffCookie,
  });
  check(
    "memberId of the COLLABORATOR includes the task",
    Array.isArray(asCollab.json) && asCollab.json.some((t) => t.id === taskId),
    `status ${asCollab.status}`,
  );

  // Remove the collaborator and confirm they no longer match via memberId.
  const removed = await req(
    "DELETE",
    `/tasks/${taskId}/collaborators/${collaborator.id}`,
    { cookie: staffCookie },
  );
  check(
    "Staff can remove a collaborator",
    removed.status === 200 &&
      Array.isArray(removed.json) &&
      !removed.json.some((c) => c.userId === collaborator.id),
    `status ${removed.status}`,
  );
  const afterRemove = await req("GET", `/tasks?memberId=${collaborator.id}`, {
    cookie: staffCookie,
  });
  check(
    "After removal the collaborator no longer matches via memberId",
    Array.isArray(afterRemove.json) &&
      !afterRemove.json.some((t) => t.id === taskId),
    `status ${afterRemove.status}`,
  );

  // Archive (soft-delete) as staff.
  const archived = await req("DELETE", `/tasks/${taskId}`, {
    cookie: staffCookie,
    body: { actingUserId: owner.id },
  });
  check(
    "Staff can archive (soft-delete) any task",
    archived.status === 200 && archived.json?.archived === true,
    `status ${archived.status}`,
  );
  const defaultList = await req("GET", `/tasks?memberId=${owner.id}`, {
    cookie: staffCookie,
  });
  check(
    "Archived task is excluded from the default list",
    Array.isArray(defaultList.json) &&
      !defaultList.json.some((t) => t.id === taskId),
    `status ${defaultList.status}`,
  );

  // --- Manager-only routes REJECT a staff-only session (403) --------------
  // Bodies are valid where the route validates the body before the auth check,
  // so a 403 (not 400) proves the privilege boundary is what blocked the call.
  console.log("\nManager-only routes reject a staff session");
  const dash = await req("GET", "/dashboard", { cookie: staffCookie });
  check("GET /dashboard \u2192 403 for staff", dash.status === 403, `got ${dash.status}`);

  const recs = await req("GET", "/recognition/recommendations", {
    cookie: staffCookie,
  });
  check(
    "GET /recognition/recommendations \u2192 403 for staff",
    recs.status === 403,
    `got ${recs.status}`,
  );

  const goal = await req("POST", "/goals", {
    cookie: staffCookie,
    body: { title: `Should Not Create ${suffix}` },
  });
  check("POST /goals \u2192 403 for staff", goal.status === 403, `got ${goal.status}`);

  const role = await req("PATCH", `/users/${owner.id}`, {
    cookie: staffCookie,
    body: { role: "staff", actingUserId: owner.id },
  });
  check(
    "PATCH /users/:id (role change) \u2192 403 for staff",
    role.status === 403,
    `got ${role.status}`,
  );

  const assess = await req("PUT", `/tasks/${taskId}/assessment`, {
    cookie: staffCookie,
    body: { actingUserId: owner.id, qualityScore: 3, creativityScore: 3 },
  });
  check(
    "PUT /tasks/:id/assessment \u2192 403 for staff",
    assess.status === 403,
    `got ${assess.status}`,
  );

  // --- The same privileged route is reachable WITH a manager session ------
  console.log("\nManager session passes the privileged boundary");
  const dashMgr = await req("GET", "/dashboard", { cookie: mgrCookie });
  check(
    "GET /dashboard \u2192 200 for manager",
    dashMgr.status === 200,
    `got ${dashMgr.status}`,
  );

  finish();
}

function finish() {
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) {
    console.error("\nFailures:");
    for (const f of failures) console.error(`  - ${f}`);
    process.exit(1);
  }
  process.exit(0);
}

main().catch((err) => {
  console.error("Test run crashed:", err);
  process.exit(1);
});
