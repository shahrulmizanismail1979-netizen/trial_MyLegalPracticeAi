// Self-contained runner for the open-team integration tests.
//
// Boots the API server on a dedicated port (no workflow/proxy required),
// waits for /api/healthz, runs open-team.test.mjs against it via
// TEST_BASE_URL, then tears the server down and exits with the test's code.
//
// This makes `pnpm --filter @workspace/api-server run test:ci` a standalone
// check suitable for a validation step, where the long-running workflow may
// not be up. It builds the server first so the latest source is exercised.
//
// Requires DATABASE_URL and TASKRADAR_API_SECRET in the environment (both are
// set in this workspace). STAFF_PASSCODE / MANAGER_PASSCODE fall back to the
// same app defaults the test uses.

import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const artifactDir = path.resolve(here, "..");
const PORT = process.env.TEST_PORT ?? "5099";
const BASE = `http://localhost:${PORT}/api`;
const HEALTH = `${BASE}/healthz`;

function run(cmd, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, {
      cwd: artifactDir,
      stdio: "inherit",
      ...opts,
    });
    child.on("error", reject);
    child.on("exit", (code) => resolve(code ?? 1));
  });
}

async function waitForHealth(timeoutMs = 30000) {
  // /api/healthz is allowlisted by the session gate but still sits behind the
  // X-TaskRadar-Secret header gate, so the probe must carry that header.
  const headers = {};
  if (process.env.TASKRADAR_API_SECRET) {
    headers["X-TaskRadar-Secret"] = process.env.TASKRADAR_API_SECRET;
  }
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(HEALTH, { headers });
      if (res.ok) return true;
    } catch {
      // server not up yet
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL is not set — cannot run the integration tests.");
    process.exit(2);
  }
  if (!process.env.TASKRADAR_API_SECRET) {
    console.error(
      "TASKRADAR_API_SECRET is not set — cannot run the integration tests.",
    );
    process.exit(2);
  }

  console.log("Building the API server…");
  const buildCode = await run("node", ["./build.mjs"]);
  if (buildCode !== 0) {
    console.error("Build failed.");
    process.exit(buildCode);
  }

  console.log(`Starting the API server on port ${PORT}…`);
  const server = spawn("node", ["--enable-source-maps", "./dist/index.mjs"], {
    cwd: artifactDir,
    stdio: "inherit",
    env: { ...process.env, PORT, NODE_ENV: "development" },
  });

  let serverExited = false;
  server.on("exit", () => {
    serverExited = true;
  });

  const shutdown = () => {
    if (!serverExited) server.kill("SIGTERM");
  };
  process.on("exit", shutdown);
  process.on("SIGINT", () => {
    shutdown();
    process.exit(130);
  });
  process.on("SIGTERM", () => {
    shutdown();
    process.exit(143);
  });

  const healthy = await waitForHealth();
  if (!healthy || serverExited) {
    console.error("Server did not become healthy in time.");
    shutdown();
    process.exit(1);
  }

  console.log("Server is healthy. Running integration tests…\n");
  const suites = [
    "./test/open-team.test.mjs",
    "./test/activity.test.mjs",
    "./test/ai-capture.test.mjs",
  ];
  let testCode = 0;
  for (const suite of suites) {
    console.log(`\n=== ${suite} ===`);
    const code = await run("node", [suite], {
      env: { ...process.env, TEST_BASE_URL: BASE },
    });
    if (code !== 0) testCode = code;
  }

  shutdown();
  await new Promise((r) => setTimeout(r, 300));
  process.exit(testCode);
}

main().catch((err) => {
  console.error("CI runner crashed:", err);
  process.exit(1);
});
