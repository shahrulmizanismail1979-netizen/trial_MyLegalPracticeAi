// Integration tests for the AI capture flows (Meetings, Voice, Inbox).
//
// These cover the deterministic, non-LLM parts of the AI features:
//   1. The manager-only authorization boundary on the "create tasks" endpoints
//      (/meetings/:id/create-tasks and /ingest/create-tasks) — staff get 403,
//      a manager session passes the boundary.
//   2. The documented explicit-failure contract: when an AI connector is
//      unavailable the route returns HTTP 502 with a human-readable message
//      (no silent fallback). We exercise this against the Gmail connector,
//      which is intentionally NOT connected and throws AiProviderError -> 502,
//      so the test is deterministic and incurs no real LLM/transcription cost.
//
// Like open-team.test.mjs these run against a LIVE server reached through the
// shared Replit proxy (localhost:80) and are dependency-free (Node's global
// fetch only). Run with:
//
//   pnpm --filter @workspace/api-server run test:ai
//
// Requires the API Server + proxy to be up and TASKRADAR_API_SECRET to be set.
// The script logs in for real session cookies; it never prints the secret or
// any cookie value.

const BASE = process.env.TEST_BASE_URL ?? "http://localhost:80/api";
const SECRET = process.env.TASKRADAR_API_SECRET ?? "";
const STAFF_PASSCODE = process.env.STAFF_PASSCODE ?? "spice";
const MANAGER_PASSCODE = process.env.MANAGER_PASSCODE ?? "240680";

let passed = 0;
let failed = 0;
const failures = [];

function check(name, cond, detail = "") {
  if (cond) {
    passed += 1;
    console.log(`  \u2713 ${name}`);
  } else {
    failed += 1;
    failures.push(`${name}${detail ? ` \u2014 ${detail}` : ""}`);
    console.error(`  \u2717 ${name}${detail ? ` \u2014 ${detail}` : ""}`);
  }
}

function baseHeaders(extra = {}) {
  const h = { "Content-Type": "application/json", ...extra };
  if (SECRET) h["X-TaskRadar-Secret"] = SECRET;
  return h;
}

// Extract a single cookie name=value pair from a fetch Response's Set-Cookie.
function cookieFrom(res, name) {
  const all =
    typeof res.headers.getSetCookie === "function"
      ? res.headers.getSetCookie()
      : [res.headers.get("set-cookie")].filter(Boolean);
  for (const line of all) {
    const m = line.match(new RegExp(`${name}=([^;]+)`));
    if (m) return `${name}=${m[1]}`;
  }
  return null;
}

async function req(method, path, { cookie, body } = {}) {
  const headers = baseHeaders(cookie ? { Cookie: cookie } : {});
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let json = null;
  const text = await res.text();
  if (text) {
    try {
      json = JSON.parse(text);
    } catch {
      json = text;
    }
  }
  return { status: res.status, json, res };
}

// An integer id that is virtually guaranteed not to match any meeting, so the
// manager path falls through to a 404 (proving it passed the auth boundary).
const MISSING_MEETING_ID = 2147480000;

async function main() {
  if (!SECRET) {
    console.error(
      "TASKRADAR_API_SECRET is not set in this environment \u2014 cannot run.",
    );
    process.exit(2);
  }

  // --- Sessions -----------------------------------------------------------
  console.log("\nSession gate (AI capture routes)");
  const staffLogin = await req("POST", "/auth/staff", {
    body: { passcode: STAFF_PASSCODE },
  });
  const staffCookie = cookieFrom(staffLogin.res, "tr_staff");
  check(
    "Staff passcode mints a staff session",
    staffLogin.status === 200 && !!staffCookie,
    `status ${staffLogin.status}`,
  );

  const mgrLogin = await req("POST", "/auth/manager", {
    body: { passcode: MANAGER_PASSCODE },
  });
  const mgrCookie = cookieFrom(mgrLogin.res, "tr_mgr");
  check(
    "Manager passcode mints a manager session",
    mgrLogin.status === 200 && !!mgrCookie && mgrLogin.json?.manager === true,
    `status ${mgrLogin.status}`,
  );

  if (!staffCookie || !mgrCookie) {
    console.error("\nCannot continue without sessions.");
    finish();
    return;
  }

  // An anonymous (no-session) AI create-tasks call is blocked by the session
  // gate before any AI work — proves these routes are not internet-open.
  const anonCreate = await req("POST", "/ingest/create-tasks", {
    body: { actingUserId: null, drafts: [] },
  });
  check(
    "POST /ingest/create-tasks without a session \u2192 401",
    anonCreate.status === 401,
    `got ${anonCreate.status}`,
  );

  // Pick a staff (non-manager) user for attribution fields.
  const usersRes = await req("GET", "/users", { cookie: staffCookie });
  const users = Array.isArray(usersRes.json) ? usersRes.json : [];
  const staffUser = users.find((u) => u.role !== "manager");
  check("There is at least one staff user", !!staffUser, `found ${users.length}`);
  const actingId = staffUser?.id ?? null;

  // --- /meetings/:id/create-tasks: manager-only --------------------------
  // The route validates params + body BEFORE the auth check, so a valid body
  // means a 403 (not a 400) proves the privilege boundary is what blocked it.
  console.log("\n/meetings/:id/create-tasks (manager-only)");
  const meetingItemsBody = {
    actingUserId: actingId,
    items: [{ actionItemIndex: 0, category: "backlog", reason: "internal" }],
  };

  const meetStaff = await req(
    "POST",
    `/meetings/${MISSING_MEETING_ID}/create-tasks`,
    { cookie: staffCookie, body: meetingItemsBody },
  );
  check(
    "Staff session \u2192 403",
    meetStaff.status === 403,
    `got ${meetStaff.status}`,
  );

  // A manager passes the boundary; with a non-existent meeting it then 404s
  // (anything other than 403 proves the auth check let the manager through).
  const meetMgr = await req(
    "POST",
    `/meetings/${MISSING_MEETING_ID}/create-tasks`,
    { cookie: mgrCookie, body: meetingItemsBody },
  );
  check(
    "Manager session passes the boundary (404 for a missing meeting, not 403)",
    meetMgr.status === 404,
    `got ${meetMgr.status}`,
  );

  // --- /ingest/create-tasks: manager-only --------------------------------
  console.log("\n/ingest/create-tasks (manager-only)");
  // Empty drafts is a valid body and creates no tasks, so the manager call is
  // side-effect free while still proving the boundary.
  const emptyDraftsBody = { actingUserId: actingId, drafts: [] };

  const ingestStaff = await req("POST", "/ingest/create-tasks", {
    cookie: staffCookie,
    body: emptyDraftsBody,
  });
  check(
    "Staff session \u2192 403",
    ingestStaff.status === 403,
    `got ${ingestStaff.status}`,
  );

  const ingestMgr = await req("POST", "/ingest/create-tasks", {
    cookie: mgrCookie,
    body: emptyDraftsBody,
  });
  check(
    "Manager session passes the boundary (200, creates nothing)",
    ingestMgr.status === 200 &&
      Array.isArray(ingestMgr.json?.created) &&
      ingestMgr.json.created.length === 0,
    `got ${ingestMgr.status}`,
  );

  // --- Voice capture: input validation + explicit-failure contract -------
  // /voice/parse is session-gated (not manager-only). Two deterministic,
  // zero-LLM-cost paths exercise its failure contract:
  //   - an empty recording is rejected with a 400 + human message;
  //   - undecodable audio fails format conversion -> AiProviderError -> 502.
  console.log("\n/voice/parse (input validation + explicit failure)");
  const voiceEmpty = await req("POST", "/voice/parse", {
    cookie: staffCookie,
    body: { audioBase64: "", mimeType: "audio/webm", lang: "en" },
  });
  const emptyMsg =
    typeof voiceEmpty.json?.error === "string" ? voiceEmpty.json.error : "";
  check(
    "Empty recording \u2192 400 with a human message",
    voiceEmpty.status === 400 && emptyMsg.length > 0,
    `got ${voiceEmpty.status}: ${JSON.stringify(emptyMsg)}`,
  );

  // 2 KiB of non-audio bytes: format conversion (ffmpeg) cannot read it, so
  // the route surfaces the documented 502 rather than silently continuing.
  const garbage = Buffer.from(
    Array.from({ length: 2048 }, (_, i) => (i * 37 + 11) % 256),
  ).toString("base64");
  const voiceGarbage = await req("POST", "/voice/parse", {
    cookie: staffCookie,
    body: { audioBase64: garbage, mimeType: "audio/webm", lang: "en" },
  });
  const garbageMsg =
    typeof voiceGarbage.json?.error === "string" ? voiceGarbage.json.error : "";
  check(
    "Undecodable audio \u2192 502 with a human message",
    voiceGarbage.status === 502 && garbageMsg.length > 0,
    `got ${voiceGarbage.status}: ${JSON.stringify(garbageMsg)}`,
  );

  // --- Explicit-failure contract: connector unavailable -> 502 -----------
  // Gmail is intentionally not connected; fetchRecentEmails throws
  // AiProviderError, which every AI route maps to a 502 with a human message.
  // This exercises the real route + error-mapping path with no LLM cost.
  console.log("\nExplicit-failure contract (502 + human message)");
  const gmail = await req("POST", "/ingest/gmail", {
    cookie: staffCookie,
    body: { lang: "en", actingUserId: actingId },
  });
  const gmailMsg = typeof gmail.json?.error === "string" ? gmail.json.error : "";
  check(
    "POST /ingest/gmail with no Gmail connector \u2192 502",
    gmail.status === 502,
    `got ${gmail.status}`,
  );
  check(
    "502 body carries a human-readable error message",
    gmailMsg.length > 0 && gmailMsg.toLowerCase().includes("gmail"),
    `message: ${JSON.stringify(gmailMsg)}`,
  );

  finish();
}

function finish() {
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) {
    console.error("\nFailures:");
    for (const f of failures) console.error(`  - ${f}`);
    process.exit(1);
  }
  process.exit(0);
}

main().catch((err) => {
  console.error("Test run crashed:", err);
  process.exit(1);
});
