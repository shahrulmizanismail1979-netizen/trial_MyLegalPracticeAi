// Integration tests for the task Change History audit trail.
//
// Asserts that every auditable action writes exactly ONE task_activity row with
// the correct `action` key and `meta`, and that "log only when something
// changed" no-ops (re-acknowledge, status no-op, PATCH no-op, duplicate
// collaborator add, removing a non-existent collaborator) write NO row.
//
// Runs against a LIVE server reached through TEST_BASE_URL (the shared proxy in
// dev, or the dedicated CI port booted by run-ci.mjs). Dependency-free (Node's
// global fetch only). Requires TASKRADAR_API_SECRET in the environment; logs in
// for real staff + manager session cookies (never prints secrets or cookies).

const BASE = process.env.TEST_BASE_URL ?? "http://localhost:80/api";
const SECRET = process.env.TASKRADAR_API_SECRET ?? "";
const STAFF_PASSCODE = process.env.STAFF_PASSCODE ?? "spice";
const MANAGER_PASSCODE = process.env.MANAGER_PASSCODE ?? "240680";

let passed = 0;
let failed = 0;
const failures = [];

function check(name, cond, detail = "") {
  if (cond) {
    passed += 1;
    console.log(`  \u2713 ${name}`);
  } else {
    failed += 1;
    failures.push(`${name}${detail ? ` \u2014 ${detail}` : ""}`);
    console.error(`  \u2717 ${name}${detail ? ` \u2014 ${detail}` : ""}`);
  }
}

function baseHeaders(extra = {}) {
  const h = { "Content-Type": "application/json", ...extra };
  if (SECRET) h["X-TaskRadar-Secret"] = SECRET;
  return h;
}

function cookieFrom(res, name) {
  const all =
    typeof res.headers.getSetCookie === "function"
      ? res.headers.getSetCookie()
      : [res.headers.get("set-cookie")].filter(Boolean);
  for (const line of all) {
    const m = line.match(new RegExp(`${name}=([^;]+)`));
    if (m) return `${name}=${m[1]}`;
  }
  return null;
}

async function req(method, path, { cookie, body } = {}) {
  const headers = baseHeaders(cookie ? { Cookie: cookie } : {});
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let json = null;
  const text = await res.text();
  if (text) {
    try {
      json = JSON.parse(text);
    } catch {
      json = text;
    }
  }
  return { status: res.status, json, res };
}

// Fetch a task's audit trail (newest first).
async function activity(taskId, cookie) {
  const r = await req("GET", `/tasks/${taskId}/activity`, { cookie });
  return Array.isArray(r.json) ? r.json : [];
}

async function main() {
  if (!SECRET) {
    console.error(
      "TASKRADAR_API_SECRET is not set in this environment \u2014 cannot run.",
    );
    process.exit(2);
  }

  console.log("\nChange History audit trail");

  // --- Sessions -----------------------------------------------------------
  const staffLogin = await req("POST", "/auth/staff", {
    body: { passcode: STAFF_PASSCODE },
  });
  const staffCookie = cookieFrom(staffLogin.res, "tr_staff");
  const mgrLogin = await req("POST", "/auth/manager", {
    body: { passcode: MANAGER_PASSCODE },
  });
  const mgrCookie = cookieFrom(mgrLogin.res, "tr_mgr");
  check(
    "Staff + manager sessions established",
    !!staffCookie && !!mgrCookie,
    `staff ${staffLogin.status}, mgr ${mgrLogin.status}`,
  );
  if (!staffCookie || !mgrCookie) {
    finish();
    return;
  }

  // --- Two distinct staff users -------------------------------------------
  const usersRes = await req("GET", "/users", { cookie: staffCookie });
  const users = Array.isArray(usersRes.json) ? usersRes.json : [];
  const staffUsers = users.filter((u) => u.role !== "manager");
  check(
    "At least two staff users available",
    staffUsers.length >= 2,
    `found ${staffUsers.length}`,
  );
  if (staffUsers.length < 2) {
    finish();
    return;
  }
  const owner = staffUsers[0];
  const other = staffUsers[1];

  // --- Create a fresh urgent task (starts with zero activity rows) --------
  const suffix = `${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
  const created = await req("POST", "/tasks", {
    cookie: staffCookie,
    body: {
      title: `Audit Test ${suffix}`,
      category: "urgent",
      reason: "internal",
      ownerId: owner.id,
      createdById: owner.id,
    },
  });
  const taskId = created.json?.id;
  check(
    "Created an urgent task with an owner",
    created.status === 201 && typeof taskId === "number",
    `status ${created.status}`,
  );
  if (typeof taskId !== "number") {
    finish();
    return;
  }

  const start = await activity(taskId, staffCookie);
  check(
    "A new task starts with no audit rows",
    start.length === 0,
    `found ${start.length}`,
  );

  // Helper: run `act`, then assert exactly one new row with `action` and that
  // its meta satisfies `metaCheck` (optional). `before` is the pre-action list.
  let before = start;
  async function expectOne(label, action, act, metaCheck) {
    const prev = before.length;
    await act();
    const after = await activity(taskId, staffCookie);
    before = after;
    const added = after.length - prev;
    if (added !== 1) {
      check(label, false, `expected +1 row, got +${added}`);
      return null;
    }
    const row = after[0]; // newest first
    const actionOk = row.action === action;
    const metaOk = metaCheck ? metaCheck(row.meta) : true;
    check(
      label,
      actionOk && metaOk,
      `action=${row.action} meta=${JSON.stringify(row.meta)}`,
    );
    return row;
  }

  // Helper: run `act` and assert NO new row was written.
  async function expectNone(label, act) {
    const prev = before.length;
    await act();
    const after = await activity(taskId, staffCookie);
    before = after;
    check(label, after.length === prev, `wrote ${after.length - prev} row(s)`);
  }

  // --- acknowledged -------------------------------------------------------
  await expectOne(
    "acknowledge writes one 'acknowledged' row",
    "acknowledged",
    () =>
      req("POST", `/tasks/${taskId}/acknowledge`, {
        cookie: staffCookie,
        body: { actingUserId: owner.id },
      }),
  );
  await expectNone("re-acknowledge writes no row", () =>
    req("POST", `/tasks/${taskId}/acknowledge`, {
      cookie: staffCookie,
      body: { actingUserId: owner.id },
    }),
  );

  // --- status_changed via POST /status ------------------------------------
  await expectOne(
    "POST /status (acknowledged\u2192in_progress) writes 'status_changed'",
    "status_changed",
    () =>
      req("POST", `/tasks/${taskId}/status`, {
        cookie: staffCookie,
        body: { status: "in_progress", actingUserId: owner.id },
      }),
    (m) => m?.from === "acknowledged" && m?.to === "in_progress",
  );
  await expectNone("POST /status no-op (same status) writes no row", () =>
    req("POST", `/tasks/${taskId}/status`, {
      cookie: staffCookie,
      body: { status: "in_progress", actingUserId: owner.id },
    }),
  );

  // --- status_changed via PATCH -------------------------------------------
  await expectOne(
    "PATCH (status\u2192blocked) writes 'status_changed'",
    "status_changed",
    () =>
      req("PATCH", `/tasks/${taskId}`, {
        cookie: staffCookie,
        body: { status: "blocked", actingUserId: owner.id },
      }),
    (m) => m?.from === "in_progress" && m?.to === "blocked",
  );

  // --- reassigned ---------------------------------------------------------
  await expectOne(
    "PATCH (reassign owner) writes 'reassigned'",
    "reassigned",
    () =>
      req("PATCH", `/tasks/${taskId}`, {
        cookie: staffCookie,
        body: { ownerId: other.id, actingUserId: owner.id },
      }),
    (m) => m?.from === owner.name && m?.to === other.name,
  );

  // --- classification_changed (category) ----------------------------------
  await expectOne(
    "PATCH (category change) writes 'classification_changed'",
    "classification_changed",
    () =>
      req("PATCH", `/tasks/${taskId}`, {
        cookie: staffCookie,
        body: { category: "backlog", actingUserId: owner.id },
      }),
    (m) => m?.from === "urgent" && m?.to === "backlog",
  );

  // --- reason_changed -----------------------------------------------------
  await expectOne(
    "PATCH (reason change) writes 'reason_changed'",
    "reason_changed",
    () =>
      req("PATCH", `/tasks/${taskId}`, {
        cookie: staffCookie,
        body: { reason: "finance", actingUserId: owner.id },
      }),
    (m) => m?.from === "internal" && m?.to === "finance",
  );

  // --- goal_changed (needs a real goal; created with a manager session) ---
  const goal = await req("POST", "/goals", {
    cookie: mgrCookie,
    body: { title: `Audit Goal ${suffix}` },
  });
  const goalId = goal.json?.id;
  check(
    "Created a goal to link",
    goal.status === 201 && typeof goalId === "number",
    `status ${goal.status}`,
  );
  if (typeof goalId === "number") {
    await expectOne(
      "PATCH (goal link) writes 'goal_changed'",
      "goal_changed",
      () =>
        req("PATCH", `/tasks/${taskId}`, {
          cookie: staffCookie,
          body: { goalId, actingUserId: owner.id },
        }),
      (m) => m?.from === null && m?.to === goalId,
    );
  }

  // --- due_changed --------------------------------------------------------
  const dueIso = new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString();
  await expectOne(
    "PATCH (due date) writes 'due_changed'",
    "due_changed",
    () =>
      req("PATCH", `/tasks/${taskId}`, {
        cookie: staffCookie,
        body: { dueAt: dueIso, actingUserId: owner.id },
      }),
    (m) => typeof m?.to === "string",
  );

  // --- edited (title) -----------------------------------------------------
  const editedTitle = `Audit Test Edited ${suffix}`;
  await expectOne(
    "PATCH (title) writes 'edited' with fields",
    "edited",
    () =>
      req("PATCH", `/tasks/${taskId}`, {
        cookie: staffCookie,
        body: { title: editedTitle, actingUserId: owner.id },
      }),
    (m) => Array.isArray(m?.fields) && m.fields.includes("title"),
  );
  await expectNone("PATCH no-op (same title) writes no row", () =>
    req("PATCH", `/tasks/${taskId}`, {
      cookie: staffCookie,
      body: { title: editedTitle, actingUserId: owner.id },
    }),
  );

  // --- note_added ---------------------------------------------------------
  await expectOne(
    "POST /notes writes 'note_added'",
    "note_added",
    () =>
      req("POST", `/tasks/${taskId}/notes`, {
        cookie: staffCookie,
        body: { authorId: owner.id, body: `Audit note ${suffix}` },
      }),
  );

  // --- attempt_added ------------------------------------------------------
  await expectOne(
    "POST /attempts (text) writes 'attempt_added'",
    "attempt_added",
    () =>
      req("POST", `/tasks/${taskId}/attempts`, {
        cookie: staffCookie,
        body: { authorId: owner.id, body: `Audit attempt ${suffix}` },
      }),
    (m) => m?.source === "text",
  );

  // --- nudged (current owner is `other` after the reassign above) ---------
  await expectOne(
    "POST /nudge writes 'nudged'",
    "nudged",
    () =>
      req("POST", `/tasks/${taskId}/nudge`, {
        cookie: staffCookie,
        body: { actingUserId: owner.id },
      }),
    (m) => m?.target === other.name,
  );

  // --- collaborator_added (add `owner`, who is no longer the task owner) ---
  await expectOne(
    "POST /collaborators writes 'collaborator_added'",
    "collaborator_added",
    () =>
      req("POST", `/tasks/${taskId}/collaborators`, {
        cookie: staffCookie,
        body: { userId: owner.id, actingUserId: other.id },
      }),
    (m) => m?.target === owner.name,
  );
  await expectNone("Duplicate collaborator add writes no row", () =>
    req("POST", `/tasks/${taskId}/collaborators`, {
      cookie: staffCookie,
      body: { userId: owner.id, actingUserId: other.id },
    }),
  );

  // --- collaborator_removed -----------------------------------------------
  await expectOne(
    "DELETE /collaborators writes 'collaborator_removed'",
    "collaborator_removed",
    () =>
      req("DELETE", `/tasks/${taskId}/collaborators/${owner.id}`, {
        cookie: staffCookie,
        body: { actingUserId: other.id },
      }),
    (m) => m?.target === owner.name,
  );
  await expectNone("Removing a non-collaborator writes no row", () =>
    req("DELETE", `/tasks/${taskId}/collaborators/${owner.id}`, {
      cookie: staffCookie,
      body: { actingUserId: other.id },
    }),
  );

  // --- evidence_added (real upload through object storage) -----------------
  const fileName = `audit-${suffix}.txt`;
  const fileBytes = Buffer.from(`audit evidence ${suffix}`, "utf8");
  const urlReq = await req("POST", "/storage/uploads/request-url", {
    cookie: staffCookie,
    body: {
      actingUserId: owner.id,
      name: fileName,
      size: fileBytes.length,
      contentType: "text/plain",
    },
  });
  const uploadURL = urlReq.json?.uploadURL;
  const objectPath = urlReq.json?.objectPath;
  let evidenceId = null;
  if (typeof uploadURL === "string" && typeof objectPath === "string") {
    const put = await fetch(uploadURL, {
      method: "PUT",
      headers: { "Content-Type": "text/plain" },
      body: fileBytes,
    });
    check("Uploaded evidence bytes to storage", put.ok, `PUT ${put.status}`);
    const ev = await expectOne(
      "POST /evidence writes 'evidence_added'",
      "evidence_added",
      async () => {
        const r = await req("POST", `/tasks/${taskId}/evidence`, {
          cookie: staffCookie,
          body: {
            authorId: owner.id,
            objectPath,
            fileName,
            contentType: "text/plain",
            fileSize: fileBytes.length,
          },
        });
        evidenceId = r.json?.id ?? null;
      },
      (m) => m?.target === fileName,
    );
    void ev;
  } else {
    check(
      "Requested an evidence upload URL",
      false,
      `status ${urlReq.status}`,
    );
  }

  // --- evidence_deleted (manager-only) ------------------------------------
  if (typeof evidenceId === "number") {
    await expectOne(
      "DELETE /evidence (manager) writes 'evidence_deleted'",
      "evidence_deleted",
      () =>
        req("DELETE", `/tasks/${taskId}/evidence/${evidenceId}`, {
          cookie: mgrCookie,
          body: { actingUserId: owner.id },
        }),
      (m) => m?.target === fileName,
    );
  }

  // --- acknowledge is NOT urgent-only (open-team relaxation) ---------------
  // A non-urgent task can be acknowledged by any staff session, and the
  // acknowledge writes exactly one 'acknowledged' audit row.
  const routine = await req("POST", "/tasks", {
    cookie: staffCookie,
    body: {
      title: `Backlog Ack Test ${suffix}`,
      category: "backlog",
      reason: "internal",
      ownerId: owner.id,
      createdById: owner.id,
    },
  });
  const routineId = routine.json?.id;
  check(
    "Created a non-urgent (backlog) task",
    routine.status === 201 && typeof routineId === "number",
    `status ${routine.status}`,
  );
  if (typeof routineId === "number") {
    const ackRes = await req("POST", `/tasks/${routineId}/acknowledge`, {
      cookie: staffCookie,
      body: { actingUserId: owner.id },
    });
    check(
      "Acknowledging a non-urgent task is allowed (200)",
      ackRes.status === 200,
      `status ${ackRes.status}`,
    );
    const routineRows = await activity(routineId, staffCookie);
    check(
      "Non-urgent acknowledge writes one 'acknowledged' row",
      routineRows.filter((r) => r.action === "acknowledged").length === 1,
      `rows ${JSON.stringify(routineRows.map((r) => r.action))}`,
    );
    await req("DELETE", `/tasks/${routineId}`, {
      cookie: staffCookie,
      body: { actingUserId: owner.id },
    });
  }

  // --- archived -----------------------------------------------------------
  await expectOne(
    "DELETE /tasks/:id writes 'archived'",
    "archived",
    () =>
      req("DELETE", `/tasks/${taskId}`, {
        cookie: staffCookie,
        body: { actingUserId: owner.id },
      }),
  );

  // --- Every logged row carries the action's actor attribution ------------
  const finalRows = await activity(taskId, staffCookie);
  check(
    "Every audit row has an action key and ISO timestamp",
    finalRows.length > 0 &&
      finalRows.every(
        (r) =>
          typeof r.action === "string" &&
          r.action.length > 0 &&
          typeof r.createdAt === "string",
      ),
    `rows ${finalRows.length}`,
  );

  finish();
}

function finish() {
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) {
    console.error("\nFailures:");
    for (const f of failures) console.error(`  - ${f}`);
    process.exit(1);
  }
  process.exit(0);
}

main().catch((err) => {
  console.error("Test run crashed:", err);
  process.exit(1);
});
