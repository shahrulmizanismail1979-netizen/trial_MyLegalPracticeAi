import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { hasValidSession } from "./lib/managerSession";

const app: Express = express();

// Behind Replit's reverse proxy there is exactly one trusted hop. Trusting it
// lets Express derive the real client IP from X-Forwarded-For (used by the AI
// rate limiter to key per-user) and resolves express-rate-limit's
// ERR_ERL_UNEXPECTED_X_FORWARDED_FOR validation error. Use a fixed hop count
// (not `true`) so attacker-supplied X-Forwarded-For values can't spoof the IP.
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// ---------------------------------------------------------------------------
// CORS — restrict allowed origins to the app's own published domain(s) and
// the Replit dev-preview domain.  Wildcard `*` lets any website make
// credentialled cross-origin calls to the API; restricting to known origins
// eliminates that attack surface.
// ---------------------------------------------------------------------------
const rawDomains = process.env.REPLIT_DOMAINS ?? "";
const allowedOrigins: string[] = rawDomains
  .split(",")
  .map((d) => d.trim())
  .filter(Boolean)
  .map((d) => `https://${d}`);

const devDomain = process.env.REPLIT_DEV_DOMAIN;
if (devDomain) {
  allowedOrigins.push(`https://${devDomain}`);
}

app.use(
  cors({
    origin: (origin, callback) => {
      // Same-origin browser requests and server-to-server calls have no Origin
      // header — allow them.  The API-secret check below is the real identity gate.
      if (!origin) {
        callback(null, true);
        return;
      }
      if (allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(null, false);
      }
    },
    credentials: true,
  }),
);


// Base64-encoded meeting audio and screenshot payloads are large; the default
// ~100kb limit would reject realistic uploads, so raise it to a bounded cap.
app.use(express.json({ limit: "30mb" }));
app.use(express.urlencoded({ extended: true, limit: "30mb" }));

// Parse cookies so the manager-session middleware can read the signed
// httpOnly session cookie that gates privileged routes.
app.use(cookieParser());

// ---------------------------------------------------------------------------
// API secret gate (coarse, optional) — when TASKRADAR_API_SECRET is set, every
// /api request must carry it in the X-TaskRadar-Secret header.  Because this
// value ships in the client bundle it is NOT a real secret against a determined
// caller; it only provides coarse filtering against drive-by traffic.  The real
// trust boundary is the session gate below.  If the variable is absent the
// header check is skipped.
// ---------------------------------------------------------------------------
const API_SECRET = process.env.TASKRADAR_API_SECRET;

if (API_SECRET) {
  app.use("/api", (req: Request, res: Response, next: NextFunction): void => {
    // Object-serving GETs are reached via plain <a href> navigations and <img>
    // tags, which cannot attach the X-TaskRadar-Secret header. They stay
    // protected by the staff/manager session-cookie gate below (the cookie IS
    // sent on navigation), so they are exempt from this coarse header gate only.
    if (req.method === "GET" && req.path.startsWith("/storage/objects/")) {
      next();
      return;
    }
    const header = req.headers["x-taskradar-secret"];
    if (header !== API_SECRET) {
      res.status(401).json({ error: "Unauthorized." });
      return;
    }
    next();
  });
}

// ---------------------------------------------------------------------------
// Session gate — the PRIMARY authentication boundary.  Every /api route requires
// a valid server-verified session cookie (staff or manager).  The only routes
// reachable without a session are the login endpoints themselves and the health
// check.  Staff obtain a session via the shared staff passcode (POST
// /auth/staff); managers additionally via the manager passcode.  This replaces
// the client-embedded shared secret as the trust boundary, closing anonymous
// reads and writes across the API.
// ---------------------------------------------------------------------------
const SESSION_PUBLIC_PATHS = new Set<string>([
  "/auth/staff",
  "/auth/manager",
  "/auth/logout",
  "/auth/session",
  "/healthz",
]);

app.use("/api", (req: Request, res: Response, next: NextFunction): void => {
  if (SESSION_PUBLIC_PATHS.has(req.path)) {
    next();
    return;
  }
  if (hasValidSession(req)) {
    next();
    return;
  }
  res.status(401).json({ error: "Authentication required." });
});

app.use("/api", router);

export default app;
