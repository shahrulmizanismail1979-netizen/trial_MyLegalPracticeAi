import { Router, type IRouter } from "express";
import { and, asc, eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import {
  ManagerLoginBody,
  ManagerLoginResponse,
  ManagerLogoutResponse,
  GetManagerSessionResponse,
  StaffLoginBody,
  StaffLoginResponse,
} from "@workspace/api-zod";
import {
  setManagerCookie,
  clearManagerCookie,
  setStaffCookie,
  requireManagerSession,
  hasValidSession,
} from "../lib/managerSession";
import { getManagerPasscode } from "../lib/storageTokens";

const router: IRouter = Router();

/**
 * The manager passcode is the single shared secret that promotes a browser
 * into manager mode. It is verified server-side here; on success we mint a
 * signed httpOnly session cookie. There is no per-user manager password in the
 * no-auth model, so the passcode maps the caller onto the first manager account.
 *
 * Single source of truth: getManagerPasscode() (lib/storageTokens.ts) is used
 * by BOTH this manager-mode login and the object-storage session, so they can
 * never drift to different values/defaults.
 */

/**
 * The staff passcode is the single shared secret that unlocks the app for any
 * staff member. It is verified server-side and mints a signed httpOnly staff
 * session cookie — the primary authentication gate for every API route. Staff
 * remain otherwise anonymous (they self-identify via the user switcher); this
 * gate only proves the caller belongs to the team.
 */
const STAFF_PASSCODE = process.env.STAFF_PASSCODE ?? "spice";

router.post("/auth/staff", async (req, res): Promise<void> => {
  const parsed = StaffLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (parsed.data.passcode !== STAFF_PASSCODE) {
    res.status(401).json({ error: "Incorrect passcode." });
    return;
  }

  setStaffCookie(res);
  res.json(StaffLoginResponse.parse({ staff: true, manager: false }));
});

router.post("/auth/manager", async (req, res): Promise<void> => {
  const parsed = ManagerLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (parsed.data.passcode !== getManagerPasscode()) {
    res.status(401).json({ error: "Incorrect passcode." });
    return;
  }

  const [manager] = await db
    .select()
    .from(usersTable)
    .where(and(eq(usersTable.role, "manager"), eq(usersTable.activeStatus, true)))
    .orderBy(asc(usersTable.id))
    .limit(1);

  if (!manager) {
    res.status(401).json({ error: "No manager account is available." });
    return;
  }

  // A manager is also a staff member, so issue both cookies. This keeps the
  // staff session alive when the manager later "exits manager mode" (which
  // clears only the manager cookie).
  setManagerCookie(res, manager.id);
  setStaffCookie(res);
  res.json(
    ManagerLoginResponse.parse({ manager: true, staff: true, user: manager }),
  );
});

// "Exit manager mode" — clears only the manager cookie. The staff session (if
// present) survives, so the user stays signed in to the app as staff.
router.post("/auth/logout", async (req, res): Promise<void> => {
  clearManagerCookie(res);
  res.json(
    ManagerLogoutResponse.parse({ manager: false, staff: hasValidSession(req) }),
  );
});

router.get("/auth/session", async (req, res): Promise<void> => {
  const staff = hasValidSession(req);
  const managerId = await requireManagerSession(req);
  if (managerId == null) {
    res.json(GetManagerSessionResponse.parse({ manager: false, staff }));
    return;
  }

  const [manager] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, managerId));

  if (!manager) {
    clearManagerCookie(res);
    res.json(GetManagerSessionResponse.parse({ manager: false, staff }));
    return;
  }

  res.json(
    GetManagerSessionResponse.parse({ manager: true, staff: true, user: manager }),
  );
});

export default router;
