# MySyariahAI — Platform Feature List

**The Most Comprehensive AI-Powered Shariah Legal Practice Platform for Malaysia**

Bilingual (English / Bahasa Melayu) | Dark Islamic-Inspired Interface | Built for Malaysian Legal Practitioners

---

## CORE LEGAL REFERENCE MODULES

### 1. Shariah Provisions Library
A complete, structured reference covering 40 legal topics across Islamic Family Law, Property Law, Court Procedure, Criminal Law, Banking & Finance, and Constitutional Issues. Each topic includes bilingual overviews, legal principles, relevant legislation with section numbers, practical notes for practitioners, and linked case authorities. Everything a Shariah lawyer needs at their fingertips — no more flipping through stacks of statutes.

### 2. Case Law Database
Over 80 landmark Shariah and constitutional cases — from Indira Gandhi to Boto' binti Taha — with full bilingual summaries, judicial holdings, court levels, judge names, and practical significance. Instantly search and cite the authority you need.

### 3. Legislation Reference
All key federal statutes governing Shariah practice — Act 303, Act 585, Act 561, Act 559, Act 560, Act 505, Act 759, and the Federal Constitution — organized with descriptions, scope, and relevance notes. One-stop access to the legislative framework.

### 4. Cause Paper Templates
12 ready-to-use Shariah court document templates including summons (MS 1-5), divorce applications (MS 13), fasakh petitions (MS 26), maintenance claims, custody applications, faraid certificates (MS 24), affidavits, and appeals (MS 40). Each template includes step-by-step filing instructions and court-specific guidance.

### 5. Procedural Workflows
20 step-by-step practice workflows — from marriage registration to Islamic banking litigation. Each workflow maps the entire journey: filing, service, mediation, trial, and judgment, with estimated timelines and practical tips at every stage. Never miss a procedural step again.

### 6. Quranic Verses Reference
Over 40 Quranic verses directly relevant to Malaysian Shariah legal practice — with Arabic text, English and Bahasa Melayu translations, legal relevance analysis, and linked legislation. The spiritual and textual foundation behind every ruling, connected to modern practice.

### 7. Gazetted Fatwa Collection
Key gazetted fatwas from Malaysian religious authorities on takaful, khalwat, Islamic banking disputes, organ donation, polygamy, and more — each with issuing authority, year, legal status, and practical implications.

### 8. Legal Glossary
240 essential Shariah legal terms — from Talaq to Qawa'id Fiqhiyyah — with precise definitions in both English and Bahasa Melayu. Ensure accurate terminology in every submission and opinion.

### 9. Classical Kitab Library
A curated database of 20 authoritative Islamic legal texts used in Malaysian courts — including Mughni al-Muhtaj, Fath al-Mu'in, I'anat al-Talibin, Al-Umm, Tuhfat al-Muhtaj, and Bidayat al-Mujtahid. Each entry includes the Arabic title, author with dates, school of jurisprudence, description, relevance to Malaysian practice, key topics, and volume count.

### 10. Court Fee & Timeline Calculator
Instant estimates for Shariah court filing fees across family law, inheritance, enforcement, and criminal matters — with limitation periods, statutory basis, and procedural timelines for divorce and nafkah proceedings. Labeled for Federal Territory with state variance noted. Helps lawyers advise clients on costs and expectations upfront.

### 11. Dashboard & Analytics
A practice command center showing total provisions, cases, legislation, and glossary terms at a glance — with quick-access navigation to every module on the platform.

---

## PREMIUM AI-POWERED FEATURES
*Powered by Gemini 2.5 Flash with real-time streaming responses*

### 12. AI Shariah Research Assistant
Ask any question about Malaysian Shariah law and receive comprehensive, source-cited answers drawing from the entire platform database — provisions, cases, legislation, Quranic verses, and fatwas. Responses stream in real time, grounded in actual Malaysian legal authority. Like having a senior Shariah associate available 24/7.

### 13. AI Kitab Analysis Engine
Query the classical Arabic legal texts through AI — pose a legal question and receive analysis citing specific kitab, relevant chapters (bab), Arabic legal terminology with translations, applicable legal maxims (qawa'id fiqhiyyah), and guidance on how classical positions apply in modern Malaysian courts. Select specific texts or search across all 20 kitab simultaneously.

### 14. AI Legal Opinion Writer
Generate structured legal opinions across 9 areas of Shariah law — Family Law, Property & Inheritance, Criminal, Banking & Finance, Constitutional, Wakaf & Endowments, Zakat, Evidence & Procedure, and Administrative. Input your facts, select the area of law, and receive a professionally structured opinion with legal analysis, authorities, and recommendations — ready to refine and deliver.

### 15. AI Shariah Compliance Checker
Evaluate any transaction or arrangement against Shariah principles — across 13 transaction types including Murabahah, Musharakah, Mudarabah, Ijarah, Takaful, Sukuk, Hibah, Wakaf, and more. Receive a structured compliance verdict with risk assessment, applicable SAC rulings, required rectifications, and documentation recommendations. Essential for Islamic finance practitioners and compliance officers.

### 16. AI Client Intake Assistant
Smart intake forms for the three most common Shariah family law matters — Nafkah (Maintenance), Fasakh (Judicial Dissolution), and Hadhanah (Custody). Clients or paralegals fill in structured details, and the AI generates a comprehensive case brief with legal analysis, recommended strategy, evidence checklist, relevant authorities, and estimated timelines. Turn a 30-minute intake into a 3-minute process.

---

## PLATFORM CAPABILITIES

- **Fully Bilingual**: Every screen, every label, every piece of content available in English and Bahasa Melayu — switch instantly
- **Role-Based Access**: Practitioner, Judge, and Administrator access levels with secure code-based authentication
- **Dark Islamic-Inspired Design**: Deep teal, gold, and emerald theme — professional, dignified, and easy on the eyes during long sessions
- **Real-Time AI Streaming**: Responses appear word-by-word as they generate — no waiting for long processing
- **Mobile Responsive**: Full functionality on desktop, tablet, and phone
- **Malaysian-Specific**: Built exclusively for Malaysian Shariah legal practice — every reference, every citation, every workflow is grounded in Malaysian law

---

*MySyariahAI — Where Islamic Legal Tradition Meets Modern Intelligence.*
