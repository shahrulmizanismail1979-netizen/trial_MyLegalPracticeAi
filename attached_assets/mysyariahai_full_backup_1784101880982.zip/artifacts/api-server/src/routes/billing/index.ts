import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, TIERS, type Tier } from "@workspace/db";
import { requireAuth } from "../../lib/auth";
import { PACKAGES } from "../../lib/tiers";
import { effectiveTier } from "../../lib/grandfather";
import {
  getOrCreateCustomerId,
  getPriceIdForTier,
  reconcileCustomerTier,
} from "../../lib/billing";
import { getUncachableStripeClient } from "../../lib/stripeClient";

const router: IRouter = Router();

function safeReturnUrl(
  candidate: unknown,
  host: string | undefined,
  fallback: string,
): string {
  if (typeof candidate === "string" && /^https?:\/\//.test(candidate)) {
    if (host && candidate.includes(host)) return candidate;
  }
  return fallback;
}

router.get("/billing/packages", async (req, res): Promise<void> => {
  res.json({
    currency: "MYR",
    packages: PACKAGES,
    currentTier: req.session.userTier ?? "starter",
    accountType: req.session.accountType ?? null,
  });
});

router.post(
  "/billing/checkout",
  requireAuth,
  async (req, res): Promise<void> => {
    if (req.session.accountType !== "email") {
      res.status(400).json({
        error: "Billing is only available for email accounts.",
      });
      return;
    }

    const { tier } = (req.body ?? {}) as { tier?: string };
    if (!tier || !TIERS.includes(tier as Tier) || tier === "starter") {
      res.status(400).json({ error: "Invalid plan selected." });
      return;
    }

    try {
      const [user] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, req.session.userId!))
        .limit(1);
      if (!user) {
        res.status(404).json({ error: "User not found" });
        return;
      }

      const priceId = await getPriceIdForTier(tier as Tier);
      if (!priceId) {
        res.status(400).json({
          error:
            "This plan is not available yet. Please contact support.",
        });
        return;
      }

      const customerId = await getOrCreateCustomerId(
        user.id,
        user.email,
        user.name,
      );

      const host = req.get("host");
      const origin =
        req.get("origin") ||
        (host ? `${req.protocol}://${host}` : "");
      const successUrl = safeReturnUrl(
        req.body?.successUrl,
        host,
        `${origin}/account?checkout=success`,
      );
      const cancelUrl = safeReturnUrl(
        req.body?.cancelUrl,
        host,
        `${origin}/pricing?checkout=cancelled`,
      );

      const stripe = await getUncachableStripeClient();
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        mode: "subscription",
        line_items: [{ price: priceId, quantity: 1 }],
        success_url: successUrl,
        cancel_url: cancelUrl,
        allow_promotion_codes: true,
      });

      res.json({ url: session.url });
    } catch (err) {
      req.log?.error({ err }, "Stripe checkout failed");
      res.status(502).json({ error: "Could not start checkout." });
    }
  },
);

router.post("/billing/portal", requireAuth, async (req, res): Promise<void> => {
  if (req.session.accountType !== "email") {
    res.status(400).json({ error: "Billing is only available for email accounts." });
    return;
  }
  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId!))
      .limit(1);
    if (!user?.stripeCustomerId) {
      res.status(400).json({ error: "No billing account found." });
      return;
    }
    const host = req.get("host");
    const origin = req.get("origin") || (host ? `${req.protocol}://${host}` : "");
    const returnUrl = safeReturnUrl(
      req.body?.returnUrl,
      host,
      `${origin}/account`,
    );
    const stripe = await getUncachableStripeClient();
    const portal = await stripe.billingPortal.sessions.create({
      customer: user.stripeCustomerId,
      return_url: returnUrl,
    });
    res.json({ url: portal.url });
  } catch (err) {
    req.log?.error({ err }, "Stripe portal failed");
    res.status(502).json({ error: "Could not open billing portal." });
  }
});

// Called by the success page after checkout to immediately refresh the tier.
router.post("/billing/sync", requireAuth, async (req, res): Promise<void> => {
  if (req.session.accountType !== "email") {
    res.json({ tier: req.session.userTier ?? "starter" });
    return;
  }
  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId!))
      .limit(1);
    if (!user?.stripeCustomerId) {
      // Grandfathered users keep full access even without a Stripe subscription.
      const tier = user ? effectiveTier(user) : "starter";
      req.session.userTier = tier;
      res.json({ tier });
      return;
    }
    const subscriptionTier = await reconcileCustomerTier(user.stripeCustomerId);
    // A grandfathered user always resolves to full access regardless of what
    // their Stripe subscription reconciles to.
    const tier = user.grandfathered ? "firm" : subscriptionTier;
    req.session.userTier = tier;
    res.json({ tier });
  } catch (err) {
    req.log?.error({ err }, "Stripe sync failed");
    res.status(502).json({ error: "Could not refresh subscription." });
  }
});

export default router;
