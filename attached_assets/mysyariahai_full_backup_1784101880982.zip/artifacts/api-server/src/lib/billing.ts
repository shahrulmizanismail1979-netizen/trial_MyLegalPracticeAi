import { eq } from "drizzle-orm";
import { db, usersTable, type Tier } from "@workspace/db";
import { getUncachableStripeClient } from "./stripeClient";
import { PACKAGES } from "./tiers";

const ACTIVE_STATUSES = new Set(["active", "trialing", "past_due"]);

export async function getOrCreateCustomerId(
  userId: number,
  email: string,
  name: string,
): Promise<string> {
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, userId))
    .limit(1);

  if (user?.stripeCustomerId) return user.stripeCustomerId;

  const stripe = await getUncachableStripeClient();
  const customer = await stripe.customers.create({
    email,
    name,
    metadata: { appUserId: String(userId) },
  });

  await db
    .update(usersTable)
    .set({ stripeCustomerId: customer.id })
    .where(eq(usersTable.id, userId));

  return customer.id;
}

export async function getPriceIdForTier(tier: Tier): Promise<string | null> {
  const pkg = PACKAGES.find((p) => p.tier === tier);
  if (!pkg?.lookupKey) return null;

  const stripe = await getUncachableStripeClient();
  const prices = await stripe.prices.list({
    lookup_keys: [pkg.lookupKey],
    active: true,
    limit: 1,
  });
  return prices.data[0]?.id ?? null;
}

function tierForLookupKey(lookupKey: string | null | undefined): Tier {
  if (!lookupKey) return "starter";
  const pkg = PACKAGES.find((p) => p.lookupKey === lookupKey);
  return pkg?.tier ?? "starter";
}

/**
 * Reads the customer's live subscription from Stripe and updates the
 * matching app_users row's tier / status. Returns the resolved tier.
 */
export async function reconcileCustomerTier(customerId: string): Promise<Tier> {
  const stripe = await getUncachableStripeClient();
  const subs = await stripe.subscriptions.list({
    customer: customerId,
    status: "all",
    limit: 10,
    expand: ["data.items.data.price"],
  });

  const active = subs.data.find((s) => ACTIVE_STATUSES.has(s.status));

  let tier: Tier = "starter";
  let status: string | null = null;
  let subscriptionId: string | null = null;

  if (active) {
    status = active.status;
    subscriptionId = active.id;
    const price = active.items.data[0]?.price;
    tier = tierForLookupKey(price?.lookup_key);
  } else if (subs.data.length > 0) {
    status = subs.data[0].status;
  }

  await db
    .update(usersTable)
    .set({
      tier,
      subscriptionStatus: status,
      stripeSubscriptionId: subscriptionId,
    })
    .where(eq(usersTable.stripeCustomerId, customerId));

  return tier;
}
