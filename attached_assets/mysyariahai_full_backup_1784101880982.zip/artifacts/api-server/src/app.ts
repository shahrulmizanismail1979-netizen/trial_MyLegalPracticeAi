import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import session from "express-session";
import router from "./routes";
import { logger } from "./lib/logger";
import { WebhookHandlers } from "./lib/webhookHandlers";

const app: Express = express();

app.set("trust proxy", 1);

// Stripe webhook MUST be registered BEFORE express.json() so it receives the
// raw Buffer body required for signature verification. (Replit Stripe integration)
app.post(
  "/api/stripe/webhook",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    const signature = req.headers["stripe-signature"];
    if (!signature) {
      res.status(400).json({ error: "Missing stripe-signature" });
      return;
    }
    try {
      const sig = Array.isArray(signature) ? signature[0] : signature;
      if (!Buffer.isBuffer(req.body)) {
        logger.error(
          "STRIPE WEBHOOK ERROR: req.body is not a Buffer. Ensure this route is before express.json().",
        );
        res.status(500).json({ error: "Webhook processing error" });
        return;
      }
      await WebhookHandlers.processWebhook(req.body as Buffer, sig);
      // Reconcile the affected customer's tier (signature already verified).
      try {
        const { reconcileCustomerTier } = await import("./lib/billing");
        const event = JSON.parse(req.body.toString());
        const obj = event?.data?.object;
        const customerId =
          typeof obj?.customer === "string"
            ? obj.customer
            : obj?.object === "customer"
              ? obj.id
              : null;
        if (customerId) await reconcileCustomerTier(customerId);
      } catch (reconcileErr) {
        logger.error({ err: reconcileErr }, "Tier reconcile after webhook failed");
      }
      res.status(200).json({ received: true });
    } catch (error) {
      logger.error({ err: error }, "Stripe webhook error");
      res.status(400).json({ error: "Webhook processing error" });
    }
  },
);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

const SESSION_SECRET = process.env.SESSION_SECRET;
if (!SESSION_SECRET || SESSION_SECRET.length < 16) {
  throw new Error(
    "SESSION_SECRET is required and must be at least 16 characters. Set it in the environment before starting the server.",
  );
}

app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000,
      sameSite: "lax" as const,
    },
  }),
);

app.use("/api", router);

export default app;
