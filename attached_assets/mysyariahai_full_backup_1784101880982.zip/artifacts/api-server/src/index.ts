import { runMigrations } from "stripe-replit-sync";
import app from "./app";
import { logger } from "./lib/logger";
import { seedAllData } from "@workspace/scripts";
import { getStripeSync } from "./lib/stripeClient";

async function seedOnStartup() {
  try {
    await seedAllData();
    logger.info("All seed data ensured in database");
  } catch (err) {
    logger.error({ err }, "Failed to seed data on startup");
  }
}

// Non-fatal: the app must still boot if Stripe isn't connected yet.
async function initStripe() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    logger.warn("DATABASE_URL missing; skipping Stripe init");
    return;
  }
  try {
    await runMigrations({ databaseUrl, schema: "stripe" });
    const stripeSync = await getStripeSync();
    const webhookBaseUrl = `https://${process.env.REPLIT_DOMAINS?.split(",")[0]}`;
    const { webhook } = await stripeSync.findOrCreateManagedWebhook(
      `${webhookBaseUrl}/api/stripe/webhook`,
    );
    logger.info({ url: webhook?.url }, "Stripe managed webhook ready");
    stripeSync
      .syncBackfill()
      .then(() => logger.info("Stripe data synced"))
      .catch((err) => logger.error({ err }, "Stripe syncBackfill failed"));
  } catch (err) {
    logger.warn(
      { err: err instanceof Error ? err.message : err },
      "Stripe not initialized (integration may not be connected yet)",
    );
  }
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

seedOnStartup()
  .then(() => initStripe())
  .then(() => {
    app.listen(port, (err) => {
      if (err) {
        logger.error({ err }, "Error listening on port");
        process.exit(1);
      }

      logger.info({ port }, "Server listening");
    });
  });
