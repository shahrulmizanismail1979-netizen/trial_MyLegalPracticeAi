---
name: Master access-code override
description: How the owner master login works and the client-side casing constraint that governs it.
---

# Master access-code override

A single owner credential grants full admin access without a DB row. It is checked
in `POST /auth/verify` (the Access Code tab path) against the `MASTER_ACCESS_CODE`
secret (global, so it works in dev and prod). On match it mints a synthetic session:
`userId=-1`, `role=admin`, `tier=firm`, `accountType=code`.

**Why case-insensitive matching is mandatory:** the Access Code field in the web
login uppercases input client-side (`code.trim().toUpperCase()`) before POSTing.
Any server-side credential compared against that field MUST normalize both sides
(trim + uppercase) or a mixed/lowercase secret will silently fail through the UI
while still passing a raw curl test. This bit us once — curl with the exact value
passed, the real UI path failed.

**How to apply:** any new credential checked on `/auth/verify` must normalize case
the same way. `userId=-1` is intentionally truthy so `requireAuth` passes; keep DB
refreshes (session/billing) gated to `accountType === "email"` so the synthetic
user never triggers a `usersTable` lookup. `/auth/verify` has an in-memory per-IP
rate limiter (10 failures / 15 min → 429); it resets on server restart.
