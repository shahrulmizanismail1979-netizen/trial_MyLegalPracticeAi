---
name: Gated endpoint 402 crash class
description: Why tier-gated list pages crash and the required pattern to prevent it
---

Tier-gated API routes return HTTP 402 with a JSON object `{error:"upgrade_required"}` (a prefix-gate middleware on the server enforces this; it is authoritative). When a frontend page fetches such an endpoint and immediately calls `.map`/`.find` on the parsed body, the body is an object, not an array, so it throws `X is not a function` and the page crashes with a Vite error overlay — even for the lock/upgrade UI that was supposed to render.

**Rule:** Any page that lists data from a gated endpoint must do BOTH:
1. Early-return `<UpgradePrompt requiredTier=... featureName=... featureNameBm=... />` when `!tierHasFeature(user?.tier, feature)`, BEFORE its data-fetching hooks run. Implement as a thin default-export wrapper that gates, then renders an inner `*Inner()` component holding the original hooks — this keeps hook order valid.
2. Guard array operations with `Array.isArray(x) ? x.find(...) : undefined` (note `x?.find` does NOT protect against an object body, only against undefined).

**Why:** Frontend tier checks are defense-in-depth only; the server is the real gate. The crash is a UX failure, not a security one, but it makes the whole page unusable for lower tiers.

**How to apply:** Feature keys live in `artifacts/mysyariahai/src/lib/tiers.ts` (mirrors the server's `tiers.ts`). aiToolkit/voiceMode = professional; elevenLabs/voiceStt/kitab/tafsir = premium.
