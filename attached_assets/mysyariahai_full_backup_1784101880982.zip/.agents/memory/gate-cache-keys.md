---
name: Gate-scoped React Query keys
description: Why every gate-aware list page must include the active gate in its React Query queryKey, and how withGate() works.
---

# Gate-scoped caching across practice gates

The three practice gates (civil/criminal/advisory) filter list content. The DB
`gates` column and the backend `gateCondition()` filtering are correct and
verified — if content "looks the same across gates", the bug is almost always on
the frontend, NOT the backend.

**Rule:** Every gate-aware list/category/facet query MUST include the active gate
in its `queryKey` (e.g. `["cases", gate, search, category]`). Get `gate` from
`useGate()` (`@/lib/gate-context`).

**Why:** React Query caches by queryKey. If the key omits the gate, switching
gates serves the previous gate's cached entry, so all gates show identical
content. `invalidateQueries` on gate switch only masks this; the key omission is
the real defect.

**How to apply:** When adding a new page that lists data from a gated endpoint,
add `const { gate } = useGate();` and put `gate` into every list/category/facet
queryKey. Detail-by-id queries should stay ungated.

**api.ts `withGate()`:** auto-appends `?gate=` to all list/category/facet paths.
The ONLY exclusion is detail-by-id paths matched by `/\/\d+$/` (an opened result
must resolve regardless of current gate). Do NOT manually append `?gate=` in
individual api methods — withGate handles it; manual appends on detail endpoints
wrongly gate them and break direct/opened lookups.

**Debugging note:** pino logs only the pathname (no query string), so a logged
URL like `/api/cases` does NOT prove the gate param was absent.
