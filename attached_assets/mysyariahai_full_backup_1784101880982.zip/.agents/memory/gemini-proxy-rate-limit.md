---
name: Gemini integration proxy rate limit
description: How the Replit @workspace/integrations-gemini-ai proxy throttles bulk generateContent calls and how to seed reliably.
---

The Replit-managed Gemini proxy (`ai.models.generateContent` from `@workspace/integrations-gemini-ai`) enforces a harsh per-minute rate limit for bulk/batch usage. Single ad-hoc calls return in ~1.5s, but a long-running seed loop reliably gets ~10 successful calls through, then the proxy **hangs over-quota requests open** (it does NOT fast-fail with 429) for a multi-minute cooldown. Bursting (concurrency >1 or tiny inter-call delays) makes it worse and the cooldown poison carries across process restarts until quota fully clears.

**How to apply (bulk AI seeding via the Gemini proxy):**
- Use concurrency = 1.
- Wrap every call in a timeout (~25s) via `Promise.race` so a hung request unblocks the loop instead of freezing forever.
- Pace calls with a fixed inter-call delay (~8s) — fast pacing trips the cooldown after ~10 rows.
- Use quota-aware retry backoff that waits out a full minute window (e.g. 20s/40s/65s), not 1–2s — short backoffs just re-hit the closed window and the row fails to NULL.
- Make the seed idempotent (only process rows whose target column IS NULL) and write EN+BM atomically in one UPDATE so re-runs cleanly resume and no partial rows occur.
- Expect bursty throughput (~6–10 rows/min then a stall); full backfill of ~100+ rows takes many minutes and may need repeated idempotent re-runs. Treat DB row counts as the source of truth — nohup stdout is buffered and lags badly.

**Why:** Babysitting wasted many turns chasing "hard stalls" that were actually the proxy's hang-on-overage behavior, not a code bug. The single-call debug always worked, which proves the model/prompt are fine and the bottleneck is purely the proxy rate limit.
