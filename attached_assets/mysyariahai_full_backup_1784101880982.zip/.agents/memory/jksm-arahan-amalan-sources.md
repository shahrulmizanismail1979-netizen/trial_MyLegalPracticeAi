---
name: JKSM Arahan Amalan source PDFs
description: How to source/verify official JKSM practice-direction PDF links for the Practice Directions module.
---

# JKSM Arahan Amalan (practice directions) source links

The official compilation used for `practice_directions.sourceUrl` is the Perak State
Syariah Judiciary portal, which mirrors the national JKSM Arahan Amalan list:
`https://syariah.perak.gov.my/index.php/en/info/arahan-amalan-jabatan-kehakiman-syariah-malaysia`
PDFs live under `…/images/pdf/arahanamalanjksm/`.

**Rule: never construct the PDF URL from a pattern.** Filenames are inconsistent across
years — older entries use `AA_{no}_{year}.pdf`, newer ones use `aa{no}tahun{year}.pdf`
(and occasional one-offs like `aat5tahun2023.pdf`). Some links on the page are also
year-mismatched vs. their stated ref number, and some 404.

**How to apply:** scrape the exact hrefs from the page, HTTP-GET each candidate, and keep
only links returning 200. For entries whose link 404s or whose filename year contradicts
the ref number, set `sourceUrl` to `null` (the detail UI hides the source card when null —
no dead links shown). The seed embeds a hand-verified `VERIFIED_URLS` map keyed by
`"{no}/{year}"` rather than building URLs at runtime.

**Why:** the user requires verified real sources, not fabricated/guessed links; a
constructed-pattern approach silently produced many dead links.
