---
name: DB column additions need a committed idempotent provisioner
description: Adding a nullable column to a schema requires a committed ALTER ... IF NOT EXISTS, not just a one-off dev ALTER.
---

Adding a column to a Drizzle schema in `lib/db` is NOT enough: the route uses `db.select()` which selects ALL schema columns, so any DB missing the column errors at runtime ("column does not exist"). A one-off `ALTER` run in the dev DB does not provision fresh/staging/production DBs.

**Rule:** every new schema column must be backed by a committed idempotent provisioner — either a standalone `scripts/src/*` script (`ALTER TABLE x ADD COLUMN IF NOT EXISTS ...` via the raw `pool` import) or, cleaner, embed that ALTER at the top of the seed script that populates the column so running the seed self-provisions.

**Why:** the project has no auto-migration on boot (startup logs "Database already seeded — skipping"); seeds/backfills are manual scripts. Without a committed provisioner the schema/DB drift silently and only break on a fresh deploy.

**How to apply:** mirror `backfill-legislation-sources.ts` or `seed-state-fatwas.ts` (which runs the ALTER before inserting). `scripts` imports `{ db, pool }` from `@workspace/db`; use `pool.query(...)` for DDL.
