---
name: Tier resolution & grandfathering
description: Every path that writes session.userTier for an email account must apply effectiveTier (grandfathered → "firm"), not the raw stored/Stripe tier.
---

# Tier resolution must be applied at EVERY entry point

Email accounts carry a `grandfathered` flag. Early adopters (credentials issued
on or before the launch cutoff) get full ("firm") access for life; only new
sign-ups AFTER the cutoff are subject to the subscription paywall. Access-code
logins are a separate trusted path that already hard-sets "firm".

The effective tier = `grandfathered ? "firm" : storedOrSubscriptionTier`.

**Rule:** anywhere that sets `req.session.userTier` for an email account must run
the value through the grandfather resolver — NOT just register/login/session.
The easily-missed one is the Stripe billing-sync path: it reconciles tier from
Stripe and would downgrade a grandfathered user with no active subscription back
to starter if it writes the raw reconciled tier.

**Why:** a code review caught that register/login/session were fixed but
`/billing/sync` still wrote the raw `reconcileCustomerTier(...)` result, silently
re-paywalling grandfathered users after they hit `/account?checkout=...`.

**How to apply:** when adding/auditing any tier write, grep for `userTier =` and
confirm each email-account branch resolves grandfathered → firm. The cutoff
constant + helpers live in api-server `lib/grandfather.ts`. Frontend reads
`user.tier` straight from the session, so no client change is needed — server is
authoritative.
