---
name: One-off DB scripts in @workspace/scripts
description: How to do raw SQL / DB writes from scripts, and why manual DB edits need a committed backfill script
---

Rule: In the `@workspace/scripts` package, do NOT `import { sql } from "drizzle-orm"` — drizzle-orm is not a dependency of that package, so tsx fails with ERR_MODULE_NOT_FOUND. Use the `pool` exported from `@workspace/db` (node-postgres) with parameterized `pool.query("... $1 ...", [val])` instead.

**Why:** scripts only depends on `@workspace/db`, not the ORM directly. Cost an extra attempt when writing the legislation source-url backfill.

**How to apply:** For any ad-hoc SQL in a scripts/src/*.ts file, reach for `pool.query`. Re-export `sql` from @workspace/db only if you truly need the query builder there.

Companion rule — avoid environment drift: when a schema/data change is applied manually in dev (e.g. `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` + ad-hoc UPDATEs) because `drizzle push` is interactive/unreliable, also commit an **idempotent** backfill script (ADD COLUMN IF NOT EXISTS + UPDATE ... WHERE key=...) and register it in scripts/package.json. Re-running the normal seeds is unsafe here because they use onConflictDoNothing on a serial PK and duplicate existing rows.
