---
name: Stripe build externalization
description: stripe-replit-sync must not be bundled by esbuild or it breaks at runtime
---

`stripe-replit-sync` resolves its SQL migrations directory relative to its own package location on disk. If esbuild bundles it into the api-server output, that path lookup fails at runtime and Stripe init crashes with an error like "stripe.accounts does not exist".

**Rule:** Keep `stripe-replit-sync` in the `external[]` array in `artifacts/api-server/build.mjs`. After this, a clean boot logs "Stripe managed webhook ready" + "Stripe data synced".

**Why:** It is a build-vs-runtime path resolution issue, not a code bug — typecheck and dev (esbuild-less) both pass, so it only surfaces in a bundled build.

## Seeding live (production) Stripe data from the dev shell

The Stripe credential helper picks its environment from `REPLIT_DEPLOYMENT === "1"` (prod → production/live creds, otherwise development/test). The seed script runs in the dev shell where that flag is unset, so a plain `pnpm --filter @workspace/scripts run seed-stripe` targets TEST mode.

**Rule:** To seed the live account from the shell, prefix the command: `REPLIT_DEPLOYMENT=1 pnpm --filter @workspace/scripts run seed-stripe`. Verify with `livemode: true` by reading prices back through the production connection (`listConnections("stripe")` → `environment === "production"`).

**Why:** Live charges only happen in the deployed app; the dev preview is intentionally test mode. The seed is idempotent (keyed by `lookup_key`) so re-running is safe.
