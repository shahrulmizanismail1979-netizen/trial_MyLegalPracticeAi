---
name: Faraid reserve-share (al-Mawquf) math
description: Why the unborn/missing-heir reserve calculator is intentionally guidance-only, not computed.
---

The Faraid calculator's "Succession & Special Cases" view computes two cases (Munasakha — heir dies before distribution; Wasiat Wajibah — orphaned grandchildren) but leaves al-Haml (unborn), al-Mafqud (missing heir), al-Gharqa (simultaneous death) and al-Khuntha (ambiguous sex) as **informational cards only**.

**Rule:** do NOT add an executable al-Mawquf reserve calculator using an aggregate-by-key shortcut (run scenarios, take per-key minimum amount, reserve the remainder).

**Why:** that shortcut is correct only when no existing/certain heir shares a class (key) with the contingent heir. When a base heir and the unborn are both e.g. sons, the engine aggregates the "son" amount, so per-capita guarantees are lost and base sons get over-paid / the reserve under-held. Rigorous al-Mawquf needs per-capita tracking and per-heir minima across ALL plausible foetus configurations, not just boundaries. Shipping the shortcut would produce subtly wrong numbers — violates the project's "verified Islamic sources, never fabricated" principle. These cases are also genuinely court-determined on facts (live birth, sex, order of death).

**How to apply:** if asked to make these cases computable, implement true per-capita scenario enumeration and get it reviewed for fiqh accuracy; otherwise keep them as guidance describing the reserve method.
