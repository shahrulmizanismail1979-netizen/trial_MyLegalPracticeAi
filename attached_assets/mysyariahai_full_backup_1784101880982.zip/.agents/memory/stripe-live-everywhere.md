---
name: Stripe forced LIVE in all environments
description: Why the dev/preview environment uses live Stripe instead of the sandbox/test connection.
---

# Stripe forced LIVE in all environments

`getStripeCredentials()` in `stripeClient.ts` hardcodes `targetEnvironment = "production"`,
so the Replit dev preview fetches the LIVE Stripe connection, not the development
(test/sandbox) one. Normal Replit setup is dev=test, prod=live; this deviates by owner request.

**Why:** the owner explicitly asked to "settle the Stripe sandbox once and for all" and
chose to run live everywhere, accepting that checkout in the preview creates real,
chargeable subscriptions.

**How to apply:** do NOT reintroduce the `REPLIT_DEPLOYMENT`-based dev/prod split here
unless the owner reverses this. Checkout/QA in preview must use real test accounts and be
treated as live money. If reversibility is wanted, gate it behind an env flag (e.g.
`STRIPE_FORCE_LIVE`) rather than silently restoring the sandbox.
