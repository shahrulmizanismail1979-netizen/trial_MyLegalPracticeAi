# MySyariahAI

## Overview

MySyariahAI is an AI-powered Shariah Legal Practice Platform for Malaysian legal practitioners. It provides a comprehensive, multilingual (English / Bahasa Melayu / Arabic with RTL) suite of tools including legal research, AI-driven analysis, document generation, and practice management features. The platform is organised around three Practice Gates (Civil Litigation, Criminal Litigation, Advisory & Consultancy) and aims to enhance efficiency and accuracy for legal professionals specializing in Shariah law.

## User Preferences

I prefer simple language, avoid jargon where possible, and provide clear explanations. I value iterative development with frequent, small updates rather than large, infrequent ones. Please ask for my approval before making any significant architectural changes or adding new external dependencies. I prefer detailed explanations for complex features and design choices.

## System Architecture

The project is built as a pnpm workspace monorepo using TypeScript, Node.js 24, and pnpm. The backend is an Express 5 API server, and the frontend uses React with Vite, Tailwind CSS, and shadcn/ui. PostgreSQL with Drizzle ORM handles data persistence. Google Gemini 2.5 Flash is integrated for AI functionalities, utilizing Server-Sent Events (SSE) for streaming responses.

**Key Features:**

*   **Authentication:** Two parallel methods — (1) self-serve email/password accounts (scrypt hashing, timing-safe compare) and (2) the original access-code system with role-based access (practitioner, admin, judge). Sessions use `express-session`; `SESSION_SECRET` is required at startup (the server fails fast if it is missing or shorter than 16 chars). The login page exposes Sign In / Sign Up / Access Code tabs.
*   **Subscription Billing (Stripe):** Four tiers in MYR — Starter (free), Professional (RM 49/mo), Premium (RM 149/mo), Firm (RM 399/mo). Stripe runs via the Replit Stripe connector (`stripeClient.ts` reads connection settings: `secret` + `webhook_secret`, header `X-Replit-Token`, `environment` query param). Products/prices are seeded with `pnpm --filter @workspace/scripts run seed-stripe`. The webhook route is mounted with `express.raw` BEFORE `express.json` so signature verification works (via `stripe-replit-sync`); `stripe-replit-sync` must stay in `build.mjs` `external[]` or its migrations dir lookup breaks the bundle. `/account?checkout=success` calls `POST /api/billing/sync` which uses `reconcileCustomerTier` (reads Stripe directly, webhook-independent) to update the user's tier. Endpoints: `/api/billing/packages`, `/checkout` (body `{tier}`), `/portal`, `/sync`.
*   **Tier Entitlements:** `FEATURE_MIN_TIER` (mirrored in `artifacts/api-server/src/lib/tiers.ts` and `artifacts/mysyariahai/src/lib/tiers.ts`) maps features to the minimum tier: `aiToolkit`/`voiceMode` = professional; `elevenLabs`/`voiceStt`/`kitab`/`tafsir` = premium. Server-side enforcement is authoritative: a prefix-gate middleware in `routes/index.ts` returns HTTP 402 `{error:"upgrade_required"}` for blocked routes, and ElevenLabs `/voice/tts` + `/voice/stt` add a `requireFeature` guard. Frontend gates are defense-in-depth only: gated pages (voice-mode, kitab, tafsir, document-generator, legal-opinion, client-intake, compliance-check) check `tierHasFeature(user?.tier, ...)` and render `<UpgradePrompt>` instead of fetching — this also avoids the crash where a page called `.map`/`.find` on a 402 JSON object. Any new page that lists data from a gated endpoint must do the same (early-return UpgradePrompt + `Array.isArray` guards).
*   **Practice Gates:** After login, users select one of three gates — Civil Litigation (emerald), Criminal Litigation (rose), or Advisory & Consultancy (amber). Selection is held in `gate-context.tsx` and the chosen gate (a) filters sidebar navigation, (b) is auto-injected as `?gate=X` on list API calls via `setApiGate()` in `api.ts`, and (c) is visible as a colored badge in the sidebar with a "Switch gate" link. Content rows carry a comma-separated `gates` column; the API uses `gateCondition()` in `artifacts/api-server/src/lib/gate-filter.ts` to filter via LIKE matching.
*   **Content Modules:** Eleven core modules for legal research, including Legal Provisions, Case Laws, Cause Papers, Procedural Workflows, Glossary, Legislation, Quranic Verses, Gazetted Fatwas, and a Dashboard. All gate-aware tables now also carry `state`, `title_ar`, `jurisdiction`, and `tafsir_en/bm` columns to support state enactments and Arabic content.
*   **Unified Workflow Surfaces:** Two consolidation pages help practitioners avoid retyping facts and avoid feature-name confusion: **AI Toolkit** at `/ai-toolkit` groups every AI feature into four intent-based sections (Case Workspace / Research the Sources / Analyse the Case / Draft & File) with "when to use" guidance and respects the active gate. **Case Workspace** at `/case-workspace` takes one scenario input (facts, parties, relief, position, questions) and fans it out in parallel via SSE to the AI Analyzer, Case Analysis & Prediction, and Legal Opinion endpoints, displaying the three results in tabs. The Client Intake assistant's generated brief now links straight into the Case Workspace via a `sessionStorage` seed, so an intake brief becomes a one-click analysis pipeline. Each parallel SSE stream is guarded by an AbortController + identity check so a cancelled prior run cannot clobber a fresh run's state.
*   **Premium AI Features:** Twelve advanced AI features — Smart Search, Case Analysis & Prediction, Document Generator, Faraid Calculator, Kitab Reference & Analysis (44-entry library spanning Shafi'i/Maliki/Hanafi/Hanbali/Usul/Maqasid/Hadith/AAOIFI/BNM SAC, plus foundational Malay-Jawi pondok texts — Sabil al-Muhtadin, Hidayat al-Salikin, Furu' al-Masa'il, Bughyat al-Tullab, Tafsir Pimpinan al-Rahman, JKSM Garis Panduan Hakim Syarie — visible across all three practice gates, with notableRulings and sampleQuestions per kitab plus a quick-pick sample-question card and full Arabic UI; load-time integrity guard), AI Analyzer, Legal Opinion Writer, Shariah Compliance Checker, Client Intake Assistant, Court Fee & Timeline Calculator, **AI Tafsir Al-Quran** (114-surah index, scholarly streaming tafsir drawing on Tabari, Ibn Kathir, Qurtubi, Razi, Jalalayn, Tafsir Pimpinan Ar-Rahman; focus modes: comprehensive/ahkam/linguistic/asbab/Malaysian application), and **Voice Mode — Court Practice** (two-way Web Speech API STT+TTS with four practice modes: Oral Submission, Examination-in-Chief, Cross-Examination, Bench Q&A; AI plays Yang Arif/witness/hostile witness; includes trainer feedback critique of the full transcript).
*   **Multilingual System:** Supports English, Bahasa Melayu, Both (side-by-side), and Arabic (العربية) with `dir="rtl"`. The language helper `t(en, bm, ar?)` and string helper `ts()` live in `language-context.tsx`.
*   **UI/UX Design:** Dark, Islamic-inspired theme using deep teal, gold, and emerald, with Inter, Playfair Display, and Space Mono fonts.
*   **AI Guardrails:** Critical restrictions are implemented in all AI prompts to ensure responses adhere strictly to Shariah/Islamic law, prevent fabrication of citations, and cite only from the provided database.
*   **Enhanced Features:** Includes AI Paralegal Drafter for cause papers, hyperlinks between provisions and related cases, enhanced AI Counsel with suggested prompts and conversation export, and deep-linking capabilities across sections.

## External Dependencies

*   **Monorepo Tool:** pnpm workspaces
*   **Database:** PostgreSQL
*   **ORM:** Drizzle ORM
*   **Frontend Frameworks:** React, Vite
*   **UI Libraries:** Tailwind CSS, shadcn/ui
*   **Charting Library:** Recharts
*   **AI Service:** Google Gemini 2.5 Flash via `@google/genai`
*   **Routing:** wouter (frontend), Express Router (backend)
*   **State Management:** React Query, React Context
*   **Validation:** Zod, drizzle-zod
*   **Build Tools:** esbuild (API), Vite (frontend)
*   **Session Management:** express-session