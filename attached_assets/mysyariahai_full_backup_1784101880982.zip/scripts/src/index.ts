export { seed } from "./seed";
export { seedNewSections } from "./seed-new-sections";
export { seedMoreVerses } from "./seed-more-verses";

import { seed } from "./seed";
import { seedNewSections } from "./seed-new-sections";
import { seedMoreVerses } from "./seed-more-verses";
import { db, provisionsTable } from "@workspace/db";

export async function seedAllData() {
  const existing = await db.select({ id: provisionsTable.id }).from(provisionsTable).limit(1);
  if (existing.length > 0) {
    console.log("Database already seeded — skipping seed to prevent duplicates.");
    return;
  }
  await seed();
  await seedNewSections();
  await seedMoreVerses();
}
