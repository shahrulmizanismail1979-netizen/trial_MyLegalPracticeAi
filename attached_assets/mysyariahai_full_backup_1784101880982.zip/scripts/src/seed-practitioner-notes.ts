import { db, pool } from "@workspace/db";
import {
  caseLawsTable,
  legislationTable,
  fatwaTable,
  quranicVersesTable,
} from "@workspace/db";
import { ai } from "@workspace/integrations-gemini-ai";
import { eq, isNull } from "drizzle-orm";

// Generates a "practitioner notes" layer for reference content that lacks one.
// The notes are GENERAL practice/how-to-use craft guidance for a Malaysian
// Shariah practitioner, grounded strictly on each row's already-verified
// fields. The model is explicitly forbidden from inventing new citations,
// statutes, case names, or facts. Re-running is idempotent: only rows whose
// practitioner_notes_en is NULL are processed.

const RULES = `You are drafting PRACTITIONER NOTES for a Malaysian Shariah legal practitioner using an item from a verified legal database.

STRICT RULES:
- Write GENERAL practice / "how to use this in practice" craft guidance ONLY.
- Do NOT invent or add any new citations, statute names, section numbers, case names, dates, or facts. Use only what is given in the source item.
- Focus on procedural craft: how a practitioner would actually use this item, what to check or verify first, the practical steps, common pitfalls and risks, and a strategic tip a junior practitioner would miss.
- Keep it concise and scannable: 2 to 4 short sentences. No headings, no markdown, no preamble.
- Output STRICT JSON only, exactly: {"en": "<English notes>", "bm": "<faithful Bahasa Melayu translation of the same notes>"}`;

type Job = { id: number; context: string };

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    p,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error(`timeout after ${ms}ms`)), ms)),
  ]);
}

async function generateNotes(context: string): Promise<{ en: string; bm: string } | null> {
  const prompt = `${RULES}\n\nSOURCE ITEM:\n${context}\n\nReturn the JSON now.`;
  // Quota-aware backoff: the Gemini free tier throttles per-minute, so when a
  // call fails (often by hanging until our timeout) we must wait out the whole
  // window before retrying, not a couple of seconds.
  const backoffs = [20000, 40000, 65000];
  for (let attempt = 0; attempt <= backoffs.length; attempt++) {
    try {
      const res = await withTimeout(
        ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            maxOutputTokens: 2048,
            thinkingConfig: { thinkingBudget: 0 },
          },
        }),
        25000,
      );
      const raw = (res.text ?? "").trim();
      const cleaned = raw.replace(/^```json\s*/i, "").replace(/^```\s*/, "").replace(/```\s*$/, "").trim();
      const parsed = JSON.parse(cleaned) as { en?: string; bm?: string };
      if (parsed.en && parsed.bm) return { en: parsed.en.trim(), bm: parsed.bm.trim() };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (attempt < backoffs.length) {
        console.warn(`  retry ${attempt + 1}/${backoffs.length} after error: ${msg} (waiting ${backoffs[attempt] / 1000}s)`);
        await new Promise((r) => setTimeout(r, backoffs[attempt]));
      } else {
        console.warn(`  gave up after error: ${msg}`);
      }
    }
  }
  return null;
}

async function runBatch(
  label: string,
  jobs: Job[],
  update: (id: number, en: string, bm: string) => Promise<void>,
): Promise<void> {
  console.log(`\n=== ${label}: ${jobs.length} rows to enrich ===`);
  const concurrency = 1;
  let done = 0;
  for (let i = 0; i < jobs.length; i += concurrency) {
    const slice = jobs.slice(i, i + concurrency);
    await Promise.all(
      slice.map(async (job) => {
        const notes = await generateNotes(job.context);
        if (notes) {
          await update(job.id, notes.en, notes.bm);
          done++;
        } else {
          console.warn(`  [${label} #${job.id}] failed to generate notes, left NULL`);
        }
      }),
    );
    console.log(`  ${label}: ${Math.min(i + concurrency, jobs.length)}/${jobs.length} processed`);
    await new Promise((r) => setTimeout(r, 8000));
  }
  console.log(`=== ${label}: ${done}/${jobs.length} enriched ===`);
}

async function seedPractitionerNotes() {
  console.log("Generating practitioner notes for reference content...");

  // CASE LAWS
  const cases = await db.select().from(caseLawsTable).where(isNull(caseLawsTable.practitionerNotesEn));
  await runBatch(
    "case_laws",
    cases.map((c) => ({
      id: c.id,
      context: `Type: Shariah case law / precedent
Case: ${c.caseName}
Citation: ${c.citation}
Court: ${c.court}
Year: ${c.year}
Category: ${c.category}
Facts: ${c.factsEn}
Issues: ${c.issuesEn}
Held: ${c.heldEn}
Significance: ${c.significanceEn}`,
    })),
    async (id, en, bm) => {
      await db.update(caseLawsTable).set({ practitionerNotesEn: en, practitionerNotesBm: bm }).where(eq(caseLawsTable.id, id));
    },
  );

  // LEGISLATION
  const legs = await db.select().from(legislationTable).where(isNull(legislationTable.practitionerNotesEn));
  await runBatch(
    "legislation",
    legs.map((l) => ({
      id: l.id,
      context: `Type: Legislation / enactment
Title: ${l.titleEn}
Act number: ${l.actNumber ?? "-"}
Year: ${l.year ?? "-"}
Category: ${l.category ?? "-"}
Description: ${l.descriptionEn}
Key provisions: ${l.keyProvisionsEn ?? "-"}`,
    })),
    async (id, en, bm) => {
      await db.update(legislationTable).set({ practitionerNotesEn: en, practitionerNotesBm: bm }).where(eq(legislationTable.id, id));
    },
  );

  // GAZETTED FATWAS
  const fatwas = await db.select().from(fatwaTable).where(isNull(fatwaTable.practitionerNotesEn));
  await runBatch(
    "gazetted_fatwas",
    fatwas.map((f) => ({
      id: f.id,
      context: `Type: Gazetted fatwa
Title: ${f.titleEn}
Issuing body: ${f.issuingBody}
Year: ${f.year}
State: ${f.state ?? "-"}
Category: ${f.category}
Summary: ${f.summaryEn}
Details: ${f.detailsEn}`,
    })),
    async (id, en, bm) => {
      await db.update(fatwaTable).set({ practitionerNotesEn: en, practitionerNotesBm: bm }).where(eq(fatwaTable.id, id));
    },
  );

  // QURANIC VERSES
  const verses = await db.select().from(quranicVersesTable).where(isNull(quranicVersesTable.practitionerNotesEn));
  await runBatch(
    "quranic_verses",
    verses.map((v) => ({
      id: v.id,
      context: `Type: Quranic verse used as a legal source
Surah: ${v.surahName} (${v.ayahRange})
Category: ${v.category}
Translation: ${v.translationEn}
Legal relevance: ${v.relevanceEn}`,
    })),
    async (id, en, bm) => {
      await db.update(quranicVersesTable).set({ practitionerNotesEn: en, practitionerNotesBm: bm }).where(eq(quranicVersesTable.id, id));
    },
  );

  console.log("\nPractitioner notes generation complete.");
}

seedPractitionerNotes()
  .then(() => pool.end())
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    return pool.end().then(() => process.exit(1));
  });
