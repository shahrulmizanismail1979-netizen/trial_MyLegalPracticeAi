import { db, pool } from "@workspace/db";
import { practiceDirectionsTable, type InsertPracticeDirection } from "@workspace/db";

/**
 * Seed for the "Practice Directions & Circulars" module.
 *
 * SOURCE / ACCURACY POLICY:
 * Every entry below is a REAL JKSM Arahan Amalan (Practice Direction). The
 * reference number, year, Bahasa Melayu title, revocation status, and source PDF
 * link are taken from the official Syariah Judiciary compilation published on the
 * Perak State Syariah Judiciary portal (syariah.perak.gov.my), which mirrors the
 * national JKSM Arahan Amalan. The English title, plain-language summary, and
 * practitioner notes are editorial explanations written to help users understand
 * each direction — they are NOT verbatim translations of the official text, so the
 * official PDF (linked as `sourceUrl`) remains authoritative and must be verified
 * before being relied on in court.
 */

/**
 * Verified source PDF links (HTTP 200) for each direction, keyed by "no/year".
 * Taken from the official Syariah Judiciary compilation on the Perak State Syariah
 * Judiciary portal. Filenames are inconsistent across years, so each link was
 * individually checked; entries without a verified resolving link are omitted here
 * and fall back to `null` (no broken links shown to the user).
 */
const VERIFIED_URLS: Record<string, string> = {
  "3/2002": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_3_2002.pdf",
  "11/2005": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_11_2005.pdf",
  "4/2006": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_4_2006.pdf",
  "6/2020": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_6_2020.pdf",
  "8/2022": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa8tahun2022.pdf",
  "11/2002": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_11_2002.pdf",
  "7/2018": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_7_2018.pdf",
  "2/2021": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa2tahun2021.pdf",
  "4/2002": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_4_2002.pdf",
  "5/2022": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa5tahun2022.pdf",
  "1/2001": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_1_2001.pdf",
  "1/2003": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_1_2003.pdf",
  "2/2006": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_2_2006.pdf",
  "1/2006": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_1_2006.pdf",
  "2/2002": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_2_2002.pdf",
  "5/2016": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_5_2016.pdf",
  "5/2020": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_5_2020.pdf",
  "10/2021": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa10tahun2021.pdf",
  "7/2021": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa7tahun2021.pdf",
  "6/2021": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa6tahun2021.pdf",
  "2/2020": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_2_2020.pdf",
  "8/2021": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa8tahun2021.pdf",
  "7/2022": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa7tahun2022.pdf",
  "9/2016": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_9_2016.pdf",
  "7/2006": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_7_2006.pdf",
  "2/2023": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa2tahun2023.pdf",
  "3/2023": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa3tahun2023.pdf",
  "4/2023": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa4tahun2023.pdf",
  "4/2020": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_4_2020.pdf",
  "12/2003": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_12_2003.pdf",
  "10/2016": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_10_2016.pdf",
  "11/2016": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/AA_11_2016.pdf",
  "9/2021": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa9tahun2021.pdf",
  "1/2022": "https://syariah.perak.gov.my/images/pdf/arahanamalanjksm/aa1tahun2022.pdf",
};

/** Build a verified entry from the official AA reference. */
function aa(
  no: string,
  year: string,
  rest: Omit<InsertPracticeDirection, "refNo" | "year" | "sourceUrl" | "titleBm" | "issuingBody" | "issuingBodyBm" | "docType" | "state" | "jurisdiction"> & {
    titleBm: string;
    docType?: string;
    state?: string;
  },
): InsertPracticeDirection {
  return {
    refNo: `Arahan Amalan No. ${no} Tahun ${year} (JKSM)`,
    year,
    sourceUrl: VERIFIED_URLS[`${no}/${year}`] ?? null,
    issuingBody: "Department of Syariah Judiciary Malaysia (JKSM)",
    issuingBodyBm: "Jabatan Kehakiman Syariah Malaysia (JKSM)",
    docType: rest.docType ?? "practice_direction",
    state: rest.state ?? "Federal",
    jurisdiction: "malaysia",
    ...rest,
  };
}

const directions: InsertPracticeDirection[] = [
  // ───────────────────────── SULH (MEDIATION) ─────────────────────────
  aa("3", "2002", {
    titleEn: "Application of Sulh (Mediation)",
    titleBm: "Pemakaian Sulh",
    category: "Mediation (Sulh)",
    categoryBm: "Sulh",
    summaryEn:
      "Establishes Sulh (court-annexed mediation) as a standard step in the Syariah Courts, requiring eligible mal claims to be referred to a Sulh session before full trial.",
    summaryBm:
      "Menetapkan Sulh sebagai langkah standard di Mahkamah Syariah, mewajibkan tuntutan mal yang layak dirujuk ke Majlis Sulh sebelum perbicaraan penuh.",
    detailsEn:
      "Sets out the principle that parties should be given a structured opportunity to settle amicably through a trained Sulh Officer. Settlements reached are recorded and can be endorsed as a consent order; unresolved issues proceed to trial.",
    detailsBm:
      "Menetapkan prinsip bahawa pihak-pihak harus diberi peluang berstruktur untuk berdamai melalui Pegawai Sulh terlatih. Penyelesaian yang dicapai direkodkan dan boleh disahkan sebagai perintah persetujuan; isu yang belum selesai diteruskan ke perbicaraan.",
    practicalNotesEn:
      "Treat Sulh as a genuine settlement opportunity, not a formality. Come with a realistic settlement range, supporting figures (e.g. mutaah / maintenance computations) and authority to settle. Discussions are without prejudice.",
    practicalNotesBm:
      "Anggap Sulh sebagai peluang penyelesaian sebenar, bukan formaliti. Hadir dengan julat penyelesaian realistik, angka sokongan (cth. pengiraan mutaah / nafkah) dan kuasa untuk menyelesaikan. Perbincangan adalah tanpa prejudis.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments (Sulh provisions)",
    gates: "civil,advisory",
    order: 1,
  }),
  aa("11", "2005", {
    titleEn: "Jurisdiction of the Lower Syariah Court to Record Sulh and Mutual Agreement",
    titleBm: "Bidang Kuasa Mahkamah Rendah Syariah Merekodkan Sulh dan Persetujuan Bersama",
    category: "Mediation (Sulh)",
    categoryBm: "Sulh",
    summaryEn:
      "Clarifies that the Lower Syariah Court has jurisdiction to record a Sulh settlement and mutual agreement reached between parties.",
    summaryBm:
      "Menjelaskan bahawa Mahkamah Rendah Syariah mempunyai bidang kuasa untuk merekodkan penyelesaian Sulh dan persetujuan bersama yang dicapai antara pihak-pihak.",
    detailsEn:
      "Addresses which court level may record and endorse a Sulh agreement so that the settlement carries the force of a court order without unnecessary referral upwards.",
    detailsBm:
      "Menangani peringkat mahkamah mana yang boleh merekod dan mengesahkan perjanjian Sulh supaya penyelesaian itu mempunyai kuat kuasa perintah mahkamah tanpa rujukan ke atas yang tidak perlu.",
    practicalNotesEn:
      "Confirm the recording court has jurisdiction over the subject matter before finalising — recording in the wrong forum can expose the consent order to challenge.",
    practicalNotesBm:
      "Pastikan mahkamah yang merekod mempunyai bidang kuasa ke atas perkara sebelum dimuktamadkan — merekod di forum yang salah boleh mendedahkan perintah persetujuan kepada cabaran.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments",
    gates: "civil,advisory",
    order: 2,
  }),
  aa("4", "2006", {
    titleEn: "Order on a Sulh Consent Agreement",
    titleBm: "Perintah Perjanjian Persetujuan Sulh",
    category: "Mediation (Sulh)",
    categoryBm: "Sulh",
    summaryEn:
      "Provides the procedure for converting a successful Sulh consent agreement into a formal court order.",
    summaryBm:
      "Menyediakan prosedur untuk menukar perjanjian persetujuan Sulh yang berjaya menjadi perintah mahkamah formal.",
    detailsEn:
      "Covers how the agreed terms are drafted, recorded and endorsed by the court so the settlement becomes enforceable.",
    detailsBm:
      "Meliputi cara terma yang dipersetujui dirangka, direkod dan disahkan oleh mahkamah supaya penyelesaian menjadi boleh dikuatkuasakan.",
    practicalNotesEn:
      "Draft the consent terms precisely — payment amounts, dates, and what happens on default. Vague Sulh orders are the most common cause of later enforcement disputes.",
    practicalNotesBm:
      "Rangka terma persetujuan dengan tepat — jumlah bayaran, tarikh, dan apa yang berlaku jika ingkar. Perintah Sulh yang kabur adalah punca paling biasa pertikaian penguatkuasaan kemudian.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments",
    gates: "civil,advisory",
    order: 3,
  }),
  aa("6", "2020", {
    titleEn: "Priority Fast-Track Endorsement of Successful Sulh Agreements",
    titleBm: "Keutamaan Pengendorsan Melalui Laluan Pantas Perjanjian Persetujuan Yang Berjaya Diselesaikan Melalui Majlis Sulh",
    category: "Mediation (Sulh)",
    categoryBm: "Sulh",
    summaryEn:
      "Gives priority, fast-track endorsement to settlement agreements successfully concluded through a Sulh session.",
    summaryBm:
      "Memberi keutamaan pengendorsan laluan pantas kepada perjanjian penyelesaian yang berjaya disempurnakan melalui Majlis Sulh.",
    detailsEn:
      "Streamlines the post-Sulh process so that agreements reached are endorsed quickly rather than waiting in the general cause list.",
    detailsBm:
      "Memperkemas proses selepas Sulh supaya perjanjian yang dicapai disahkan dengan pantas dan tidak menunggu dalam senarai kes umum.",
    practicalNotesEn:
      "Once Sulh succeeds, push for same-day or fast-track endorsement while parties are present and aligned — delay invites second thoughts and renegotiation.",
    practicalNotesBm:
      "Sebaik Sulh berjaya, desak pengendorsan pada hari yang sama atau laluan pantas semasa pihak hadir dan sehaluan — kelewatan mengundang teragak-agak dan rundingan semula.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments",
    gates: "civil,advisory",
    order: 4,
  }),

  // ───────────────────────── CASE MANAGEMENT / PROCEDURE ─────────────────────────
  aa("8", "2022", {
    titleEn: "Mal Case Management: Filing of Bundle of Documents, Case Facts and Witness Statements",
    titleBm: "Garis Panduan Pengurusan Kes Mal Bagi Pemfailan Ikatan Dokumen, Fakta Kes Dan Penyata Keterangan",
    category: "Case Management",
    categoryBm: "Pengurusan Kes",
    summaryEn:
      "Standardises pre-trial case management in mal (civil) cases, including filing of the bundle of documents, agreed case facts, and written witness statements.",
    summaryBm:
      "Menyeragamkan pengurusan kes pra-perbicaraan dalam kes mal, termasuk pemfailan ikatan dokumen, fakta kes yang dipersetujui, dan penyata keterangan saksi bertulis.",
    detailsEn:
      "Sets expectations for what must be filed and exchanged before trial so issues are narrowed and hearings run efficiently.",
    detailsBm:
      "Menetapkan jangkaan tentang apa yang mesti difailkan dan ditukar sebelum perbicaraan supaya isu diperincikan dan perbicaraan berjalan cekap.",
    practicalNotesEn:
      "Prepare your bundle and witness statements early and to the required format. Non-compliant or late documents can be shut out, costing you evidence at trial.",
    practicalNotesBm:
      "Sediakan ikatan dokumen dan penyata saksi anda lebih awal dan mengikut format yang dikehendaki. Dokumen yang tidak mematuhi atau lewat boleh ditolak, merugikan keterangan anda di perbicaraan.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments",
    gates: "civil,advisory",
    order: 5,
  }),
  aa("11", "2002", {
    titleEn: "Priority of Cases",
    titleBm: "Keutamaan Kes",
    category: "Case Management",
    categoryBm: "Pengurusan Kes",
    summaryEn:
      "Directs which categories of cases are to be given priority in scheduling and disposal.",
    summaryBm:
      "Mengarahkan kategori kes mana yang perlu diberi keutamaan dalam penjadualan dan pelupusan.",
    detailsEn:
      "Identifies urgent and welfare-sensitive matters that should be heard ahead of the ordinary queue.",
    detailsBm:
      "Mengenal pasti perkara mendesak dan sensitif kebajikan yang patut didengar mendahului giliran biasa.",
    practicalNotesEn:
      "If your matter falls within a priority category (e.g. welfare of children, urgent injunctions), say so clearly at mention and ask for expedited dates.",
    practicalNotesBm:
      "Jika perkara anda termasuk dalam kategori keutamaan (cth. kebajikan kanak-kanak, injunksi mendesak), nyatakan dengan jelas semasa sebutan dan pohon tarikh dipercepat.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments",
    gates: "civil,criminal,advisory",
    order: 6,
  }),
  aa("3", "2022", {
    titleEn: "Conduct of Proceedings After the Trial Judge is Transferred Out",
    titleBm: "Tatacara Pengendalian Prosiding Kes Di Mahkamah Syariah Selepas Perpindahan Keluar Hakim Bicara",
    category: "Case Management",
    categoryBm: "Pengurusan Kes",
    summaryEn:
      "Provides how a part-heard case is to be handled when the trial judge is transferred before judgment.",
    summaryBm:
      "Menyediakan cara kes yang separa didengar dikendalikan apabila hakim bicara bertukar sebelum penghakiman.",
    detailsEn:
      "Addresses continuity — whether the case is continued, re-heard, or handled by the succeeding judge — to avoid prejudice to the parties.",
    detailsBm:
      "Menangani kesinambungan — sama ada kes diteruskan, didengar semula, atau dikendalikan oleh hakim pengganti — bagi mengelak prejudis kepada pihak-pihak.",
    practicalNotesEn:
      "If your trial judge is transferred mid-case, raise continuity immediately and protect the record so prior evidence is not lost or has to be repeated unnecessarily.",
    practicalNotesBm:
      "Jika hakim bicara anda bertukar di pertengahan kes, bangkitkan isu kesinambungan dengan segera dan lindungi rekod supaya keterangan terdahulu tidak hilang atau perlu diulang tanpa keperluan.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments",
    gates: "civil,criminal,advisory",
    order: 7,
  }),

  // ───────────────────────── DIGITAL / E-SYARIAH ─────────────────────────
  aa("7", "2018", {
    titleEn: "Digital / Electronic Management in the Syariah Courts",
    titleBm: "Pengurusan Digital/Elektronik Di Mahkamah Syariah",
    docType: "circular",
    category: "Filing & e-Syariah",
    categoryBm: "Pemfailan & e-Syariah",
    summaryEn:
      "Provides for digital and electronic management of court processes in the Syariah Courts.",
    summaryBm:
      "Memperuntukkan pengurusan digital dan elektronik bagi proses mahkamah di Mahkamah Syariah.",
    detailsEn:
      "Covers the move toward electronic handling of case documents and court workflow as part of e-Syariah modernisation.",
    detailsBm:
      "Meliputi peralihan ke arah pengendalian elektronik dokumen kes dan aliran kerja mahkamah sebagai sebahagian pemodenan e-Syariah.",
    practicalNotesEn:
      "Keep your e-Syariah credentials current and file well before deadlines — queues and document rejections (wrong format, incomplete fields) can cost a day. Always keep the electronic acknowledgement as proof of filing.",
    practicalNotesBm:
      "Pastikan kelayakan e-Syariah anda terkini dan failkan jauh sebelum tarikh akhir — giliran dan penolakan dokumen (format salah, medan tidak lengkap) boleh merugikan sehari. Sentiasa simpan akuan elektronik sebagai bukti pemfailan.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments (filing & registration)",
    gates: "civil,criminal,advisory",
    order: 8,
  }),
  aa("2", "2021", {
    titleEn: "Guidelines for Conducting Mal Proceedings via Remote Communication Technology",
    titleBm: "Garis Panduan Pengendalian Prosiding Kes Mal Di Mahkamah Syariah Melalui Teknologi Komunikasi Jarak Jauh",
    category: "Filing & e-Syariah",
    categoryBm: "Pemfailan & e-Syariah",
    summaryEn:
      "Sets out how mal (civil) proceedings may be conducted remotely using video / remote communication technology.",
    summaryBm:
      "Menetapkan cara prosiding kes mal boleh dikendalikan secara jarak jauh menggunakan teknologi komunikasi video / jarak jauh.",
    detailsEn:
      "Covers the conditions, conduct, and decorum for online hearings, including verifying identity and ensuring orderly participation.",
    detailsBm:
      "Meliputi syarat, pengendalian, dan tatatertib bagi perbicaraan dalam talian, termasuk pengesahan identiti dan memastikan penyertaan yang teratur.",
    practicalNotesEn:
      "For online hearings, test your connection, audio and document-sharing beforehand. Have witnesses in a neutral, private setting and your bundle ready to screen-share or pre-filed.",
    practicalNotesBm:
      "Untuk perbicaraan dalam talian, uji sambungan, audio dan perkongsian dokumen anda terlebih dahulu. Pastikan saksi berada di tempat neutral dan persendirian serta ikatan dokumen anda sedia untuk dikongsi skrin atau difailkan awal.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments",
    gates: "civil",
    order: 9,
  }),

  // ───────────────────────── ETIQUETTE / CONDUCT / DRESS ─────────────────────────
  aa("4", "2002", {
    titleEn: "Ethics of Syarie Lawyers",
    titleBm: "Etika Peguam Syarie",
    category: "Conduct & Ethics",
    categoryBm: "Tatatertib & Etika",
    summaryEn:
      "Sets out the ethical standards expected of Syarie lawyers appearing before the Syariah Courts.",
    summaryBm:
      "Menetapkan piawaian etika yang dijangka daripada Peguam Syarie yang hadir di hadapan Mahkamah Syariah.",
    detailsEn:
      "Covers professional conduct, duties to the court and clients, and the standards of behaviour required in proceedings.",
    detailsBm:
      "Meliputi tatakelakuan profesional, tanggungjawab kepada mahkamah dan klien, serta piawaian tingkah laku yang dikehendaki dalam prosiding.",
    practicalNotesEn:
      "Your duty to the court is paramount and overrides client instructions where they conflict. Candour, punctuality and courtesy are not optional — breaches can lead to disciplinary consequences.",
    practicalNotesBm:
      "Tanggungjawab anda kepada mahkamah adalah utama dan mengatasi arahan klien apabila bercanggah. Keikhlasan, ketepatan masa dan kesopanan bukan pilihan — pelanggaran boleh membawa akibat tatatertib.",
    status: "In Force",
    relatedLegislation: "Syarie Legal Practice rules; Syariah Court Civil Procedure enactments",
    gates: "civil,criminal,advisory",
    order: 10,
  }),
  aa("5", "2022", {
    titleEn: "Dress Guidelines for Syarie Judges, Prosecutors, Lawyers and Court Officers in the Courtroom",
    titleBm: "Garis Panduan Pakaian Hakim Syarie, Pendakwa Syarie, Peguam Syarie Dan Pegawai Mahkamah Di Dalam Dewan Mahkamah",
    category: "Conduct & Ethics",
    categoryBm: "Tatatertib & Etika",
    summaryEn:
      "Standardises the dress code for judges, Syarie prosecutors, Syarie lawyers and court officers in the courtroom.",
    summaryBm:
      "Menyeragamkan kod pakaian bagi hakim, Pendakwa Syarie, Peguam Syarie dan pegawai mahkamah di dalam dewan mahkamah.",
    detailsEn:
      "Sets the required attire to maintain the dignity and decorum of Syariah Court proceedings.",
    detailsBm:
      "Menetapkan pakaian yang dikehendaki bagi mengekalkan maruah dan tatatertib prosiding Mahkamah Syariah.",
    practicalNotesEn:
      "Comply with the dress code precisely — being turned away or admonished for attire undermines your standing before you have said a word.",
    practicalNotesBm:
      "Patuhi kod pakaian dengan tepat — ditolak atau ditegur kerana pakaian menjejaskan kedudukan anda sebelum anda berkata sepatah pun.",
    status: "In Force",
    relatedLegislation: "Syariah Court practice directions (dress)",
    gates: "civil,criminal,advisory",
    order: 11,
  }),
  aa("1", "2001", {
    titleEn: "Code of Ethics for Syarie Judges",
    titleBm: "Kod Etika Hakim Syarie",
    category: "Conduct & Ethics",
    categoryBm: "Tatatertib & Etika",
    summaryEn:
      "Sets out the code of ethics governing the conduct of Syarie judges.",
    summaryBm:
      "Menetapkan kod etika yang mentadbir tatakelakuan hakim Syarie.",
    detailsEn:
      "Covers impartiality, integrity, and the standards of conduct expected of the Syariah bench.",
    detailsBm:
      "Meliputi kesaksamaan, integriti, dan piawaian tatakelakuan yang dijangka daripada hakim Syariah.",
    practicalNotesEn:
      "Useful when considering recusal or raising concerns about apparent bias — frame any such application by reference to the standards the bench itself is bound by.",
    practicalNotesBm:
      "Berguna apabila mempertimbangkan penarikan diri hakim atau membangkitkan kebimbangan tentang berat sebelah — rangka permohonan sedemikian dengan merujuk piawaian yang mengikat hakim itu sendiri.",
    status: "In Force",
    relatedLegislation: "Syariah judicial administration",
    gates: "civil,criminal,advisory",
    order: 12,
  }),

  // ───────────────────────── OATH / EVIDENCE / HAKAM ─────────────────────────
  aa("1", "2003", {
    titleEn: "Use of the Istizhar Oath in Mal Cases",
    titleBm: "Penggunaan Lafaz Sumpah Istizhar Dalam Kes Mal",
    category: "Evidence & Oath",
    categoryBm: "Keterangan & Sumpah",
    summaryEn:
      "Provides for the use and wording of the istizhar oath in mal (civil) cases.",
    summaryBm:
      "Memperuntukkan penggunaan dan lafaz sumpah istizhar dalam kes mal.",
    detailsEn:
      "Addresses when the istizhar oath may be administered and the correct form, given its evidentiary weight in Syariah procedure.",
    detailsBm:
      "Menangani bila sumpah istizhar boleh dilaksanakan dan bentuk yang betul, memandangkan beratnya dari segi keterangan dalam prosedur Syariah.",
    practicalNotesEn:
      "Advise clients carefully before any oath is taken — the consequences in Syariah evidence can be decisive. Make sure the wording and procedure follow the direction exactly.",
    practicalNotesBm:
      "Nasihatkan klien dengan teliti sebelum apa-apa sumpah diangkat — akibatnya dalam keterangan Syariah boleh menentukan kes. Pastikan lafaz dan prosedur mengikut arahan dengan tepat.",
    status: "In Force",
    relatedLegislation: "Syariah Court Evidence enactments",
    gates: "civil,advisory",
    order: 13,
  }),
  aa("2", "2006", {
    titleEn: "Practice of Oath-Taking in the Syariah Courts",
    titleBm: "Amalan Sumpah Mahkamah Syariah",
    category: "Evidence & Oath",
    categoryBm: "Keterangan & Sumpah",
    summaryEn:
      "Standardises the practice and procedure for administering oaths in the Syariah Courts.",
    summaryBm:
      "Menyeragamkan amalan dan prosedur pelaksanaan sumpah di Mahkamah Syariah.",
    detailsEn:
      "Covers when and how oaths are administered and their role in the determination of cases.",
    detailsBm:
      "Meliputi bila dan bagaimana sumpah dilaksanakan serta peranannya dalam penentuan kes.",
    practicalNotesEn:
      "Know the order in which the right to take or refer an oath falls between the parties — getting this wrong can lose an otherwise winnable point.",
    practicalNotesBm:
      "Ketahui susunan hak untuk bersumpah atau merujuk sumpah antara pihak — kesilapan di sini boleh menyebabkan kehilangan isu yang sepatutnya boleh dimenangi.",
    status: "In Force",
    relatedLegislation: "Syariah Court Evidence enactments",
    gates: "civil,criminal,advisory",
    order: 14,
  }),
  aa("1", "2006", {
    titleEn: "Practice of Hakam (Arbitration) in the Syariah Courts",
    titleBm: "Amalan Hakam Mahkamah Syariah",
    category: "Evidence & Oath",
    categoryBm: "Keterangan & Sumpah",
    summaryEn:
      "Provides for the appointment and practice of hakam (arbitrators) in resolving matrimonial disputes (shiqaq).",
    summaryBm:
      "Memperuntukkan pelantikan dan amalan hakam dalam menyelesaikan pertikaian rumah tangga (shiqaq).",
    detailsEn:
      "Covers the role of hakam in syiqaq cases, their appointment, and how their findings feed into the court's determination.",
    detailsBm:
      "Meliputi peranan hakam dalam kes syiqaq, pelantikan mereka, dan bagaimana dapatan mereka digunakan dalam penentuan mahkamah.",
    practicalNotesEn:
      "In shiqaq matters, prepare your client for the hakam process and ensure the appointed hakam understand their mandate — a flawed hakam process can unravel the eventual order.",
    practicalNotesBm:
      "Dalam perkara syiqaq, sediakan klien anda untuk proses hakam dan pastikan hakam yang dilantik memahami mandat mereka — proses hakam yang cacat boleh meruntuhkan perintah akhir.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments (syiqaq / hakam)",
    gates: "civil,advisory",
    order: 15,
  }),

  // ───────────────────────── FAMILY (MARRIAGE, DIVORCE, CUSTODY) ─────────────────────────
  aa("2", "2002", {
    titleEn: "Hadhanah, Jointly Acquired Property and Ex-Parte Cases in the High Syariah Court",
    titleBm: "Kes Hadhanah, Harta Sepencarian dan ex-parte Di Mahkamah Tinggi Syariah",
    category: "Family Cases",
    categoryBm: "Kes Keluarga",
    summaryEn:
      "Provides direction on the handling of custody (hadhanah), jointly acquired property (harta sepencarian) and ex-parte applications in the High Syariah Court.",
    summaryBm:
      "Memberi arahan mengenai pengendalian kes penjagaan (hadhanah), harta sepencarian dan permohonan ex-parte di Mahkamah Tinggi Syariah.",
    detailsEn:
      "Addresses jurisdiction and procedure for these family matters to ensure they are filed and heard in the correct forum.",
    detailsBm:
      "Menangani bidang kuasa dan prosedur bagi perkara keluarga ini bagi memastikan ia difailkan dan didengar di forum yang betul.",
    practicalNotesEn:
      "Check forum and jurisdiction at filing — hadhanah and harta sepencarian claims filed at the wrong court level cause costly delay. For ex-parte relief, be ready to justify urgency.",
    practicalNotesBm:
      "Semak forum dan bidang kuasa semasa pemfailan — tuntutan hadhanah dan harta sepencarian yang difailkan di peringkat mahkamah yang salah menyebabkan kelewatan yang mahal. Untuk relief ex-parte, bersedia mewajarkan kesegeraan.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments",
    gates: "civil,advisory",
    order: 16,
  }),
  aa("5", "2016", {
    titleEn: "Guidelines for Ex-Parte Hadhanah and Injunction Proceedings",
    titleBm: "Garis Panduan Prosiding Ex Parte Hadhanah dan Injunksi",
    category: "Family Cases",
    categoryBm: "Kes Keluarga",
    summaryEn:
      "Sets guidelines for ex-parte applications in custody (hadhanah) and injunction matters.",
    summaryBm:
      "Menetapkan garis panduan bagi permohonan ex-parte dalam perkara penjagaan (hadhanah) dan injunksi.",
    detailsEn:
      "Covers the threshold for granting urgent ex-parte relief and the safeguards required, including the duty of full and frank disclosure.",
    detailsBm:
      "Meliputi ambang pemberian relief ex-parte mendesak dan perlindungan yang diperlukan, termasuk kewajipan pendedahan penuh dan jujur.",
    practicalNotesEn:
      "On ex-parte applications you owe a duty of full and frank disclosure — disclose facts against your client too. Non-disclosure is the quickest way to have an ex-parte order set aside.",
    practicalNotesBm:
      "Dalam permohonan ex-parte anda terhutang kewajipan pendedahan penuh dan jujur — dedahkan juga fakta yang menentang klien anda. Tidak mendedahkan adalah cara terpantas untuk perintah ex-parte diketepikan.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments; Syariah Court Civil Procedure enactments",
    gates: "civil,advisory",
    order: 17,
  }),
  aa("5", "2020", {
    titleEn: "Standardising Maintenance Orders: Mode of Payment and Complete Order Terms",
    titleBm: "Penyelarasan Perintah Nafkah Dari Segi Cara Pembayaran Dan Terma-Terma Lengkap Perintah",
    category: "Family Cases",
    categoryBm: "Kes Keluarga",
    summaryEn:
      "Standardises maintenance (nafkah) orders, including the mode of payment and ensuring complete, clear order terms.",
    summaryBm:
      "Menyeragamkan perintah nafkah, termasuk cara pembayaran dan memastikan terma perintah yang lengkap dan jelas.",
    detailsEn:
      "Aims to reduce later enforcement disputes by ensuring maintenance orders specify amount, frequency, mode and start date precisely.",
    detailsBm:
      "Bertujuan mengurangkan pertikaian penguatkuasaan kemudian dengan memastikan perintah nafkah menyatakan jumlah, kekerapan, cara dan tarikh mula dengan tepat.",
    practicalNotesEn:
      "When seeking a maintenance order, propose the exact terms — amount, payment channel, due date, and arrears mechanism. A complete order is far easier to enforce later.",
    practicalNotesBm:
      "Apabila memohon perintah nafkah, cadangkan terma yang tepat — jumlah, saluran bayaran, tarikh akhir, dan mekanisme tunggakan. Perintah yang lengkap jauh lebih mudah dikuatkuasakan kemudian.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments (maintenance)",
    gates: "civil,advisory",
    order: 18,
  }),
  aa("10", "2021", {
    titleEn: "Welfare Officer / Expert Advice Before Custody (Hadhanah) or Child Maintenance Orders",
    titleBm: "Penerimaan Nasihat Daripada Pegawai Kebajikan Masyarakat Atau Pakar Sebelum Mahkamah Membuat Perintah Mengenai Jagaan (Hadhanah) Atau Nafkah Seorang Kanak-kanak",
    category: "Family Cases",
    categoryBm: "Kes Keluarga",
    summaryEn:
      "Allows the court to receive advice from a gazetted welfare/protection officer or relevant expert before making custody (hadhanah) or child maintenance orders.",
    summaryBm:
      "Membolehkan mahkamah menerima nasihat daripada pegawai kebajikan/pelindung yang diwartakan atau pakar berkaitan sebelum membuat perintah penjagaan (hadhanah) atau nafkah kanak-kanak.",
    detailsEn:
      "Reinforces the welfare-of-the-child principle by bringing professional assessment into decisions affecting children.",
    detailsBm:
      "Memperkukuh prinsip kebajikan kanak-kanak dengan membawa penilaian profesional ke dalam keputusan yang menjejaskan kanak-kanak.",
    practicalNotesEn:
      "Engage with the welfare/social report constructively — courts weigh it heavily. If you dispute it, address its findings specifically rather than attacking the officer.",
    practicalNotesBm:
      "Tangani laporan kebajikan/sosial secara membina — mahkamah menimbangnya dengan berat. Jika anda mempertikaikannya, tangani dapatannya secara khusus dan bukan menyerang pegawai.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments (hadhanah / maintenance)",
    gates: "civil,advisory",
    order: 19,
  }),
  aa("7", "2021", {
    titleEn: "Notice to Existing Wife/Wives to Attend Polygamy Permission and Registration Proceedings",
    titleBm: "Pemakluman Kepada Isteri/ Isteri-isteri Sedia Ada Untuk Hadir Dalam Prosiding Permohonan Kebenaran Poligami Serta Permohonan Pengesahan Dan Pendaftaran Nikah Poligami",
    category: "Family Cases",
    categoryBm: "Kes Keluarga",
    summaryEn:
      "Requires the existing wife or wives to be notified to attend proceedings on an application for permission to practise polygamy and registration of a polygamous marriage.",
    summaryBm:
      "Mewajibkan isteri atau isteri-isteri sedia ada dimaklumkan untuk hadir dalam prosiding permohonan kebenaran berpoligami serta pengesahan dan pendaftaran nikah poligami.",
    detailsEn:
      "Protects the rights of existing wives by ensuring they have notice and an opportunity to be heard.",
    detailsBm:
      "Melindungi hak isteri sedia ada dengan memastikan mereka mendapat notis dan peluang untuk didengar.",
    practicalNotesEn:
      "If acting for the applicant, ensure proper service on existing wives early — defective notice will stall or defeat the application. If acting for an existing wife, secure her right to be heard.",
    practicalNotesBm:
      "Jika bertindak untuk pemohon, pastikan penyampaian yang betul kepada isteri sedia ada lebih awal — notis yang cacat akan melengahkan atau menggagalkan permohonan. Jika bertindak untuk isteri sedia ada, pastikan haknya untuk didengar.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments (polygamy)",
    gates: "civil,advisory",
    order: 20,
  }),
  aa("6", "2021", {
    titleEn: "Confirmation of Talaq Pronounced Outside and Without Court Permission; Refusal to Take Oath (Nukul)",
    titleBm: "Amalan Pengesahan Talaq Diluar Dan Tanpa Kebenaran Mahkamah Serta Penjelasan Terhadap Keengganan Bersumpah (Nukul)",
    category: "Family Cases",
    categoryBm: "Kes Keluarga",
    summaryEn:
      "Provides the practice for confirming a talaq pronounced outside court and without permission, and addresses the effect of refusal to take an oath (nukul).",
    summaryBm:
      "Menyediakan amalan pengesahan talaq yang dilafazkan di luar mahkamah dan tanpa kebenaran, serta menangani kesan keengganan bersumpah (nukul).",
    detailsEn:
      "Covers the procedure and evidentiary treatment when a divorce is pronounced outside the court process.",
    detailsBm:
      "Meliputi prosedur dan layanan keterangan apabila perceraian dilafazkan di luar proses mahkamah.",
    practicalNotesEn:
      "Advise clients that pronouncing talaq outside court carries penalties and still requires confirmation. Understand how refusal to take an oath (nukul) can shift the outcome.",
    practicalNotesBm:
      "Nasihatkan klien bahawa melafazkan talaq di luar mahkamah membawa penalti dan masih memerlukan pengesahan. Fahami bagaimana keengganan bersumpah (nukul) boleh mengubah keputusan.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments (divorce); Syariah Criminal Offences enactments",
    gates: "civil,advisory",
    order: 21,
  }),
  aa("2", "2020", {
    titleEn: "Social/Conduct Report Form (JKM) for Underage Marriage Applications",
    titleBm: "Format Dan Pemakaian Borang Laporan Sosial/Akhlak Jabatan Kebajikan Masyarakat (JKM) Bagi Kes Permohonan Perkahwinan Bawah Umur",
    category: "Family Cases",
    categoryBm: "Kes Keluarga",
    summaryEn:
      "Provides the format and use of the Welfare Department (JKM) social/conduct report in applications for underage marriage.",
    summaryBm:
      "Menyediakan format dan penggunaan borang laporan sosial/akhlak Jabatan Kebajikan Masyarakat (JKM) dalam permohonan perkahwinan bawah umur.",
    detailsEn:
      "Brings a structured welfare assessment into the court's consideration of underage marriage applications.",
    detailsBm:
      "Membawa penilaian kebajikan berstruktur ke dalam pertimbangan mahkamah terhadap permohonan perkahwinan bawah umur.",
    practicalNotesEn:
      "Expect close scrutiny in underage marriage applications. Ensure the JKM report is obtained and addressed — the court will not proceed without it and weighs it heavily.",
    practicalNotesBm:
      "Jangkakan penelitian rapi dalam permohonan perkahwinan bawah umur. Pastikan laporan JKM diperoleh dan ditangani — mahkamah tidak akan teruskan tanpanya dan menimbangnya dengan berat.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments (marriage)",
    gates: "civil,advisory",
    order: 22,
  }),

  // ───────────────────────── ESTATE / FARAID / PROPERTY ─────────────────────────
  aa("8", "2021", {
    titleEn: "Resolve Jointly Acquired Property Before Hibah, Wasiat and Inheritance Cases on the Same Property",
    titleBm: "Keperluan Penyelesaian Kes Harta Sepencarian Terlebih Dahulu Sebelum Perbicaraan Kes Hibah, Wasiat Dan Pusaka Yang Melibatkan Harta Yang Sama",
    category: "Estate & Faraid",
    categoryBm: "Pusaka & Faraid",
    summaryEn:
      "Requires jointly acquired property (harta sepencarian) claims to be resolved before hearing hibah, wasiat and inheritance (pusaka) cases involving the same property.",
    summaryBm:
      "Mewajibkan tuntutan harta sepencarian diselesaikan terlebih dahulu sebelum mendengar kes hibah, wasiat dan pusaka yang melibatkan harta yang sama.",
    detailsEn:
      "Ensures the estate is properly defined — by first separating the surviving spouse's matrimonial share — before distribution questions are decided.",
    detailsBm:
      "Memastikan harta pusaka ditakrifkan dengan betul — dengan mengasingkan dahulu bahagian harta sepencarian pasangan yang masih hidup — sebelum persoalan pembahagian diputuskan.",
    practicalNotesEn:
      "In estate disputes, deal with harta sepencarian first. Distributing under faraid before carving out the matrimonial share is a common and reversible error.",
    practicalNotesBm:
      "Dalam pertikaian pusaka, selesaikan harta sepencarian dahulu. Membahagikan mengikut faraid sebelum mengasingkan bahagian harta sepencarian adalah kesilapan biasa yang boleh dibatalkan.",
    status: "In Force",
    relatedLegislation: "Islamic Family Law enactments; Faraid / inheritance law",
    gates: "civil,advisory",
    order: 23,
  }),
  aa("7", "2022", {
    titleEn: "All Entitled Heirs Must Be Made Parties in Claims Against a Deceased's Property",
    titleBm: "Keperluan Menjadikan Semua Ahli Waris Yang Berhak Dan Berkepentingan Sebagai Pihak-pihak Dalam Kes Melibatkan Tuntutan Terhadap Harta Si Mati",
    category: "Estate & Faraid",
    categoryBm: "Pusaka & Faraid",
    summaryEn:
      "Requires all entitled and interested heirs to be joined as parties in cases involving claims against a deceased's property.",
    summaryBm:
      "Mewajibkan semua ahli waris yang berhak dan berkepentingan disertakan sebagai pihak dalam kes yang melibatkan tuntutan terhadap harta si mati.",
    detailsEn:
      "Prevents orders being made that affect heirs who were never before the court, protecting their rights and the finality of the order.",
    detailsBm:
      "Mengelakkan perintah dibuat yang menjejaskan ahli waris yang tidak pernah hadir di mahkamah, melindungi hak mereka dan kemuktamadan perintah.",
    practicalNotesEn:
      "Identify and join every entitled heir at the outset. A missing heir can later set the order aside — map the faraid shares before you file.",
    practicalNotesBm:
      "Kenal pasti dan sertakan setiap ahli waris yang berhak dari awal. Ahli waris yang tertinggal boleh mengetepikan perintah kemudian — petakan bahagian faraid sebelum anda memfailkan.",
    status: "In Force",
    relatedLegislation: "Faraid / inheritance law; Syariah Court Civil Procedure enactments",
    gates: "civil,advisory",
    order: 24,
  }),
  aa("5", "2023", {
    titleEn: "Current Title Search Required for Immovable Property Claims",
    titleBm: "Keperluan Untuk Mengemukakan Carian Rasmi/Persendirian Geran Hak Milik Terkini Bagi Tuntutan/Permohonan Harta Tak Alih",
    category: "Estate & Faraid",
    categoryBm: "Pusaka & Faraid",
    summaryEn:
      "Requires a current official/private land title search to be produced at registration and before judgment in claims involving immovable property.",
    summaryBm:
      "Mewajibkan carian hak milik tanah rasmi/persendirian terkini dikemukakan semasa pendaftaran dan sebelum penghakiman bagi tuntutan yang melibatkan harta tak alih.",
    detailsEn:
      "Ensures the court decides on the basis of the current registered ownership and encumbrances of the property.",
    detailsBm:
      "Memastikan mahkamah memutuskan berdasarkan pemilikan berdaftar terkini dan bebanan ke atas harta tersebut.",
    practicalNotesEn:
      "Always obtain a fresh title search before filing and refresh it before judgment — ownership, charges or caveats may have changed and can derail an order made on stale information.",
    practicalNotesBm:
      "Sentiasa dapatkan carian hak milik baharu sebelum memfailkan dan kemas kini sebelum penghakiman — pemilikan, gadaian atau kaveat mungkin berubah dan boleh menggagalkan perintah yang dibuat atas maklumat lapuk.",
    status: "In Force",
    relatedLegislation: "Faraid / inheritance law; National Land Code (title)",
    gates: "civil,advisory",
    order: 25,
  }),
  aa("9", "2016", {
    titleEn: "Standardised Order Format and Brief Grounds in the e-Faraid System",
    titleBm: "Penyeragaman Format Perintah, Alasan Penghakiman Ringkas dan Surat Makluman Dalam Sistem e-Faraid",
    docType: "circular",
    category: "Estate & Faraid",
    categoryBm: "Pusaka & Faraid",
    summaryEn:
      "Standardises the order format, brief grounds of judgment, and notification letters produced through the e-Faraid system.",
    summaryBm:
      "Menyeragamkan format perintah, alasan penghakiman ringkas, dan surat makluman yang dihasilkan melalui sistem e-Faraid.",
    detailsEn:
      "Promotes consistency and accuracy in faraid certificates and related court outputs generated electronically.",
    detailsBm:
      "Menggalakkan keseragaman dan ketepatan dalam sijil faraid dan output mahkamah berkaitan yang dihasilkan secara elektronik.",
    practicalNotesEn:
      "Check e-Faraid outputs carefully against the heirs and shares you pleaded — automated computations still require a human check before the certificate is relied upon.",
    practicalNotesBm:
      "Semak output e-Faraid dengan teliti berbanding ahli waris dan bahagian yang anda plidkan — pengiraan automatik masih memerlukan semakan manusia sebelum sijil dipakai.",
    status: "In Force",
    relatedLegislation: "Faraid / inheritance law",
    gates: "civil,advisory",
    order: 26,
  }),

  // ───────────────────────── CRIMINAL (JENAYAH SYARIAH) ─────────────────────────
  aa("7", "2006", {
    titleEn: "Guidance on Complaints of Syariah Criminal Offences to the Judge",
    titleBm: "Panduan Darihal Aduan Kesalahan Jenayah Syariah Kepada Hakim",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    summaryEn:
      "Provides guidance on how complaints of Syariah criminal offences are brought before and handled by the judge.",
    summaryBm:
      "Menyediakan panduan tentang cara aduan kesalahan jenayah Syariah dibawa kepada dan dikendalikan oleh hakim.",
    detailsEn:
      "Covers the proper channel and procedure for initiating Syariah criminal complaints to ensure due process.",
    detailsBm:
      "Meliputi saluran dan prosedur yang betul untuk memulakan aduan jenayah Syariah bagi memastikan proses yang sewajarnya.",
    practicalNotesEn:
      "Ensure the complaint is properly constituted and channelled before the accused is brought up — defects at the complaint stage can be fatal to the prosecution.",
    practicalNotesBm:
      "Pastikan aduan dibentuk dan disalurkan dengan betul sebelum tertuduh dibawa ke mahkamah — kecacatan di peringkat aduan boleh memudaratkan pendakwaan.",
    status: "In Force",
    relatedLegislation: "Syariah Criminal Procedure enactments",
    gates: "criminal",
    order: 27,
  }),
  aa("2", "2023", {
    titleEn: "Preparation and Issuance of Written Orders in Syariah Criminal Cases",
    titleBm: "Penyediaan Dan Pengeluaran Perintah Bertulis Bagi Kes Jenayah Syariah",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    summaryEn:
      "Standardises the preparation and issuance of written orders in Syariah criminal cases.",
    summaryBm:
      "Menyeragamkan penyediaan dan pengeluaran perintah bertulis bagi kes jenayah Syariah.",
    detailsEn:
      "Ensures criminal orders are reduced to writing accurately and issued promptly for enforcement and appeal.",
    detailsBm:
      "Memastikan perintah jenayah dicatat secara bertulis dengan tepat dan dikeluarkan dengan segera untuk penguatkuasaan dan rayuan.",
    practicalNotesEn:
      "Obtain the sealed written order promptly — appeal periods and enforcement both run off the formal order. Check it matches what the court pronounced.",
    practicalNotesBm:
      "Dapatkan perintah bertulis yang dimeterai dengan segera — tempoh rayuan dan penguatkuasaan kedua-duanya berdasarkan perintah formal. Semak ia sepadan dengan apa yang diputuskan mahkamah.",
    status: "In Force",
    relatedLegislation: "Syariah Criminal Procedure enactments",
    gates: "criminal",
    order: 28,
  }),
  aa("3", "2023", {
    titleEn: "Preparation of Arrest Warrants and Notice to Bailor in Syariah Criminal Cases",
    titleBm: "Penyediaan Waran Tangkap Dan Notis Kepada Penjamin Bagi Kes Jenayah Syariah",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    summaryEn:
      "Provides for the preparation of arrest warrants and notices to the bailor (guarantor) in Syariah criminal cases.",
    summaryBm:
      "Memperuntukkan penyediaan waran tangkap dan notis kepada penjamin dalam kes jenayah Syariah.",
    detailsEn:
      "Covers the procedure when an accused fails to attend, including notifying the bailor and issuing a warrant.",
    detailsBm:
      "Meliputi prosedur apabila tertuduh gagal hadir, termasuk memaklumkan penjamin dan mengeluarkan waran.",
    practicalNotesEn:
      "Advise bailors of their exposure clearly. If your client is at risk of a warrant for non-attendance, address it before the date — purging early is far cheaper than after arrest.",
    practicalNotesBm:
      "Maklumkan penjamin tentang risiko mereka dengan jelas. Jika klien anda berisiko dikenakan waran kerana tidak hadir, tanganinya sebelum tarikh — menyelesaikannya awal jauh lebih murah daripada selepas ditangkap.",
    status: "In Force",
    relatedLegislation: "Syariah Criminal Procedure enactments",
    gates: "criminal",
    order: 29,
  }),
  aa("4", "2023", {
    titleEn: "Time Limits for Registration and Mention of Syariah Criminal Cases",
    titleBm: "Had Masa Pendaftaran Dan Sebutan Kes Jenayah Syariah",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    summaryEn:
      "Sets time limits for the registration and first mention of Syariah criminal cases.",
    summaryBm:
      "Menetapkan had masa bagi pendaftaran dan sebutan pertama kes jenayah Syariah.",
    detailsEn:
      "Aims to ensure criminal matters are brought before the court promptly after charges are ready.",
    detailsBm:
      "Bertujuan memastikan perkara jenayah dibawa ke mahkamah dengan segera selepas pertuduhan sedia.",
    practicalNotesEn:
      "Track the registration and mention deadlines closely — undue delay can found an argument of prejudice for the defence and may affect how the court manages the case.",
    practicalNotesBm:
      "Pantau tarikh akhir pendaftaran dan sebutan dengan rapi — kelewatan yang tidak wajar boleh menjadi asas hujah prejudis bagi pembelaan dan boleh menjejaskan cara mahkamah menguruskan kes.",
    status: "In Force",
    relatedLegislation: "Syariah Criminal Procedure enactments",
    gates: "criminal",
    order: 30,
  }),
  aa("4", "2020", {
    titleEn: "Tendering Forensic Evidence in Syariah Court Proceedings",
    titleBm: "Pengemukaan Bukti Forensik Dalam Prosiding Di Mahkamah Syariah",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    summaryEn:
      "Provides for the tendering and handling of forensic evidence in Syariah Court proceedings.",
    summaryBm:
      "Memperuntukkan pengemukaan dan pengendalian bukti forensik dalam prosiding di Mahkamah Syariah.",
    detailsEn:
      "Covers the admission of forensic and scientific evidence, including chain of custody and expert testimony.",
    detailsBm:
      "Meliputi penerimaan bukti forensik dan saintifik, termasuk rantaian jagaan dan keterangan pakar.",
    practicalNotesEn:
      "If relying on forensic evidence, secure the chain of custody and the expert's availability early. A break in custody is the most common ground for excluding otherwise strong evidence.",
    practicalNotesBm:
      "Jika bergantung pada bukti forensik, pastikan rantaian jagaan dan kehadiran pakar lebih awal. Putus dalam rantaian jagaan adalah alasan paling biasa untuk mengecualikan bukti yang sebaliknya kukuh.",
    status: "In Force",
    relatedLegislation: "Syariah Court Evidence enactments",
    gates: "criminal,civil",
    order: 31,
  }),

  // ───────────────────────── APPEALS & REVIEW ─────────────────────────
  aa("12", "2003", {
    titleEn: "Case Chronology and Written Submissions for Appeals",
    titleBm: "Penyediaan Kronologi Kes Dan Ringkasan Penghujahan Bertulis Bagi Kes-Kes Rayuan Di Mahkamah Tinggi Syariah Dan Mahkamah Rayuan Syariah",
    category: "Appeals & Review",
    categoryBm: "Rayuan & Semakan",
    summaryEn:
      "Requires preparation of a case chronology and written submissions for appeal cases in the High Syariah Court and Syariah Court of Appeal.",
    summaryBm:
      "Mewajibkan penyediaan kronologi kes dan ringkasan penghujahan bertulis bagi kes rayuan di Mahkamah Tinggi Syariah dan Mahkamah Rayuan Syariah.",
    detailsEn:
      "Standardises appeal documentation to focus the court on the issues and the record.",
    detailsBm:
      "Menyeragamkan dokumentasi rayuan untuk memberi tumpuan mahkamah kepada isu dan rekod.",
    practicalNotesEn:
      "Invest in a tight chronology and focused written submissions — appeals are won on the record and the issues, not on re-arguing the whole trial.",
    practicalNotesBm:
      "Laburkan dalam kronologi yang padat dan penghujahan bertulis yang fokus — rayuan dimenangi atas rekod dan isu, bukan dengan menghujah semula keseluruhan perbicaraan.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments (appeals)",
    gates: "civil,criminal,advisory",
    order: 32,
  }),
  aa("10", "2016", {
    titleEn: "Work Process for Mal Appeals in the Syariah Court",
    titleBm: "Proses Kerja Rayuan Mal Mahkamah Syariah",
    category: "Appeals & Review",
    categoryBm: "Rayuan & Semakan",
    summaryEn:
      "Sets out the standardised work process for mal (civil) appeals in the Syariah Courts.",
    summaryBm:
      "Menetapkan proses kerja yang diseragamkan bagi rayuan mal di Mahkamah Syariah.",
    detailsEn:
      "Covers the steps and timelines from filing the notice of appeal to disposal of the mal appeal.",
    detailsBm:
      "Meliputi langkah dan tempoh masa dari pemfailan notis rayuan hingga pelupusan rayuan mal.",
    practicalNotesEn:
      "Diary every appeal deadline from the date of decision. Missing the notice or record-of-appeal timelines is the most common way a meritorious appeal is lost on procedure.",
    practicalNotesBm:
      "Catat setiap tarikh akhir rayuan dari tarikh keputusan. Terlepas tempoh notis atau rekod rayuan adalah cara paling biasa rayuan yang bermerit hilang atas teknikal prosedur.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments (appeals)",
    gates: "civil,advisory",
    order: 33,
  }),
  aa("11", "2016", {
    titleEn: "Work Process for Criminal Appeals in the Syariah Court",
    titleBm: "Proses Kerja Rayuan Jenayah Mahkamah Syariah",
    category: "Appeals & Review",
    categoryBm: "Rayuan & Semakan",
    summaryEn:
      "Sets out the standardised work process for Syariah criminal appeals.",
    summaryBm:
      "Menetapkan proses kerja yang diseragamkan bagi rayuan jenayah Syariah.",
    detailsEn:
      "Covers the steps and timelines for criminal appeals from filing to disposal.",
    detailsBm:
      "Meliputi langkah dan tempoh masa bagi rayuan jenayah dari pemfailan hingga pelupusan.",
    practicalNotesEn:
      "For criminal appeals, secure the grounds of decision and notes of proceedings early and watch the short appeal windows — liberty and penalties turn on strict compliance.",
    practicalNotesBm:
      "Untuk rayuan jenayah, dapatkan alasan keputusan dan nota prosiding lebih awal dan perhatikan tempoh rayuan yang singkat — kebebasan dan hukuman bergantung pada pematuhan yang ketat.",
    status: "In Force",
    relatedLegislation: "Syariah Criminal Procedure enactments (appeals)",
    gates: "criminal",
    order: 34,
  }),

  // ───────────────────────── ENFORCEMENT & EXECUTION ─────────────────────────
  aa("9", "2021", {
    titleEn: "Guidelines on Judgment Debtor Claims/Summons and Judgment Notices",
    titleBm: "Garis Panduan Kes Tuntutan/Saman Penghutang Penghakiman Dan Notis Penghakiman",
    category: "Enforcement",
    categoryBm: "Penguatkuasaan",
    summaryEn:
      "Provides guidelines for judgment debtor proceedings (claims/summons) and the issuance of judgment notices.",
    summaryBm:
      "Menyediakan garis panduan bagi prosiding penghutang penghakiman (tuntutan/saman) dan pengeluaran notis penghakiman.",
    detailsEn:
      "Covers the mechanism for pursuing a party who has not satisfied a court order, including the judgment debtor summons process.",
    detailsBm:
      "Meliputi mekanisme untuk mengejar pihak yang tidak mematuhi perintah mahkamah, termasuk proses saman penghutang penghakiman.",
    practicalNotesEn:
      "Document arrears precisely — dates, amounts and proof of non-payment make or break enforcement. Advise clients to keep records from the moment the order is made.",
    practicalNotesBm:
      "Dokumenkan tunggakan dengan tepat — tarikh, jumlah dan bukti tidak bayar menentukan kejayaan penguatkuasaan. Nasihatkan klien menyimpan rekod sejak perintah dibuat.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments (enforcement)",
    gates: "civil,advisory",
    order: 35,
  }),
  aa("1", "2022", {
    titleEn: "Syariah Court Orders Through Pension Deduction",
    titleBm: "Perintah Mahkamah Syariah Melalui Potongan Pencen",
    category: "Enforcement",
    categoryBm: "Penguatkuasaan",
    summaryEn:
      "Provides for enforcement of Syariah Court orders (such as maintenance) through deduction from a pension.",
    summaryBm:
      "Memperuntukkan penguatkuasaan perintah Mahkamah Syariah (seperti nafkah) melalui potongan daripada pencen.",
    detailsEn:
      "Offers a reliable enforcement route for orders against pensioners by attaching pension payments.",
    detailsBm:
      "Menawarkan laluan penguatkuasaan yang boleh dipercayai bagi perintah terhadap pesara dengan menyandar bayaran pencen.",
    practicalNotesEn:
      "Where the debtor is a pensioner, pension deduction can be the most effective enforcement mechanism — establish the pension source and amount before applying.",
    practicalNotesBm:
      "Apabila penghutang seorang pesara, potongan pencen boleh menjadi mekanisme penguatkuasaan paling berkesan — pastikan sumber dan jumlah pencen sebelum memohon.",
    status: "In Force",
    relatedLegislation: "Syariah Court Civil Procedure enactments (enforcement)",
    gates: "civil,advisory",
    order: 36,
  }),
];

export async function seedPracticeDirections() {
  console.log("Seeding practice directions & circulars...");
  await db.delete(practiceDirectionsTable);
  if (directions.length > 0) {
    await db.insert(practiceDirectionsTable).values(directions);
  }
  console.log(`Seeded ${directions.length} practice directions / circulars.`);
}

seedPracticeDirections()
  .then(() => pool.end())
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
