import { getUncachableStripeClient } from "./stripeClient";

/**
 * Creates MySyariahAI subscription products & monthly MYR prices in Stripe.
 * Idempotent: prices are keyed by lookup_key, so re-running skips existing plans.
 *
 * Run with: pnpm --filter @workspace/scripts exec tsx src/seed-stripe-products.ts
 */
interface PlanSeed {
  tier: string;
  name: string;
  description: string;
  amountMyr: number;
  lookupKey: string;
}

const PLANS: PlanSeed[] = [
  {
    tier: "professional",
    name: "MySyariahAI Professional",
    description: "Full AI toolkit for everyday Shariah legal practice.",
    amountMyr: 49,
    lookupKey: "professional_monthly",
  },
  {
    tier: "premium",
    name: "MySyariahAI Premium",
    description:
      "Realistic AI voices, speech-to-text, Kitab library and AI Tafsir.",
    amountMyr: 149,
    lookupKey: "premium_monthly",
  },
  {
    tier: "firm",
    name: "MySyariahAI Firm",
    description: "For chambers and legal teams. Multiple seats, unlimited voice.",
    amountMyr: 399,
    lookupKey: "firm_monthly",
  },
];

async function seed() {
  const stripe = await getUncachableStripeClient();
  console.log("Seeding Stripe products & prices (MYR)...");

  for (const plan of PLANS) {
    const existing = await stripe.prices.list({
      lookup_keys: [plan.lookupKey],
      active: true,
      limit: 1,
    });
    if (existing.data.length > 0) {
      console.log(
        `✓ ${plan.name} already exists (price ${existing.data[0].id}). Skipping.`,
      );
      continue;
    }

    const searchExisting = await stripe.products.search({
      query: `name:'${plan.name}' AND active:'true'`,
    });
    const product =
      searchExisting.data[0] ??
      (await stripe.products.create({
        name: plan.name,
        description: plan.description,
        metadata: { tier: plan.tier },
      }));

    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: plan.amountMyr * 100,
      currency: "myr",
      recurring: { interval: "month" },
      lookup_key: plan.lookupKey,
      metadata: { tier: plan.tier },
    });

    console.log(
      `✓ Created ${plan.name}: RM${plan.amountMyr}/mo (product ${product.id}, price ${price.id})`,
    );
  }

  console.log("Done. Webhooks will sync this data into the database.");
}

seed().catch((err) => {
  console.error("Error seeding Stripe products:", err);
  process.exit(1);
});
