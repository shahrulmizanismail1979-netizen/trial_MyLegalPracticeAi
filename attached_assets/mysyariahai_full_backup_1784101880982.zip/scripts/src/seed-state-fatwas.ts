import { db, pool, fatwaTable } from "@workspace/db";

type StateFatwa = typeof fatwaTable.$inferInsert;

const stateFatwas: StateFatwa[] = [
  {
    titleEn: "Poco-Poco Dance and Exercise Declared Haram",
    titleBm: "Tarian dan Senaman Poco-Poco Diharamkan",
    issuingBody: "Perak State Fatwa Committee",
    issuingBodyBm: "Jawatankuasa Fatwa Negeri Perak",
    gazetteRef: null,
    sourceUrl: null,
    year: "2011",
    state: "Perak",
    category: "Religious Practice",
    categoryBm: "Amalan Keagamaan",
    summaryEn:
      "The Perak State Fatwa Committee, at its 186th meeting (24–26 January 2011) under Mufti Tan Sri Harussani Zakaria, unanimously ruled that the poco-poco dance/exercise is haram for Muslims. The committee found that the practice originated from a community in Jamaica and carried characteristics associated with Christian ritual and spirit worship, and approved the ruling for gazetting in Perak.",
    summaryBm:
      "Jawatankuasa Fatwa Negeri Perak, dalam Mesyuarat ke-186 (24–26 Januari 2011) di bawah Mufti Tan Sri Harussani Zakaria, secara sebulat suara memutuskan bahawa tarian/senaman poco-poco adalah haram bagi orang Islam. Jawatankuasa mendapati amalan ini berasal daripada masyarakat di Jamaica dan mempunyai ciri yang dikaitkan dengan ritual agama Kristian serta pemujaan roh, dan memperaku keputusan ini untuk diwartakan di Perak.",
    detailsEn:
      "The ruling rests on the principle that practices touching matters of belief (aqidah) and imitating the religious rituals of other faiths (tasyabbuh) are impermissible for Muslims. A study cited by the committee indicated that the dance, commonly practised in Jamaica, carried Christian and spirit-worship characteristics. The fatwa applies within the State of Perak; not every Malaysian state gazetted an identical ruling, so practitioners should confirm the position in the relevant jurisdiction. Once gazetted, contravening or disputing the fatwa is an offence under the state's Syariah Criminal Offences enactment.",
    detailsBm:
      "Keputusan ini berasaskan prinsip bahawa amalan yang menyentuh perkara akidah dan meniru ritual keagamaan agama lain (tasyabbuh) adalah tidak harus bagi orang Islam. Kajian yang dirujuk jawatankuasa menyatakan tarian yang lazim diamalkan di Jamaica itu bercirikan agama Kristian dan pemujaan roh. Fatwa ini terpakai dalam Negeri Perak; tidak semua negeri di Malaysia mewartakan keputusan yang serupa, justeru pengamal perlu mengesahkan kedudukan dalam bidang kuasa berkenaan. Setelah diwartakan, mengingkari atau mempersoal fatwa ini adalah suatu kesalahan di bawah enakmen kesalahan jenayah syariah negeri.",
    status: "Active",
    relatedLegislation: null,
    gates: "civil,criminal,advisory",
    order: 100,
  },
  {
    titleEn: "Religious Liberalism and Pluralism Declared Deviant",
    titleBm: "Pemikiran Liberalisme dan Pluralisme Agama Diisytiharkan Menyeleweng",
    issuingBody: "Selangor State Fatwa Committee",
    issuingBodyBm: "Jawatankuasa Fatwa Negeri Selangor",
    gazetteRef: null,
    sourceUrl: null,
    year: "2014",
    state: "Selangor",
    category: "Religious Practice",
    categoryBm: "Amalan Keagamaan",
    summaryEn:
      "The Selangor State Fatwa Committee (meeting of 6 June 2013) ruled that the ideology of religious liberalism and pluralism — whether held by individuals or institutions — is deviant and contrary to Islamic teachings. The Selangor Mufti Department issued the fatwa on 17 July 2014, and it was gazetted on 31 July 2014.",
    summaryBm:
      "Jawatankuasa Fatwa Negeri Selangor (mesyuarat 6 Jun 2013) memutuskan bahawa fahaman liberalisme dan pluralisme agama — sama ada dipegang oleh individu mahupun institusi — adalah menyeleweng dan bertentangan dengan ajaran Islam. Jabatan Mufti Negeri Selangor mengeluarkan fatwa pada 17 Julai 2014, dan ia diwartakan pada 31 Julai 2014.",
    detailsEn:
      "The gazetted fatwa declares that doctrines of religious liberalism and pluralism deviate from Islam. Its scope was later examined in the Malaysian courts in relation to how far a gazetted fatwa may bind named bodies versus individuals; practitioners advising clients in Selangor should check the current judicial position. The fatwa is binding on Muslims within the State of Selangor once gazetted.",
    detailsBm:
      "Fatwa yang diwartakan ini mengisytiharkan bahawa doktrin liberalisme dan pluralisme agama menyeleweng daripada Islam. Skopnya kemudian diteliti di mahkamah Malaysia berkenaan sejauh mana fatwa yang diwartakan boleh mengikat badan tertentu berbanding individu; pengamal yang menasihati klien di Selangor perlu menyemak kedudukan kehakiman semasa. Fatwa ini mengikat orang Islam dalam Negeri Selangor setelah diwartakan.",
    status: "Active",
    relatedLegislation: null,
    gates: "civil,criminal,advisory",
    order: 101,
  },
  {
    titleEn: "Smoking Declared Haram (Penang)",
    titleBm: "Merokok Diharamkan (Pulau Pinang)",
    issuingBody: "Penang State Fatwa Committee (Mufti of Penang)",
    issuingBodyBm: "Jawatankuasa Fatwa Negeri Pulau Pinang (Mufti Pulau Pinang)",
    gazetteRef: null,
    sourceUrl: null,
    year: "2004",
    state: "Pulau Pinang",
    category: "Public Health & Morality",
    categoryBm: "Kesihatan Awam & Moral",
    summaryEn:
      "Penang gazetted a fatwa in 2004 declaring that smoking is haram, adopting the National Fatwa Council's decision of 23 March 1995 that smoking is haram because of its proven harm. Penang and Selangor are frequently cited as the states that gazetted the smoking-haram ruling into enforceable state fatwa.",
    summaryBm:
      "Pulau Pinang mewartakan fatwa pada tahun 2004 yang memutuskan bahawa merokok adalah haram, dengan menerima pakai keputusan Muzakarah Jawatankuasa Fatwa Majlis Kebangsaan pada 23 Mac 1995 bahawa merokok adalah haram kerana kemudaratannya. Pulau Pinang dan Selangor kerap disebut sebagai negeri yang mewartakan keputusan haram merokok sebagai fatwa negeri yang boleh dikuatkuasakan.",
    detailsEn:
      "The ruling rests on conclusive evidence of harm to health, the Quranic prohibition against self-harm, the principle 'la dharar wa la dhirar' (no harm and no reciprocal harm), and the prohibition of wasteful spending (israf). While the National Fatwa Council declared smoking haram in 1995, the ruling only carries the force of law in states that gazette it; Penang's 2004 gazetting makes it enforceable within the state.",
    detailsBm:
      "Keputusan ini berasaskan bukti kukuh kemudaratan kesihatan, larangan al-Quran terhadap mencederakan diri, prinsip 'la dharar wa la dhirar' (tiada kemudaratan dan tiada kemudaratan balas), serta larangan pembaziran (israf). Walaupun Muzakarah Kebangsaan mengisytiharkan merokok haram pada 1995, keputusan itu hanya berkuat kuasa undang-undang di negeri yang mewartakannya; pewartaan oleh Pulau Pinang pada 2004 menjadikannya boleh dikuatkuasakan dalam negeri.",
    status: "Active",
    relatedLegislation: null,
    gates: "civil,criminal,advisory",
    order: 102,
  },
  {
    titleEn: "Women Resembling Men (Pengkid) Declared Haram",
    titleBm: "Wanita Menyerupai Lelaki (Pengkid) Diharamkan",
    issuingBody: "Negeri Sembilan State Fatwa Committee",
    issuingBodyBm: "Jawatankuasa Fatwa Negeri Sembilan",
    gazetteRef: null,
    sourceUrl: "https://muftins.gov.my/fatwa/wanita-menyerupai-lelaki-pengkid/",
    year: "2013",
    state: "Negeri Sembilan",
    category: "Public Health & Morality",
    categoryBm: "Kesihatan Awam & Moral",
    summaryEn:
      "The Negeri Sembilan State Fatwa Committee, at meeting No. 5/1434H on 30 April 2013, ruled that 'pengkid' — women who adopt the appearance, behaviour and sexual inclinations of men — is haram under Islamic law. The state ruling reinforces the National Fatwa Council's earlier decision (2008) on the matter.",
    summaryBm:
      "Jawatankuasa Fatwa Negeri Sembilan, dalam Mesyuarat Bil. 5/1434H pada 30 April 2013, memutuskan bahawa 'pengkid' — iaitu wanita yang berpenampilan, bertingkah laku dan mempunyai naluri seksual seperti lelaki — adalah haram di sisi hukum Islam. Keputusan negeri ini mengukuhkan keputusan Majlis Fatwa Kebangsaan terdahulu (2008) berkenaan perkara tersebut.",
    detailsEn:
      "The committee held that adopting the appearance and behaviour of the opposite sex contradicts human fitrah and the prohibition of tasyabbuh (imitation) between the sexes, and may lead to intimate relationships forbidden in Islam. Once gazetted at state level, the fatwa is binding on Muslims in Negeri Sembilan and disregarding it may constitute an offence under the state's Syariah Criminal Offences enactment.",
    detailsBm:
      "Jawatankuasa berpendapat bahawa meniru penampilan dan tingkah laku jantina yang berlawanan bertentangan dengan fitrah manusia dan larangan tasyabbuh antara jantina, serta boleh membawa kepada hubungan intim yang dilarang dalam Islam. Setelah diwartakan di peringkat negeri, fatwa ini mengikat orang Islam di Negeri Sembilan dan mengabaikannya boleh menjadi suatu kesalahan di bawah enakmen kesalahan jenayah syariah negeri.",
    status: "Active",
    relatedLegislation: null,
    gates: "civil,criminal,advisory",
    order: 103,
  },
  {
    titleEn: "Yoga Exercise Containing Hindu Religious Elements Prohibited",
    titleBm: "Senaman Yoga Yang Mengandungi Unsur Keagamaan Hindu Dilarang",
    issuingBody: "Johor State Fatwa Committee",
    issuingBodyBm: "Jawatankuasa Fatwa Negeri Johor",
    gazetteRef: null,
    sourceUrl: null,
    year: "2008",
    state: "Johor",
    category: "Religious Practice",
    categoryBm: "Amalan Keagamaan",
    summaryEn:
      "Following the National Fatwa Council's 83rd Muzakarah (2008), the Johor State Fatwa Committee adopted the ruling that yoga originating from Hindu practice — combining physical movements with religious philosophy, mantras (chanting) and worship aimed at union with a deity — is prohibited where it contains those elements, as it can corrupt a Muslim's aqidah.",
    summaryBm:
      "Berikutan Muzakarah ke-83 Jawatankuasa Fatwa Majlis Kebangsaan (2008), Jawatankuasa Fatwa Negeri Johor menerima pakai keputusan bahawa yoga yang berasal daripada amalan Hindu — yang menggabungkan gerakan fizikal dengan falsafah keagamaan, mantera dan pemujaan bertujuan penyatuan dengan tuhan — adalah dilarang apabila ia mengandungi unsur-unsur tersebut, kerana ia boleh merosakkan akidah seorang Muslim.",
    detailsEn:
      "The national ruling distinguishes between the components of yoga: where the practice combines physical postures with chanting (mantra) and worship, it is haram for Muslims because of the elements of other-religion ritual and potential harm to belief. The committee's guidance is that Muslims should avoid yoga to prevent confusion, even though physical movement on its own is not the object of prohibition. Practitioners should confirm the specific gazetted position applicable in the relevant state.",
    detailsBm:
      "Keputusan kebangsaan membezakan komponen yoga: apabila amalan itu menggabungkan postur fizikal dengan mantera dan pemujaan, ia haram bagi orang Islam kerana terdapat unsur ritual agama lain dan kemungkinan kemudaratan kepada akidah. Panduan jawatankuasa ialah orang Islam wajar menjauhi yoga bagi mengelak kekeliruan, walaupun gerakan fizikal semata-mata bukanlah objek pengharaman. Pengamal perlu mengesahkan kedudukan khusus yang diwartakan dalam negeri berkenaan.",
    status: "Active",
    relatedLegislation: null,
    gates: "civil,criminal,advisory",
    order: 104,
  },
  {
    titleEn: "Wahdatul Wujud Doctrine Declared Contrary to Islamic Creed",
    titleBm: "Fahaman Wahdatul Wujud Diisytiharkan Bertentangan Akidah Islam",
    issuingBody: "Kedah State Fatwa Committee",
    issuingBodyBm: "Jawatankuasa Fatwa Negeri Kedah",
    gazetteRef: null,
    sourceUrl: "https://mufti.kedah.gov.my/bahagian-fatwa/",
    year: "2001",
    state: "Kedah",
    category: "Religious Practice",
    categoryBm: "Amalan Keagamaan",
    summaryEn:
      "The Kedah State Fatwa Committee gazetted a fatwa (27 September 2001) declaring that the doctrine of Wahdatul Wujud (belief in the 'unity of being') contradicts the creed of Ahlus Sunnah Wal Jamaah and is contrary to Islamic teachings. It was issued under Kedah's fatwa istinbat and gazetting procedures.",
    summaryBm:
      "Jawatankuasa Fatwa Negeri Kedah mewartakan fatwa (27 September 2001) yang mengisytiharkan bahawa fahaman Wahdatul Wujud (kepercayaan 'kesatuan wujud') bertentangan dengan akidah Ahlus Sunnah Wal Jamaah dan bercanggah dengan ajaran Islam. Ia dikeluarkan menerusi prosedur istinbat dan pewartaan fatwa Negeri Kedah.",
    detailsEn:
      "Wahdatul Wujud is treated by the committee as a deviant belief that blurs the distinction between the Creator and creation, departing from the aqidah of Ahlus Sunnah Wal Jamaah. Once gazetted, the fatwa is binding on Muslims in Kedah and propagating the doctrine may constitute an offence relating to deviant teachings under the state's Syariah Criminal Offences enactment.",
    detailsBm:
      "Wahdatul Wujud dianggap oleh jawatankuasa sebagai kepercayaan menyeleweng yang mengaburkan perbezaan antara Pencipta dan makhluk, lalu menyimpang daripada akidah Ahlus Sunnah Wal Jamaah. Setelah diwartakan, fatwa ini mengikat orang Islam di Kedah dan menyebarkan fahaman tersebut boleh menjadi suatu kesalahan berkaitan ajaran sesat di bawah enakmen kesalahan jenayah syariah negeri.",
    status: "Active",
    relatedLegislation: null,
    gates: "civil,criminal,advisory",
    order: 105,
  },
];

export async function seedStateFatwas() {
  console.log("Seeding verified state-level gazetted fatwas...");

  // Ensure the source_url column exists so this script is safe to run on any
  // database (fresh, staging, or production) without a separate migration step.
  await pool.query("ALTER TABLE gazetted_fatwas ADD COLUMN IF NOT EXISTS source_url text");

  const existing = await db.select({ titleEn: fatwaTable.titleEn }).from(fatwaTable);
  const existingTitles = new Set(existing.map((r) => r.titleEn));

  let inserted = 0;
  for (const f of stateFatwas) {
    if (existingTitles.has(f.titleEn)) {
      console.log(`  - skip (exists): ${f.titleEn}`);
      continue;
    }
    await db.insert(fatwaTable).values(f);
    inserted++;
    console.log(`  + inserted: ${f.state} — ${f.titleEn}`);
  }

  console.log(`Done. Inserted ${inserted} of ${stateFatwas.length} state fatwas.`);
}

seedStateFatwas()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
