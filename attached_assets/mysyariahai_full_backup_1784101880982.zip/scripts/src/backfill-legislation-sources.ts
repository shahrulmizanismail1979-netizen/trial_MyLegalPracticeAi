import { pool } from "@workspace/db";

/**
 * Idempotent backfill for the Legislation module's `source_url` column.
 *
 * SOURCE / ACCURACY POLICY:
 * Every link below is a REAL, web-verified PDF on the official Attorney
 * General's Chambers Laws of Malaysia portal (lom.agc.gov.my). Each URL was
 * confirmed to return HTTP 200 with `Content-Type: application/pdf`. URLs that
 * could not be verified are deliberately left null rather than guessed — never
 * construct government PDF URLs from a pattern.
 *
 * This script is SAFE TO RE-RUN. It only adds the column if missing and updates
 * existing rows by `act_number`; it never inserts rows (the state enactments and
 * federal acts already exist). Use this instead of re-running the seeds, which
 * use onConflictDoNothing on a serial primary key and would create duplicates.
 *
 * Run with: pnpm --filter @workspace/scripts run backfill-legislation-sources
 */

const VERIFIED_SOURCES: Record<string, string> = {
  "Act 303": "https://lom.agc.gov.my/ilims/upload/portal/akta/LOM/EN/Act%20303%20(11.3.2014).pdf",
  "Act 585": "https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/Act%20585.pdf",
  "Act 560": "https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/Act%20560.pdf",
  "Act 759": "https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/20130322_759_BI_Combined.pdf",
  "Act 164": "https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/Act%20164%20original.pdf",
  "Act 701": "https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/Act%20701.pdf",
};

async function main() {
  await pool.query("ALTER TABLE legislation ADD COLUMN IF NOT EXISTS source_url text");

  let updated = 0;
  for (const [actNumber, url] of Object.entries(VERIFIED_SOURCES)) {
    const res = await pool.query(
      "UPDATE legislation SET source_url = $1 WHERE act_number = $2",
      [url, actNumber],
    );
    const count = res.rowCount ?? 0;
    updated += count;
    console.log(`${count ? "✓" : "—"} ${actNumber} (${count} row${count === 1 ? "" : "s"})`);
  }

  console.log(`Backfill complete: ${updated} legislation row(s) updated with verified source links.`);
  await pool.end();
}

main().catch((err) => {
  console.error("Backfill failed:", err);
  process.exit(1);
});
