import { db, pool } from "@workspace/db";
import {
  provisionsTable,
  causePapersTable,
  proceduralWorkflowsTable,
  fatwaTable,
  quranicVersesTable,
} from "@workspace/db";

/**
 * Seeds substantial content for the Criminal Litigation and Advisory &
 * Consultancy practice gates, which were previously thin compared to Civil.
 *
 * Idempotent: each section reads the existing `title_en` (or surah/ayah) values
 * for its table and only inserts rows that are not already present, so the
 * script is safe to run repeatedly.
 */

async function existingTitles(table: "provisions" | "cause_papers" | "procedural_workflows" | "gazetted_fatwas"): Promise<Set<string>> {
  const { rows } = await pool.query(`SELECT title_en FROM ${table}`);
  return new Set(rows.map((r: { title_en: string }) => r.title_en));
}

async function existingVerseKeys(): Promise<Set<string>> {
  const { rows } = await pool.query(
    `SELECT surah_number, ayah_range FROM quranic_verses`,
  );
  return new Set(
    rows.map(
      (r: { surah_number: number; ayah_range: string }) =>
        `${r.surah_number}:${r.ayah_range}`,
    ),
  );
}

// ============================================================
// CRIMINAL — Provisions (Syariah Criminal Offences)
// ============================================================
const criminalProvisions = [
  {
    category: "Syariah Criminal Law",
    categoryBm: "Undang-Undang Jenayah Syariah",
    titleEn: "Khalwat (Close Proximity)",
    titleBm: "Khalwat (Berdua-duaan)",
    titleAr: "الخلوة",
    overviewEn:
      "Khalwat is the offence of close, suspicious proximity between a man and a woman who are not married to each other and are not mahram (within prohibited degrees of kinship), in a secluded place that gives rise to suspicion of immoral conduct. It is one of the most frequently prosecuted Syariah criminal offences in Malaysia. The offence is committed even without proof of sexual relations — what is criminalised is the secluded proximity itself in circumstances that arouse suspicion.",
    overviewBm:
      "Khalwat adalah kesalahan berdua-duaan secara rapat dan mencurigakan antara seorang lelaki dan seorang perempuan yang bukan suami isteri dan bukan mahram, di tempat terpencil yang menimbulkan syak wasangka terhadap perlakuan tidak bermoral. Ia merupakan antara kesalahan jenayah Syariah yang paling kerap didakwa di Malaysia. Kesalahan ini terlaksana walaupun tanpa bukti hubungan seks — apa yang dijenayahkan adalah pengasingan diri itu sendiri dalam keadaan yang menimbulkan syak.",
    principlesEn:
      "Elements the prosecution must prove: (1) The accused is a Muslim, (2) A man and a woman who are not married and not mahram, (3) Were together in a secluded/private place, (4) In circumstances which may give rise to suspicion that they were engaged in immoral acts. Standard of proof in Syariah criminal cases is 'beyond reasonable doubt'. Defences include marriage, mahram relationship, or innocent presence (e.g., a lawful reason such as work or a medical emergency).",
    principlesBm:
      "Elemen yang mesti dibuktikan oleh pendakwaan: (1) Tertuduh seorang Muslim, (2) Seorang lelaki dan seorang perempuan yang bukan suami isteri dan bukan mahram, (3) Berada bersama di tempat terpencil/persendirian, (4) Dalam keadaan yang boleh menimbulkan syak bahawa mereka melakukan perbuatan tidak bermoral. Standard pembuktian dalam kes jenayah Syariah adalah 'melampaui keraguan munasabah'. Pembelaan termasuk perkahwinan, hubungan mahram, atau kehadiran yang tidak bersalah (cth., sebab sah seperti kerja atau kecemasan perubatan).",
    legislationEn:
      "Syariah Criminal Offences (Federal Territories) Act 1997 (Act 559) s.27. Parallel provisions exist in every state Syariah criminal offences enactment (e.g., Selangor s.31, Johor s.27). Penalty: fine not exceeding RM3,000 or imprisonment not exceeding 2 years or both (Act 559).",
    legislationBm:
      "Akta Kesalahan Jenayah Syariah (Wilayah-Wilayah Persekutuan) 1997 (Akta 559) s.27. Peruntukan selari wujud dalam setiap enakmen kesalahan jenayah Syariah negeri (cth., Selangor s.31, Johor s.27). Hukuman: denda tidak melebihi RM3,000 atau penjara tidak melebihi 2 tahun atau kedua-duanya (Akta 559).",
    practicalNotesEn:
      "When defending a khalwat charge: (1) Scrutinise the manner of arrest and whether enforcement officers had lawful grounds to enter, (2) Challenge whether the place was genuinely 'secluded', (3) Test the suspicion element — mere presence in a public or semi-public place may not suffice, (4) Raise any lawful explanation for the proximity, (5) Verify the identity and religion of the accused. Many khalwat cases are resolved by a plea of guilty with a plea in mitigation; advise the client on the religious and reputational consequences.",
    practicalNotesBm:
      "Apabila membela pertuduhan khalwat: (1) Teliti cara tangkapan dan sama ada pegawai penguatkuasa mempunyai alasan sah untuk masuk, (2) Cabar sama ada tempat itu benar-benar 'terpencil', (3) Uji elemen syak — kehadiran semata-mata di tempat awam atau separa awam mungkin tidak mencukupi, (4) Bangkitkan apa-apa penjelasan sah bagi kedekatan itu, (5) Sahkan identiti dan agama tertuduh. Banyak kes khalwat diselesaikan dengan pengakuan bersalah berserta rayuan pengurangan hukuman; nasihatkan klien tentang akibat keagamaan dan reputasi.",
    relatedCases:
      "Pendakwa Syarie v Mohd Nor; Pendakwa Syarie Selangor v Wan Norazlin",
    gates: "criminal",
    order: 60,
  },
  {
    category: "Syariah Criminal Law",
    categoryBm: "Undang-Undang Jenayah Syariah",
    titleEn: "Zina (Unlawful Sexual Intercourse)",
    titleBm: "Zina (Persetubuhan Haram)",
    titleAr: "الزنا",
    overviewEn:
      "Zina is the offence of sexual intercourse between a man and a woman who are not married to each other. Under Malaysian Syariah criminal law it is a ta'zir offence (punishment at the discretion of the court within statutory limits), not a hudud offence, because the states lack jurisdiction to impose hudud punishments. Proof is exceptionally demanding: the classical standard requires either four credible eyewitnesses to the act itself or a voluntary confession.",
    overviewBm:
      "Zina adalah kesalahan persetubuhan antara seorang lelaki dan seorang perempuan yang bukan suami isteri. Di bawah undang-undang jenayah Syariah Malaysia ia adalah kesalahan ta'zir (hukuman atas budi bicara mahkamah dalam had statutori), bukan kesalahan hudud, kerana negeri tidak mempunyai bidang kuasa untuk mengenakan hukuman hudud. Pembuktian amat berat: standard klasik memerlukan sama ada empat saksi mata yang boleh dipercayai terhadap perbuatan itu atau pengakuan secara sukarela.",
    principlesEn:
      "Elements: (1) The accused is a Muslim, (2) Sexual intercourse occurred, (3) Between persons not validly married to each other. Evidentiary safeguards are paramount: four eyewitnesses of the act, or a clear voluntary confession (which may be retracted). Pregnancy alone is generally insufficient absent a confession or witnesses. The high evidentiary threshold reflects the Shariah policy of avoiding wrongful conviction (the principle of dar' al-hudud bi al-shubuhat — averting punishment by doubt).",
    principlesBm:
      "Elemen: (1) Tertuduh seorang Muslim, (2) Persetubuhan berlaku, (3) Antara orang yang tidak sah berkahwin antara satu sama lain. Perlindungan keterangan amat penting: empat saksi mata terhadap perbuatan, atau pengakuan sukarela yang jelas (yang boleh ditarik balik). Kehamilan semata-mata secara umumnya tidak mencukupi tanpa pengakuan atau saksi. Ambang keterangan yang tinggi mencerminkan dasar Syariah mengelakkan sabitan yang salah (prinsip dar' al-hudud bi al-syubuhat — menolak hukuman kerana keraguan).",
    legislationEn:
      "Syariah Criminal Offences (Federal Territories) Act 1997 (Act 559) s.23. State enactments contain parallel provisions. Penalty (ta'zir): fine not exceeding RM5,000 or imprisonment not exceeding 3 years or whipping not exceeding 6 strokes or any combination (Act 559).",
    legislationBm:
      "Akta Kesalahan Jenayah Syariah (Wilayah-Wilayah Persekutuan) 1997 (Akta 559) s.23. Enakmen negeri mengandungi peruntukan selari. Hukuman (ta'zir): denda tidak melebihi RM5,000 atau penjara tidak melebihi 3 tahun atau sebatan tidak melebihi 6 sebatan atau apa-apa gabungan (Akta 559).",
    practicalNotesEn:
      "Defending zina: (1) Test the admissibility and voluntariness of any confession — confessions obtained under pressure are inadmissible and may be retracted at any time before judgment, (2) Scrutinise the number and credibility of witnesses, (3) Apply the doubt principle — any reasonable doubt must result in acquittal, (4) Be alert to the qazaf exposure of accusers who fail to prove the allegation. Always advise the client of the right to silence.",
    practicalNotesBm:
      "Membela zina: (1) Uji kebolehterimaan dan kesukarelaan apa-apa pengakuan — pengakuan yang diperoleh di bawah tekanan tidak boleh diterima dan boleh ditarik balik pada bila-bila masa sebelum penghakiman, (2) Teliti bilangan dan kebolehpercayaan saksi, (3) Terapkan prinsip keraguan — apa-apa keraguan munasabah mesti mengakibatkan pembebasan, (4) Berwaspada terhadap pendedahan qazaf bagi penuduh yang gagal membuktikan dakwaan, (5) Sentiasa nasihatkan klien tentang hak untuk berdiam diri.",
    relatedCases: "Pendakwa Syarie v Hamzah; cases applying dar' al-hudud bi al-shubuhat",
    gates: "criminal",
    order: 61,
  },
  {
    category: "Syariah Criminal Law",
    categoryBm: "Undang-Undang Jenayah Syariah",
    titleEn: "Qazaf (False Accusation of Zina)",
    titleBm: "Qazaf (Tuduhan Palsu Zina)",
    titleAr: "القذف",
    overviewEn:
      "Qazaf is the offence of falsely accusing a chaste person of zina without being able to produce the required proof. It protects reputation and deters reckless allegations of sexual immorality. A person who alleges zina but cannot satisfy the strict evidentiary standard exposes themselves to a qazaf charge. This linkage is a deliberate Shariah safeguard against character assassination.",
    overviewBm:
      "Qazaf adalah kesalahan menuduh secara palsu seseorang yang suci dengan zina tanpa dapat mengemukakan bukti yang diperlukan. Ia melindungi maruah dan mencegah dakwaan melulu tentang keruntuhan akhlak. Seseorang yang mendakwa zina tetapi tidak dapat memenuhi standard keterangan yang ketat mendedahkan dirinya kepada pertuduhan qazaf. Kaitan ini adalah perlindungan Syariah yang sengaja terhadap pembunuhan karakter.",
    principlesEn:
      "Elements: (1) An accusation of zina (or denial of legitimate parentage) was made against an identified person, (2) The person accused was of good reputation (muhsan), (3) The accuser failed to prove the accusation by four witnesses. The offence flows directly from the Quranic injunction in Surah An-Nur (24:4). Truth is a complete defence if proven to the required standard.",
    principlesBm:
      "Elemen: (1) Satu tuduhan zina (atau penafian keturunan sah) dibuat terhadap seseorang yang dikenal pasti, (2) Orang yang dituduh berreputasi baik (muhsan), (3) Penuduh gagal membuktikan tuduhan dengan empat saksi. Kesalahan ini mengalir terus daripada perintah Al-Quran dalam Surah An-Nur (24:4). Kebenaran adalah pembelaan lengkap jika dibuktikan kepada standard yang diperlukan.",
    legislationEn:
      "Syariah Criminal Offences (Federal Territories) Act 1997 (Act 559) s.24. State enactments contain parallel provisions. Penalty (ta'zir): fine or imprisonment as prescribed; classical hadd of qazaf is 80 lashes but states impose ta'zir penalties only.",
    legislationBm:
      "Akta Kesalahan Jenayah Syariah (Wilayah-Wilayah Persekutuan) 1997 (Akta 559) s.24. Enakmen negeri mengandungi peruntukan selari. Hukuman (ta'zir): denda atau penjara sebagaimana ditetapkan; hadd qazaf klasik ialah 80 sebatan tetapi negeri hanya mengenakan hukuman ta'zir.",
    practicalNotesEn:
      "Advise complainants in zina matters of their qazaf exposure before they lodge a report. When defending a qazaf charge, assess whether the words used truly amounted to an accusation of zina, whether the complainant is muhsan, and whether any privilege or context (e.g., testimony in court) applies.",
    practicalNotesBm:
      "Nasihatkan pengadu dalam perkara zina tentang pendedahan qazaf mereka sebelum membuat laporan. Apabila membela pertuduhan qazaf, nilai sama ada perkataan yang digunakan benar-benar merupakan tuduhan zina, sama ada pengadu itu muhsan, dan sama ada apa-apa keistimewaan atau konteks (cth., keterangan di mahkamah) terpakai.",
    relatedCases: "Cases on s.24 Act 559 qazaf prosecutions",
    gates: "criminal",
    order: 62,
  },
  {
    category: "Syariah Criminal Law",
    categoryBm: "Undang-Undang Jenayah Syariah",
    titleEn: "Drinking Intoxicants (Minum Minuman Memabukkan)",
    titleBm: "Minum Minuman Yang Memabukkan",
    titleAr: "شرب المسكر",
    overviewEn:
      "It is a Syariah criminal offence for a Muslim to consume, possess, or be found in a state of intoxication from alcoholic or intoxicating drinks in a public place. The prohibition of khamr (intoxicants) is a foundational Shariah ruling. Enforcement typically arises from observation by religious enforcement officers or referrals from police.",
    overviewBm:
      "Adalah kesalahan jenayah Syariah bagi seorang Muslim untuk meminum, memiliki, atau didapati dalam keadaan mabuk akibat minuman beralkohol atau memabukkan di tempat awam. Larangan khamr (minuman memabukkan) adalah hukum Syariah yang asas. Penguatkuasaan biasanya timbul daripada pemerhatian oleh pegawai penguatkuasa agama atau rujukan daripada polis.",
    principlesEn:
      "Elements: (1) The accused is a Muslim, (2) Consumed, sold, gave, or possessed intoxicating drink, or was found intoxicated. Proof may be by confession, witness testimony, or objective evidence (e.g., a positive alcohol test, observable intoxication). Medical necessity may be a defence in narrow circumstances.",
    principlesBm:
      "Elemen: (1) Tertuduh seorang Muslim, (2) Meminum, menjual, memberi, atau memiliki minuman memabukkan, atau didapati mabuk. Pembuktian boleh melalui pengakuan, keterangan saksi, atau bukti objektif (cth., ujian alkohol positif, kemabukan yang dapat diperhatikan). Keperluan perubatan mungkin menjadi pembelaan dalam keadaan terhad.",
    legislationEn:
      "Syariah Criminal Offences (Federal Territories) Act 1997 (Act 559) s.26. State enactments contain parallel provisions. Penalty: fine not exceeding RM5,000 or imprisonment not exceeding 3 years or whipping not exceeding 6 strokes or any combination.",
    legislationBm:
      "Akta Kesalahan Jenayah Syariah (Wilayah-Wilayah Persekutuan) 1997 (Akta 559) s.26. Enakmen negeri mengandungi peruntukan selari. Hukuman: denda tidak melebihi RM5,000 atau penjara tidak melebihi 3 tahun atau sebatan tidak melebihi 6 sebatan atau apa-apa gabungan.",
    practicalNotesEn:
      "Check the reliability and chain of custody of any breath/blood test, the religion of the accused, and whether the consumption occurred in a place within the enactment's reach. Consider mitigation factors such as first offence, remorse, and rehabilitation.",
    practicalNotesBm:
      "Semak kebolehpercayaan dan rantaian jagaan apa-apa ujian nafas/darah, agama tertuduh, dan sama ada minuman itu berlaku di tempat dalam jangkauan enakmen. Pertimbangkan faktor pengurangan seperti kesalahan pertama, kekesalan, dan pemulihan.",
    relatedCases: "Prosecutions under s.26 Act 559",
    gates: "criminal",
    order: 63,
  },
  {
    category: "Syariah Criminal Procedure",
    categoryBm: "Tatacara Jenayah Syariah",
    titleEn: "Arrest, Investigation & Bail in Syariah Criminal Cases",
    titleBm: "Tangkapan, Siasatan & Jamin dalam Kes Jenayah Syariah",
    titleAr: "القبض والتحقيق والكفالة",
    overviewEn:
      "Syariah criminal procedure governs how religious enforcement officers investigate, arrest, and charge suspects, and how the accused may obtain bail pending trial. The procedure mirrors many features of civil criminal procedure but operates under the Syariah Criminal Procedure enactments. Respect for the accused's rights — including the right to counsel and the right against self-incrimination — is central.",
    overviewBm:
      "Tatacara jenayah Syariah mengawal cara pegawai penguatkuasa agama menyiasat, menangkap, dan mendakwa suspek, serta cara tertuduh boleh mendapat jamin sementara menunggu perbicaraan. Tatacara ini mencerminkan banyak ciri tatacara jenayah sivil tetapi beroperasi di bawah enakmen Tatacara Jenayah Syariah. Penghormatan terhadap hak tertuduh — termasuk hak kepada peguam dan hak terhadap mendakwa diri sendiri — adalah penting.",
    principlesEn:
      "Key safeguards: (1) Arrest must be lawful and the grounds communicated, (2) The accused must be produced before a court within the statutory period, (3) The accused is entitled to legal representation (peguam Syarie), (4) Bail may be granted for bailable offences and at the court's discretion for others, (5) Statements to enforcement officers must be voluntary to be admissible.",
    principlesBm:
      "Perlindungan utama: (1) Tangkapan mesti sah dan alasan dimaklumkan, (2) Tertuduh mesti dibawa ke hadapan mahkamah dalam tempoh statutori, (3) Tertuduh berhak kepada perwakilan undang-undang (peguam Syarie), (4) Jamin boleh diberikan bagi kesalahan boleh jamin dan atas budi bicara mahkamah bagi yang lain, (5) Kenyataan kepada pegawai penguatkuasa mesti sukarela untuk boleh diterima.",
    legislationEn:
      "Syariah Criminal Procedure (Federal Territories) Act 1997 (Act 560) and the equivalent state Syariah Criminal Procedure enactments govern arrest, investigation, charge, bail, trial, and appeal.",
    legislationBm:
      "Akta Tatacara Jenayah Syariah (Wilayah-Wilayah Persekutuan) 1997 (Akta 560) dan enakmen Tatacara Jenayah Syariah negeri yang setara mengawal tangkapan, siasatan, pertuduhan, jamin, perbicaraan, dan rayuan.",
    practicalNotesEn:
      "On first taking instructions: (1) Establish the exact charge and the enactment section, (2) Apply for bail promptly, (3) Obtain the charge sheet and investigation papers, (4) Advise the client not to give any statement without counsel present, (5) Diarise all procedural time limits, especially for filing any appeal or revision.",
    practicalNotesBm:
      "Apabila mula mengambil arahan: (1) Tetapkan pertuduhan tepat dan seksyen enakmen, (2) Mohon jamin dengan segera, (3) Dapatkan kertas pertuduhan dan kertas siasatan, (4) Nasihatkan klien supaya tidak memberi apa-apa kenyataan tanpa kehadiran peguam, (5) Catatkan semua had masa tatacara, terutamanya bagi memfailkan apa-apa rayuan atau semakan.",
    relatedCases: "Procedural rulings under Act 560",
    gates: "criminal",
    order: 64,
  },
];

// ============================================================
// CRIMINAL — Cause Papers
// ============================================================
const criminalCausePapers = [
  {
    titleEn: "Charge Sheet (Pertuduhan) — Syariah Criminal Offence",
    titleBm: "Kertas Pertuduhan — Kesalahan Jenayah Syariah",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    descriptionEn:
      "The formal charge document setting out the offence, the enactment section, and the particulars of the alleged act, read to the accused at the commencement of a Syariah criminal trial.",
    descriptionBm:
      "Dokumen pertuduhan rasmi yang menyatakan kesalahan, seksyen enakmen, dan butiran perbuatan yang didakwa, dibacakan kepada tertuduh pada permulaan perbicaraan jenayah Syariah.",
    templateEn:
      "DALAM MAHKAMAH RENDAH SYARIAH DI ______\nKES JENAYAH NO: ______\n\nPENDAKWA SYARIE\nlawan\n[Nama Tertuduh] (No. K/P: ______)\n\nPERTUDUHAN\n\nBahawa kamu, pada ______ (tarikh), lebih kurang jam ______, di ______ (tempat), dalam Negeri ______, telah melakukan kesalahan [nyatakan perbuatan], dan dengan itu kamu telah melakukan satu kesalahan di bawah seksyen ______ [Enakmen/Akta] yang boleh dihukum di bawah seksyen yang sama.\n\nDibacakan dan diterangkan kepada tertuduh: ____________\nTandatangan Pendakwa Syarie: ____________\nTarikh: ____________",
    templateBm:
      "DALAM MAHKAMAH RENDAH SYARIAH DI ______\nKES JENAYAH NO: ______\n\nPENDAKWA SYARIE\nlawan\n[Nama Tertuduh] (No. K/P: ______)\n\nPERTUDUHAN\n\nBahawa kamu, pada ______ (tarikh), lebih kurang jam ______, di ______ (tempat), dalam Negeri ______, telah melakukan kesalahan [nyatakan perbuatan], dan dengan itu kamu telah melakukan satu kesalahan di bawah seksyen ______ [Enakmen/Akta] yang boleh dihukum di bawah seksyen yang sama.\n\nDibacakan dan diterangkan kepada tertuduh: ____________\nTandatangan Pendakwa Syarie: ____________\nTarikh: ____________",
    formNumber: "Borang Pertuduhan",
    requiredFields: "Court, case number, accused name & IC, date, time, place, state, offence, enactment section",
    gates: "criminal",
    order: 60,
  },
  {
    titleEn: "Bail Application (Permohonan Jaminan)",
    titleBm: "Permohonan Jaminan",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    descriptionEn:
      "Application by an accused person for release on bail pending the hearing of a Syariah criminal charge, supported by an affidavit setting out grounds and proposed sureties.",
    descriptionBm:
      "Permohonan oleh tertuduh untuk dibebaskan dengan jaminan sementara menunggu pendengaran pertuduhan jenayah Syariah, disokong oleh afidavit yang menyatakan alasan dan penjamin yang dicadangkan.",
    templateEn:
      "DALAM MAHKAMAH RENDAH SYARIAH DI ______\nKES JENAYAH NO: ______\n\nPENDAKWA SYARIE lawan [Nama Tertuduh]\n\nPERMOHONAN UNTUK JAMINAN\n\nPemohon (tertuduh) memohon supaya dibebaskan dengan jaminan atas alasan berikut:\n1. Pemohon mempunyai tempat kediaman tetap di ______;\n2. Pemohon tidak berisiko melarikan diri dan akan hadir pada setiap tarikh perbicaraan;\n3. Pemohon bersedia mengemukakan penjamin yang mencukupi;\n4. [Alasan lain].\n\nPenjamin dicadangkan: [Nama, No. K/P, hubungan, jumlah jaminan]\n\nDisokong oleh afidavit pemohon bertarikh ______.\nTandatangan: ____________",
    templateBm:
      "DALAM MAHKAMAH RENDAH SYARIAH DI ______\nKES JENAYAH NO: ______\n\nPENDAKWA SYARIE lawan [Nama Tertuduh]\n\nPERMOHONAN UNTUK JAMINAN\n\nPemohon (tertuduh) memohon supaya dibebaskan dengan jaminan atas alasan berikut:\n1. Pemohon mempunyai tempat kediaman tetap di ______;\n2. Pemohon tidak berisiko melarikan diri dan akan hadir pada setiap tarikh perbicaraan;\n3. Pemohon bersedia mengemukakan penjamin yang mencukupi;\n4. [Alasan lain].\n\nPenjamin dicadangkan: [Nama, No. K/P, hubungan, jumlah jaminan]\n\nDisokong oleh afidavit pemohon bertarikh ______.\nTandatangan: ____________",
    formNumber: null,
    requiredFields: "Court, case number, accused name, grounds, proposed sureties, supporting affidavit",
    gates: "criminal",
    order: 61,
  },
  {
    titleEn: "Plea in Mitigation (Rayuan Pengurangan Hukuman)",
    titleBm: "Rayuan Pengurangan Hukuman",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    descriptionEn:
      "A plea delivered after conviction (or after a guilty plea) urging the court to impose a lighter sentence, setting out mitigating circumstances personal to the accused.",
    descriptionBm:
      "Rayuan yang disampaikan selepas sabitan (atau selepas pengakuan bersalah) yang menggesa mahkamah mengenakan hukuman yang lebih ringan, dengan menyatakan keadaan pengurangan yang peribadi kepada tertuduh.",
    templateEn:
      "RAYUAN PENGURANGAN HUKUMAN\n\nYang Arif, bagi pihak tertuduh, saya memohon mahkamah mempertimbangkan faktor pengurangan berikut:\n1. Tertuduh seorang pesalah kali pertama tanpa rekod lampau;\n2. Tertuduh telah mengaku salah pada peringkat awal dan menjimatkan masa mahkamah;\n3. Tertuduh menyesali perbuatannya dan berjanji tidak akan mengulanginya;\n4. Tertuduh menanggung [tanggungan keluarga / pekerjaan / keadaan kesihatan];\n5. [Faktor lain].\n\nMaka, dipohon hukuman yang setimpal dan berbentuk pemulihan dikenakan.\nTandatangan Peguam Syarie: ____________",
    templateBm:
      "RAYUAN PENGURANGAN HUKUMAN\n\nYang Arif, bagi pihak tertuduh, saya memohon mahkamah mempertimbangkan faktor pengurangan berikut:\n1. Tertuduh seorang pesalah kali pertama tanpa rekod lampau;\n2. Tertuduh telah mengaku salah pada peringkat awal dan menjimatkan masa mahkamah;\n3. Tertuduh menyesali perbuatannya dan berjanji tidak akan mengulanginya;\n4. Tertuduh menanggung [tanggungan keluarga / pekerjaan / keadaan kesihatan];\n5. [Faktor lain].\n\nMaka, dipohon hukuman yang setimpal dan berbentuk pemulihan dikenakan.\nTandatangan Peguam Syarie: ____________",
    formNumber: null,
    requiredFields: "Accused background, first offence status, remorse, dependants, other mitigating factors",
    gates: "criminal",
    order: 62,
  },
  {
    titleEn: "Notice of Appeal (Notis Rayuan) — Criminal",
    titleBm: "Notis Rayuan — Jenayah",
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    descriptionEn:
      "Notice filed to appeal against conviction and/or sentence in a Syariah criminal matter, to be lodged within the statutory time limit.",
    descriptionBm:
      "Notis yang difailkan untuk merayu terhadap sabitan dan/atau hukuman dalam perkara jenayah Syariah, untuk difailkan dalam had masa statutori.",
    templateEn:
      "DALAM MAHKAMAH TINGGI SYARIAH DI ______\nRAYUAN JENAYAH NO: ______\n\n[Nama Perayu] ... Perayu\nlawan\nPENDAKWA SYARIE ... Responden\n\nNOTIS RAYUAN\n\nAmbil perhatian bahawa Perayu yang tersebut di atas merayu kepada Mahkamah Tinggi Syariah terhadap keseluruhan keputusan [sabitan dan/atau hukuman] Mahkamah Rendah Syariah di ______ yang diberikan pada ______.\n\nBertarikh: ______\nTandatangan Peguam Syarie: ____________",
    templateBm:
      "DALAM MAHKAMAH TINGGI SYARIAH DI ______\nRAYUAN JENAYAH NO: ______\n\n[Nama Perayu] ... Perayu\nlawan\nPENDAKWA SYARIE ... Responden\n\nNOTIS RAYUAN\n\nAmbil perhatian bahawa Perayu yang tersebut di atas merayu kepada Mahkamah Tinggi Syariah terhadap keseluruhan keputusan [sabitan dan/atau hukuman] Mahkamah Rendah Syariah di ______ yang diberikan pada ______.\n\nBertarikh: ______\nTandatangan Peguam Syarie: ____________",
    formNumber: "Notis Rayuan",
    requiredFields: "Court, appeal number, appellant, lower court & date, scope of appeal (conviction/sentence)",
    gates: "criminal",
    order: 63,
  },
];

// ============================================================
// CRIMINAL — Procedural Workflows
// ============================================================
const criminalWorkflows = [
  {
    titleEn: "Syariah Criminal Prosecution — From Charge to Sentence",
    titleBm: "Pendakwaan Jenayah Syariah — Dari Pertuduhan ke Hukuman",
    category: "Syariah Criminal Procedure",
    categoryBm: "Tatacara Jenayah Syariah",
    descriptionEn:
      "End-to-end procedure for a Syariah criminal case, from the reading of the charge through trial to conviction or acquittal and sentencing.",
    descriptionBm:
      "Tatacara menyeluruh bagi kes jenayah Syariah, dari pembacaan pertuduhan melalui perbicaraan hingga sabitan atau pembebasan dan penjatuhan hukuman.",
    stepsJson: JSON.stringify([
      { step: 1, titleEn: "Reading of the charge", titleBm: "Pembacaan pertuduhan", detailEn: "The charge is read and explained to the accused, who pleads guilty or not guilty.", detailBm: "Pertuduhan dibacakan dan diterangkan kepada tertuduh, yang mengaku salah atau tidak salah." },
      { step: 2, titleEn: "Plea", titleBm: "Pengakuan", detailEn: "A guilty plea proceeds to mitigation and sentence; a not-guilty plea proceeds to trial.", detailBm: "Pengakuan salah meneruskan ke rayuan dan hukuman; pengakuan tidak salah meneruskan ke perbicaraan." },
      { step: 3, titleEn: "Prosecution case", titleBm: "Kes pendakwaan", detailEn: "The Pendakwa Syarie calls witnesses and tenders evidence; defence cross-examines.", detailBm: "Pendakwa Syarie memanggil saksi dan mengemukakan keterangan; pembelaan memeriksa balas." },
      { step: 4, titleEn: "Prima facie ruling", titleBm: "Keputusan prima facie", detailEn: "The court decides whether a prima facie case is made; if not, the accused is acquitted.", detailBm: "Mahkamah memutuskan sama ada kes prima facie dibuktikan; jika tidak, tertuduh dibebaskan." },
      { step: 5, titleEn: "Defence case", titleBm: "Kes pembelaan", detailEn: "If called to enter a defence, the accused gives evidence and may call witnesses.", detailBm: "Jika dipanggil membela diri, tertuduh memberi keterangan dan boleh memanggil saksi." },
      { step: 6, titleEn: "Judgment", titleBm: "Penghakiman", detailEn: "The court delivers a verdict of guilty or not guilty applying the beyond-reasonable-doubt standard.", detailBm: "Mahkamah menyampaikan keputusan bersalah atau tidak bersalah menerapkan standard melampaui keraguan munasabah." },
      { step: 7, titleEn: "Mitigation & sentence", titleBm: "Rayuan & hukuman", detailEn: "On conviction, the defence pleads in mitigation before the court passes sentence.", detailBm: "Atas sabitan, pembelaan membuat rayuan pengurangan sebelum mahkamah menjatuhkan hukuman." },
    ]),
    estimatedTimeline: "3–12 months depending on complexity and number of witnesses",
    requiredDocuments: "Charge sheet, investigation papers, witness statements, exhibits",
    courtFees: "As prescribed by the Syariah court fees rules",
    gates: "criminal",
    order: 60,
  },
  {
    titleEn: "Bail Application Process (Syariah Criminal)",
    titleBm: "Proses Permohonan Jaminan (Jenayah Syariah)",
    category: "Syariah Criminal Procedure",
    categoryBm: "Tatacara Jenayah Syariah",
    descriptionEn:
      "Procedure for applying for and obtaining bail for an accused person pending the disposal of a Syariah criminal charge.",
    descriptionBm:
      "Tatacara memohon dan mendapatkan jaminan bagi tertuduh sementara menunggu pelupusan pertuduhan jenayah Syariah.",
    stepsJson: JSON.stringify([
      { step: 1, titleEn: "Assess bailability", titleBm: "Nilai kebolehjaminan", detailEn: "Determine whether the offence is bailable, and identify suitable sureties.", detailBm: "Tentukan sama ada kesalahan boleh dijamin, dan kenal pasti penjamin yang sesuai." },
      { step: 2, titleEn: "File application", titleBm: "Failkan permohonan", detailEn: "Lodge the bail application with a supporting affidavit setting out grounds.", detailBm: "Failkan permohonan jaminan dengan afidavit sokongan yang menyatakan alasan." },
      { step: 3, titleEn: "Hearing", titleBm: "Pendengaran", detailEn: "The court hears submissions on flight risk, residence, and surety adequacy.", detailBm: "Mahkamah mendengar hujahan tentang risiko melarikan diri, kediaman, dan kecukupan penjamin." },
      { step: 4, titleEn: "Order & conditions", titleBm: "Perintah & syarat", detailEn: "If granted, the bail sum is set and conditions imposed; sureties execute the bond.", detailBm: "Jika diluluskan, jumlah jaminan ditetapkan dan syarat dikenakan; penjamin menandatangani bon." },
      { step: 5, titleEn: "Release", titleBm: "Pembebasan", detailEn: "Upon perfecting the bail bond, the accused is released pending trial.", detailBm: "Setelah menyempurnakan bon jaminan, tertuduh dibebaskan sementara menunggu perbicaraan." },
    ]),
    estimatedTimeline: "Same day to a few days",
    requiredDocuments: "Bail application, supporting affidavit, surety identification",
    courtFees: "As prescribed",
    gates: "criminal",
    order: 61,
  },
  {
    titleEn: "Syariah Criminal Appeal Process",
    titleBm: "Proses Rayuan Jenayah Syariah",
    category: "Syariah Criminal Procedure",
    categoryBm: "Tatacara Jenayah Syariah",
    descriptionEn:
      "Procedure for appealing a conviction and/or sentence from the Syariah Subordinate Court to the Syariah High Court and onward to the Syariah Appeal Court.",
    descriptionBm:
      "Tatacara merayu sabitan dan/atau hukuman dari Mahkamah Rendah Syariah ke Mahkamah Tinggi Syariah dan seterusnya ke Mahkamah Rayuan Syariah.",
    stepsJson: JSON.stringify([
      { step: 1, titleEn: "File notice of appeal", titleBm: "Failkan notis rayuan", detailEn: "Lodge the notice of appeal within the statutory time limit from the decision.", detailBm: "Failkan notis rayuan dalam had masa statutori dari keputusan." },
      { step: 2, titleEn: "Obtain grounds of judgment", titleBm: "Dapatkan alasan penghakiman", detailEn: "Request the written grounds of judgment and the certified record of appeal.", detailBm: "Mohon alasan penghakiman bertulis dan rekod rayuan yang diperakui." },
      { step: 3, titleEn: "File petition of appeal", titleBm: "Failkan petisyen rayuan", detailEn: "Set out the specific grounds of appeal against conviction and/or sentence.", detailBm: "Nyatakan alasan rayuan yang khusus terhadap sabitan dan/atau hukuman." },
      { step: 4, titleEn: "Hearing", titleBm: "Pendengaran", detailEn: "The appellate court hears submissions; it may affirm, reverse, or vary the decision.", detailBm: "Mahkamah rayuan mendengar hujahan; ia boleh mengesahkan, mengubah, atau membatalkan keputusan." },
      { step: 5, titleEn: "Decision", titleBm: "Keputusan", detailEn: "The appellate court delivers its decision; further appeal may lie to the Syariah Appeal Court.", detailBm: "Mahkamah rayuan menyampaikan keputusannya; rayuan lanjut boleh dibuat ke Mahkamah Rayuan Syariah." },
    ]),
    estimatedTimeline: "6–18 months",
    requiredDocuments: "Notice of appeal, grounds of judgment, record of appeal, petition of appeal",
    courtFees: "As prescribed",
    gates: "criminal",
    order: 62,
  },
];

// ============================================================
// CRIMINAL — Fatwas
// ============================================================
const criminalFatwas = [
  {
    titleEn: "Fatwa on Enforcement of Syariah Criminal Offences",
    titleBm: "Fatwa Mengenai Penguatkuasaan Kesalahan Jenayah Syariah",
    issuingBody: "National Fatwa Council (Majlis Fatwa Kebangsaan)",
    issuingBodyBm: "Majlis Fatwa Kebangsaan",
    gazetteRef: null,
    year: "2010",
    state: null,
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    summaryEn:
      "Guidance affirming that enforcement of Syariah criminal offences must observe due process, the dignity of the accused, and the Shariah principle of averting punishment in cases of doubt.",
    summaryBm:
      "Panduan yang menegaskan bahawa penguatkuasaan kesalahan jenayah Syariah mesti mematuhi tatacara wajar, maruah tertuduh, dan prinsip Syariah menolak hukuman dalam kes keraguan.",
    detailsEn:
      "The fatwa emphasises that the objective of Syariah criminal enforcement is reform and the protection of public morality, not humiliation. Officers must act within the law, evidence must meet the prescribed standard, and the maxim 'avert the hudud by doubts' (dar' al-hudud bi al-shubuhat) applies. Diversion and rehabilitation are encouraged for first-time and minor offenders.",
    detailsBm:
      "Fatwa ini menekankan bahawa objektif penguatkuasaan jenayah Syariah ialah pemulihan dan perlindungan akhlak awam, bukan penghinaan. Pegawai mesti bertindak dalam lingkungan undang-undang, keterangan mesti memenuhi standard yang ditetapkan, dan kaedah 'tolak hudud dengan keraguan' (dar' al-hudud bi al-syubuhat) terpakai. Pelencongan dan pemulihan digalakkan bagi pesalah kali pertama dan kesalahan kecil.",
    status: "Active",
    relatedLegislation: "Act 559; Act 560; state Syariah criminal enactments",
    gates: "criminal",
    order: 60,
  },
  {
    titleEn: "Fatwa on Repentance (Taubat) and Its Effect on Punishment",
    titleBm: "Fatwa Mengenai Taubat dan Kesannya Terhadap Hukuman",
    issuingBody: "State Fatwa Committee",
    issuingBodyBm: "Jawatankuasa Fatwa Negeri",
    gazetteRef: null,
    year: "2015",
    state: null,
    category: "Syariah Criminal",
    categoryBm: "Jenayah Syariah",
    summaryEn:
      "Clarifies the role of sincere repentance in mitigating, but not automatically extinguishing, ta'zir punishments for Syariah criminal offences.",
    summaryBm:
      "Menjelaskan peranan taubat yang ikhlas dalam mengurangkan, tetapi tidak secara automatik memadamkan, hukuman ta'zir bagi kesalahan jenayah Syariah.",
    detailsEn:
      "Sincere repentance (taubat nasuha) is highly meritorious and may be considered by the court as a mitigating factor in ta'zir offences. However, repentance does not by itself nullify a lawful charge; the court retains discretion to impose a reformative sentence. The fatwa encourages rehabilitation programmes alongside or in place of punitive measures where appropriate.",
    detailsBm:
      "Taubat yang ikhlas (taubat nasuha) sangat dituntut dan boleh dipertimbangkan oleh mahkamah sebagai faktor pengurangan dalam kesalahan ta'zir. Walau bagaimanapun, taubat dengan sendirinya tidak membatalkan pertuduhan yang sah; mahkamah mengekalkan budi bicara untuk mengenakan hukuman pemulihan. Fatwa ini menggalakkan program pemulihan bersama atau menggantikan langkah hukuman jika sesuai.",
    status: "Active",
    relatedLegislation: "Act 559; state Syariah criminal enactments",
    gates: "criminal",
    order: 61,
  },
];

// ============================================================
// CRIMINAL — Quranic Verses (justice, evidence, punishment)
// ============================================================
const criminalVerses = [
  {
    surahName: "An-Nur",
    surahNameBm: "An-Nur",
    surahNumber: 24,
    ayahRange: "4",
    textArabic:
      "وَالَّذِينَ يَرْمُونَ الْمُحْصَنَاتِ ثُمَّ لَمْ يَأْتُوا بِأَرْبَعَةِ شُهَدَاءَ فَاجْلِدُوهُمْ ثَمَانِينَ جَلْدَةً وَلَا تَقْبَلُوا لَهُمْ شَهَادَةً أَبَدًا",
    translationEn:
      "And those who accuse chaste women and then do not produce four witnesses — lash them with eighty lashes and do not accept their testimony ever after.",
    translationBm:
      "Dan orang-orang yang menuduh perempuan baik-baik (dengan zina) kemudian mereka tidak membawa empat orang saksi, maka sebatlah mereka lapan puluh sebatan, dan janganlah kamu menerima persaksian mereka selama-lamanya.",
    category: "Syariah Criminal — Qazaf",
    categoryBm: "Jenayah Syariah — Qazaf",
    relevanceEn:
      "The foundational basis for the offence of qazaf (false accusation of zina) and the four-witness evidentiary standard that protects reputation.",
    relevanceBm:
      "Asas utama bagi kesalahan qazaf (tuduhan palsu zina) dan standard keterangan empat saksi yang melindungi maruah.",
    relatedLegislation: "Act 559 s.24 (qazaf)",
    gates: "criminal",
    order: 60,
  },
  {
    surahName: "Al-Ma'idah",
    surahNameBm: "Al-Ma'idah",
    surahNumber: 5,
    ayahRange: "8",
    textArabic:
      "يَا أَيُّهَا الَّذِينَ آمَنُوا كُونُوا قَوَّامِينَ لِلَّهِ شُهَدَاءَ بِالْقِسْطِ وَلَا يَجْرِمَنَّكُمْ شَنَآنُ قَوْمٍ عَلَىٰ أَلَّا تَعْدِلُوا اعْدِلُوا هُوَ أَقْرَبُ لِلتَّقْوَىٰ",
    translationEn:
      "O you who believe, be steadfast for Allah, witnesses in justice, and do not let the hatred of a people prevent you from being just. Be just; that is nearer to righteousness.",
    translationBm:
      "Wahai orang-orang yang beriman, hendaklah kamu menjadi orang yang sentiasa menegakkan keadilan kerana Allah, lagi menjadi saksi dengan adil; dan jangan sekali-kali kebencian kamu terhadap sesuatu kaum mendorong kamu berlaku tidak adil. Berlaku adillah, kerana ia lebih hampir kepada takwa.",
    category: "Syariah Criminal — Justice",
    categoryBm: "Jenayah Syariah — Keadilan",
    relevanceEn:
      "Commands absolute impartiality of prosecutors, judges, and witnesses even towards adversaries — a cornerstone of fair Syariah criminal process.",
    relevanceBm:
      "Memerintahkan ketidakberatsebelahan mutlak pendakwa, hakim, dan saksi walaupun terhadap musuh — tunjang proses jenayah Syariah yang adil.",
    relatedLegislation: "Act 560 (Syariah Criminal Procedure)",
    gates: "criminal",
    order: 61,
  },
  {
    surahName: "An-Nisa",
    surahNameBm: "An-Nisa",
    surahNumber: 4,
    ayahRange: "135",
    textArabic:
      "يَا أَيُّهَا الَّذِينَ آمَنُوا كُونُوا قَوَّامِينَ بِالْقِسْطِ شُهَدَاءَ لِلَّهِ وَلَوْ عَلَىٰ أَنفُسِكُمْ أَوِ الْوَالِدَيْنِ وَالْأَقْرَبِينَ",
    translationEn:
      "O you who believe, be persistently standing firm in justice, witnesses for Allah, even if it be against yourselves or parents and relatives.",
    translationBm:
      "Wahai orang-orang yang beriman, hendaklah kamu menjadi orang yang sentiasa menegakkan keadilan, lagi menjadi saksi kerana Allah, walaupun terhadap diri kamu sendiri, atau ibu bapa dan kaum kerabat kamu.",
    category: "Syariah Criminal — Justice",
    categoryBm: "Jenayah Syariah — Keadilan",
    relevanceEn:
      "Demands that justice be upheld without favour, underpinning the integrity expected of all participants in criminal proceedings.",
    relevanceBm:
      "Menuntut keadilan ditegakkan tanpa pilih kasih, mendasari integriti yang diharapkan daripada semua pihak dalam prosiding jenayah.",
    relatedLegislation: "Act 560 (Syariah Criminal Procedure)",
    gates: "criminal",
    order: 62,
  },
  {
    surahName: "Al-Ma'idah",
    surahNameBm: "Al-Ma'idah",
    surahNumber: 5,
    ayahRange: "90",
    textArabic:
      "يَا أَيُّهَا الَّذِينَ آمَنُوا إِنَّمَا الْخَمْرُ وَالْمَيْسِرُ وَالْأَنصَابُ وَالْأَزْلَامُ رِجْسٌ مِّنْ عَمَلِ الشَّيْطَانِ فَاجْتَنِبُوهُ",
    translationEn:
      "O you who believe, intoxicants, gambling, idolatrous sacrifices, and divining arrows are but defilement from the work of Satan, so avoid it.",
    translationBm:
      "Wahai orang-orang yang beriman, sesungguhnya arak, judi, pemujaan berhala, dan mengundi nasib dengan batang-batang anak panah adalah kotor (keji) dari perbuatan syaitan; oleh itu hendaklah kamu menjauhinya.",
    category: "Syariah Criminal — Intoxicants",
    categoryBm: "Jenayah Syariah — Minuman Memabukkan",
    relevanceEn:
      "Scriptural basis for the prohibition of intoxicants underlying the Syariah criminal offence of drinking khamr.",
    relevanceBm:
      "Asas nas bagi larangan minuman memabukkan yang mendasari kesalahan jenayah Syariah meminum khamr.",
    relatedLegislation: "Act 559 s.26",
    gates: "criminal",
    order: 63,
  },
];

// ============================================================
// ADVISORY — Cause Papers (documentation instruments)
// ============================================================
const advisoryCausePapers = [
  {
    titleEn: "Hibah Deed (Surat Hibah)",
    titleBm: "Surat Hibah",
    category: "Advisory — Wealth Planning",
    categoryBm: "Khidmat Nasihat — Perancangan Harta",
    descriptionEn:
      "A deed of gift (hibah) by which a donor transfers ownership of property to a donee during the donor's lifetime, without consideration, taking effect upon delivery and acceptance.",
    descriptionBm:
      "Surat pemberian (hibah) di mana pemberi memindahkan pemilikan harta kepada penerima semasa hayat pemberi, tanpa balasan, berkuat kuasa setelah penyerahan dan penerimaan.",
    templateEn:
      "SURAT HIBAH\n\nSaya, [Nama Pemberi] (No. K/P: ______) (\"Pemberi\"), dengan ini menghibahkan kepada [Nama Penerima] (No. K/P: ______) (\"Penerima\") harta berikut secara percuma dan tanpa balasan:\n[Perihal harta — cth. hartanah, wang, saham].\n\n1. Pemberi mengisytiharkan ijab (tawaran) hibah ini dengan rela hati;\n2. Penerima menerima (qabul) hibah ini;\n3. Penyerahan milikan (qabd) telah/akan disempurnakan pada ______;\n4. Hibah ini muktamad dan tidak boleh ditarik balik kecuali hibah ibu/bapa kepada anak mengikut hukum syarak.\n\nSaksi 1: ____________   Pemberi: ____________\nSaksi 2: ____________   Penerima: ____________\nTarikh: ____________",
    templateBm:
      "SURAT HIBAH\n\nSaya, [Nama Pemberi] (No. K/P: ______) (\"Pemberi\"), dengan ini menghibahkan kepada [Nama Penerima] (No. K/P: ______) (\"Penerima\") harta berikut secara percuma dan tanpa balasan:\n[Perihal harta — cth. hartanah, wang, saham].\n\n1. Pemberi mengisytiharkan ijab (tawaran) hibah ini dengan rela hati;\n2. Penerima menerima (qabul) hibah ini;\n3. Penyerahan milikan (qabd) telah/akan disempurnakan pada ______;\n4. Hibah ini muktamad dan tidak boleh ditarik balik kecuali hibah ibu/bapa kepada anak mengikut hukum syarak.\n\nSaksi 1: ____________   Pemberi: ____________\nSaksi 2: ____________   Penerima: ____________\nTarikh: ____________",
    formNumber: null,
    requiredFields: "Donor, donee, property description, declaration of offer & acceptance, delivery (qabd), witnesses",
    gates: "advisory",
    order: 60,
  },
  {
    titleEn: "Wasiat (Islamic Will) Deed",
    titleBm: "Surat Wasiat",
    category: "Advisory — Wealth Planning",
    categoryBm: "Khidmat Nasihat — Perancangan Harta",
    descriptionEn:
      "An Islamic will (wasiat) directing the disposal of up to one-third of the estate to non-heirs, taking effect upon the testator's death and subject to faraid for the remainder.",
    descriptionBm:
      "Wasiat Islam yang mengarahkan pelupusan sehingga satu pertiga harta pusaka kepada bukan waris, berkuat kuasa setelah kematian pewasiat dan tertakluk kepada faraid bagi baki.",
    templateEn:
      "SURAT WASIAT\n\nSaya, [Nama Pewasiat] (No. K/P: ______), dalam keadaan sihat akal dan dengan kerelaan sendiri, berwasiat seperti berikut:\n1. Saya melantik [Nama Wasi] sebagai wasi (executor) wasiat ini;\n2. Saya mewasiatkan tidak melebihi satu pertiga (1/3) daripada harta pusaka saya kepada [penerima bukan waris / badan amal];\n3. Baki harta pusaka hendaklah dibahagikan mengikut hukum faraid;\n4. Segala hutang, nafkah tertunggak, dan perbelanjaan pengebumian hendaklah diselesaikan terlebih dahulu.\n\nPewasiat: ____________\nSaksi 1: ____________   Saksi 2: ____________\nTarikh: ____________",
    templateBm:
      "SURAT WASIAT\n\nSaya, [Nama Pewasiat] (No. K/P: ______), dalam keadaan sihat akal dan dengan kerelaan sendiri, berwasiat seperti berikut:\n1. Saya melantik [Nama Wasi] sebagai wasi (executor) wasiat ini;\n2. Saya mewasiatkan tidak melebihi satu pertiga (1/3) daripada harta pusaka saya kepada [penerima bukan waris / badan amal];\n3. Baki harta pusaka hendaklah dibahagikan mengikut hukum faraid;\n4. Segala hutang, nafkah tertunggak, dan perbelanjaan pengebumian hendaklah diselesaikan terlebih dahulu.\n\nPewasiat: ____________\nSaksi 1: ____________   Saksi 2: ____________\nTarikh: ____________",
    formNumber: null,
    requiredFields: "Testator, executor (wasi), bequest (max 1/3), beneficiaries, witnesses, debts clause",
    gates: "advisory",
    order: 61,
  },
  {
    titleEn: "Wakaf Declaration (Surat Ikrar Wakaf)",
    titleBm: "Surat Ikrar Wakaf",
    category: "Advisory — Wealth Planning",
    categoryBm: "Khidmat Nasihat — Perancangan Harta",
    descriptionEn:
      "A declaration dedicating property as a perpetual Islamic endowment (wakaf), the corpus held inalienably with its benefit applied to specified charitable or religious purposes.",
    descriptionBm:
      "Pengisytiharan mewakafkan harta sebagai endowmen Islam kekal (wakaf), di mana modal dipegang tanpa boleh dipindah milik dengan manfaatnya digunakan untuk tujuan amal atau keagamaan yang ditetapkan.",
    templateEn:
      "SURAT IKRAR WAKAF\n\nSaya, [Nama Pewakaf] (No. K/P: ______), dengan rela hati mewakafkan harta berikut: [perihal harta].\n1. Jenis wakaf: [wakaf am / wakaf khas];\n2. Tujuan/penerima manfaat: [cth. masjid, sekolah agama, anak yatim];\n3. Pentadbir (nazir): Majlis Agama Islam Negeri ______;\n4. Harta yang diwakafkan adalah kekal, tidak boleh dijual, dihibah, atau diwarisi.\n\nPewakaf: ____________\nSaksi 1: ____________   Saksi 2: ____________\nTarikh: ____________",
    templateBm:
      "SURAT IKRAR WAKAF\n\nSaya, [Nama Pewakaf] (No. K/P: ______), dengan rela hati mewakafkan harta berikut: [perihal harta].\n1. Jenis wakaf: [wakaf am / wakaf khas];\n2. Tujuan/penerima manfaat: [cth. masjid, sekolah agama, anak yatim];\n3. Pentadbir (nazir): Majlis Agama Islam Negeri ______;\n4. Harta yang diwakafkan adalah kekal, tidak boleh dijual, dihibah, atau diwarisi.\n\nPewakaf: ____________\nSaksi 1: ____________   Saksi 2: ____________\nTarikh: ____________",
    formNumber: null,
    requiredFields: "Settlor (pewakaf), property, type of wakaf, beneficiaries, administrator (nazir), witnesses",
    gates: "advisory",
    order: 62,
  },
  {
    titleEn: "Legal Opinion Letter (Surat Pendapat Guaman)",
    titleBm: "Surat Pendapat Guaman",
    category: "Advisory — Consultancy",
    categoryBm: "Khidmat Nasihat — Perundingan",
    descriptionEn:
      "A formal written opinion advising a client on a Shariah legal question, setting out the facts, issues, applicable law, analysis, and recommendation.",
    descriptionBm:
      "Pendapat bertulis rasmi yang menasihati klien mengenai persoalan undang-undang Syariah, menyatakan fakta, isu, undang-undang terpakai, analisis, dan cadangan.",
    templateEn:
      "SURAT PENDAPAT GUAMAN\n\nKepada: [Nama Klien]\nDaripada: [Nama Peguam Syarie]\nTarikh: ______\nPerkara: [Tajuk pendapat]\n\n1. LATAR BELAKANG FAKTA\n[Ringkasan fakta yang diberikan oleh klien.]\n\n2. ISU UNDANG-UNDANG\n[Senaraikan persoalan undang-undang yang ditimbulkan.]\n\n3. UNDANG-UNDANG TERPAKAI\n[Nyatakan enakmen, peruntukan, fatwa, dan nas yang berkaitan.]\n\n4. ANALISIS\n[Aplikasi undang-undang kepada fakta.]\n\n5. PENDAPAT & CADANGAN\n[Kesimpulan dan langkah yang disyorkan.]\n\nTandatangan Peguam Syarie: ____________",
    templateBm:
      "SURAT PENDAPAT GUAMAN\n\nKepada: [Nama Klien]\nDaripada: [Nama Peguam Syarie]\nTarikh: ______\nPerkara: [Tajuk pendapat]\n\n1. LATAR BELAKANG FAKTA\n[Ringkasan fakta yang diberikan oleh klien.]\n\n2. ISU UNDANG-UNDANG\n[Senaraikan persoalan undang-undang yang ditimbulkan.]\n\n3. UNDANG-UNDANG TERPAKAI\n[Nyatakan enakmen, peruntukan, fatwa, dan nas yang berkaitan.]\n\n4. ANALISIS\n[Aplikasi undang-undang kepada fakta.]\n\n5. PENDAPAT & CADANGAN\n[Kesimpulan dan langkah yang disyorkan.]\n\nTandatangan Peguam Syarie: ____________",
    formNumber: null,
    requiredFields: "Client, facts, legal issues, applicable law, analysis, opinion & recommendation",
    gates: "advisory",
    order: 63,
  },
];

// ============================================================
// ADVISORY — Procedural Workflows
// ============================================================
const advisoryWorkflows = [
  {
    titleEn: "Estate Distribution (Faraid) Advisory Process",
    titleBm: "Proses Khidmat Nasihat Pembahagian Pusaka (Faraid)",
    category: "Advisory — Inheritance",
    categoryBm: "Khidmat Nasihat — Pusaka",
    descriptionEn:
      "The advisory process for guiding a family through the determination and distribution of a deceased Muslim's estate according to faraid.",
    descriptionBm:
      "Proses khidmat nasihat untuk membimbing keluarga melalui penentuan dan pembahagian harta pusaka si mati Muslim mengikut faraid.",
    stepsJson: JSON.stringify([
      { step: 1, titleEn: "Identify heirs", titleBm: "Kenal pasti waris", detailEn: "Establish the surviving heirs and their relationship to the deceased.", detailBm: "Tetapkan waris yang masih hidup dan hubungan mereka dengan si mati." },
      { step: 2, titleEn: "Inventory the estate", titleBm: "Senaraikan harta pusaka", detailEn: "List all assets and liabilities; settle debts, funeral costs, and any valid wasiat (max 1/3).", detailBm: "Senaraikan semua aset dan liabiliti; selesaikan hutang, kos pengebumian, dan apa-apa wasiat sah (maksimum 1/3)." },
      { step: 3, titleEn: "Compute faraid shares", titleBm: "Kira bahagian faraid", detailEn: "Calculate each heir's fixed and residuary share using the faraid rules.", detailBm: "Kira bahagian tetap dan baki setiap waris menggunakan kaedah faraid." },
      { step: 4, titleEn: "Obtain faraid certificate", titleBm: "Dapatkan sijil faraid", detailEn: "Apply to the Syariah court for a faraid certificate confirming the shares.", detailBm: "Mohon kepada mahkamah Syariah untuk sijil faraid yang mengesahkan bahagian." },
      { step: 5, titleEn: "Distribute", titleBm: "Agihkan", detailEn: "Distribute the estate per the certificate, via the relevant land/asset authorities.", detailBm: "Agihkan harta pusaka mengikut sijil, melalui pihak berkuasa tanah/aset yang berkaitan." },
    ]),
    estimatedTimeline: "2–6 months",
    requiredDocuments: "Death certificate, heir identification, asset documents, debt records, any wasiat",
    courtFees: "As prescribed for faraid certificate",
    gates: "advisory",
    order: 60,
  },
  {
    titleEn: "Hibah Documentation & Implementation Process",
    titleBm: "Proses Dokumentasi & Pelaksanaan Hibah",
    category: "Advisory — Wealth Planning",
    categoryBm: "Khidmat Nasihat — Perancangan Harta",
    descriptionEn:
      "The process for validly creating and perfecting a hibah so that ownership transfers effectively during the donor's lifetime.",
    descriptionBm:
      "Proses untuk mewujudkan dan menyempurnakan hibah secara sah supaya pemilikan berpindah dengan berkesan semasa hayat pemberi.",
    stepsJson: JSON.stringify([
      { step: 1, titleEn: "Confirm capacity & intent", titleBm: "Sahkan keupayaan & niat", detailEn: "Verify the donor's legal capacity and genuine, uncoerced intention to gift.", detailBm: "Sahkan keupayaan undang-undang pemberi dan niat sebenar tanpa paksaan untuk menghibah." },
      { step: 2, titleEn: "Identify property", titleBm: "Kenal pasti harta", detailEn: "Ascertain that the property is owned by the donor and clearly identifiable.", detailBm: "Pastikan harta dimiliki oleh pemberi dan dapat dikenal pasti dengan jelas." },
      { step: 3, titleEn: "Execute offer & acceptance", titleBm: "Laksanakan ijab & qabul", detailEn: "Document the ijab (offer) and qabul (acceptance) in a hibah deed before witnesses.", detailBm: "Dokumenkan ijab (tawaran) dan qabul (penerimaan) dalam surat hibah di hadapan saksi." },
      { step: 4, titleEn: "Effect delivery (qabd)", titleBm: "Laksanakan penyerahan (qabd)", detailEn: "Transfer possession/control to the donee, e.g., register the land transfer.", detailBm: "Pindahkan milikan/kawalan kepada penerima, cth. daftarkan pindah milik tanah." },
      { step: 5, titleEn: "Retain evidence", titleBm: "Simpan bukti", detailEn: "Keep the executed deed and proof of delivery to resist later inheritance disputes.", detailBm: "Simpan surat yang disempurnakan dan bukti penyerahan untuk menangkis pertikaian pusaka kemudian." },
    ]),
    estimatedTimeline: "2–8 weeks",
    requiredDocuments: "Hibah deed, property ownership documents, witnesses, transfer/registration forms",
    courtFees: "Registration fees as applicable",
    gates: "advisory",
    order: 61,
  },
  {
    titleEn: "Wasiat Preparation & Safekeeping Process",
    titleBm: "Proses Penyediaan & Penyimpanan Wasiat",
    category: "Advisory — Wealth Planning",
    categoryBm: "Khidmat Nasihat — Perancangan Harta",
    descriptionEn:
      "The advisory process for drafting a Shariah-compliant wasiat, ensuring it stays within the one-third limit and is properly witnessed and stored.",
    descriptionBm:
      "Proses khidmat nasihat untuk menyediakan wasiat yang patuh Syariah, memastikan ia kekal dalam had satu pertiga dan disaksikan serta disimpan dengan betul.",
    stepsJson: JSON.stringify([
      { step: 1, titleEn: "Take instructions", titleBm: "Ambil arahan", detailEn: "Understand the testator's wishes, assets, and intended non-heir beneficiaries.", detailBm: "Fahami hasrat pewasiat, aset, dan penerima bukan waris yang dihasratkan." },
      { step: 2, titleEn: "Apply the one-third rule", titleBm: "Terapkan kaedah satu pertiga", detailEn: "Ensure bequests to non-heirs do not exceed one-third without heir consent.", detailBm: "Pastikan wasiat kepada bukan waris tidak melebihi satu pertiga tanpa persetujuan waris." },
      { step: 3, titleEn: "Appoint executor (wasi)", titleBm: "Lantik wasi", detailEn: "Name a trustworthy and capable executor to administer the wasiat.", detailBm: "Namakan wasi yang amanah dan berkemampuan untuk mentadbir wasiat." },
      { step: 4, titleEn: "Execute & witness", titleBm: "Laksana & saksikan", detailEn: "Have the testator sign before competent witnesses as required.", detailBm: "Pastikan pewasiat menandatangani di hadapan saksi yang berkelayakan seperti yang diperlukan." },
      { step: 5, titleEn: "Safekeeping", titleBm: "Penyimpanan", detailEn: "Store the wasiat securely (e.g., with a wasiat custodian) and inform the executor.", detailBm: "Simpan wasiat dengan selamat (cth. dengan kustodian wasiat) dan maklumkan wasi." },
    ]),
    estimatedTimeline: "1–4 weeks",
    requiredDocuments: "Asset list, beneficiary details, executor consent, witness identification",
    courtFees: "Custodian/registration fees as applicable",
    gates: "advisory",
    order: 62,
  },
];

async function seed() {
  console.log("Seeding Criminal & Advisory gate content...");

  // Provisions
  {
    const have = await existingTitles("provisions");
    const rows = criminalProvisions.filter((r) => !have.has(r.titleEn));
    if (rows.length) await db.insert(provisionsTable).values(rows);
    console.log(`Provisions: inserted ${rows.length}, skipped ${criminalProvisions.length - rows.length}`);
  }

  // Cause papers (criminal + advisory)
  {
    const have = await existingTitles("cause_papers");
    const all = [...criminalCausePapers, ...advisoryCausePapers];
    const rows = all.filter((r) => !have.has(r.titleEn));
    if (rows.length) await db.insert(causePapersTable).values(rows);
    console.log(`Cause papers: inserted ${rows.length}, skipped ${all.length - rows.length}`);
  }

  // Procedural workflows (criminal + advisory)
  {
    const have = await existingTitles("procedural_workflows");
    const all = [...criminalWorkflows, ...advisoryWorkflows];
    const rows = all.filter((r) => !have.has(r.titleEn));
    if (rows.length) await db.insert(proceduralWorkflowsTable).values(rows);
    console.log(`Procedural workflows: inserted ${rows.length}, skipped ${all.length - rows.length}`);
  }

  // Fatwas
  {
    const have = await existingTitles("gazetted_fatwas");
    const rows = criminalFatwas.filter((r) => !have.has(r.titleEn));
    if (rows.length) await db.insert(fatwaTable).values(rows);
    console.log(`Fatwas: inserted ${rows.length}, skipped ${criminalFatwas.length - rows.length}`);
  }

  // Quranic verses
  {
    const have = await existingVerseKeys();
    const rows = criminalVerses.filter(
      (r) => !have.has(`${r.surahNumber}:${r.ayahRange}`),
    );
    if (rows.length) await db.insert(quranicVersesTable).values(rows);
    console.log(`Quranic verses: inserted ${rows.length}, skipped ${criminalVerses.length - rows.length}`);
  }

  console.log("Done.");
}

seed()
  .then(async () => {
    await pool.end();
    process.exit(0);
  })
  .catch(async (err) => {
    console.error(err);
    await pool.end();
    process.exit(1);
  });
